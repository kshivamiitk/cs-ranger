# Portfolio Project Reporting

> Your model's accuracy isn't what gets you hired — your ability to *explain* the project is. A portfolio report turns a messy notebook into a one-page story a recruiter trusts in two minutes and a peer can reproduce in ten.

## What is this?

Portfolio project reporting is **writing up an ML project so it demonstrates skill, not just results.** It's the README and one-page report a reader sees *before* (and often *instead of*) any of your code. The deliverable isn't more modeling — it's a clear, honest narrative that answers, without anyone running anything:

- **Problem** — what you predict, for whom, and why it matters.
- **Data** — source, size, the target, and any imbalance.
- **Method** — preprocessing, the baseline, the final model, the validation scheme.
- **Results** — an honest metric table that includes a *baseline row*, on a *held-out* test set.
- **Error analysis** — where the model fails and why.
- **Limitations** — what it can't do, and that you checked for leakage.
- **Reproduce** — exact commands, fixed `random_state`, pinned versions.

The metric for *this* task isn't accuracy — it's **comprehension speed and trust.** A great report makes a stranger understand and believe your project fast.

## Why do we need it?

Recruiters and senior engineers spend **under two minutes** per portfolio project. A brilliant model buried in a 40-cell notebook with no narrative reads as "can build models, can't communicate" — and communication is most of the job. The report is where you prove *judgment*: that you chose the right metric for the problem, beat a sensible baseline, know your model's weaknesses, and can be reproduced.

There's a career-long payoff too. This exact document is the **model card / handoff doc** in a real job — the thing a teammate reads before trusting your model in production. Practicing it on a portfolio project is directly transferable. A filled-in results table with a baseline, an honest error-analysis paragraph, and copy-pasteable reproduce steps separate a real engineer from someone who pasted a tutorial.

## Where it's used in real ML

- **Job portfolios** — the README is the front door of your repo; most reviewers read it and never open a `.py` file.
- **Model cards** — companies ship a standard document with each model describing intended use, data, metrics, and limitations (Google, Hugging Face, and many teams require them).
- **Internal handoffs** — when one engineer's model moves to another team or to production, the report is what makes it trustworthy and maintainable.
- **Kaggle / competition write-ups** — the top solutions are remembered for their clear explanations, not just their leaderboard score.
- **Research and experiment logs** — a results table with a baseline and an honest caveat is the unit of credible ML communication everywhere.

## What breaks if you ignore it

- **No baseline → meaningless numbers.** "F1 = 0.78" tells a reader nothing on its own. Next to "vs 0.42 majority-class baseline," it proves the work earned its complexity. Without the baseline, a reviewer assumes the worst.
- **Reporting training-set scores → instant distrust.** Numbers from data the model fit on are inflated. A sharp reviewer asks "is that the test set?" — if you can't say yes clearly, your whole report is suspect.
- **Dumping the notebook as the report.** Forty cells of trial-and-error hide the story under noise. The reader gives up; your good work goes unseen.
- **Cosmetic dishonesty.** Rounding 0.71 up to 0.75, headlining your luckiest seed, or quietly omitting the metric that looks bad. It reads as either careless or dishonest — both are disqualifying. Slightly-modest, honest numbers are *more* credible than suspicious perfection.
- **No reproduce steps.** If a reviewer can't rerun it, your numbers are just claims. Missing `random_state` or unpinned versions means even *you* can't reproduce them next year.

## Mental model

Think of your report as an **inverted pyramid**, the structure journalists use: the most important thing first, detail narrowing below. A reader who stops after 30 seconds should already have the headline; a reader who continues gets proof, then reproducibility.

```
   ┌──────────────────────────────────────────────┐  ← read in 30 seconds
   │  PROBLEM + METRIC + HEADLINE RESULT           │     (above the fold)
   │  "Predict churners; F1 0.78 vs 0.42 baseline" │
   ├──────────────────────────────────────────────┤  ← read in 2 minutes
   │  DATA  ·  METHOD  ·  RESULTS TABLE (w/ baseline)│
   ├──────────────────────────────────────────────┤  ← read in 10 minutes
   │  ERROR ANALYSIS  ·  LIMITATIONS  ·  REPRODUCE   │
   └──────────────────────────────────────────────┘
```

A skim should never have to dig to find "what problem, how well, how to run." Lead with the answer; let the curious drill down. Anything that doesn't earn its place — dead-end experiments, raw logs, charts that changed no decision — gets cut.

## Example 1 — Tiny toy example

The smallest useful artifact: a **5-line result summary** you can fill in for any project. It forces the baseline, the held-out caveat, the honest number, and one weakness — all in a few sentences.

```
Problem : Predict which customers will churn, to target a limited retention budget.
Metric  : F1 on the churn class (accuracy lies on imbalanced churn).
Result  : F1 0.78 on a held-out test set (25%, stratified, random_state=42),
          vs 0.42 majority-class baseline.
Weakness: Misses churners on month-to-month plans with high charges (see error analysis).
Run     : pip install -r requirements.txt && python train.py
```

Filled in honestly, those five lines already pass the two-minute test — problem, metric, baseline-anchored result, a real weakness, and how to run it. Everything longer is elaboration on this skeleton.

## Example 2 — Practical ML example

A real churn project's report core: a **results table** plus the **narrative** that turns it into a sentence.

| Model                     | Precision (churn) | Recall (churn) | F1 (churn) |
|---------------------------|------------------:|---------------:|-----------:|
| Baseline (majority class) |              0.00 |           0.00 |       0.00 |
| Logistic Regression       |              0.61 |           0.55 |       0.58 |
| Random Forest (tuned)     |              0.68 |           0.74 |       0.71 |

Three things make this table trustworthy: a **baseline row** (here it scores 0 on the churn class — it never predicts churn, which is exactly why accuracy would've been misleading), **held-out** numbers (named: "25% stratified test split, `random_state=42`"), and the metric chosen *before* modeling because a missed churner is the costly error.

Now turn it into a narrative — the results section in one honest paragraph: *"On a held-out test set (25%, stratified, `random_state=42`), the tuned Random Forest reached F1 0.71 on the churn class versus a 0.00 majority-class baseline, lifting recall to 0.74 — it catches about three in four churners. The simpler Logistic Regression (F1 0.58) is close enough that I'd ship it if interpretability mattered more than the last few points."* That's a results section a reviewer believes: a number, anchored to a baseline, on stated test data, with an honest trade-off.

## Python code example

```python
# A tiny script that PRINTS the results table you paste into your report.
# The honesty (baseline row + held-out test scores) is built into the code.
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.metrics import precision_score, recall_score, f1_score

# Stand-in dataset so this runs offline; swap in your project's data.
X, y = load_breast_cancer(return_X_y=True, as_frame=True)
print("data shape:", X.shape, "| positive rate:", round(y.mean(), 3))

# Held-out test split, fixed seed -> reproducible numbers you can defend.
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y)

# BASELINE FIRST: predict the majority class. This is the bar every model must clear.
baseline = DummyClassifier(strategy="most_frequent").fit(X_tr, y_tr)
# Final model: a leak-proof pipeline (scaler fit on train only).
model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=5000)).fit(X_tr, y_tr)

def report_row(name, fitted):
    pred = fitted.predict(X_te)            # scored on the HELD-OUT test set
    return {"model": name,
            "precision": round(precision_score(y_te, pred, zero_division=0), 2),
            "recall":    round(recall_score(y_te, pred, zero_division=0), 2),
            "f1":        round(f1_score(y_te, pred, zero_division=0), 2)}

table = pd.DataFrame([
    report_row("Baseline (majority class)", baseline),
    report_row("Logistic regression", model),
])
print(table.to_string(index=False))   # copy this straight into your report's results table

# --- Turn the table into the one honest sentence the report needs ---
b, m = table.iloc[0], table.iloc[1]
print(f"\nReport sentence:\n  On a held-out test set (25%, stratified, random_state=42), "
      f"the model reached F1 {m.f1} vs a {b.f1} majority-class baseline; "
      f"recall {m.recall} means it rarely misses positives.")

# Expected output (numbers approximate):
# data shape: (569, 30) | positive rate: 0.627
#                      model  precision  recall   f1
#  Baseline (majority class)       0.63    1.00 0.77
#        Logistic regression       0.97    0.99 0.98
#
# Report sentence:
#   On a held-out test set (25%, stratified, random_state=42), the model
#   reached F1 0.98 vs a 0.77 majority-class baseline; recall 0.99 means it
#   rarely misses positives.
```

The script's job is to make honesty automatic: it computes the baseline, scores on held-out data, and even drafts the sentence — so your report can't accidentally cite a training-set number.

## Common mistakes

- **No baseline row.** A lone metric gives the reader nothing to judge against. Add the baseline — it's two lines of `DummyClassifier` and it's what makes your number mean something.
- **Reporting training-set scores as if they were test scores.** Inflated and untrustworthy. State explicitly that results are on a held-out test set and name the split/CV scheme.
- **Pasting the whole notebook as the report.** The story drowns in trial-and-error. Write a one-page report with the seven sections; *link* the notebook for anyone who wants the detail.
- **Skipping error analysis and limitations.** Stating where the model fails and that you checked for leakage signals maturity, not weakness. Omitting it reads as "didn't look."
- **Vague or missing reproduce steps.** "Run the notebook" isn't reproducible. Give the install command, the single run command, the fixed `random_state`, and pinned versions — or your numbers are just claims.

## Before you continue
- [ ] I can name the seven report sections in order (problem, data, method, results, error analysis, limitations, reproduce).
- [ ] I always include a baseline row and explain why a metric is meaningless without it.
- [ ] I report held-out test scores and name the split, never training-set scores.
- [ ] I can turn a results table into one honest, baseline-anchored sentence.
- [ ] I can write copy-pasteable reproduce steps with a fixed `random_state` and pinned versions.

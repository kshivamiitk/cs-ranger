# Capstone — Problem Framing and Dataset Assumptions

> The hardest part of a real ML project isn't the model — it's deciding *what question you're answering* and *how you'll know if you succeeded*, and you must do that **before** you fit anything.

## What you'll learn
- How to turn a vague business worry ("we're losing customers") into a crisp, modellable question.
- Why **recall / F1** is the right success metric for churn — and why **accuracy** would quietly lie to you.
- How to state your dataset assumptions and limitations *up front* so your conclusions are honest.
- The exact inline dataset you'll clean, model, and evaluate across the next four lessons.

## The business question

A subscription telecom company is bleeding customers. Every customer who leaves ("churns") is lost monthly revenue plus the cost of having acquired them. The company *can* intervene — a discount, a call from retention, a contract upgrade offer — but interventions cost money, so they can't blanket every customer.

That gives us a concrete, modellable question:

> **Given what we know about a customer today, how likely are they to churn — so we can target retention offers at the ones most at risk?**

- **Unit of analysis:** one customer.
- **Target (label):** `churn` — `1` if the customer left, `0` if they stayed. This is a **binary classification** problem.
- **Why it matters:** the model's output ranks customers by risk; the business spends its limited retention budget on the high-risk ones. A false negative (we predicted "stay" but they churned) is an *escaped* customer we never tried to save — usually the most expensive mistake.

## Choosing the success metric BEFORE modeling

Pick your metric now, in writing, so you can't move the goalposts later to flatter a weak model.

Churn is **imbalanced**: most customers stay. Suppose 73% stay and 27% churn. A do-nothing model that predicts "stay" for *everyone* scores **73% accuracy** — and catches **zero** churners. Accuracy rewards that uselessness. So accuracy is the wrong metric here.

What we actually care about is catching the customers who will leave:

- **Recall** (of the churn class) = of all customers who really churned, what fraction did we flag? High recall = few escaped customers. This maps directly to the business goal.
- **Precision** = of the customers we flagged as churners, what fraction really churned? Low precision = we waste retention budget on people who'd have stayed anyway.
- **F1** = the harmonic mean of precision and recall — a single number that punishes ignoring either one.

For this capstone we commit to **F1 on the churn (positive) class as the primary metric**, and we'll watch **recall** closely because missing a churner is costlier than a wasted offer. We pick this *before* seeing any model so the comparison in later lessons is honest.

## Dataset and its assumptions

Below is the dataset we'll use for the rest of the capstone. It's small (~35 rows) and **intentionally messy** — missing values, a duplicate row, mixed types — exactly like real data. Define it once here; lessons 03–06 reuse this same block.

```python
import io
import pandas as pd

CHURN_CSV = """customer_id,tenure_months,monthly_charges,contract_type,has_support,churn
C001,2,85.5,Month-to-month,no,1
C002,34,56.95,One year,yes,0
C003,1,75.0,Month-to-month,,1
C004,45,42.30,Two year,yes,0
C005,8,99.10,Month-to-month,no,1
C006,60,29.85,Two year,yes,0
C007,3,80.0,Month-to-month,no,1
C008,22,70.45,One year,yes,0
C009,5,89.90,Month-to-month,,1
C010,48,35.50,Two year,yes,0
C011,2,95.25,Month-to-month,no,1
C012,18,65.00,One year,no,0
C013,1,78.80,Month-to-month,,1
C014,55,40.15,Two year,yes,0
C015,9,92.00,Month-to-month,no,1
C016,30,58.40,One year,yes,0
C017,4,84.60,Month-to-month,no,1
C018,40,45.90,Two year,yes,0
C019,6,88.25,Month-to-month,,1
C020,25,62.10,One year,yes,0
C021,2,97.50,Month-to-month,no,1
C022,52,38.70,Two year,yes,0
C023,7,90.30,Month-to-month,no,1
C024,15,68.00,One year,no,0
C025,3,82.40,Month-to-month,,1
C026,58,33.25,Two year,yes,0
C027,10,93.75,Month-to-month,no,1
C028,28,60.50,One year,yes,0
C029,1,76.20,Month-to-month,no,1
C030,50,41.00,Two year,yes,0
C031,12,71.90,One year,yes,0
C032,4,86.80,Month-to-month,,1
C033,38,47.55,Two year,yes,0
C034,20,64.30,One year,no,0
C035,5,91.40,Month-to-month,no,1
C035,5,91.40,Month-to-month,no,1
"""

def load_churn():
    """Load the raw, messy capstone dataset. Reused in lessons 03-06."""
    return pd.read_csv(io.StringIO(CHURN_CSV))

df = load_churn()
print(df.shape)            # (36, 6) -- note: 35 unique + 1 duplicate (C035)
print(df["churn"].value_counts(normalize=True).round(2))
print(df.head())
```

Expected output (approximate):

```
(36, 6)
churn
0    0.53
1    0.47
Name: proportion, dtype: float64
   customer_id  tenure_months  monthly_charges  contract_type has_support  churn
0        C001              2            85.50  Month-to-month          no      1
1        C002             34            56.95        One year         yes      0
2        C003              1            75.00  Month-to-month         NaN      1
3        C004             45            42.30        Two year         yes      0
4        C005              8            99.10  Month-to-month          no      1
```

A few things to register immediately: `has_support` has **blanks** (read as `NaN`), there's a **duplicate** row (`C035` appears twice), and the classes are roughly balanced *in this teaching sample* — the real dataset is more imbalanced, which is exactly why we chose F1/recall over accuracy.

**Assumptions and limitations — write these down:**

1. **Tiny sample.** 35 customers can't represent a real customer base; any model trained here will be high-variance. We're learning the *workflow*; conclusions are illustrative, not business-grade.
2. **Snapshot, not history.** Each row is a single moment. We assume the features (tenure, charges, contract) describe the customer at the time churn was measured — no time-series leakage from *after* they left.
3. **`churn` is correct and observed.** We assume the label is accurate. In reality, a customer who's "about to" churn but hasn't yet is labelled `0`, which adds noise.
4. **Features are pre-decision.** We only use information available *before* the churn event. (Including, say, "received a win-back call" would leak the outcome.)
5. **No fairness audit here.** A production churn model would need a bias review (are we under-serving a protected group?); that's out of scope for the capstone but flagged as next steps.

## This scales to the real dataset

This inline CSV is a faithful miniature of the public **Telco Customer Churn** dataset (a ~7,000-row CSV with the same spirit of columns: tenure, monthly charges, contract type, services, and a churn label). You can download it yourself (search "Telco Customer Churn dataset") and **swap `load_churn()` for `pd.read_csv("Telco-Customer-Churn.csv")`** — every cleaning, modeling, and evaluation step in lessons 03–06 works on it unchanged, just with more rows and more columns. Build the pipeline small, then point it at the real thing.

## Small exercise

Before touching code, write two sentences in a scratch file: (1) the business question in your own words, and (2) why a 73%-accuracy "always predict stay" model would be useless here. Then run the block above and confirm the duplicate `C035` row and the `NaN`s in `has_support` are present — you'll fix both next lesson.

## Before you continue
- [ ] I can state the target, the unit of analysis, and the business cost of a false negative.
- [ ] I can explain in one sentence why accuracy is misleading for churn and what we use instead.
- [ ] I have run `load_churn()` and seen the duplicate and missing values.
- [ ] I've written down at least three dataset assumptions/limitations.

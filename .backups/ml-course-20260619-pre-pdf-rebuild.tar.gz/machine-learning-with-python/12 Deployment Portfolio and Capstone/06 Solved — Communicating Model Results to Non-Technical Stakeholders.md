# Solved — Communicating Model Results to Non-Technical Stakeholders

> A VP does not care that your F1 is 0.77. They care how many customers you can save, how much it costs, and whether to fund the team — so your job is to translate metrics into money and a decision.

## Problem statement

You trained a churn model, evaluated it honestly on a held-out test set, and it works. Now you have ten minutes in a leadership meeting to answer three questions a non-technical executive actually has: *How many customers can this catch? What will it cost us to act on it? Is it worth funding?* You will not get to show a precision-recall curve. You get one slide, a one-page note, or a verbal headline.

The deliverable is **not another model and not a technical report** — it is a translation. Given the model's confusion matrix on the test set and a few agreed business assumptions (the value of a saved customer, how often a retention offer actually works, the cost of one outreach call), produce the **business-facing numbers** — how many customers get flagged, what fraction of real churners you catch (recall), the estimated dollar value of catching them, and how much outreach is wasted on false alarms (precision) — and print a **plain-language summary** an executive could read aloud. The "metric" for success is whether a non-technical decision-maker leaves the room knowing what to do.

## Why this problem matters

Most models that work technically never get deployed, and the usual cause is not the model — it is a failure to communicate. A data scientist who says "recall is 0.80" to a VP has said nothing actionable; a data scientist who says "we'll catch 8 of every 10 customers about to leave and net about $17k this quarter" has just gotten the project funded. This is the single highest-leverage skill in applied ML, and it is the one most courses skip. It is also where careers separate: the person who can stand in front of leadership and turn a confusion matrix into a decision is the person who gets to keep building models. The same skeleton is what you would put on a portfolio project's front page so a non-technical hiring manager understands the impact in fifteen seconds.

## Tiny dataset or sample data

The "data" is the model's **held-out test-set confusion matrix** plus a few **business assumptions** you agree with stakeholders (not with the data). Confusion matrix shape `(2, 2)`, layout `[[TN, FP], [FN, TP]]` with the positive class = "will churn."

| | predicted: stay | predicted: churn |
|------------------|----------------:|-----------------:|
| **actually stayed** | TN = 820 | FP = 60 |
| **actually churned** | FN = 45 | TP = 175 |

Total customers scored: `1100`. Business assumptions: a saved customer is worth `$400` in retained margin; a retention offer actually saves `30%` of the at-risk customers you reach; each outreach call costs `$15`. These three numbers come from finance and operations — your job is to plug them in, not invent them.

## Step-by-step reasoning

1. **Start from the confusion matrix, not the metrics.** Executives understand *counts of people* far better than ratios. Read the four cells as: 175 real leavers we caught (TP), 45 real leavers we missed (FN), 60 loyal customers we wrongly bothered (FP), 820 we correctly left alone (TN). Everything else is derived from these.
2. **Translate recall into "catch rate."** Recall = `TP / (TP + FN) = 175 / 220 = 0.80`. Say it as: *"We catch 8 of every 10 customers who are about to leave, in time to act."* Never say the word "recall" in the room without the plain-language version next to it.
3. **Translate precision into "wasted outreach."** Precision = `TP / (TP + FP) = 175 / 235 = 0.74`. The flip side is the number that worries an ops manager: `26%` of the calls go to people who were never leaving. Frame the cost honestly — false alarms are real money and real annoyance, not just a "bad metric."
4. **Convert caught customers into dollars.** Not every caught churner is saved — the offer only works `30%` of the time. So saved ≈ `175 × 0.30 ≈ 52` customers, worth `52 × $400 ≈ $21,000`. Subtract outreach spend (`235 calls × $15 ≈ $3,525`) to get a **net value** of about `$17,475`. This is the number that funds the project.
5. **Decide what to show and what to hide.** SHOW: the catch rate, the dollar net value, the wasted-call count, and the assumptions behind the money (so no one feels misled later). HIDE: ROC curves, log-loss, hyperparameters, "we used class weights," and the model architecture. They do not change the decision and they erode the audience's attention.
6. **End on one sentence anyone can repeat.** Leadership will paraphrase you to *their* boss. Hand them the sentence so it survives the relay: catch rate + customers kept + net dollars + cost. If they can repeat it accurately, you communicated.

## Python solution

```python
import numpy as np

# ----------------------------------------------------------------------
# You already trained & evaluated a churn model. These are the held-out
# test-set results, hardcoded as a confusion matrix so this runs offline.
# The job NOW is translation: turn these counts into money and decisions
# a non-technical executive can act on. No modeling happens here.
# ----------------------------------------------------------------------

# Confusion matrix from the held-out test set, layout [[TN, FP], [FN, TP]]:
#   row = actual, col = predicted ; positive class = "will churn".
#   TN = stayers correctly left alone   FP = stayers we wrongly flagged
#   FN = churners we MISSED             TP = churners we correctly caught
cm = np.array([[820,  60],
               [ 45, 175]])
TN, FP = cm[0]
FN, TP = cm[1]

# --- Business assumptions (agree these with the business, not the data team) ---
MARGIN_PER_SAVED = 400.0   # $ lifetime value retained if we save a churner
SAVE_RATE        = 0.30    # fraction of contacted churners the offer actually saves
OUTREACH_COST    = 15.0    # $ cost of one retention call/offer (incl. discount handling)

# --- Counts the business cares about ---
total_customers = int(cm.sum())
actual_churners = int(TP + FN)
flagged         = int(TP + FP)       # how many customers we'd actually contact
caught          = int(TP)            # real churners inside the flagged list
missed          = int(FN)            # real churners we never called
wasted_calls    = int(FP)            # calls to people who were never going to leave

# --- Core metrics, but named in plain language ---
recall    = TP / (TP + FN)           # % of real churners we caught
precision = TP / (TP + FP)           # % of our flagged list that were real churners

# --- Turn metrics into money ---
saved_customers = caught * SAVE_RATE
revenue_saved   = saved_customers * MARGIN_PER_SAVED
outreach_spend  = flagged * OUTREACH_COST
net_value       = revenue_saved - outreach_spend

print("=" * 64)
print("CHURN MODEL - RESULTS FOR LEADERSHIP (held-out test set)")
print("=" * 64)
print(f"We scored {total_customers} customers. The model flags the riskiest ones so the")
print("retention team can call them before they leave.\n")

print("WHO THE MODEL FLAGGED")
print(f"  - It flagged {flagged} of {total_customers} customers as 'likely to leave'.")
print(f"  - Of the {actual_churners} customers who really did leave, the model caught {caught}.")
print(f"  - It MISSED {missed} real leavers (they were not on the call list).\n")

print("HOW GOOD IS IT (in plain terms)")
print(f"  - Catch rate (recall):   {round(recall*100)}% of customers who leave are caught in time.")
print(f"  - List quality (precision): {round(precision*100)}% of the people we call were truly at risk;")
print(f"    the other {round((1-precision)*100)}% are 'false alarms' - wasted outreach.\n")

print("WHAT IT IS WORTH (this quarter, on these assumptions)")
print(f"  - Calling {flagged} flagged customers costs about ${outreach_spend:,.0f} in outreach.")
print(f"  - If we save {round(SAVE_RATE*100)}% of the {caught} real leavers we reach, that is "
      f"~{round(saved_customers)} customers kept,")
print(f"    worth about ${revenue_saved:,.0f} in retained revenue.")
print(f"  - NET ESTIMATED VALUE: ${net_value:,.0f}.")
print(f"  - {wasted_calls} calls ({round((1-precision)*100)}% of the list) go to people who were not leaving anyway.")
print("=" * 64)

print("\nONE-LINE SUMMARY (the headline you say out loud):")
print(f'  "The model catches {round(recall*10)} in 10 customers who are about to leave. If we')
print(f'   call the {flagged} it flags, we expect to keep ~{round(saved_customers)} of them and net about')
print(f'   ${net_value:,.0f} this quarter - for the price of ~{wasted_calls} wasted courtesy calls."')
```

## Expected output

```
================================================================
CHURN MODEL - RESULTS FOR LEADERSHIP (held-out test set)
================================================================
We scored 1100 customers. The model flags the riskiest ones so the
retention team can call them before they leave.

WHO THE MODEL FLAGGED
  - It flagged 235 of 1100 customers as 'likely to leave'.
  - Of the 220 customers who really did leave, the model caught 175.
  - It MISSED 45 real leavers (they were not on the call list).

HOW GOOD IS IT (in plain terms)
  - Catch rate (recall):   80% of customers who leave are caught in time.
  - List quality (precision): 74% of the people we call were truly at risk;
    the other 26% are 'false alarms' - wasted outreach.

WHAT IT IS WORTH (this quarter, on these assumptions)
  - Calling 235 flagged customers costs about $3,525 in outreach.
  - If we save 30% of the 175 real leavers we reach, that is ~52 customers kept,
    worth about $21,000 in retained revenue.
  - NET ESTIMATED VALUE: $17,475.
  - 60 calls (26% of the list) go to people who were not leaving anyway.
================================================================

ONE-LINE SUMMARY (the headline you say out loud):
  "The model catches 8 in 10 customers who are about to leave. If we
   call the 235 it flags, we expect to keep ~52 of them and net about
   $17,475 this quarter - for the price of ~60 wasted courtesy calls."
```

## Explanation of the output

The script never prints a raw metric without its business meaning, and that is the entire lesson:

- **"Flagged 235 of 1100" / "caught 175 of 220 leavers" / "missed 45."** These three counts are the confusion matrix retold as *people*. An executive can hold "we missed 45 leavers" in their head; they cannot do anything with "FN = 45."
- **"Catch rate 80%."** This is recall, renamed. It directly answers "how good is it at the thing we hired it for" — catching leavers before they go.
- **"74% of the people we call were truly at risk; the other 26% are false alarms."** This is precision and its inverse, framed as a cost the operations team feels. Reporting only recall would hide the annoyance and expense of those wasted calls — reporting both is the honest picture.
- **"Net estimated value: $17,475."** This is the number that gets the project funded, and it is built from explicit, visible assumptions (`$400`, `30%`, `$15`). Showing the assumptions is what keeps you credible: if finance disputes the `$400`, you can rerun in seconds rather than be accused of inventing a rosy figure.
- **The one-line summary.** It compresses catch rate + customers kept + net dollars + wasted-call cost into a sentence leadership can repeat verbatim to *their* boss. That repeatability — not your model's AUC — is what carries the decision out of the room.

## Common mistakes

1. **Leading with metrics instead of money.** Opening with "F1 = 0.77, AUC = 0.88" loses the room in five seconds. **Fix:** open with the decision and the dollar figure; keep the metric names in your back pocket and only translate them when asked.
2. **Reporting recall while hiding precision (or vice-versa).** "We catch 80% of leavers!" sounds great until ops discovers a quarter of the calls were pointless. **Fix:** always report both sides — what you catch *and* what you waste — so no one is blindsided later.
3. **Quoting dollar value without stating the assumptions.** "$17k of value" with no `$400`-per-save or `30%`-save-rate behind it reads as a number you made up, and one challenge sinks your credibility. **Fix:** print the assumptions next to the result and label them as assumptions to be confirmed.
4. **Showing the technical artifacts.** ROC curves, hyperparameter tables, and the model architecture answer questions nobody in the room is asking and signal that you can't prioritize. **Fix:** cut everything that doesn't change the decision; offer the technical appendix only if someone requests it.
5. **Forgetting that catching a churner is not the same as saving one.** Recall measures who you *flagged*, not who you *kept* — the retention offer still has to work. Quoting "175 customers saved" overstates impact by 3x here. **Fix:** apply the realistic save rate (`30%`) before quoting customers kept or dollars.

## Extension challenge

1. The CFO disputes the assumptions: a saved customer is worth `$250`, not `$400`, and offers only work `20%` of the time. Re-run and report the new net value — is the project still worth funding? This is exactly the live recalculation that wins (or loses) the meeting.
2. Add a **"do nothing" comparison**: estimate the revenue lost if the model didn't exist (all 220 churners leave) and frame your net value as a reduction of that loss. Does the framing change which number you lead with?
3. Turn the printed block into a literal **one-pager**: a single headline sentence, three bullet numbers (catch rate, net value, wasted calls), and a two-line "assumptions" footnote. Then read it aloud to a non-technical friend and have them tell you the decision in their own words — if they can't, revise the wording, not the model.

## Matching animation

A dedicated animation for stakeholder communication is **not yet available** for this module — this lesson stands on its own. For related deployment context, see the **Model Deployment Request Lifecycle** (`50 Model Deployment Request Lifecycle`): it steps through one prediction request from client to JSON response, which is useful background for the conversation that *follows* a "yes, fund it" decision — how the flagged-customer list actually reaches the retention team in production. The communication skill in this lesson is what gets you to that "yes" in the first place.

"use strict";

/* ============================================================================
   Model Deployment Request Lifecycle
   ----------------------------------------------------------------------------
   A deployed model is an API. We animate ONE prediction request as a glowing
   packet travelling through seven pipeline stages, accumulating latency at
   each hop, and we break it three different ways:

     - healthy  : flows end to end, returns 200
     - badinput : fails schema validation at stage 3 -> 422
     - skew     : flows through but stage 4 uses the WRONG preprocessing,
                  returning 200 with a silently wrong prediction
     - coldstart: model weights load on first hit -> huge latency at stage 5

   Everything is deterministic: identical scenario => identical numbers and
   identical drawing. No randomness, no libraries, no external assets.
   ============================================================================ */

(function () {
  var canvas = document.getElementById("plot");
  var ctx = canvas.getContext("2d");

  /* logical drawing size (canvas attribute size); CSS scales it responsively */
  var W = canvas.width;   // 900
  var H = canvas.height;  // 500

  /* ---- DOM ---------------------------------------------------------------- */
  var seg = document.getElementById("seg");
  var segBtns = Array.prototype.slice.call(seg.querySelectorAll(".seg-btn"));
  var scenarioVal = document.getElementById("scenarioVal");
  var speedInput = document.getElementById("speed");
  var speedVal = document.getElementById("speedVal");
  var showTimes = document.getElementById("showTimes");
  var sendBtn = document.getElementById("send");
  var resetBtn = document.getElementById("reset");

  var elStatus = document.getElementById("rStatus");
  var elLatency = document.getElementById("rLatency");
  var elSlowest = document.getElementById("rSlowest");
  var elBody = document.getElementById("rBody");

  /* ---- palette (kept in sync with style.css tokens) ----------------------- */
  var COL = {
    text: "#e2e8f0",
    dim: "#94a3b8",
    border: "rgba(255,255,255,0.10)",
    violet: "#a78bfa",
    cyan: "#22d3ee",
    success: "#34d399",
    danger: "#f87171",
    warn: "#fbbf24",
    boxIdle: "rgba(255,255,255,0.035)",
    boxStroke: "rgba(255,255,255,0.12)"
  };

  /* ---- the seven pipeline stages ----------------------------------------- *
     `base` is the nominal latency contribution (ms) for that stage on a
     healthy request. Scenarios mutate these via per-stage overrides.          */
  var STAGES = [
    { id: "client",     title: "Client",        sub: "POST /predict",     base: 4,   icon: "client" },
    { id: "server",     title: "API Server",    sub: "FastAPI receives",  base: 6,   icon: "server" },
    { id: "validate",   title: "Validate",      sub: "schema + types",    base: 5,   icon: "shield" },
    { id: "preprocess", title: "Preprocess",    sub: "fitted pipeline",   base: 9,   icon: "gear"   },
    { id: "predict",    title: "model.predict", sub: "raw output",        base: 12,  icon: "brain"  },
    { id: "postprocess",title: "Post-process",  sub: "label + prob",      base: 5,   icon: "tag"    },
    { id: "respond",    title: "Return 200",    sub: "JSON to client",    base: 4,   icon: "send"   }
  ];

  /* ---- scenarios ---------------------------------------------------------- *
     Each scenario describes how the request behaves. `failAt` is the stage
     index where it errors (or -1 = no error). `warnAt` flags a stage that is
     dangerous-but-not-failing (train/serve skew). `times` overrides per-stage
     latency. `result` is what we render in the readout once the packet
     finishes (or fails).                                                       */
  var SCENARIOS = {
    healthy: {
      label: "Healthy request",
      failAt: -1,
      warnAt: -1,
      times: {},
      requestBody: '{ "tenure": 14, "monthly": 79.9, "contract": "month-to-month" }',
      result: {
        status: 200, kind: "ok",
        body: '{"label":"churn","probability":0.78}'
      },
      caption: "Valid input flows through every stage and returns 200."
    },
    badinput: {
      label: "Missing field / bad type",
      failAt: 2,            // dies at "Validate"
      warnAt: -1,
      times: { client: 4, server: 6, validate: 7 },
      requestBody: '{ "tenure": "fourteen", "monthly": 79.9 }',
      result: {
        status: 422, kind: "bad",
        body: '{"detail":[{"loc":["body","tenure"],"msg":"not an integer"},{"loc":["body","contract"],"msg":"field required"}]}'
      },
      caption: "Schema check rejects bad input at the edge: 422, model never runs."
    },
    skew: {
      label: "Train/serve skew",
      failAt: -1,
      warnAt: 3,            // danger flagged at "Preprocess"
      times: { preprocess: 9 },
      requestBody: '{ "tenure": 14, "monthly": 79.9, "contract": "two-year" }',
      result: {
        status: 200, kind: "warn",
        body: '{"label":"stay","probability":0.71}   // wrong: skewed features'
      },
      caption: "Stage 4 fit a FRESH transformer instead of the trained one. 200 OK, but the prediction is silently wrong."
    },
    coldstart: {
      label: "Cold start",
      failAt: -1,
      warnAt: -1,
      times: { predict: 1450 },   // weights load on first hit
      requestBody: '{ "tenure": 14, "monthly": 79.9, "contract": "month-to-month" }',
      result: {
        status: 200, kind: "ok",
        body: '{"label":"churn","probability":0.78}'
      },
      caption: "First hit after deploy loads model weights from disk: correct answer, brutal latency at stage 5."
    }
  };

  /* ---- live state --------------------------------------------------------- */
  var state = {
    scenario: "healthy",
    speed: 1,
    showTimes: true,
    running: false,
    finished: false,
    // animation
    startTs: 0,
    elapsedMs: 0,            // logical pipeline time, scaled by speed
    perStage: [],           // resolved latency per stage (ms)
    cumulative: [],         // cumulative latency boundaries (ms)
    totalMs: 0,
    failIndex: -1,
    warnIndex: -1,
    // packet position
    packetSeg: 0,           // current stage/segment index the packet is on
    packetT: 0,             // 0..1 progress within current hop
    bounced: false,         // for badinput: packet bounced back from fail stage
    finishPulse: 0          // for the success/fail glow pulse on the final box
  };

  /* per-stage layout, computed once for current canvas size */
  var layout = null;

  /* ===========================================================================
     LAYOUT
     =========================================================================*/
  function computeLayout() {
    var n = STAGES.length;
    var marginX = 30;
    var rowY = 150;          // vertical center of the box row
    var boxH = 92;
    var gap = 26;            // horizontal gap between boxes (arrow lives here)
    var usable = W - marginX * 2;
    var boxW = (usable - gap * (n - 1)) / n;

    var boxes = [];
    for (var i = 0; i < n; i++) {
      var x = marginX + i * (boxW + gap);
      boxes.push({
        x: x,
        y: rowY - boxH / 2,
        w: boxW,
        h: boxH,
        cx: x + boxW / 2,
        cy: rowY
      });
    }
    layout = { boxes: boxes, rowY: rowY, boxH: boxH, boxW: boxW, gap: gap, marginX: marginX };
  }

  /* ===========================================================================
     SCENARIO RESOLUTION
     -------------------------------------------------------------------------
     Turn the active scenario into concrete per-stage latencies and the
     cumulative timeline the animation walks along.
     =========================================================================*/
  function resolveScenario() {
    var scn = SCENARIOS[state.scenario];
    state.failIndex = scn.failAt;
    state.warnIndex = scn.warnAt;

    var per = [];
    for (var i = 0; i < STAGES.length; i++) {
      var s = STAGES[i];
      var t = (scn.times && Object.prototype.hasOwnProperty.call(scn.times, s.id))
        ? scn.times[s.id]
        : s.base;
      per.push(t);
    }

    /* If the request fails at stage k, stages after k never execute. */
    var lastStage = (scn.failAt >= 0) ? scn.failAt : STAGES.length - 1;

    var cum = [];
    var running = 0;
    for (var j = 0; j <= lastStage; j++) {
      running += per[j];
      cum.push(running);
    }

    state.perStage = per;
    state.cumulative = cum;
    state.lastStage = lastStage;
    state.totalMs = running;
  }

  /* ===========================================================================
     ANIMATION DRIVER
     =========================================================================*/
  var SCREEN_MS_PER_HOP = 520;   // wall-clock ms to animate one hop at 1x

  function startRequest() {
    if (state.running) return;
    resolveScenario();
    state.running = true;
    state.finished = false;
    state.bounced = false;
    state.finishPulse = 0;
    state.packetSeg = 0;
    state.packetT = 0;
    state.startTs = 0;
    state.elapsedMs = 0;
    sendBtn.disabled = true;

    setStatus("…", "");
    elLatency.textContent = "0 ms";
    elSlowest.textContent = "—";
    elBody.textContent = "request in flight…";
    elBody.className = "v mono";
  }

  function finishRequest() {
    var scn = SCENARIOS[state.scenario];
    state.running = false;
    state.finished = true;
    state.finishPulse = 1;
    sendBtn.disabled = false;

    setStatus(String(scn.result.status), scn.result.kind);
    elLatency.textContent = state.totalMs + " ms";

    /* slowest stage among the ones that actually executed */
    var maxIdx = 0, maxV = -1;
    for (var i = 0; i <= state.lastStage; i++) {
      if (state.perStage[i] > maxV) { maxV = state.perStage[i]; maxIdx = i; }
    }
    elSlowest.textContent = STAGES[maxIdx].title + " (" + maxV + " ms)";

    elBody.textContent = scn.result.body;
    elBody.className = "v mono " + scn.result.kind;
  }

  function setStatus(text, kind) {
    elStatus.textContent = text;
    elStatus.className = "v" + (kind ? " " + kind : "");
  }

  /* The packet travels between box centers. For most scenarios it moves
     forward through every executed stage. For badinput it advances to the
     failing stage, then bounces back toward the client to deliver the error. */
  function advance(dtMs) {
    var hopDuration = SCREEN_MS_PER_HOP / state.speed;
    state.packetT += dtMs / hopDuration;

    while (state.packetT >= 1) {
      state.packetT -= 1;

      if (!state.bounced) {
        /* forward travel */
        if (state.failIndex >= 0 && state.packetSeg >= state.failIndex) {
          /* reached the failing stage -> turn around */
          state.bounced = true;
          state.packetSeg = state.failIndex;
        } else if (state.packetSeg >= state.lastStage) {
          /* reached the end successfully */
          state.packetT = 0;
          finishRequest();
          return;
        } else {
          state.packetSeg += 1;
        }
      } else {
        /* bouncing back toward client to return the error response */
        if (state.packetSeg <= 0) {
          state.packetT = 0;
          finishRequest();
          return;
        } else {
          state.packetSeg -= 1;
        }
      }
    }
  }

  function tick(ts) {
    if (state.startTs === 0) state.startTs = ts;
    var dt = ts - (state._lastTs || ts);
    state._lastTs = ts;
    if (dt > 60) dt = 60; // clamp big gaps (tab switches) for determinism-ish smoothness

    if (state.running) {
      advance(dt);
      /* live latency readout follows the packet's logical progress */
      var liveMs = liveLatency();
      elLatency.textContent = liveMs + " ms";
    }

    if (state.finishPulse > 0) {
      state.finishPulse = Math.max(0, state.finishPulse - dt / 900);
    }

    draw();
    requestAnimationFrame(tick);
  }

  /* logical accumulated latency at the packet's current position */
  function liveLatency() {
    if (!state.bounced) {
      var seg = state.packetSeg;
      var before = seg > 0 ? state.cumulative[seg - 1] : 0;
      var stageT = state.perStage[seg] || 0;
      return Math.round(before + stageT * clamp01(state.packetT));
    }
    /* once bounced, latency is effectively fixed at the fail point */
    return state.totalMs;
  }

  function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }

  /* ===========================================================================
     DRAWING
     =========================================================================*/
  function draw() {
    ctx.clearRect(0, 0, W, H);
    drawTitleStrip();
    drawArrows();
    var i;
    for (i = 0; i < STAGES.length; i++) drawBox(i);
    drawPacket();
    drawCaption();
  }

  function drawTitleStrip() {
    ctx.save();
    ctx.fillStyle = COL.dim;
    ctx.font = "600 14px ui-monospace, Menlo, monospace";
    ctx.textBaseline = "top";
    ctx.textAlign = "left";
    ctx.fillText("REQUEST", 30, 36);
    ctx.textAlign = "right";
    ctx.fillText("RESPONSE", W - 30, 36);
    /* a faint timeline arrow under the heading */
    ctx.strokeStyle = "rgba(255,255,255,0.06)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(30, 62);
    ctx.lineTo(W - 30, 62);
    ctx.stroke();
    ctx.restore();
  }

  /* state of a box at index i: idle | active | done | fail | warn */
  function boxState(i) {
    if (!state.running && !state.finished) {
      return "idle";
    }
    var reached = state.bounced
      ? true /* during bounce every stage up to failIndex was reached */
      : (i < state.packetSeg) || (i === state.packetSeg);

    if (state.finished) {
      if (i === state.failIndex) return "fail";
      if (i === state.warnIndex && i <= state.lastStage) return "warn";
      if (i <= state.lastStage) return "done";
      return "idle";
    }
    /* running */
    if (state.failIndex >= 0 && i === state.failIndex && state.bounced) return "fail";
    if (i === state.warnIndex && i <= state.packetSeg) return "warn";
    if (i === state.packetSeg) return "active";
    if (i < state.packetSeg) return "done";
    return "idle";
  }

  function colorFor(st) {
    switch (st) {
      case "active": return COL.cyan;
      case "done":   return COL.success;
      case "fail":   return COL.danger;
      case "warn":   return COL.warn;
      default:       return COL.boxStroke;
    }
  }

  function drawBox(i) {
    var b = layout.boxes[i];
    var s = STAGES[i];
    var st = boxState(i);
    var accent = colorFor(st);
    var lit = (st !== "idle");

    ctx.save();

    /* glow for lit boxes */
    if (lit) {
      ctx.shadowColor = accent;
      ctx.shadowBlur = (st === "active") ? 24 : 14;
    }
    roundRect(b.x, b.y, b.w, b.h, 12);
    ctx.fillStyle = lit ? tint(st) : COL.boxIdle;
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.lineWidth = lit ? 2 : 1.2;
    ctx.strokeStyle = lit ? accent : COL.boxStroke;
    ctx.stroke();

    /* icon */
    drawIcon(s.icon, b.x + 14, b.y + 14, 20, lit ? accent : COL.dim);

    /* title + sub */
    ctx.textAlign = "left";
    ctx.textBaseline = "alphabetic";
    ctx.fillStyle = lit ? COL.text : COL.dim;
    ctx.font = "700 13px " + cssFont();
    fitText(s.title, b.x + 12, b.y + 56, b.w - 24, 13);

    ctx.fillStyle = COL.dim;
    ctx.font = "500 11px " + cssFont();
    fitText(s.sub, b.x + 12, b.y + 74, b.w - 24, 11);

    /* per-stage time chip (top-right) once executed */
    if (state.showTimes && (st === "done" || st === "fail" || st === "warn" || st === "active")) {
      var t = state.perStage[i];
      var label = t + "ms";
      ctx.font = "600 10px ui-monospace, Menlo, monospace";
      var tw = ctx.measureText(label).width + 10;
      var chipX = b.x + b.w - tw - 6;
      var chipY = b.y + 6;
      ctx.fillStyle = "rgba(0,0,0,0.35)";
      roundRect(chipX, chipY, tw, 16, 8);
      ctx.fill();
      ctx.fillStyle = accent;
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(label, chipX + tw / 2, chipY + 8.5);
    }

    /* stage number bubble */
    ctx.beginPath();
    ctx.arc(b.x + b.w - 14, b.y + b.h - 14, 9, 0, Math.PI * 2);
    ctx.fillStyle = lit ? accent : "rgba(255,255,255,0.10)";
    ctx.fill();
    ctx.fillStyle = lit ? "#0b0b10" : COL.dim;
    ctx.font = "700 10px " + cssFont();
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(String(i + 1), b.x + b.w - 14, b.y + b.h - 13);

    ctx.restore();
  }

  function tint(st) {
    switch (st) {
      case "active": return "rgba(34,211,238,0.10)";
      case "done":   return "rgba(52,211,153,0.08)";
      case "fail":   return "rgba(248,113,113,0.12)";
      case "warn":   return "rgba(251,191,36,0.12)";
      default:       return COL.boxIdle;
    }
  }

  function drawArrows() {
    for (var i = 0; i < STAGES.length - 1; i++) {
      var a = layout.boxes[i];
      var b = layout.boxes[i + 1];
      var x1 = a.x + a.w;
      var x2 = b.x;
      var y = a.cy;

      /* arrow is "lit" if the packet has crossed this gap */
      var crossed = (state.running || state.finished) &&
                    (i < state.packetSeg || (state.finished && i < state.lastStage) || (state.bounced && i < state.failIndex));
      ctx.save();
      ctx.strokeStyle = crossed ? COL.success : "rgba(255,255,255,0.16)";
      ctx.fillStyle = crossed ? COL.success : "rgba(255,255,255,0.16)";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x1 + 2, y);
      ctx.lineTo(x2 - 8, y);
      ctx.stroke();
      /* arrowhead */
      ctx.beginPath();
      ctx.moveTo(x2 - 8, y);
      ctx.lineTo(x2 - 16, y - 5);
      ctx.lineTo(x2 - 16, y + 5);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    }
  }

  /* The packet glides along the row between box centers. */
  function drawPacket() {
    if (!state.running && !state.finished) return;

    var pos = packetPosition();
    var x = pos.x, y = pos.y;

    /* color: cyan in flight, red while bouncing back an error,
       amber when sitting on the skew warning stage, green on success end. */
    var c = COL.cyan;
    if (state.bounced) c = COL.danger;
    else if (state.packetSeg === state.warnIndex) c = COL.warn;
    if (state.finished) {
      var k = SCENARIOS[state.scenario].result.kind;
      c = (k === "ok") ? COL.success : (k === "bad") ? COL.danger : COL.warn;
    }

    ctx.save();
    /* trailing comet */
    var trail = state.bounced ? 18 : -18;
    var grad = ctx.createLinearGradient(x + trail, y, x, y);
    grad.addColorStop(0, "rgba(0,0,0,0)");
    grad.addColorStop(1, c);
    ctx.strokeStyle = grad;
    ctx.lineWidth = 6;
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(x + trail, y);
    ctx.lineTo(x, y);
    ctx.stroke();

    /* glowing core */
    ctx.shadowColor = c;
    ctx.shadowBlur = 22;
    ctx.fillStyle = c;
    ctx.beginPath();
    ctx.arc(x, y, 9, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.fillStyle = "#0b0b10";
    ctx.font = "700 9px " + cssFont();
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("{ }", x, y + 0.5);
    ctx.restore();
  }

  function packetPosition() {
    var boxes = layout.boxes;
    if (state.finished) {
      /* park the packet on the meaningful stage */
      var idx = (state.failIndex >= 0) ? 0 : state.lastStage;
      if (state.warnIndex >= 0 && SCENARIOS[state.scenario].result.kind === "warn") idx = state.warnIndex;
      return { x: boxes[idx].cx, y: boxes[idx].cy };
    }
    var seg = state.packetSeg;
    var from, to;
    if (!state.bounced) {
      from = boxes[seg];
      to = boxes[Math.min(seg + 1, boxes.length - 1)];
      if (seg >= state.lastStage) { from = to = boxes[state.lastStage]; }
    } else {
      from = boxes[seg];
      to = boxes[Math.max(seg - 1, 0)];
    }
    var t = clamp01(state.packetT);
    return { x: lerp(from.cx, to.cx, t), y: lerp(from.cy, to.cy, t) };
  }

  function drawCaption() {
    var scn = SCENARIOS[state.scenario];
    var y = 230;

    /* request body block */
    drawCodeCard("REQUEST BODY  ·  POST /predict", scn.requestBody, 30, y, W - 60, COL.violet);

    /* outcome caption */
    var capY = y + 96;
    ctx.save();
    ctx.textAlign = "left";
    ctx.textBaseline = "top";

    var noteColor = COL.dim;
    if (state.finished) {
      var k = scn.result.kind;
      noteColor = (k === "ok") ? COL.success : (k === "bad") ? COL.danger : COL.warn;
    }
    ctx.fillStyle = noteColor;
    ctx.font = "600 13px " + cssFont();
    wrapText(scn.caption, 30, capY, W - 60, 19);

    /* response card once finished */
    if (state.finished) {
      var ry = capY + 56;
      var rc = (scn.result.kind === "ok") ? COL.success
             : (scn.result.kind === "bad") ? COL.danger : COL.warn;
      var hdr = "RESPONSE  ·  HTTP " + scn.result.status +
                (scn.result.kind === "warn" ? "  (200 OK but WRONG)" : "");
      drawCodeCard(hdr, scn.result.body, 30, ry, W - 60, rc);
    }
    ctx.restore();
  }

  function drawCodeCard(header, body, x, y, w, accent) {
    ctx.save();
    var h = 70;
    roundRect(x, y, w, h, 12);
    ctx.fillStyle = "rgba(0,0,0,0.28)";
    ctx.fill();
    ctx.lineWidth = 1.2;
    ctx.strokeStyle = withAlpha(accent, 0.45);
    ctx.stroke();

    /* left accent bar */
    ctx.fillStyle = accent;
    roundRect(x, y, 4, h, 2);
    ctx.fill();

    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    ctx.fillStyle = accent;
    ctx.font = "700 11px ui-monospace, Menlo, monospace";
    ctx.fillText(header, x + 16, y + 12);

    ctx.fillStyle = COL.text;
    ctx.font = "500 13px ui-monospace, Menlo, monospace";
    var bodyText = clipMono(body, w - 36);
    ctx.fillText(bodyText, x + 16, y + 36);
    ctx.restore();
  }

  /* ===========================================================================
     CANVAS PRIMITIVES
     =========================================================================*/
  function roundRect(x, y, w, h, r) {
    var rr = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + rr, y);
    ctx.arcTo(x + w, y, x + w, y + h, rr);
    ctx.arcTo(x + w, y + h, x, y + h, rr);
    ctx.arcTo(x, y + h, x, y, rr);
    ctx.arcTo(x, y, x + w, y, rr);
    ctx.closePath();
  }

  function lerp(a, b, t) { return a + (b - a) * t; }

  function cssFont() {
    return 'Inter, -apple-system, "Segoe UI", Roboto, Helvetica, Arial, sans-serif';
  }

  function withAlpha(hex, a) {
    /* accepts #rrggbb */
    var r = parseInt(hex.slice(1, 3), 16);
    var g = parseInt(hex.slice(3, 5), 16);
    var b = parseInt(hex.slice(5, 7), 16);
    return "rgba(" + r + "," + g + "," + b + "," + a + ")";
  }

  function fitText(text, x, y, maxW, size) {
    ctx.font = ctx.font.replace(/\d+px/, size + "px");
    var t = text;
    while (ctx.measureText(t).width > maxW && t.length > 3) {
      t = t.slice(0, -2);
    }
    if (t !== text) t = t.slice(0, -1) + "…";
    ctx.fillText(t, x, y);
  }

  function clipMono(text, maxW) {
    var t = text;
    while (ctx.measureText(t).width > maxW && t.length > 4) t = t.slice(0, -2);
    if (t !== text) t = t.slice(0, -1) + "…";
    return t;
  }

  function wrapText(text, x, y, maxW, lineH) {
    var words = text.split(" ");
    var line = "";
    var lines = 0;
    for (var i = 0; i < words.length; i++) {
      var test = line ? line + " " + words[i] : words[i];
      if (ctx.measureText(test).width > maxW && line) {
        ctx.fillText(line, x, y + lines * lineH);
        line = words[i];
        lines++;
      } else {
        line = test;
      }
    }
    ctx.fillText(line, x, y + lines * lineH);
  }

  /* ---- icons: pure canvas paths, no images ------------------------------- */
  function drawIcon(name, x, y, size, color) {
    ctx.save();
    ctx.translate(x, y);
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = 1.8;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    var s = size;
    switch (name) {
      case "client": /* browser window */
        strokeRoundRect(0, 0, s, s * 0.8, 3);
        line(0, s * 0.26, s, s * 0.26);
        dot(s * 0.16, s * 0.13, 1.3);
        dot(s * 0.3, s * 0.13, 1.3);
        break;
      case "server": /* stacked racks */
        strokeRoundRect(0, 0, s, s * 0.34, 2);
        strokeRoundRect(0, s * 0.43, s, s * 0.34, 2);
        dot(s * 0.18, s * 0.17, 1.3);
        dot(s * 0.18, s * 0.6, 1.3);
        break;
      case "shield": /* validation shield with check */
        ctx.beginPath();
        ctx.moveTo(s * 0.5, 0);
        ctx.lineTo(s, s * 0.22);
        ctx.lineTo(s, s * 0.55);
        ctx.quadraticCurveTo(s, s * 0.9, s * 0.5, s);
        ctx.quadraticCurveTo(0, s * 0.9, 0, s * 0.55);
        ctx.lineTo(0, s * 0.22);
        ctx.closePath();
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(s * 0.3, s * 0.5);
        ctx.lineTo(s * 0.45, s * 0.66);
        ctx.lineTo(s * 0.72, s * 0.34);
        ctx.stroke();
        break;
      case "gear": /* preprocessing pipeline = gear */
        ctx.beginPath();
        ctx.arc(s * 0.5, s * 0.5, s * 0.22, 0, Math.PI * 2);
        ctx.stroke();
        for (var t = 0; t < 8; t++) {
          var ang = (Math.PI * 2 / 8) * t;
          var ix = s * 0.5 + Math.cos(ang) * s * 0.3;
          var iy = s * 0.5 + Math.sin(ang) * s * 0.3;
          var ox = s * 0.5 + Math.cos(ang) * s * 0.44;
          var oy = s * 0.5 + Math.sin(ang) * s * 0.44;
          line(ix, iy, ox, oy);
        }
        break;
      case "brain": /* model node graph */
        dot(s * 0.2, s * 0.25, 2.4);
        dot(s * 0.2, s * 0.75, 2.4);
        dot(s * 0.55, s * 0.5, 2.4);
        dot(s * 0.85, s * 0.3, 2.4);
        dot(s * 0.85, s * 0.7, 2.4);
        line(s * 0.2, s * 0.25, s * 0.55, s * 0.5);
        line(s * 0.2, s * 0.75, s * 0.55, s * 0.5);
        line(s * 0.55, s * 0.5, s * 0.85, s * 0.3);
        line(s * 0.55, s * 0.5, s * 0.85, s * 0.7);
        break;
      case "tag": /* response label tag */
        ctx.beginPath();
        ctx.moveTo(s * 0.12, s * 0.5);
        ctx.lineTo(s * 0.5, s * 0.12);
        ctx.lineTo(s, s * 0.12);
        ctx.lineTo(s, s * 0.6);
        ctx.lineTo(s * 0.62, s);
        ctx.closePath();
        ctx.stroke();
        dot(s * 0.78, s * 0.32, 1.6);
        break;
      case "send": /* paper-plane / return */
        ctx.beginPath();
        ctx.moveTo(0, s * 0.5);
        ctx.lineTo(s, 0);
        ctx.lineTo(s * 0.62, s);
        ctx.lineTo(s * 0.46, s * 0.6);
        ctx.closePath();
        ctx.stroke();
        line(s * 0.46, s * 0.6, s, 0);
        break;
    }
    ctx.restore();

    function line(ax, ay, bx, by) {
      ctx.beginPath(); ctx.moveTo(ax, ay); ctx.lineTo(bx, by); ctx.stroke();
    }
    function dot(dx, dy, r) {
      ctx.beginPath(); ctx.arc(dx, dy, r, 0, Math.PI * 2); ctx.fill();
    }
    function strokeRoundRect(rx, ry, rw, rh, rr) {
      ctx.save();
      ctx.translate(0, 0);
      var rad = Math.min(rr, rw / 2, rh / 2);
      ctx.beginPath();
      ctx.moveTo(rx + rad, ry);
      ctx.arcTo(rx + rw, ry, rx + rw, ry + rh, rad);
      ctx.arcTo(rx + rw, ry + rh, rx, ry + rh, rad);
      ctx.arcTo(rx, ry + rh, rx, ry, rad);
      ctx.arcTo(rx, ry, rx + rw, ry, rad);
      ctx.closePath();
      ctx.stroke();
      ctx.restore();
    }
  }

  /* ===========================================================================
     CONTROLS
     =========================================================================*/
  function selectScenario(scn) {
    state.scenario = scn;
    scenarioVal.textContent = SCENARIOS[scn].label;
    segBtns.forEach(function (b) {
      b.classList.toggle("active", b.getAttribute("data-scn") === scn);
    });
    resetView();
  }

  function resetView() {
    state.running = false;
    state.finished = false;
    state.bounced = false;
    state.packetSeg = 0;
    state.packetT = 0;
    state.finishPulse = 0;
    sendBtn.disabled = false;
    resolveScenario();
    setStatus("idle", "");
    elLatency.textContent = "0 ms";
    elSlowest.textContent = "—";
    elBody.textContent = "awaiting request";
    elBody.className = "v mono";
  }

  seg.addEventListener("click", function (e) {
    var btn = e.target.closest(".seg-btn");
    if (!btn) return;
    selectScenario(btn.getAttribute("data-scn"));
  });

  speedInput.addEventListener("input", function () {
    state.speed = parseFloat(speedInput.value);
    speedVal.innerHTML = state.speed.toFixed(1) + "&times;";
  });

  showTimes.addEventListener("change", function () {
    state.showTimes = showTimes.checked;
  });

  sendBtn.addEventListener("click", startRequest);
  resetBtn.addEventListener("click", resetView);

  /* ===========================================================================
     BOOT
     =========================================================================*/
  computeLayout();
  selectScenario("healthy");
  requestAnimationFrame(tick);
})();

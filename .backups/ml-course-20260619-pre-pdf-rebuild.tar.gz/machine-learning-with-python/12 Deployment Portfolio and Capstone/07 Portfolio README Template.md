# Portfolio README Template

> The README is the front door of your repo — most recruiters read it for 30 seconds and never open a single `.py` file, so it has to sell the project on its own.

## How to use this
- Copy the block below into a file named `README.md` at the root of your churn project repo.
- Replace every `[ ... ]` placeholder with your own content; delete what doesn't apply.
- Keep the badges line truthful (don't claim 95% test coverage you don't have).
- It's written for the churn capstone, but the structure fits any ML portfolio project.

````markdown
# Customer Churn Prediction

![Python](https://img.shields.io/badge/python-3.11-blue)
![scikit-learn](https://img.shields.io/badge/scikit--learn-1.4-orange)
![License: MIT](https://img.shields.io/badge/license-MIT-green)

Predict which telecom customers are about to churn, so a limited retention budget can be aimed at the customers most at risk.

## Problem
[2–3 sentences: the business pain (lost recurring revenue), the decision the model supports
(who to target with a retention offer), and the costly error to avoid (a missed churner).]

## Dataset
- **Source:** [public Telco Customer Churn dataset, ~7,000 rows — link — / synthetic teaching sample]
- **Target:** `churn` (1 = left, 0 = stayed) — binary classification, [imbalanced ~27% positive]
- **Key features:** tenure, monthly charges, contract type, support membership, [payment method, ...]
- **Cleaning:** dropped duplicates, imputed missing categorical values with the mode, coerced types,
  validated numeric ranges.

## Approach
- Leak-proof `Pipeline` + `ColumnTransformer`: median-impute & scale numerics; mode-impute &
  one-hot encode categoricals.
- Metric chosen **before** modeling: **F1 on the churn class** (accuracy is misleading on imbalanced churn).
- Models: majority-class baseline → Logistic Regression → tuned Random Forest (`GridSearchCV`,
  stratified 3-fold CV).
- Evaluated on a fixed, stratified held-out test split (`random_state=42`) for reproducibility.

## Results
| Model                   | F1 (churn) | Recall (churn) | ROC-AUC |
|-------------------------|------------|----------------|---------|
| Majority-class baseline | [0.00]     | [0.00]         | [0.50]  |
| Logistic Regression     | [ ]        | [ ]            | [ ]     |
| Random Forest (tuned)   | [ ]        | [ ]            | [ ]     |

**Shipped model:** [name] — [one-line honest reason]. Full write-up in [`report.md`](report.md).

## How to run
```bash
git clone https://github.com/[you]/customer-churn-prediction.git
cd customer-churn-prediction
pip install -r requirements.txt

python train.py        # trains, prints metrics, saves churn_pipeline.joblib
python predict.py       # loads the saved pipeline and scores a sample customer
```

## Repo structure
```
customer-churn-prediction/
├── README.md            # you are here
├── requirements.txt     # pinned dependencies (random_state fixed for reproducibility)
├── data/                # dataset (or a script/link to download it)
├── notebooks/
│   └── eda.ipynb        # cleaning + exploratory data analysis
├── src/
│   ├── train.py         # builds the pipeline, tunes, evaluates, saves the artifact
│   └── predict.py       # loads churn_pipeline.joblib and predicts on new data
├── churn_pipeline.joblib# the saved, ready-to-serve model
└── report.md            # the final report (problem → results → error analysis)
```

## What I learned
- [Why F1/recall beat accuracy for imbalanced churn, and how to argue a metric before modeling.]
- [How a ColumnTransformer pipeline prevents data leakage end to end.]
- [How to compare models honestly on one split — and accept a tie in favor of the simpler model.]
- [What error analysis revealed: which customers the model misses and how to fix it.]

## License
Released under the MIT License — see [LICENSE](LICENSE).
````

## What makes a portfolio repo impressive

A reviewer can tell a real project from a tutorial dump in seconds. Aim for these signals:

- **It runs from a clean clone.** `git clone` → `pip install -r requirements.txt` → `python train.py` must work with no hidden steps. Pin versions so it still works next year.
- **The README answers "so what?" fast.** Problem, metric, headline result, all above the fold. Lead with the business framing, not the algorithm.
- **Honest, specific numbers.** A filled-in results table that includes the *baseline* row shows you understand what "good" means. Never report training-set scores as if they were test scores.
- **Visible reasoning, not just code.** The error-analysis section and the "what I learned" list prove you can think about a model, not just call `.fit()`.
- **Clean structure.** `src/` for code, `notebooks/` for exploration, a saved artifact, a report. No 2,000-line monolith notebook.
- **Reproducibility.** Fixed `random_state`, a pinned `requirements.txt`, and clear run instructions. This is the single thing most beginner repos miss.
- **A real commit history.** Several meaningful commits (`add cleaning`, `add baseline`, `tune RF`, `error analysis`) tell a story; one giant "initial commit" does not.
- **A license file.** MIT is a safe default and signals you intend the work to be shared and reused.

Skip: screenshots of accuracy with no baseline, copied tutorial text, datasets committed as 200MB blobs (link or script the download instead), and "TODO" sections left in the README.

## Small exercise
Create the repo skeleton above, paste in your filled README, and ask a friend (or just re-read it yourself a day later) to answer three questions from the README *alone*: what problem does it solve, how well does it work, and how do I run it? If any answer isn't obvious in under a minute, tighten that section.

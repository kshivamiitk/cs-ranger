# Solved — Writing a Portfolio-Ready ML Project Report

> You finished an ML project; now turn it into a one-page report + README that a recruiter can skim in two minutes and a peer can reproduce in ten.

## Problem statement

You have a working churn classifier in a messy notebook: some EDA, a few models, scattered metrics. The deliverable is **not more modeling** — it's a recruiter-ready **report** and a repo **README** that communicate the project honestly. "Done" means a reader can answer, without running anything: *What problem? On what data? What approach? How good is it versus a baseline? Where does it fail? How do I reproduce it?* The "metric" for this task is comprehension speed and trust, not accuracy.

## Data sample

The artifact you're shaping is a short, structured document. Here is the skeleton — the section order is the point.

| Section | What it answers | Length |
|---------|-----------------|--------|
| Problem & metric | What you predict, for whom, why; the metric chosen and why | 2-3 sentences |
| Data | Source, size (rows x cols), target, any imbalance | 2-3 sentences + 1 table |
| Approach | Preprocessing, baseline, final model, validation scheme | a short list |
| Results | A results table with a **baseline row** + final model on a held-out test set | 1 table |
| Error analysis | Where it fails and why (segments, confusion matrix reading) | 2-4 sentences |
| Limitations | What it can't do / data caveats / leakage risks ruled out | a short list |
| Reproduce | Setup + exact commands + `random_state` + versions | a code block |

## Why this problem matters

Recruiters and senior engineers spend under two minutes per portfolio project. A brilliant model buried in a 40-cell notebook with no narrative reads as "can't communicate". The report is where you demonstrate judgment: that you picked the right metric, beat a baseline, know your model's weaknesses, and can be reproduced. In a real job this same document is the model card / handoff doc, so practicing it now is directly transferable.

## Step-by-step reasoning

1. **Lead with the problem and the metric, not the model.** State the prediction target, who acts on it, and the metric tied to the cost of errors (e.g. "recall on churners — a missed churner is an avoidable cancellation"). This frames everything that follows.
2. **Always include a baseline row.** A number only means something relative to "predict the majority class" or a tiny logistic regression. The baseline turns "F1 = 0.78" into "F1 = 0.78 vs 0.42 baseline" — proof the work earned its complexity.
3. **Report held-out test numbers, never training numbers.** Be explicit that results are on data the model never saw, and name the split/CV scheme so the reader trusts them.
4. **Phrase results honestly.** Don't round up, don't headline the cherry-picked best run, don't hide the metric that looks bad. Honest, slightly-modest numbers read as more credible than suspicious perfection.
5. **Show vs cut.** SHOW: the one results table, one decisive plot (e.g. confusion matrix or PR curve), the top failure mode, reproduce steps. CUT: every dead-end experiment, raw training logs, walls of `print()` output, and EDA charts that didn't change a decision.
6. **Make reproduce steps copy-pasteable.** Setup command, the single command to run it, the fixed `random_state`, and pinned versions. If a reviewer can't rerun it, the numbers are just claims.
7. **End with limitations.** Stating what the model can't do (and that you checked for leakage) signals maturity, not weakness.

## Python solution

The "solution" here is mostly prose, but two pieces of code make a report trustworthy: a tiny script that **prints the results table you'll paste in**, and **reproducible** saving of the model. Both are offline.

```python
import numpy as np
import pandas as pd
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.dummy import DummyClassifier
from sklearn.metrics import f1_score, recall_score, precision_score

# Stand-in dataset so this runs offline; swap in your real project data.
X, y = load_breast_cancer(return_X_y=True, as_frame=True)
print("data shape:", X.shape, "| positive rate:", round(y.mean(), 3))

X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

# Baseline FIRST: predict the majority class. This is the bar to beat.
baseline = DummyClassifier(strategy="most_frequent").fit(X_tr, y_tr)

# Final model: a leak-proof pipeline (scaler fit on train only).
model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=5000))
model.fit(X_tr, y_tr)
```

```python
# --- Build the exact results table you'll paste into the report ---
def row(name, fitted):
    p = fitted.predict(X_te)
    return {
        "model": name,
        "precision": round(precision_score(y_te, p, zero_division=0), 2),
        "recall": round(recall_score(y_te, p, zero_division=0), 2),
        "f1": round(f1_score(y_te, p, zero_division=0), 2),
    }

results = pd.DataFrame([
    row("Baseline (majority class)", baseline),
    row("Logistic regression", model),
])
print(results.to_string(index=False))   # copy this straight into the report table
```

```python
# --- Reproducibility: save the WHOLE fitted pipeline, and pin versions ---
import joblib, sklearn, sys
joblib.dump(model, "model.joblib")       # preprocessing + model travel together
print("python :", sys.version.split()[0])
print("sklearn:", sklearn.__version__)   # put these in requirements.txt
# requirements.txt example:
#   scikit-learn==1.5.0
#   pandas==2.2.2
#   numpy==1.26.4
```

## Expected output

Running it prints roughly:

```
data shape: (569, 30) | positive rate: 0.627
                     model  precision  recall   f1
 Baseline (majority class)       0.63    1.00 0.77
       Logistic regression       0.97    0.99 0.98
python : 3.11.x
sklearn: 1.5.0
```

How to read it — and how it becomes your report table:

| model | precision | recall | F1 |
|-------|-----------|--------|----|
| Baseline (majority class) | 0.63 | 1.00 | 0.77 |
| Logistic regression | 0.97 | 0.99 | 0.98 |

The baseline's recall is a deceptive `1.00` (it calls everything positive), but its precision is only `0.63` and that's the honest comparison point. The logistic model lifts precision to `0.97` while keeping recall high — F1 `0.98` vs `0.77`. In the report you'd write: *"On a held-out test set (25%, stratified, `random_state=42`), the model reached F1 0.98 vs a 0.77 majority-class baseline; recall 0.99 means it rarely misses positives."* That one honest, baseline-anchored sentence is the whole results section.

## Common mistakes

- **No baseline.** A lone "F1 = 0.98" gives the reader nothing to judge it against. Fix: always include the baseline row — it's two lines of `DummyClassifier`.
- **Reporting training-set scores.** Numbers from data the model fit on are inflated. Fix: state explicitly that results are on a held-out test set and name the split/CV.
- **Dumping the notebook as the report.** 40 cells of trial-and-error hide the story. Fix: a one-page report with the seven sections above; link the notebook for those who want detail.
- **Saving only the estimator, not the pipeline.** `joblib.dump(logreg)` loses the scaler, so serving preprocesses differently (train/serve skew). Fix: dump the whole `Pipeline`.
- **Cosmetic dishonesty.** Rounding 0.71 up to 0.75, headlining your luckiest seed, or omitting the metric that looks bad. Fix: report the real number and the metric the problem actually demands; reviewers reward candor.

## Extension challenge

1. Add a third results row for a tuned model (e.g. `RandomForestClassifier`) and write one sentence on whether the extra complexity is worth it versus logistic regression.
2. Add an **error-analysis** paragraph: pull the false negatives from the test set, look for a shared trait, and state one concrete next step.
3. Turn the printed table + reproduce block into an actual `README.md` with the seven sections, and have a peer try to reproduce your numbers from it alone.

## Matching animation

See **"Model Deployment Request Lifecycle"** (`50 Model Deployment Request Lifecycle`). Step through one prediction request from client to JSON response and toggle "train/serve skew" to watch what happens when serving preprocessing differs from training — the exact failure your "save the whole pipeline" reproduce step is designed to prevent.

# Lab — Capstone: Improved Model and Tuning

## Objective

Try to beat the baseline — *honestly*. You'll swap the logistic regression for a `RandomForestClassifier` inside the same leak-proof pipeline, then use `GridSearchCV` with cross-validation to tune its hyperparameters. Crucially, you'll judge the tuned model on the **same held-out split and the same F1 metric** as the baseline, so the comparison is fair. You'll learn to report improvement truthfully — including the case where the fancy model *doesn't* win.

## Dataset

Same cleaned churn data and the **same split** as lesson 04. Re-create it with the identical `random_state` so "the bar to beat" means something:

```python
# (paste lesson-02 loader + lesson-03 clean_churn first)
from sklearn.model_selection import train_test_split

clean = clean_churn(load_churn())
X = clean.drop(columns=["customer_id", "churn"])
y = clean["churn"]

X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.30, random_state=42, stratify=y)   # SAME split as the baseline
```

We also rebuild the same preprocessing block (numeric scale + categorical one-hot):

```python
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder

numeric_cols     = ["tenure_months", "monthly_charges"]
categorical_cols = ["contract_type", "has_support"]

preprocess = ColumnTransformer([
    ("num", Pipeline([("impute", SimpleImputer(strategy="median")),
                      ("scale",  StandardScaler())]), numeric_cols),
    ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                      ("onehot", OneHotEncoder(handle_unknown="ignore"))]), categorical_cols),
])
```

## Steps

**Step 1 — Put a Random Forest in the same pipeline.** A forest can capture non-linear interactions (e.g. "short tenure AND month-to-month") that a linear model can't.

```python
from sklearn.ensemble import RandomForestClassifier

rf_pipe = Pipeline([
    ("prep",  preprocess),
    ("model", RandomForestClassifier(random_state=42)),
])
```

**Step 2 — Define a small, sensible hyperparameter grid.** Reference parameters with the `step__param` double-underscore syntax. Keep the grid small — every combination is trained `cv` times.

```python
param_grid = {
    "model__n_estimators":      [100, 300],
    "model__max_depth":         [None, 3, 5],
    "model__min_samples_leaf":  [1, 2],
}
```

**Step 3 — Cross-validate to choose hyperparameters.** With only ~24 training rows, use **stratified** 3-fold CV so every fold has both classes, and score by **F1** to match our objective. CV happens *inside the training set only* — the test set is never touched here.

```python
from sklearn.model_selection import GridSearchCV, StratifiedKFold

cv = StratifiedKFold(n_splits=3, shuffle=True, random_state=42)
search = GridSearchCV(
    rf_pipe, param_grid,
    scoring="f1",          # optimize the churn-class F1, same metric as the baseline
    cv=cv,
    n_jobs=-1,
)
search.fit(X_tr, y_tr)     # tunes using cross-validation on training data ONLY

print("Best CV F1:", round(search.best_score_, 3))
print("Best params:", search.best_params_)
```

**Step 4 — Evaluate the tuned model on the held-out split.** `search` behaves like the best pipeline already refit on all training data, so just call it.

```python
from sklearn.metrics import f1_score, accuracy_score

best = search.best_estimator_
rf_pred = best.predict(X_te)
RF_F1 = f1_score(y_te, rf_pred, pos_label=1)
print("Tuned RF accuracy:", round(accuracy_score(y_te, rf_pred), 3))
print("Tuned RF F1 (churn):", round(RF_F1, 3))
```

**Step 5 — Compare to the baseline honestly.** Re-fit the baseline logistic regression on the same split and put the two numbers side by side.

```python
from sklearn.linear_model import LogisticRegression

baseline = Pipeline([("prep", preprocess),
                     ("model", LogisticRegression(max_iter=1000, random_state=42))]).fit(X_tr, y_tr)
BASELINE_F1 = f1_score(y_te, baseline.predict(X_te), pos_label=1)

print(f"Baseline (LogReg) F1: {BASELINE_F1:.3f}")
print(f"Tuned RF        F1: {RF_F1:.3f}")
delta = RF_F1 - BASELINE_F1
verdict = "RF wins" if delta > 0 else ("tie" if delta == 0 else "baseline wins")
print(f"Improvement: {delta:+.3f}  ->  {verdict}")
```

## Expected output

- `GridSearchCV` prints a best CV F1 and the winning hyperparameters (often a shallow `max_depth`, which guards against overfitting such a tiny set).
- On this teaching dataset, **both models likely score very high F1 (close to 1.0)** because `contract_type` is almost a perfect predictor — so the realistic verdict here is often a **tie**, or a tiny delta in either direction. *That is a legitimate, honest result.* The lesson is the discipline, not a guaranteed win.
- On the real Telco data the picture is more interesting: a tuned Random Forest typically edges out logistic regression by a few F1 points — a real but modest gain. Sometimes the simpler logistic model ties it; report whatever you actually measure.

**How to report it honestly:**

- Compare on the **same split and same metric** (we did).
- Never tune on the test set; we tuned with CV on training data only.
- If the complex model doesn't beat the baseline, **say so and ship the baseline** — it's simpler, faster, and more interpretable. Resisting the urge to fake an improvement is what separates a credible portfolio from a misleading one.

## Extension challenge

1. Replace the held-out single split with `cross_val_score(best, X, y, scoring="f1", cv=cv)` over the full data and report the mean ± std. The std tells you how shaky the estimate is on 35 rows.
2. Add `class_weight="balanced"` to the Random Forest's grid (`"model__class_weight": [None, "balanced"]`) and see whether recall on the churn class improves.
3. Pull feature importances from the tuned forest: `best.named_steps["model"].feature_importances_` aligned with `best.named_steps["prep"].get_feature_names_out()`. Does the model agree with your EDA that contract type dominates?

# Model Deployment

> Deployment is the moment your model stops being a notebook cell and becomes a service: a saved file, loaded behind an API, that takes a raw request and returns a prediction as JSON — fast, validated, and preprocessed exactly the way it was trained.

## What is this?

Model deployment is **turning a trained model into something other programs (and people) can actually call.** In the notebook you have the model in memory and you type `model.predict(...)` yourself. In deployment, a *different* computer — with no notebook, no variables in memory, no training data — receives a request over the network and returns an answer, over and over, for real users.

The minimal recipe has four moves:

1. **Save** the trained model to a file (`joblib.dump`), so it survives outside your notebook.
2. **Load** that file once, behind a small web server (Flask or FastAPI).
3. On each request: **validate** the input, apply the **same preprocessing** used in training, call `model.predict`, and **return JSON**.
4. Keep it **fast** — load the model once at startup, not per request.

That's it. A deployed model is just a saved artifact plus a thin layer that turns an HTTP request into a `predict` call and the result back into JSON.

## Why do we need it?

A model that only runs in your notebook helps exactly one person — you, while you're watching. Every product use of ML needs the prediction to happen somewhere else: a mobile app asking "is this transaction fraud?", a website scoring a loan application, a backend deciding which customers to email. None of those can open your notebook and re-run your cells.

Deployment is the bridge from "it works on my machine" to "it works for users." It forces you to make the model **self-contained** (everything it needs is in the saved file), **reachable** (behind a stable URL), and **robust** (it can't crash on a malformed request). Crucially, it forces you to apply the *exact same transformations at serving time that you applied at training time* — get that wrong and the model returns confident nonsense. The notebook lets you be sloppy about all of this; deployment does not.

## Where it's used in real ML

- **Fraud and risk scoring** — a payments backend POSTs a transaction to a `/predict` endpoint and gets a risk score in milliseconds, before approving the charge.
- **Recommendation and ranking** — a feed service calls a model to score and order items per user on each page load.
- **Document and image classification** — an upload pipeline routes a file to a model service that tags or moderates it.
- **Internal tools and dashboards** — a Streamlit or FastAPI app wraps the model so non-engineers can get predictions by filling a form.
- **Batch scoring** — the same saved artifact loaded by a nightly job to score a whole table at once (deployment isn't always a live API).

## What breaks if you ignore it

- **Train/serve skew — the silent killer.** If serving preprocessing differs *at all* from training (a different imputation value, a forgotten scaler, encoder categories in a different order), the model gets inputs in a distribution it never saw and returns confidently *wrong* answers. No error, no alert — just bad predictions. The fix is to save the *whole fitted `Pipeline`*, so the exact learned transformers travel with the model.
- **Unvalidated input crashes the service.** A request with a missing field, a string where a number belongs, or an extra column will throw deep inside `predict`. Validate at the edge and reject bad input with a clear `4xx` error instead of a `500` crash.
- **Latency you didn't budget for.** Loading the model inside the request handler re-reads the file on every call and tanks response time. The first request after startup (*cold start*) is also slow because weights load then. Load once at startup into a module-level variable.
- **Irreproducible artifacts.** Unpickling a model with a mismatched library version can warn or silently misbehave. Pin versions in `requirements.txt`.

## Mental model

Your notebook is the **kitchen** where you develop the dish. The saved pipeline is the **frozen meal** — fully prepped, nothing left to improvise. The API server is the **microwave** that reheats one meal per order. The customer never sees your kitchen; they just send an order and get a plate back.

Follow one order through the line — this is the **Model Deployment Request Lifecycle**:

```
   CLIENT                          API SERVER
   ──────                          ──────────
   { "tenure": 12,                 1. receive request (JSON in)
     "charges": 70,         ─────► 2. validate: all fields present? right types?   ──┐ bad? -> 422
     "contract": "M2M" }           3. SAME fitted preprocessing as training           │  (reject early)
                                    4. model.predict(...)        <- the smallest box  │
                                    5. serialize result to JSON                       │
   { "churn_probability": 0.81,  ◄ 6. return response (JSON out)  ◄────────────────────┘
     "prediction": 1 }
```

Notice `model.predict` is *one box among many*. A live prediction spends most of its life in validation, preprocessing, and serialization — the model itself is the smallest part. (Step through this in the **"Model Deployment Request Lifecycle"** animation: toggle *Missing field* to watch validation reject with a 422, *Train/serve skew* to see a 200 with a wrong answer, and *Cold start* to see latency spike on the first hit.)

## Example 1 — Tiny toy example

Save a trained model to disk and load it back in a fresh program — the smallest possible "deployment." Train, `joblib.dump`, then (pretending we're a new process) `joblib.load` and predict, with zero training code.

```
TRAIN (your kitchen)                SERVE (a new program)
  model.fit(X, y)                     model = joblib.load("model.joblib")
  joblib.dump(model, "model.joblib")  model.predict(new_row)   # same answer
        │                                      ▲
        └──────────  one file  ────────────────┘
```

The point: once the file exists, prediction needs *nothing* from training — not the data, not the variables, not even the import of the preprocessing class (it rode along inside the pipeline). If it predicts correctly from a clean reload, your artifact is truly self-contained, which is the whole job of "save."

## Example 2 — Practical ML example

A real churn service. You trained a leak-proof `Pipeline` (`ColumnTransformer` for imputing + scaling + one-hot encoding, then a classifier) and saved it as `churn_pipeline.joblib`. Now you wrap it in a FastAPI app with a single `/predict` endpoint.

A request arrives as JSON: `{"tenure_months": 12, "monthly_charges": 70.0, "contract_type": "Month-to-month"}`. The endpoint **validates** it (FastAPI does this automatically from a typed schema — missing `monthly_charges` or a string where a float belongs is rejected with a `422` before the model is ever touched), builds a one-row DataFrame with the *same column names* the pipeline was trained on, lets the pipeline apply the *same fitted* imputers/scaler/encoder, calls `predict_proba`, and returns `{"churn_probability": 0.81, "prediction": 1}`. The model loads **once** when the server starts, so each request is just a fast `predict`, not a file read. This is the realistic shape of a deployed model: a saved Pipeline + a thin validated endpoint.

## Python code example

```python
# ---- PART 1: train and SAVE a self-contained pipeline (run once) ----
import joblib
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression

# Tiny inline training set. Real projects load a CSV; the pattern is identical.
df = pd.DataFrame({
    "tenure_months":  [1, 2, 24, 36, 3, 48, 6, 60],
    "monthly_charges":[85.0, 90.0, 25.0, 20.0, 80.0, 19.0, 75.0, 18.0],
    "contract_type":  ["Month-to-month","Month-to-month","Two year","Two year",
                       "Month-to-month","Two year","Month-to-month","Two year"],
    "churn":          [1, 1, 0, 0, 1, 0, 1, 0],
})
X, y = df.drop(columns="churn"), df["churn"]

# The WHOLE thing is one object: preprocessing + model, fitted together.
pre = ColumnTransformer([
    ("num", StandardScaler(), ["tenure_months", "monthly_charges"]),
    ("cat", OneHotEncoder(handle_unknown="ignore"), ["contract_type"]),
])
pipe = Pipeline([("pre", pre), ("model", LogisticRegression(random_state=42))])
pipe.fit(X, y)
joblib.dump(pipe, "churn_pipeline.joblib")   # one shippable artifact
print("saved churn_pipeline.joblib")

# ---- PART 2: SERVE it. This is all a minimal API does. ----
# A fresh process would start here. Load ONCE at startup, never per request.
model = joblib.load("churn_pipeline.joblib")

def predict(request: dict) -> dict:
    """Stand-in for a Flask/FastAPI POST /predict handler."""
    # 1. VALIDATE the input at the edge (reject bad input with a clear error).
    required = ["tenure_months", "monthly_charges", "contract_type"]
    missing = [k for k in required if k not in request]
    if missing:
        return {"status": 422, "error": f"missing fields: {missing}"}
    try:
        row = pd.DataFrame([{
            "tenure_months": float(request["tenure_months"]),
            "monthly_charges": float(request["monthly_charges"]),
            "contract_type": str(request["contract_type"]),
        }])
    except (TypeError, ValueError):
        return {"status": 422, "error": "bad types"}

    # 2. SAME fitted preprocessing as training happens INSIDE the pipeline.
    # 3. predict.  4. return JSON.
    proba = float(model.predict_proba(row)[0, 1])
    return {"status": 200,
            "churn_probability": round(proba, 3),
            "prediction": int(proba >= 0.5)}

# Simulate three incoming requests.
print(predict({"tenure_months": 2,  "monthly_charges": 88, "contract_type": "Month-to-month"}))
print(predict({"tenure_months": 50, "monthly_charges": 19, "contract_type": "Two year"}))
print(predict({"tenure_months": 2}))   # malformed -> rejected, model never touched

# Expected output (probabilities approximate):
# saved churn_pipeline.joblib
# {'status': 200, 'churn_probability': 0.93, 'prediction': 1}   # likely churner
# {'status': 200, 'churn_probability': 0.06, 'prediction': 0}   # likely to stay
# {'status': 422, 'error': "missing fields: ['monthly_charges', 'contract_type']"}
#
# To make this a real web service, the same predict() body goes inside:
#   @app.post("/predict")          # FastAPI / Flask
#   def predict_endpoint(req): ...  return jsonify(predict(req))
```

The serving code never imports `StandardScaler` or `OneHotEncoder` and never re-fits anything — the fitted transformers rode along inside the pipeline. That is how you avoid train/serve skew.

## Common mistakes

- **Saving only the model, not the whole pipeline.** `joblib.dump(classifier)` drops the scaler/encoder, forcing you to re-preprocess by hand at serving time — the classic source of train/serve skew. Dump the whole `Pipeline`.
- **Re-fitting a transformer at prediction time.** Serving data has no labels and often comes one row at a time; calling `.fit` again computes new stats from that one row and corrupts the input. Always *reuse* the training-time transformer (the pipeline does this for you).
- **Loading the model inside the request handler.** That re-reads the file on every call and destroys latency. Load once at startup into a module-level variable.
- **Skipping input validation.** A missing field or wrong type throws deep inside `predict` and returns a `500`. Validate at the edge and reply with a `4xx` and a clear message instead.
- **No version pinning.** Unpickling a model with a mismatched scikit-learn version can warn (`InconsistentVersionWarning`) or silently misbehave. Pin versions in `requirements.txt`.

## Before you continue
- [ ] I can list the four moves: save → load → (validate, preprocess, predict, return JSON) → keep it fast.
- [ ] I can explain train/serve skew and why saving the whole Pipeline prevents it.
- [ ] I can load a `.joblib` artifact in a fresh process and serve a prediction.
- [ ] I know why the model must be loaded once at startup, not per request.
- [ ] I can name two things a request does *besides* `model.predict` (validate, preprocess, serialize).

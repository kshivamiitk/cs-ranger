# Checkpoint — Capstone and Next Steps

You've gone from "what is a feature?" to shipping an end-to-end churn predictor. This checkpoint recaps the whole course, tests the ideas that matter most, and hands you a concrete plan for turning the capstone into a public portfolio piece.

## What you should now be able to do
- Frame a fuzzy business problem as a modellable task, and **choose a success metric before modeling**.
- Clean messy real-world data (duplicates, missing values, wrong types) and explore it with matplotlib EDA.
- Build a **leak-proof `Pipeline` + `ColumnTransformer`** that preprocesses and predicts as one object.
- Establish a baseline, then tune a stronger model with cross-validation and compare them **honestly on one split**.
- Read a confusion matrix, precision/recall/F1, and ROC-AUC, and perform **error analysis** that yields concrete fixes.
- Save a fitted pipeline with `joblib`, sketch a Flask/Streamlit service around it, and make the project **reproducible** (`requirements.txt`, `random_state`).
- Write a final report and a portfolio README that communicate the work to a non-author.

## Review questions

1. Why is **accuracy** a misleading metric for churn, and what did we use instead and why?
2. What does it mean for a pipeline to be **leak-proof**, and which scikit-learn objects make it so?
3. You report 73% accuracy. A teammate says a `DummyClassifier` also gets 73%. What does that tell you, and how do you respond?
4. Why must hyperparameter tuning (`GridSearchCV`) happen on the **training data only**, never touching the test split?
5. In a churn confusion matrix laid out `[[TN, FP], [FN, TP]]`, which cell is usually the *most expensive* mistake for the business, and why?
6. What is the difference between a model's predicted **probability** and its predicted **label**, and how could you trade precision for recall without retraining?
7. Why do we save the **whole `Pipeline`** with joblib rather than just the trained classifier?
8. Your tuned Random Forest ties the logistic-regression baseline on F1. Which do you ship, and how do you justify it in your report?
9. Name two concrete habits that make an ML project **reproducible** by someone else.
10. What does **ROC-AUC** measure that a single F1 score does not?

## Answers

<details>
<summary>Show answers</summary>

1. **Accuracy** rewards predicting the majority class. With ~73% of customers staying, a model that always says "stay" scores 73% accuracy while catching *zero* churners. We used **F1 (and recall) on the churn class**, which only looks good if the model actually finds churners.

2. **Leak-proof** means no information from the test set (or from the future) influences training. We achieve it by putting all preprocessing — imputation, scaling, one-hot encoding — *inside* the `Pipeline`/`ColumnTransformer`, so the transformers learn their parameters from training folds only and reapply them to held-out data. Fitting a scaler on the whole dataset before splitting would leak.

3. It tells you your model has **learned nothing useful** — it's no better than always guessing the majority class. The right response is to stop quoting accuracy and report F1/recall on the churn class, which would expose the dummy's near-zero score and reveal whether the real model adds value.

4. The test split is your stand-in for unseen production data. If you tune on it, you've effectively *peeked* and your reported test score becomes optimistic — you've leaked the test set into model selection. CV inside the training data gives an honest estimate while keeping the test split pristine for one final evaluation.

5. The **FN** cell (bottom-left): customers who churned but were predicted to stay. These are customers you never tried to retain — lost revenue with zero intervention. A false positive only wastes a retention offer on someone who'd have stayed, which is usually cheaper.

6. The **probability** is the model's continuous confidence (e.g. P(churn)=0.62); the **label** is the discrete decision after applying a threshold (0.62 ≥ 0.5 → "churn"). You can trade precision for recall by **moving the threshold**: lowering it below 0.5 flags more customers as churners (higher recall, lower precision) — no retraining needed, since you reuse `predict_proba`.

7. Because the pipeline contains the *learned* preprocessing (imputation medians, scaler means, encoder categories) as well as the model. Saving only the classifier means re-doing preprocessing by hand at serve time — a prime source of train/serve skew. Save the whole thing and prediction is one `.predict()` call.

8. **Ship the logistic regression** (the baseline). When two models tie on the chosen metric, prefer the simpler, faster, more interpretable one. Justify it honestly: "Random Forest matched but did not beat the baseline F1; we ship logistic regression for interpretability and lower complexity." Faking an improvement would undermine the report's credibility.

9. Any two of: pin dependency versions in a `requirements.txt`; fix every `random_state` (split, CV, model); provide clear run instructions; version-control the code; script or link the dataset download instead of relying on a local file.

10. **ROC-AUC** measures how well the model *ranks* customers by risk across **all possible thresholds** — it's threshold-independent. A single F1 reflects performance at one specific threshold (usually 0.5). A model can have great ranking (high AUC) but poor F1 at 0.5 if its threshold is badly placed.

</details>

## Hands-on tasks

1. **Run the full capstone end to end in one script.** Concatenate the lesson-02 loader, lesson-03 `clean_churn`, the lesson-04 split + baseline, the lesson-05 tuned RF, and the lesson-06 evaluation. Confirm it runs top-to-bottom with no errors and prints a baseline F1, a tuned F1, and a confusion matrix.

2. **Save and reload your shipped model.** Add `joblib.dump(model, "churn_pipeline.joblib")`, then in a *fresh* script `joblib.load` it and score one hand-written customer row (e.g. tenure 2, charges 95, Month-to-month, no support). Verify the probability is high.

3. **Fill in both templates.** Copy lesson 07 into `report.md` and lesson 08 into `README.md`, and replace every bracket with your real numbers and findings. Read them back as if you were a recruiter.

4. **Point the pipeline at real data.** Download the public Telco Customer Churn dataset, swap `load_churn()` for `pd.read_csv(...)` (handle its `TotalCharges` blank-string quirk), and rerun. Note how your F1 and error patterns change versus the toy data — this is the moment the project becomes genuinely yours.

## Next steps beyond this course
- **Publish the repo** on GitHub with the README, report, pinned `requirements.txt`, and a clean commit history. A live link beats a private folder every time.
- **Write it up** — a short blog post or LinkedIn note: the problem, your metric choice, the headline result, and the most interesting thing error analysis revealed.
- **Try a second, different dataset** (a Kaggle classification problem in another domain) using the same workflow. Reusing the pipeline on new data proves the skill is yours, not the tutorial's.
- **Deploy it for real** — wrap the saved pipeline in a Streamlit app and host it for free, so you can send a working demo link, not just code.

## You're ready for the next module when…
- [ ] My capstone runs end-to-end from a clean clone and beats the dummy baseline on F1.
- [ ] I can explain my metric choice and at least one concrete error pattern out loud.
- [ ] My `report.md` and `README.md` are fully filled in with real test-split numbers.
- [ ] The project is pushed to a public GitHub repo with pinned dependencies and a license.

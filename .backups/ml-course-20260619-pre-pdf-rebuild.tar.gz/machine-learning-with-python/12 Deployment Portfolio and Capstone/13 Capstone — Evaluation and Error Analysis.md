# Lab — Capstone: Evaluation and Error Analysis

## Objective

Go beyond a single F1 number. You'll read the full **confusion matrix**, compute **precision / recall / F1** per class, measure **ROC-AUC** (which judges the model's ranking, independent of the 0.5 threshold), and then do the part most beginners skip: **error analysis**. You'll pull out the model's actual mistakes — false negatives and false positives — look at the customers behind them, hypothesize *why* the model erred, and turn those hypotheses into concrete fixes and new features. This is how you'd justify shipping (or not shipping) the model to a stakeholder.

## Dataset

Same cleaned churn data, same frozen split, and the tuned model (or the baseline — pick the one you'll ship). Paste the lesson-02 loader, lesson-03 `clean_churn`, and rebuild the split + a fitted pipeline:

```python
# (paste loader + clean_churn first)
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression

clean = clean_churn(load_churn())
X = clean.drop(columns=["customer_id", "churn"]); y = clean["churn"]
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.30, random_state=42, stratify=y)

preprocess = ColumnTransformer([
    ("num", Pipeline([("impute", SimpleImputer(strategy="median")),
                      ("scale",  StandardScaler())]), ["tenure_months", "monthly_charges"]),
    ("cat", Pipeline([("impute", SimpleImputer(strategy="most_frequent")),
                      ("onehot", OneHotEncoder(handle_unknown="ignore"))]),
                      ["contract_type", "has_support"]),
])
model = Pipeline([("prep", preprocess),
                  ("model", LogisticRegression(max_iter=1000, random_state=42))]).fit(X_tr, y_tr)
```

## Steps

**Step 1 — Confusion matrix.** Rows are truth, columns are prediction. The four cells are the whole story: true negatives, false positives, false negatives, true positives.

```python
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
import matplotlib.pyplot as plt

y_pred = model.predict(X_te)
cm = confusion_matrix(y_te, y_pred, labels=[0, 1])
print("Confusion matrix [rows=true, cols=pred]:\n", cm)
#  [[TN FP]
#   [FN TP]]   <- FN (bottom-left) = churners we MISSED, the costly mistake

ConfusionMatrixDisplay(cm, display_labels=["stay(0)", "churn(1)"]).plot(cmap="Purples")
plt.title("Confusion matrix")
plt.tight_layout(); plt.show()
```

**Step 2 — Precision, recall, F1 per class.** `classification_report` lays out all three for both classes at once.

```python
from sklearn.metrics import classification_report
print(classification_report(y_te, y_pred, target_names=["stay", "churn"], digits=3))
```
Focus on the **churn** row: recall = fraction of real churners we caught; precision = fraction of our churn-flags that were right.

**Step 3 — ROC-AUC.** This scores how well the model *ranks* customers by risk, regardless of the 0.5 cutoff. 1.0 = perfect ranking, 0.5 = coin flip.

```python
from sklearn.metrics import roc_auc_score, RocCurveDisplay
proba = model.predict_proba(X_te)[:, 1]               # P(churn) for each test customer
print("ROC-AUC:", round(roc_auc_score(y_te, proba), 3))

RocCurveDisplay.from_predictions(y_te, proba)
plt.title("ROC curve")
plt.tight_layout(); plt.show()
```

**Step 4 — Build an error table.** Join predictions and probabilities back onto the original test rows so each mistake has a face.

```python
import pandas as pd

results = X_te.copy()
results["true"]  = y_te.values
results["pred"]  = y_pred
results["proba"] = proba.round(3)

false_neg = results[(results["true"] == 1) & (results["pred"] == 0)]   # missed churners
false_pos = results[(results["true"] == 0) & (results["pred"] == 1)]   # false alarms
print(f"False negatives: {len(false_neg)} | False positives: {len(false_pos)}")
print("\n--- FALSE NEGATIVES (churners we missed) ---")
print(false_neg if len(false_neg) else "none on this split")
print("\n--- FALSE POSITIVES (we cried wolf) ---")
print(false_pos if len(false_pos) else "none on this split")
```

**Step 5 — Inspect the near-misses even when there are no hard errors.** On this tiny, well-separated sample the model may make **zero** mistakes — so look at the *least confident* correct predictions, which are the cases most likely to flip on real data.

```python
borderline = results.reindex(
    (results["proba"] - 0.5).abs().sort_values().index).head(3)
print("Least-confident predictions (closest to 0.5):")
print(borderline)
```

## Expected output

- On the real Telco data: expect a confusion matrix with a meaningful **FN** count, churn-class **recall around 0.5–0.7**, and **ROC-AUC around 0.80–0.85** — solid but imperfect. The error tables in Step 4 will be populated and worth reading.
- On this teaching sample: precision/recall/F1 for churn are often **1.0** and ROC-AUC **1.0**, with **empty** FN/FP tables — because `contract_type` nearly determines the label. Don't be fooled: that's the toy data being easy, not a triumph. Step 5's borderline cases are what to study here.

## Error analysis — turn mistakes into actions

Whatever your split produces, write up the *pattern* behind the errors. On realistic churn data the recurring story is:

- **False negatives (missed churners) cluster among short-tenure, month-to-month, high-charge customers** whose behavior looked superficially like a stayer (maybe they had support = yes). *Why:* the model leaned on contract type and under-weighted the tenure × charges interaction. *Fix:* engineer an interaction feature (`charges_per_tenure`), or add `class_weight="balanced"` to push recall up; lowering the decision threshold below 0.5 also recovers FNs (at the cost of precision).
- **False positives (false alarms) cluster among newer annual-contract customers** the model over-penalized for high charges. *Why:* high charges correlate with churn overall, but not within long contracts. *Fix:* the interaction feature again, or more data so the model learns the conditional pattern. A false positive is cheaper here (a wasted retention offer), so we tolerate more of them to catch churners.
- **Borderline cases (proba near 0.5)** are where a threshold tweak has the most leverage — and where extra features (payment method, recent support tickets, usage trend) would help most.

The deliverable of error analysis is a short list like the above: *what went wrong, the likely cause, and a concrete next step.* That paragraph is often the most impressive part of a portfolio project, because it shows you understand the model's failure modes, not just its score.

## Extension challenge

1. Sweep the decision threshold: for thresholds `0.3, 0.4, 0.5, 0.6`, recompute precision and recall (`(proba >= t).astype(int)`). Plot the precision–recall trade-off and pick the threshold that matches the business cost of a missed churner.
2. Re-run the whole evaluation on the **Random Forest** from lesson 05. Do its errors fall on the same customers, or different ones? Disagreement between models flags genuinely hard cases.
3. Add `charges_per_tenure = monthly_charges / (tenure_months + 1)` as a new feature in the pipeline, refit, and check whether the false negatives shrink — closing the loop from error analysis to a real fix.

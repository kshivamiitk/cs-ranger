# From Notebook to Shipped Model

> A model that only runs in your notebook helps nobody — shipping it means saving the whole pipeline, wrapping it behind a request, and making it reproducible by someone who isn't you.

## What you'll learn
- Why you save the **whole fitted pipeline** with `joblib`, not just the final estimator or the raw weights.
- How to load that saved artifact in a fresh process and serve a single prediction.
- What "in production" actually means, and the minimal shape of a Flask endpoint or a Streamlit app that exposes your model.
- The two pillars of reproducibility: a pinned `requirements.txt` and a fixed `random_state`.

## Intuition

Think of your trained pipeline as a sealed factory machine, not a recipe scribbled in a notebook. During training you fed it raw, messy rows and it learned two things at once: **how to transform** the input (impute missing values, scale numbers, one-hot encode categories) and **how to predict** from those transformed numbers. If you save only the classifier and re-do the preprocessing by hand later, you will almost certainly do it slightly differently — a different median for imputation, a forgotten column — and your predictions silently drift. The fix is to save the *entire* `Pipeline` object as one file. It already contains the learned medians, the learned category lists, and the learned model weights. Load it, call `.predict()`, done.

"In production" is less glamorous than it sounds. It just means: a *different* computer, running *without you watching*, takes a new row of data and returns a prediction in a fraction of a second, over and over, for real users. That computer doesn't have your notebook, your variables in memory, or your training data. All it has is the artifact file you shipped and the code that loads it. Everything that mattered during training must have been baked into that artifact, or it won't work.

A useful mental model: your notebook is the *kitchen* where you develop the dish; the saved pipeline is the *frozen meal*; the Flask/Streamlit app is the *microwave* that reheats it on demand for a customer. The customer never sees your kitchen.

## Python in practice

First, train a pipeline and save it. We use the breast-cancer dataset so this runs offline, but the *pattern* is identical to the churn pipeline you'll build in the capstone.

```python
import joblib
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler

X, y = load_breast_cancer(return_X_y=True)
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y)  # fixed seed = reproducible split

# The WHOLE thing is one object: scaling + model. Both get fitted together.
pipe = Pipeline([
    ("scale", StandardScaler()),
    ("model", LogisticRegression(max_iter=5000, random_state=42)),
])
pipe.fit(X_tr, y_tr)

# Save the fitted pipeline to disk as a single artifact.
joblib.dump(pipe, "churn_pipeline.joblib")   # creates one file you can ship
print("Saved. Test accuracy now:", round(pipe.score(X_te, y_te), 3))
```

Now simulate "production": a *fresh* program that has never seen the training data. It only loads the file and predicts.

```python
import joblib
import numpy as np

# A brand-new process would start here. No training code, no original data.
model = joblib.load("churn_pipeline.joblib")

# One incoming "request" — a single raw row with the same columns as training.
new_row = np.array([[14.0, 20.0, 90.0, 600.0, 0.1, 0.1, 0.05, 0.03, 0.18, 0.06,
                     0.4, 1.2, 2.8, 40.0, 0.006, 0.02, 0.02, 0.01, 0.02, 0.003,
                     16.0, 27.0, 105.0, 800.0, 0.13, 0.25, 0.27, 0.11, 0.29, 0.08]])
proba = model.predict_proba(new_row)[0, 1]   # confidence for the positive class
label = int(model.predict(new_row)[0])
print(f"label={label}  probability={proba:.3f}")   # e.g. label=1  probability=0.987
```

Notice the production code never imports `StandardScaler` or re-scales anything — the scaler's learned mean/std rode along inside the pipeline.

### Wrapping it in a tiny service (illustration only)

You don't run these here, but this is *all* a minimal web service is. A **Flask** JSON endpoint:

```python
# app.py  — run with: python app.py  (needs `pip install flask`)
import joblib
import pandas as pd
from flask import Flask, request, jsonify

app = Flask(__name__)
model = joblib.load("churn_pipeline.joblib")   # load ONCE at startup, not per request

@app.post("/predict")
def predict():
    row = pd.DataFrame([request.get_json()])    # client sends a JSON object of features
    proba = float(model.predict_proba(row)[0, 1])
    return jsonify({"churn_probability": round(proba, 3),
                    "prediction": int(proba >= 0.5)})

if __name__ == "__main__":
    app.run(port=8000)
```

Or a **Streamlit** app, which gives you an instant web UI with sliders instead of JSON:

```python
# streamlit_app.py  — run with: streamlit run streamlit_app.py
import joblib
import pandas as pd
import streamlit as st

model = joblib.load("churn_pipeline.joblib")
st.title("Churn predictor")
tenure = st.slider("Tenure (months)", 0, 72, 12)
charges = st.slider("Monthly charges", 0.0, 150.0, 70.0)
contract = st.selectbox("Contract", ["Month-to-month", "One year", "Two year"])
if st.button("Predict"):
    row = pd.DataFrame([{"tenure_months": tenure,
                         "monthly_charges": charges,
                         "contract_type": contract}])
    st.metric("Churn probability", f"{model.predict_proba(row)[0,1]:.0%}")
```

Flask is for *machines* calling your model (another app, a backend); Streamlit is for *humans* clicking around. Pick based on your audience.

### Reproducibility: the part beginners skip

A model is only "shipped" if someone else can recreate it. Two cheap habits make that possible:

```python
# 1) Pin your environment so the same versions install everywhere.
#    Generate it from your working environment:
#    $ pip freeze > requirements.txt
#    A trimmed requirements.txt for this project might read:
#       scikit-learn==1.4.2
#       pandas==2.2.2
#       numpy==1.26.4
#       joblib==1.4.0

# 2) Fix every source of randomness so results are identical run-to-run.
from sklearn.ensemble import RandomForestClassifier
RandomForestClassifier(random_state=42)   # same seed -> same trees -> same predictions
# train_test_split(..., random_state=42), cross_val with a fixed seed, etc.
```

Without these, your colleague installs a newer scikit-learn, the API changed, the unpickling warns or breaks, and your "finished" model is suddenly irreproducible.

## Common mistakes
- **Saving only the model, not the pipeline.** If you `joblib.dump` just the `LogisticRegression`, you lose the scaler/encoder and must re-preprocess by hand — a recipe for train/serve skew. Save the whole `Pipeline`.
- **Re-fitting the scaler at prediction time.** Production data has no labels and often arrives one row at a time; you must *reuse* the training-time transformer (which the pipeline does for you), never `fit` again.
- **Loading the model inside the request handler.** That re-reads the file on every call and tanks latency. Load once at startup, into a module-level variable.
- **No version pinning.** Unpickling a scikit-learn object with a mismatched library version can raise `InconsistentVersionWarning` or silently misbehave. Pin versions in `requirements.txt`.
- **Forgetting `random_state`.** Without fixed seeds, your "result" changes every run and you can't tell a real improvement from noise.

## Small exercise

Run the first two code blocks to create `churn_pipeline.joblib`, then write a *third*, separate script that only does `model = joblib.load("churn_pipeline.joblib")` and predicts on `new_row`. Confirm you get the same probability without importing `StandardScaler` or `load_breast_cancer`. (Hint: if it works with zero preprocessing code, your artifact is correctly self-contained.)

## Before you continue
- [ ] I can explain why I save the whole `Pipeline` instead of just the estimator.
- [ ] I can load a `.joblib` artifact in a fresh process and produce a prediction.
- [ ] I can describe, in one sentence each, what Flask and Streamlit add on top of the model.
- [ ] I know the two reproducibility habits: pin `requirements.txt` and fix `random_state`.

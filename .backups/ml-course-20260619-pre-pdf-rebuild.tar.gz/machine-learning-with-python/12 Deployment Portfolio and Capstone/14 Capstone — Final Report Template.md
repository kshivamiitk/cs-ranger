# Capstone — Final Report Template

> A model without a write-up is invisible to employers — copy this template, fill every bracketed blank with *your* numbers and findings, and you have a report a hiring manager can read in five minutes.

## How to use this template
- Copy everything inside the fenced block below into a new file (e.g. `report.md`) in your project.
- Replace every `[ ... ]` placeholder with your own content. Delete the italic *hints*.
- Keep it short and specific. A great report is one page of real numbers, not three pages of hedging.
- Use the metric you committed to in lesson 02 (F1 / recall on the churn class). Report it on your **held-out test split**, not on training data.

```markdown
# Predicting Customer Churn — Capstone Report

**Author:** [your name]   ·   **Date:** [YYYY-MM-DD]   ·   **Code:** [link to your repo]

## 1. Problem
[One paragraph: who the customer is, why churn matters to them, and the decision the model
supports — e.g. "target a limited retention budget at the highest-risk customers."]
- **Target:** [churn = 1 if the customer left, else 0]
- **Type:** [binary classification]
- **Most costly error:** [false negative — a churner we failed to flag and never tried to save]

## 2. Data
- **Source:** [inline teaching sample of N customers / public Telco Customer Churn, ~7k rows]
- **Rows / columns:** [N rows × M columns]
- **Features used:** [tenure_months, monthly_charges, contract_type, has_support, ...]
- **Cleaning performed:** [dropped K duplicate rows; imputed has_support with the mode;
  coerced churn/tenure to int; validated charge/tenure ranges]
- **Known limitations:** [tiny/imbalanced sample; snapshot not time-series; no fairness audit; ...]

## 3. Method
- **Success metric (chosen before modeling):** [F1 on the churn class; recall watched closely]
- **Validation scheme:** [single held-out test split, test_size=0.30, stratified, random_state=42;
  hyperparameters tuned with 3-fold stratified CV on the training set only]
- **Preprocessing:** [ColumnTransformer — median-impute + StandardScaler on numerics;
  mode-impute + OneHotEncoder(handle_unknown="ignore") on categoricals — all inside the Pipeline]
- **Models compared:** [DummyClassifier baseline → LogisticRegression → tuned RandomForestClassifier]

## 4. Results
*Report your real numbers on the same held-out split.*

| Model                    | Accuracy | Precision (churn) | Recall (churn) | F1 (churn) | ROC-AUC |
|--------------------------|----------|-------------------|----------------|------------|---------|
| Majority-class baseline  | [ ]      | [ ]               | [0.00]         | [0.00]     | [0.50]  |
| Logistic Regression      | [ ]      | [ ]               | [ ]            | [ ]        | [ ]     |
| Random Forest (tuned)    | [ ]      | [ ]               | [ ]            | [ ]        | [ ]     |

- **Chosen model & why:** [name the model you'd ship and the honest reason — best F1, or a tie
  resolved in favor of the simpler/more interpretable model.]
- **Best hyperparameters:** [n_estimators=..., max_depth=..., min_samples_leaf=...]
- **One-line verdict:** [the chosen model improved churn F1 from [baseline] to [final], a [+X] gain.]

## 5. Error analysis
- **False negatives looked like:** [e.g. short-tenure, month-to-month, high-charge customers with
  has_support=yes — superficially resembled stayers.]
- **False positives looked like:** [e.g. newer annual-contract customers over-penalized for high charges.]
- **Likely cause:** [model under-weighted the tenure × charges interaction.]
- **Concrete fix tried / proposed:** [added charges_per_tenure feature / class_weight="balanced" /
  lowered the decision threshold to 0.4 to favor recall.]

## 6. Limitations
- [Sample size / imbalance and what it means for confidence in the numbers.]
- [Snapshot data; no temporal validation; no leakage check beyond the pipeline.]
- [No fairness/bias review; features available may differ in production.]

## 7. Next steps
- [Validate on the full public Telco dataset / collect more rows.]
- [Add features: payment method, recent support tickets, usage trend.]
- [Calibrate probabilities and tune the threshold to the business cost of each error type.]
- [Wrap the saved pipeline in a Flask/Streamlit service and monitor it in production.]

## How to reproduce
```
pip install -r requirements.txt
python train.py        # fits the pipeline, prints the metrics in section 4, saves churn_pipeline.joblib
```
All randomness is seeded with random_state=42, so the numbers above reproduce exactly.
```

## What "done" looks like
- [ ] Every bracket is replaced with a real value or sentence.
- [ ] The results table is filled from your **test split**, and the baseline row is there for contrast.
- [ ] Section 5 names a concrete error pattern and a concrete fix — not "the model could be improved."
- [ ] Someone who has never seen your code could read this and understand what you did and how well it worked.

# Lab — Capstone: Cleaning and EDA

## Objective

Take the raw, messy churn dataset from lesson 02 and turn it into a clean, analysis-ready table: drop the duplicate, fix data types, and impute the missing `has_support` values. Then *look* at the data — compute churn rate by contract type, compare the monthly-charges distribution for churners vs stayers — and write down three concrete insights that will guide your modeling. By the end you'll have a `clean_churn()` function the rest of the capstone depends on.

## Dataset

We reuse the exact dataset defined in lesson 02. Raw, it has six columns and these known defects:

| Defect | Where | Fix |
|---|---|---|
| Duplicate row | `C035` appears twice | `drop_duplicates()` |
| Missing values | `has_support` blanks → `NaN` | impute with the most frequent value |
| Wrong type risk | `churn` should be integer 0/1 | enforce `int` |

Here is the loader again (identical to lesson 02 — paste it at the top of your script):

```python
import io
import pandas as pd

CHURN_CSV = """customer_id,tenure_months,monthly_charges,contract_type,has_support,churn
C001,2,85.5,Month-to-month,no,1
C002,34,56.95,One year,yes,0
C003,1,75.0,Month-to-month,,1
C004,45,42.30,Two year,yes,0
C005,8,99.10,Month-to-month,no,1
C006,60,29.85,Two year,yes,0
C007,3,80.0,Month-to-month,no,1
C008,22,70.45,One year,yes,0
C009,5,89.90,Month-to-month,,1
C010,48,35.50,Two year,yes,0
C011,2,95.25,Month-to-month,no,1
C012,18,65.00,One year,no,0
C013,1,78.80,Month-to-month,,1
C014,55,40.15,Two year,yes,0
C015,9,92.00,Month-to-month,no,1
C016,30,58.40,One year,yes,0
C017,4,84.60,Month-to-month,no,1
C018,40,45.90,Two year,yes,0
C019,6,88.25,Month-to-month,,1
C020,25,62.10,One year,yes,0
C021,2,97.50,Month-to-month,no,1
C022,52,38.70,Two year,yes,0
C023,7,90.30,Month-to-month,no,1
C024,15,68.00,One year,no,0
C025,3,82.40,Month-to-month,,1
C026,58,33.25,Two year,yes,0
C027,10,93.75,Month-to-month,no,1
C028,28,60.50,One year,yes,0
C029,1,76.20,Month-to-month,no,1
C030,50,41.00,Two year,yes,0
C031,12,71.90,One year,yes,0
C032,4,86.80,Month-to-month,,1
C033,38,47.55,Two year,yes,0
C034,20,64.30,One year,no,0
C035,5,91.40,Month-to-month,no,1
C035,5,91.40,Month-to-month,no,1
"""

def load_churn():
    return pd.read_csv(io.StringIO(CHURN_CSV))
```

## Steps

**Step 1 — Inspect the damage.** Always profile before you clean, so you know what you're fixing.

```python
df = load_churn()
print("Shape:", df.shape)                      # (36, 6)
print("\nMissing per column:\n", df.isna().sum())
print("\nDuplicate rows:", df.duplicated().sum())   # 1 (the repeated C035)
print("\nDtypes:\n", df.dtypes)
```
You should see `has_support` with 7 missing values and exactly 1 fully-duplicated row.

**Step 2 — Drop the exact duplicate.** A row identical in every column is almost always a data-entry artifact, not two real customers.

```python
df = df.drop_duplicates().reset_index(drop=True)   # 36 -> 35 rows
print("After de-dup:", df.shape)                    # (35, 6)
```

**Step 3 — Impute the missing `has_support`.** It's categorical, so fill with the **most frequent** value (the mode). We compute it explicitly so you see what's happening; in the model lessons a `SimpleImputer` does this inside the pipeline.

```python
mode_support = df["has_support"].mode()[0]          # most common value, e.g. "yes"
df["has_support"] = df["has_support"].fillna(mode_support)
print("Mode used for imputation:", mode_support)
print("Missing now:", df["has_support"].isna().sum())   # 0
```

**Step 4 — Fix types and sanity-check ranges.** Make `churn` an integer label and confirm numbers are sane (no negative tenure, charges in a plausible band).

```python
df["churn"] = df["churn"].astype(int)
df["tenure_months"] = df["tenure_months"].astype(int)
df["monthly_charges"] = df["monthly_charges"].astype(float)

assert df["churn"].isin([0, 1]).all(),            "churn must be 0/1"
assert (df["tenure_months"] >= 0).all(),          "tenure can't be negative"
assert df["monthly_charges"].between(0, 200).all(), "charges out of expected range"
print("Clean shape:", df.shape, "| dtypes OK")
```

**Step 5 — Wrap it in a reusable function.** Lessons 04–06 call this to get the clean table without repeating the steps.

```python
def clean_churn(raw):
    out = raw.drop_duplicates().reset_index(drop=True)
    out["has_support"] = out["has_support"].fillna(out["has_support"].mode()[0])
    out["churn"] = out["churn"].astype(int)
    out["tenure_months"] = out["tenure_months"].astype(int)
    out["monthly_charges"] = out["monthly_charges"].astype(float)
    return out

clean = clean_churn(load_churn())
```

**Step 6 — EDA: churn rate by contract type.** Group and plot. This is the single most important picture in churn analysis.

```python
import matplotlib.pyplot as plt

rate = clean.groupby("contract_type")["churn"].mean().sort_values(ascending=False)
print(rate)

fig, ax = plt.subplots(figsize=(6, 4))
rate.plot(kind="bar", ax=ax, color="#a78bfa")
ax.set_ylabel("Churn rate")
ax.set_title("Churn rate by contract type")
ax.set_ylim(0, 1)
plt.tight_layout()
plt.show()
```

**Step 7 — EDA: monthly-charges distribution by churn.** Overlapping histograms reveal whether price separates the two groups.

```python
fig, ax = plt.subplots(figsize=(6, 4))
stayed  = clean.loc[clean["churn"] == 0, "monthly_charges"]
churned = clean.loc[clean["churn"] == 1, "monthly_charges"]
ax.hist(stayed,  bins=8, alpha=0.6, label="stayed (0)",  color="#22d3ee")
ax.hist(churned, bins=8, alpha=0.6, label="churned (1)", color="#f87171")
ax.set_xlabel("Monthly charges")
ax.set_ylabel("Count")
ax.set_title("Monthly charges by churn outcome")
ax.legend()
plt.tight_layout()
plt.show()
```

## Expected output

- The grouped table from Step 6 shows **Month-to-month** with by far the highest churn rate, and **Two year** the lowest — in this teaching sample the split is stark (close to 1.0 vs 0.0). The real Telco data is softer but the *direction* is identical: short contracts churn far more.
- The histogram in Step 7 shows churners clustered at **high monthly charges** (roughly 75–100) and stayers at **lower charges** (roughly 30–70), with some overlap in the middle. Good EDA looks like this: clear, but not perfectly separated.
- All assertions in Step 4 pass silently. If one fires, your cleaning has a bug — fix it before modeling.

## Three insights to write down

After running the lab, record these (you'll cite them in your final report):

1. **Contract type is the strongest signal.** Month-to-month customers churn dramatically more than annual-contract customers — locking customers into longer contracts is the obvious retention lever.
2. **High monthly charges track with churn.** Churners pay more on average; price sensitivity is real, and discounts may be an effective intervention for high-charge, short-tenure customers.
3. **Short tenure is a red flag.** Almost everyone who churns has low `tenure_months` — the riskiest window is early in the customer's life, so onboarding and early engagement matter.

## Extension challenge

1. Add a third EDA plot: a boxplot of `tenure_months` split by `churn` (`clean.boxplot(column="tenure_months", by="churn")`). Does it confirm insight 3?
2. Recompute the churn-rate table broken down by **both** `contract_type` and `has_support` (`groupby(["contract_type","has_support"])`). Does support membership add anything beyond contract type?
3. Swap `load_churn()` for a download of the real Telco CSV and rerun `clean_churn` — you'll need to also coerce its `TotalCharges` column (which arrives as text with blanks). Note what extra cleaning the bigger data demands.

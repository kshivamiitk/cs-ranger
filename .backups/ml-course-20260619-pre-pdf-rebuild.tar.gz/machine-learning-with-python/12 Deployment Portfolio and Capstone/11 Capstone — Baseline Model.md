# Lab — Capstone: Baseline Model

## Objective

Establish the **bar to beat**. Before reaching for a fancy model, build the two simplest things that count as predictions: (1) a dumb "predict the majority class" baseline, and (2) a plain `LogisticRegression` wrapped in a **leak-proof** `Pipeline` with a `ColumnTransformer`. You'll evaluate both with the F1 metric we committed to in lesson 02, on a single held-out test split. Every later model must beat *this* number on *this* split, or it isn't an improvement.

## Dataset

We continue with the cleaned churn table. Paste the lesson-02 loader and the lesson-03 `clean_churn()` at the top of your script, then:

```python
clean = clean_churn(load_churn())
X = clean.drop(columns=["customer_id", "churn"])   # features (drop the ID -- it's not predictive)
y = clean["churn"]                                  # target

print(X.columns.tolist())   # ['tenure_months', 'monthly_charges', 'contract_type', 'has_support']
print("Class balance:\n", y.value_counts())
```

Features split into two types, which the `ColumnTransformer` will treat differently:
- **Numeric:** `tenure_months`, `monthly_charges` → scale them.
- **Categorical:** `contract_type`, `has_support` → one-hot encode them.

## Steps

**Step 1 — Make the held-out split first, and freeze it.** Everything is judged on this exact split. `stratify=y` keeps the churn ratio the same in train and test; `random_state` makes it reproducible.

```python
from sklearn.model_selection import train_test_split

X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.30, random_state=42, stratify=y)
print("Train:", X_tr.shape, " Test:", X_te.shape)   # ~24 train / ~11 test
```

**Step 2 — The majority-class baseline.** `DummyClassifier(strategy="most_frequent")` always predicts the most common training label. This is the floor: if a real model can't beat it, the real model is worthless.

```python
from sklearn.dummy import DummyClassifier
from sklearn.metrics import f1_score, accuracy_score

dummy = DummyClassifier(strategy="most_frequent").fit(X_tr, y_tr)
dummy_pred = dummy.predict(X_te)
print("Dummy accuracy:", round(accuracy_score(y_te, dummy_pred), 3))
print("Dummy F1 (churn):", round(f1_score(y_te, dummy_pred, pos_label=1), 3))
```
Watch what happens: the dummy gets a *deceptively okay* accuracy but an **F1 near 0** for the churn class — it never predicts a churner, so it catches none. This is exactly why we chose F1, not accuracy, back in lesson 02.

**Step 3 — Build a leak-proof preprocessing block with `ColumnTransformer`.** The key idea: the imputer/scaler/encoder learn their parameters (medians, means, category lists) **only from training data**, and the pipeline reapplies them to the test data. Putting preprocessing *inside* the pipeline is what makes it leak-proof.

```python
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder

numeric_cols     = ["tenure_months", "monthly_charges"]
categorical_cols = ["contract_type", "has_support"]

numeric_pipe = Pipeline([
    ("impute", SimpleImputer(strategy="median")),   # safe even though we pre-cleaned
    ("scale",  StandardScaler()),
])
categorical_pipe = Pipeline([
    ("impute", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore")),  # tolerate unseen categories at predict time
])

preprocess = ColumnTransformer([
    ("num", numeric_pipe,     numeric_cols),
    ("cat", categorical_pipe, categorical_cols),
])
```

**Step 4 — Attach a plain LogisticRegression and fit the whole pipeline.** One `fit` call learns the preprocessing *and* the model, all from training data only.

```python
from sklearn.linear_model import LogisticRegression

baseline = Pipeline([
    ("prep",  preprocess),
    ("model", LogisticRegression(max_iter=1000, random_state=42)),
])
baseline.fit(X_tr, y_tr)   # transformers fit on X_tr only -> no leakage
```

**Step 5 — Evaluate on the held-out split with the committed metric.**

```python
lr_pred = baseline.predict(X_te)
print("LogReg accuracy:", round(accuracy_score(y_te, lr_pred), 3))
print("LogReg F1 (churn):", round(f1_score(y_te, lr_pred, pos_label=1), 3))
```

**Step 6 — Record the baseline number.** Write it down; it's the target for lesson 05.

```python
BASELINE_F1 = f1_score(y_te, lr_pred, pos_label=1)
print(f"Bar to beat -> baseline F1 = {BASELINE_F1:.3f}")
```

## Expected output

- **Dummy:** moderate accuracy, **F1 ≈ 0.0** on the churn class. It is a non-predictor dressed up as one.
- **LogisticRegression:** much higher F1 — in this clean, strongly-signalled teaching sample, often **0.9–1.0**, because `contract_type` almost perfectly separates the classes. On the real Telco data expect something more realistic like **F1 ≈ 0.55–0.62**; the high number here is a property of the toy data, not of logistic regression.
- The gap between dummy F1 and logistic-regression F1 is the *value the model adds*. A near-zero dummy F1 versus a high LR F1 is the story you want: the model genuinely learned to find churners.

Interpreting honestly: with only ~11 test rows, a single misclassification swings F1 a lot. Treat this baseline as directional. The *method* — freeze a split, beat a dummy, judge by F1 — is what transfers to real data.

## Extension challenge

1. Re-run Step 1–5 with a *different* `random_state` (say 7) and watch the test F1 move. This volatility is the cost of a tiny dataset — and a perfect motivation for the cross-validation you'll use next lesson.
2. Print the model's learned coefficients: `baseline.named_steps["model"].coef_` alongside the feature names from `baseline.named_steps["prep"].get_feature_names_out()`. Which feature pushes hardest toward "churn"? Does it match your EDA insight about contract type?
3. Add `class_weight="balanced"` to the `LogisticRegression` and see whether F1/recall improve — a cheap fix for imbalance you'll appreciate on the real data.

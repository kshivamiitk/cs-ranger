"use strict";

/* ------------------------------------------------------------------ *
 * Logistic Regression Decision Boundary Explorer
 *
 * Model:   z = w1*x + w2*y + b
 *          p = sigmoid(z) = 1 / (1 + e^-z)      -> P(class = 1)
 *          label = 1 if p >= 0.5  (i.e. z >= 0)
 * Boundary: the line z = 0, i.e. w1*x + w2*y + b = 0  (always LINEAR).
 *
 * "Fit" runs real batch gradient descent on the log-loss:
 *          dL/dw1 = mean( (p - y) * x )
 *          dL/dw2 = mean( (p - y) * y_feat )
 *          dL/db  = mean( (p - y) )
 * ------------------------------------------------------------------ */

// ----- World coordinates: features live in a tidy [-5, 5] box -----
const X_LO = -5, X_HI = 5, Y_LO = -5, Y_HI = 5;
const PAD = { l: 46, r: 18, t: 18, b: 40 };

// ----- DOM -----
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const w1Input = document.getElementById("w1");
const w2Input = document.getElementById("w2");
const bInput = document.getElementById("b");
const w1Val = document.getElementById("w1Val");
const w2Val = document.getElementById("w2Val");
const bVal = document.getElementById("bVal");
const elAcc = document.getElementById("rAcc");
const elLoss = document.getElementById("rLoss");
const elIter = document.getElementById("rIter");
const elStatus = document.getElementById("rStatus");

// ----- Model state -----
let w1 = parseFloat(w1Input.value);
let w2 = parseFloat(w2Input.value);
let b = parseFloat(bInput.value);

// ----- Fit (gradient descent) state -----
let fitting = false;
let fitIter = 0;
let rafId = null;
let lastTick = 0;
const STEP_INTERVAL_MS = 45;   // pace so the line visibly swings into place
const MAX_FIT_STEPS = 400;
const LR = 0.6;                // learning rate for the demo descent

// ----- Data: ~40 points in two roughly-separable Gaussian blobs -----
let points = [];   // [{x, y, label}]

function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

function sigmoid(z) {
  // numerically stable sigmoid (guards overflow for large |z|)
  if (z >= 0) { const e = Math.exp(-z); return 1 / (1 + e); }
  const e = Math.exp(z); return e / (1 + e);
}

// Box-Muller standard normal
function gaussian(mean, sd) {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  return mean + z * sd;
}

function makeData() {
  points = [];
  // Two blob centers placed on opposite sides; small jitter -> some overlap.
  const cx0 = -1.7 + (Math.random() - 0.5) * 0.8;
  const cy0 = -1.4 + (Math.random() - 0.5) * 0.8;
  const cx1 = 1.7 + (Math.random() - 0.5) * 0.8;
  const cy1 = 1.4 + (Math.random() - 0.5) * 0.8;
  const sd = 1.15;
  for (let i = 0; i < 20; i++) {
    points.push({
      x: clamp(gaussian(cx0, sd), X_LO + 0.3, X_HI - 0.3),
      y: clamp(gaussian(cy0, sd), Y_LO + 0.3, Y_HI - 0.3),
      label: 0,
    });
    points.push({
      x: clamp(gaussian(cx1, sd), X_LO + 0.3, X_HI - 0.3),
      y: clamp(gaussian(cy1, sd), Y_LO + 0.3, Y_HI - 0.3),
      label: 1,
    });
  }
}

// ----- Coordinate transforms (world <-> pixels) -----
function plotW() { return canvas.width - PAD.l - PAD.r; }
function plotH() { return canvas.height - PAD.t - PAD.b; }
function xToPx(x) { return PAD.l + ((x - X_LO) / (X_HI - X_LO)) * plotW(); }
function yToPx(y) { return PAD.t + (1 - (y - Y_LO) / (Y_HI - Y_LO)) * plotH(); }
function pxToX(px) { return X_LO + ((px - PAD.l) / plotW()) * (X_HI - X_LO); }
function pxToY(py) { return Y_LO + (1 - (py - PAD.t) / plotH()) * (Y_HI - Y_LO); }

// ----- Metrics -----
function probOf(pt) { return sigmoid(w1 * pt.x + w2 * pt.y + b); }

function accuracy() {
  if (points.length === 0) return 0;
  let correct = 0;
  for (const pt of points) {
    const pred = probOf(pt) >= 0.5 ? 1 : 0;
    if (pred === pt.label) correct++;
  }
  return correct / points.length;
}

function logLoss() {
  if (points.length === 0) return 0;
  let sum = 0;
  const eps = 1e-12;
  for (const pt of points) {
    const p = clamp(probOf(pt), eps, 1 - eps);
    sum += -(pt.label * Math.log(p) + (1 - pt.label) * Math.log(1 - p));
  }
  return sum / points.length;
}

// ----- One batch gradient-descent step (the real update) -----
function fitStep() {
  let g1 = 0, g2 = 0, gb = 0;
  const n = points.length;
  for (const pt of points) {
    const p = sigmoid(w1 * pt.x + w2 * pt.y + b);
    const err = p - pt.label;        // dL/dz for log-loss
    g1 += err * pt.x;
    g2 += err * pt.y;
    gb += err;
  }
  g1 /= n; g2 /= n; gb /= n;
  w1 -= LR * g1;
  w2 -= LR * g2;
  b -= LR * gb;
  // keep within slider ranges so the UI stays consistent
  w1 = clamp(w1, -4, 4);
  w2 = clamp(w2, -4, 4);
  b = clamp(b, -6, 6);
  fitIter++;
  syncSliders();
}

function syncSliders() {
  w1Input.value = w1.toFixed(2);
  w2Input.value = w2.toFixed(2);
  bInput.value = b.toFixed(2);
  w1Val.textContent = w1.toFixed(2);
  w2Val.textContent = w2.toFixed(2);
  bVal.textContent = b.toFixed(2);
}

// ----- Fit animation loop -----
function tick(ts) {
  if (!fitting) return;
  if (!lastTick) lastTick = ts;
  if (ts - lastTick >= STEP_INTERVAL_MS) {
    lastTick = ts;
    fitStep();
    render();
    // stop when nearly converged (gradient tiny) or step cap reached
    if (fitIter >= MAX_FIT_STEPS || nearlyConverged()) { stopFit(true); return; }
  }
  rafId = requestAnimationFrame(tick);
}

let prevLoss = Infinity;
function nearlyConverged() {
  const cur = logLoss();
  const done = Math.abs(prevLoss - cur) < 1e-5;
  prevLoss = cur;
  return done;
}

function startFit() {
  fitting = true;
  fitIter = 0;
  prevLoss = Infinity;
  lastTick = 0;
  setStatus("fitting...", "running");
  rafId = requestAnimationFrame(tick);
}

function stopFit(converged) {
  fitting = false;
  if (rafId) cancelAnimationFrame(rafId);
  rafId = null;
  if (converged) setStatus("fit complete ✓", "good");
  render();
}

function setStatus(text, cls) {
  elStatus.textContent = text;
  elStatus.className = "v" + (cls ? " " + cls : "");
}

// ----- Rendering -----
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawProbField();   // faint shaded half-planes (decision regions)
  drawGrid();
  drawBoundary();
  drawPoints();
  updateReadout();
}

// Map a probability [0,1] to a color: 0 -> cyan, 0.5 -> grey, 1 -> violet.
function probColor(p, alpha) {
  // class-0 anchor (cyan-ish) and class-1 anchor (violet-ish)
  const c0 = [34, 211, 238];
  const c1 = [167, 139, 250];
  const r = Math.round(c0[0] + (c1[0] - c0[0]) * p);
  const g = Math.round(c0[1] + (c1[1] - c0[1]) * p);
  const bl = Math.round(c0[2] + (c1[2] - c0[2]) * p);
  return "rgba(" + r + "," + g + "," + bl + "," + alpha + ")";
}

// Shade the two half-planes by sampling a coarse grid of probabilities.
function drawProbField() {
  const cols = 60, rows = 42;
  const cw = plotW() / cols, ch = plotH() / rows;
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      const px = PAD.l + (i + 0.5) * cw;
      const py = PAD.t + (j + 0.5) * ch;
      const p = sigmoid(w1 * pxToX(px) + w2 * pxToY(py) + b);
      ctx.fillStyle = probColor(p, 0.16);
      ctx.fillRect(PAD.l + i * cw, PAD.t + j * ch, cw + 1, ch + 1);
    }
  }
}

function drawGrid() {
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.fillStyle = "#94a3b8";
  ctx.lineWidth = 1;
  ctx.font = "11px ui-monospace, Menlo, monospace";
  for (let x = X_LO; x <= X_HI; x += 1) {
    const px = xToPx(x);
    ctx.beginPath();
    ctx.moveTo(px, PAD.t);
    ctx.lineTo(px, canvas.height - PAD.b);
    ctx.stroke();
    if (x % 1 === 0) {
      ctx.textAlign = "center";
      ctx.fillText(String(x), px, canvas.height - PAD.b + 16);
    }
  }
  for (let y = Y_LO; y <= Y_HI; y += 1) {
    const py = yToPx(y);
    ctx.beginPath();
    ctx.moveTo(PAD.l, py);
    ctx.lineTo(canvas.width - PAD.r, py);
    ctx.stroke();
    ctx.textAlign = "right";
    ctx.fillText(String(y), PAD.l - 6, py + 4);
  }
  ctx.fillStyle = "#e2e8f0";
  ctx.font = "12px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("feature x", (PAD.l + canvas.width - PAD.r) / 2, canvas.height - 6);
  ctx.restore();
}

// Draw the line  w1*x + w2*y + b = 0  across the visible box.
function drawBoundary() {
  ctx.save();
  ctx.strokeStyle = "#ffffff";
  ctx.lineWidth = 2.5;
  ctx.setLineDash([]);
  const eps = 1e-9;
  let p1 = null, p2 = null;

  if (Math.abs(w2) > eps) {
    // y = -(w1*x + b) / w2  -> evaluate at the left and right edges
    const yL = -(w1 * X_LO + b) / w2;
    const yR = -(w1 * X_HI + b) / w2;
    p1 = { x: X_LO, y: yL };
    p2 = { x: X_HI, y: yR };
  } else if (Math.abs(w1) > eps) {
    // vertical line: x = -b / w1
    const xv = -b / w1;
    p1 = { x: xv, y: Y_LO };
    p2 = { x: xv, y: Y_HI };
  }

  if (p1 && p2) {
    ctx.beginPath();
    ctx.moveTo(xToPx(p1.x), yToPx(p1.y));
    ctx.lineTo(xToPx(p2.x), yToPx(p2.y));
    ctx.stroke();

    // label "p = 0.5" near the middle of the line
    const mx = (xToPx(p1.x) + xToPx(p2.x)) / 2;
    const my = (yToPx(p1.y) + yToPx(p2.y)) / 2;
    ctx.fillStyle = "#e2e8f0";
    ctx.font = "12px ui-monospace, Menlo, monospace";
    ctx.textAlign = "left";
    ctx.fillText("p = 0.5", clamp(mx + 8, PAD.l, canvas.width - 60), clamp(my - 8, PAD.t + 12, canvas.height - PAD.b));
  } else {
    // both weights ~0: no boundary, model is constant. Tell the user.
    ctx.fillStyle = "#f87171";
    ctx.font = "13px Inter, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("weights are ~0 — no boundary (model predicts one class everywhere)",
      canvas.width / 2, PAD.t + 20);
  }
  ctx.restore();
}

function drawPoints() {
  for (const pt of points) {
    const px = xToPx(pt.x), py = yToPx(pt.y);
    const p = probOf(pt);
    // fill = predicted probability gradient; ring = TRUE label so misclass is visible
    ctx.beginPath();
    ctx.arc(px, py, 7, 0, Math.PI * 2);
    ctx.fillStyle = probColor(p, 1);
    ctx.fill();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = pt.label === 1 ? "#a78bfa" : "#22d3ee";
    ctx.stroke();
    // small inner dot in the TRUE label color for extra clarity
    ctx.beginPath();
    ctx.arc(px, py, 2.2, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(11,11,16,0.9)";
    ctx.fill();
  }
}

function updateReadout() {
  const acc = accuracy();
  elAcc.textContent = (acc * 100).toFixed(1) + "%";
  elAcc.className = "v" + (acc >= 0.9 ? " good" : "");
  elLoss.textContent = logLoss().toFixed(3);
  elIter.textContent = String(fitIter);
}

// ----- Controls -----
function readSliders() {
  w1 = parseFloat(w1Input.value);
  w2 = parseFloat(w2Input.value);
  b = parseFloat(bInput.value);
  w1Val.textContent = w1.toFixed(2);
  w2Val.textContent = w2.toFixed(2);
  bVal.textContent = b.toFixed(2);
}

function onSlide() {
  if (fitting) stopFit(false);
  readSliders();
  setStatus("manual", null);
  render();
}

w1Input.addEventListener("input", onSlide);
w2Input.addEventListener("input", onSlide);
bInput.addEventListener("input", onSlide);

document.getElementById("fit").addEventListener("click", () => {
  if (fitting) { stopFit(false); setStatus("paused", null); return; }
  startFit();
});

document.getElementById("reset").addEventListener("click", () => {
  if (fitting) stopFit(false);
  w1 = 0.6; w2 = 0.6; b = 0; fitIter = 0;
  syncSliders();
  setStatus("drag the sliders", null);
  render();
});

document.getElementById("newdata").addEventListener("click", () => {
  if (fitting) stopFit(false);
  makeData();
  fitIter = 0;
  setStatus("new data — try Fit", null);
  render();
});

// ----- Init -----
makeData();
syncSliders();
render();

# Checkpoint — Classification

## What you should now be able to do
- State the difference between classification and regression, and recognize which one a problem needs.
- Explain a decision boundary and how a probability becomes a label via a threshold.
- Fit and interpret `LogisticRegression`, including its sigmoid/log-odds intuition and `predict_proba`.
- Choose between a decision tree, random forest, and KNN based on the situation, and read `feature_importances_`.
- Handle binary and multiclass problems with the same scikit-learn API.

## Review questions

1. You're predicting how many units a store will sell next month. Is that classification or regression? What if you instead predict whether sales will be "above target" or "below target"?
2. In one sentence, what is a decision boundary?
3. A model outputs `P(class=1) = 0.62`. With the default threshold, what label does it assign? Name one situation where you'd lower the threshold below 0.5.
4. What does the sigmoid function do, and why can't a plain linear output serve as a probability?
5. A logistic regression coefficient for a (standardized) feature is `+0.7`. In plain words, what does that tell you about how the feature affects the predicted class?
6. Why does a single decision tree tend to overfit, and how does a random forest reduce that problem?
7. Why must you scale features before using KNN, but scaling matters far less for a random forest?
8. What does `feature_importances_` represent, and which models expose it?
9. You have 3 classes and 4 features and want to *see* the decision boundary on a 2D plot. What's the catch, and one way around it?
10. Iris accuracy of 0.98 on a 30% test split sounds great — name one reason a single split might mislead you, and a tool that addresses it.

## Answers

<details><summary>Show answers</summary>

1. Predicting the *number* of units is **regression**. Predicting "above/below target" turns it into a **binary classification** problem (two categories).
2. A decision boundary is the surface in feature space that separates the regions a model assigns to different classes.
3. With threshold 0.5, `0.62` rounds up to label **1**. You'd lower the threshold when missing a positive is costly and false alarms are cheap — e.g. screening for a disease or detecting fraud, where you want to catch more positives.
4. The sigmoid squashes any real number into the range (0, 1), turning the linear score into a valid probability. A raw linear output can be any value (negative, above 1), so it can't be read as a probability directly.
5. A standardized coefficient of +0.7 means increasing that feature by one standard deviation **raises the log-odds of class 1 by 0.7** (multiplies the odds by `e^0.7 ≈ 2.0`), pushing predictions toward class 1.
6. An unconstrained tree keeps splitting until leaves are pure, memorizing noise (high variance). A random forest trains many trees on bootstrapped rows and random feature subsets and **averages their votes**, cancelling the uncorrelated errors and stabilizing predictions.
7. KNN classifies by raw distance, so a feature with a large numeric range dominates the distance and drowns out others; scaling puts features on equal footing. A random forest splits one feature at a time using thresholds, so the *scale* of a feature doesn't change which split is best.
8. `feature_importances_` is the (normalized, summing to 1) contribution of each feature to reducing impurity across splits. Tree-based models expose it: `DecisionTreeClassifier`, `RandomForestClassifier`, gradient boosting, etc.
9. You can only plot a boundary in 2D, but you have 4 features. Pick two features to plot, or reduce dimensions (e.g. PCA to 2 components) before plotting — accepting that the picture is a simplification.
10. A single random split can be lucky or unlucky in which samples land in the test set, especially on small data. **Cross-validation** (`cross_val_score`) averages over several splits to give a more reliable estimate.

</details>

## Hands-on tasks

1. **Boundary intuition.** Generate `make_classification(n_features=2, n_redundant=0, n_clusters_per_class=1, class_sep=1.0, random_state=3)`. Fit a `LogisticRegression` and a `DecisionTreeClassifier(max_depth=3)`. Plot both decision boundaries (grid + `predict`). Note how the logistic boundary is one straight line while the tree's is stair-stepped.
2. **Probabilities, not labels.** On `load_breast_cancer`, fit a logistic regression and print the 5 test samples whose `P(class=1)` is closest to 0.5. These are the model's least-confident calls — exactly the cases a threshold change would flip.
3. **Model bake-off.** On `load_wine`, run `DecisionTreeClassifier`, `RandomForestClassifier`, and a scaled `KNeighborsClassifier` and print all three test accuracies. Write one sentence saying which you'd deploy and why.

## You're ready for the next module when…
- [ ] I can pick the right model family for a described problem and justify it.
- [ ] I can fit a classifier and report both labels and probabilities.
- [ ] I can read `feature_importances_` and explain a model's decision in plain words.
- [ ] I understand why a single train/test accuracy number can be misleading — the gateway to Model Evaluation.

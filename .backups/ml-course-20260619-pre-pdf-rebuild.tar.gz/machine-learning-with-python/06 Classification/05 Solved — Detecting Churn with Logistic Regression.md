# Solved — Detecting Churn with Logistic Regression

> A telecom wants to phone at-risk subscribers *before* they cancel — so the model must catch churners, even at the cost of a few false alarms.

## Problem statement

You have a subscriber table with four signals — `tenure` (months as a customer), `monthly_charges` (dollars/month), `contract_type` (`month-to-month` / `one-year` / `two-year`), and `support_calls` (tickets in the last 90 days) — and a label `churn` (1 = left, 0 = stayed). Build a model that, given those four fields, outputs **the probability a customer will churn** and a yes/no flag.

The retention team can only call a limited list each week, but a missed churner is far more expensive than a wasted call. So the goal metric is **recall on the churn class** (catch as many real churners as possible), with precision and overall accuracy as secondary checks. Plain accuracy is a trap here: if only 30% churn, a model that screams "nobody churns" is already 70% accurate and 0% useful.

## Data sample

A small, realistic slice (the full inline set below has 24 rows; shape `(24, 5)`, columns `tenure, monthly_charges, contract_type, support_calls, churn`):

| tenure | monthly_charges | contract_type  | support_calls | churn |
|-------:|----------------:|----------------|--------------:|------:|
|      2 |            94.0  | month-to-month |             5 |     1 |
|      1 |            79.5  | month-to-month |             4 |     1 |
|     34 |            56.0  | two-year       |             0 |     0 |
|     48 |            42.0  | one-year       |             1 |     0 |
|      8 |            88.0  | month-to-month |             3 |     1 |
|     60 |            35.0  | two-year       |             0 |     0 |

The pattern baked into the data: **short tenure + high charges + many support calls + a month-to-month contract pushes churn up**; long tenure on a one/two-year contract pulls it down. A good model should recover that, and its coefficients should *show* it.

## Why this problem matters

Acquiring a new subscriber costs many times more than retaining an existing one, so even a small drop in churn moves real revenue. Unlike a black-box score, logistic regression hands the retention team an **interpretable** story — "every extra support call multiplies a customer's churn odds by ~1.5x" — which is exactly what a non-technical stakeholder needs to approve an intervention. And because the business explicitly prefers catching churners over avoiding false alarms, this problem is really about **choosing the decision threshold**, not just fitting a model.

## Step-by-step reasoning

1. **Frame the metric first.** The cost of a missed churner >> the cost of a needless call, so we optimize for **recall** on class 1 and treat the default 0.5 threshold as just a starting point.
2. **Handle mixed feature types without leaking.** `contract_type` is categorical (one-hot encode it); the numeric columns live on wildly different scales (`tenure` 1–60 vs `support_calls` 0–6), so scale them. Crucially, the encoder and scaler must be **fit on training data only** — if we fit them on the full set before splitting, test statistics bleed into training (leakage) and our reported scores are optimistic lies.
3. **Use a `Pipeline` + `ColumnTransformer`.** This bundles "encode + scale → LogisticRegression" into one object. When you call `.fit(X_train)` it fits every step on the training fold; when you call `.predict(X_test)` it reuses those fitted transforms. That makes leakage almost impossible and makes the model deployable as a single unit.
4. **Read coefficients as odds.** Logistic regression is linear in the **log-odds**: `log(p/(1-p)) = w·x + b`. So `exp(coef)` is the multiplier on the churn *odds* per one-unit (here, one-standard-deviation) increase in a feature. Positive coefficient → raises churn odds; negative → lowers them.
5. **Tune the threshold for the goal.** `predict` uses 0.5, but we *want* high recall, so we lower the threshold (e.g. 0.35): more customers get flagged, recall rises, precision falls. We pick the threshold by looking at the precision/recall trade-off, not by default.

## Python solution

```python
import io
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import (classification_report, confusion_matrix,
                             precision_recall_curve)

# --- 1. Inline data (no download). Mixed numeric + categorical columns. ---
csv = """tenure,monthly_charges,contract_type,support_calls,churn
2,94.0,month-to-month,5,1
1,79.5,month-to-month,4,1
3,70.0,month-to-month,3,1
4,99.0,month-to-month,6,1
8,88.0,month-to-month,3,1
6,85.0,month-to-month,4,1
12,75.0,month-to-month,3,1
5,90.0,month-to-month,5,1
10,82.0,month-to-month,2,1
2,96.5,month-to-month,4,1
7,78.0,month-to-month,3,1
9,83.0,one-year,4,1
34,56.0,two-year,0,0
48,42.0,one-year,1,0
60,35.0,two-year,0,0
24,50.0,one-year,1,0
36,45.0,two-year,0,0
50,30.0,two-year,0,0
40,65.0,one-year,1,0
55,38.0,two-year,0,0
30,48.0,one-year,2,0
44,52.0,two-year,1,0
28,60.0,one-year,1,0
38,44.0,two-year,0,0
"""
df = pd.read_csv(io.StringIO(csv))
print("Shape:", df.shape, "| churn rate:", round(df["churn"].mean(), 2))

X = df.drop(columns="churn")
y = df["churn"].values

# Stratify so both classes appear in train and test on this small set.
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.30, random_state=0, stratify=y)

# --- 2. Leak-proof preprocessing inside a Pipeline. ---
numeric = ["tenure", "monthly_charges", "support_calls"]
categorical = ["contract_type"]

pre = ColumnTransformer([
    ("num", StandardScaler(), numeric),
    # handle_unknown keeps prediction safe if an unseen contract type appears.
    ("cat", OneHotEncoder(handle_unknown="ignore"), categorical),
])

clf = Pipeline([
    ("pre", pre),
    ("lr", LogisticRegression(max_iter=1000)),
])

# .fit fits the scaler/encoder on TRAIN ONLY, then the model. No leakage.
clf.fit(X_tr, y_tr)
print("Default-threshold accuracy:", round(clf.score(X_te, y_te), 3))

# --- 3. Interpret coefficients as odds multipliers. ---
# Recover feature names from the fitted ColumnTransformer.
feat_names = (numeric +
              list(clf.named_steps["pre"]
                   .named_transformers_["cat"]
                   .get_feature_names_out(categorical)))
coefs = clf.named_steps["lr"].coef_[0]
print("\nFeature  ->  coef (log-odds)  |  odds multiplier exp(coef)")
for name, c in sorted(zip(feat_names, coefs), key=lambda t: -abs(t[1])):
    print(f"  {name:28s} coef={c:+.2f}   odds x{np.exp(c):.2f}")

# --- 4. Choose a threshold that favors RECALL (catch churners). ---
proba = clf.predict_proba(X_te)[:, 1]        # P(churn) for each test customer
default_pred = (proba >= 0.50).astype(int)
recall_pred  = (proba >= 0.35).astype(int)   # lower bar -> flag more, catch more

print("\n-- Default threshold 0.50 --")
print(classification_report(y_te, default_pred, digits=2, zero_division=0))
print("-- Recall-favoring threshold 0.35 --")
print(classification_report(y_te, recall_pred, digits=2, zero_division=0))
print("Confusion matrix @0.35 [ [TN FP] [FN TP] ]:\n",
      confusion_matrix(y_te, recall_pred))

# Inspect the trade-off curve to justify the chosen threshold.
prec, rec, thr = precision_recall_curve(y_te, proba)
print("\nthreshold  precision  recall")
for p, r, t in zip(prec[:-1], rec[:-1], thr):
    print(f"  {t:5.2f}      {p:5.2f}     {r:5.2f}")
```

## Expected output

- `Shape: (24, 5) | churn rate: 0.46` — a fairly balanced toy set, but the *method* is what generalizes.
- **Default-threshold accuracy** lands around **0.86–1.00** on the 8-row test fold (small set, so it wobbles with the split — that's expected, not a bug).
- **Coefficients (signs are the lesson, magnitudes wobble):** `support_calls` and `monthly_charges` come out **positive** (more calls / higher bill → higher churn odds; e.g. `coef=+1.1, odds x3.0`), `tenure` comes out **negative** (loyal customers stay; e.g. `coef=-1.3, odds x0.27`), and `contract_type_month-to-month` is **positive** while the longer-contract dummies are **negative**. Read `odds x3.0` as "each +1 std of support calls roughly triples the churn odds."
- **Threshold story:** at 0.50 you might miss a borderline churner (a false negative); dropping to **0.35** flags more customers, so **recall on class 1 rises toward 1.00** while precision dips slightly — the confusion matrix shows the bottom-right `TP` cell filling up and possibly one extra `FP`. That is exactly the business trade we wanted: a few wasted calls in exchange for missing almost no real churners.

## Common mistakes

1. **Fitting the scaler/encoder before the split** (`StandardScaler().fit(X)` on all data) — leaks test statistics into training and inflates your scores. Fix: do all preprocessing **inside the Pipeline**, which only ever sees the training fold during `.fit`.
2. **Label-encoding `contract_type` as 0/1/2.** That invents a fake order (`two-year` is not "twice" `one-year`). Fix: `OneHotEncoder`.
3. **Optimizing accuracy on an imbalanced churn set.** A "predict everyone stays" model can look 70%+ accurate and catch zero churners. Fix: optimize **recall** (and watch precision) for the positive class.
4. **Leaving the threshold at 0.50 when the business is asymmetric.** The default minimizes error count, not *missed churners*. Fix: pick the threshold from the precision/recall curve to hit your recall target.
5. **Comparing raw coefficients on unscaled features.** Without scaling, a big coefficient might just mean a small-unit feature. Fix: scale numerics so `exp(coef)` is a fair odds multiplier "per standard deviation."

## Extension challenge

1. Replace the hand-picked 0.35 with a programmatic choice: from `precision_recall_curve`, select the lowest threshold whose **precision ≥ 0.6**, and report the resulting recall.
2. Swap `LogisticRegression` for `RandomForestClassifier` inside the same Pipeline (drop the scaler — trees don't need it). Does recall improve? Do you lose the clean odds-multiplier interpretation?
3. Add `class_weight="balanced"` to the logistic regression and compare its default-threshold recall to the un-weighted model. Why does weighting act a bit like lowering the threshold?

## Matching animation

**Logistic Regression Decision Boundary Explorer** — drag the `weight1`, `weight2`, and `bias` sliders to move the straight boundary line, watch each point recolor by its sigmoid probability (the gradient near the line is the model's "uncertainty band"), then hit **Fit** to let gradient descent settle on a good boundary. It makes concrete why the boundary is always *linear* and how the threshold (the 0.5 contour) decides labels.

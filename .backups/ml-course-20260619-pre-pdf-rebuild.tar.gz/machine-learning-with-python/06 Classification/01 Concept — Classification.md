# Classification

> Classification is how a model answers a "which bucket?" question — spam or not, churn or stay, dog or cat — by drawing a line between groups and reporting how confident it is.

## What is this?

Classification is supervised learning where the answer you predict is a **category**, not a number. Each training example comes with a label that names a class: an email is `spam` or `ham`, a transaction is `fraud` or `legit`, a photo is `cat`, `dog`, or `horse`. The model's job is to look at the features of a new, unseen example and assign it to one of those classes.

Under the hood, most classifiers do two things:

1. They compute a **score or probability** for each class (how likely is "spam"?).
2. They apply a **threshold** to turn that probability into a hard decision.

The geometric picture is a **decision boundary**: a line (or curve, or surface) that splits the feature space into regions, one per class. Points on one side get one label, points on the other side get the other.

- **Binary classification** has exactly two classes (spam / ham).
- **Multiclass classification** has three or more (the iris flower being *setosa*, *versicolor*, or *virginica*).

The key contrast: in **regression** you predict a continuous number (a house costs `$412,300`), in **classification** you predict a discrete label (a house is `affordable` / `expensive`). Same inputs can power either — what changes is the kind of answer you want.

## Why do we need it?

A huge fraction of real decisions are categorical, not numeric. You rarely want to know "how spammy, on a scale of 0 to 100" — you want a yes/no decision so the email goes to the inbox or the junk folder. The whole point of classification is to **turn messy evidence into an action**: approve or deny, alert or stay quiet, recommend or skip.

Classification also gives you something a hard yes/no can't: a **probability** you can tune. Because the model outputs "82% likely spam" before it decides, *you* choose how cautious to be. Block only at 90%+ confidence and you rarely misfile real mail; block at 50%+ and you catch more spam but annoy more users. That dial — the threshold — is yours to set based on which mistake hurts more.

## Where it's used in real ML

- **Spam and abuse filtering** — every email and comment is classified `spam` / `not spam` before you ever see it.
- **Medical screening** — flag a scan or lab panel as `likely disease` / `likely healthy` to decide who gets a closer look.
- **Customer churn** — predict which subscribers will `cancel` vs `stay` next month so retention offers go to the right people.
- **Fraud detection** — score each card transaction `fraud` / `legit` in milliseconds, blocking the risky ones.
- **Image and document tagging** — sort photos into objects, route support tickets into departments, classify loan applications into risk tiers.

## What breaks if you ignore it

- **You treat a category as a number.** Predicting "class = 1.7" is meaningless — there is no class between `cat` (0) and `dog` (1). Using a regression model where you need a classifier gives you nonsense outputs and the wrong error metric.
- **You judge by accuracy alone on imbalanced data.** If 99% of transactions are legit, a model that always says "legit" is 99% accurate and catches zero fraud. Without classification-aware metrics (precision, recall) you'll ship a useless model that looks great.
- **You forget the threshold is a choice.** Leaving it at the default 0.5 can be exactly the wrong trade-off for cancer screening (where a miss is deadly) or for blocking email (where a false block loses real mail).
- **You ignore the probabilities.** Throwing away `predict_proba` and keeping only the hard label means you lose the ability to rank, prioritize, or set a sensible cutoff.

## Mental model

Think of a bouncer at a club door deciding "let in" or "turn away." The bouncer looks at a few signals (age, dress code, guest list) and draws an imaginary line: above the line you're in, below it you're out. That line is the **decision boundary**. The bouncer is also a little fuzzy near the line — "you're a maybe" — which is the **probability**. Where they set "maybe" before saying yes is the **threshold**.

```
        feature 2
           ^
   spam    |   x  x        decision boundary
   region  |  x  x  \      (the model's "line")
           | x  x    \
           |----------\--------------------> feature 1
           |   o  o    \   o
   ham     |  o   o     \ o   o
   region  | o  o  o     o   o
```

Everything on the upper-left is predicted `spam`; everything on the lower-right is predicted `ham`. New points just get labeled by which side of the line they land on.

## Example 1 — Tiny toy example

Six emails, by hand. Two features: length in words, and number of links. Label: spam (1) or ham (0).

```
length(words)   links   label
   40             0      ham   (0)
   55             1      ham   (0)
   30             0      ham   (0)
  120             6      spam  (1)
  140             8      spam  (1)
  110             5      spam  (1)
```

Just eyeballing it, a simple rule separates them perfectly: **if links >= 4, call it spam; otherwise ham.** That rule *is* a decision boundary — a vertical line at `links = 4` (everything to the right is spam). A new email with 7 links and length 95 lands on the spam side, so we predict `spam`. An email with 1 link lands on the ham side. Notice we didn't even need the length feature here; the link count alone splits the six rows cleanly. A real classifier finds a boundary like this automatically, and weights *both* features instead of guessing.

## Example 2 — Practical ML example

A subscription company wants to predict **churn**: will a customer cancel next month? Each customer is a row with features like `tenure_months`, `monthly_charges`, `num_support_tickets`, and `is_on_promo`. The label is `churned` (1) or `stayed` (0), taken from last month's actual outcomes.

We train a `LogisticRegression` on historical customers. For a new customer, the model doesn't just say "will churn" — it returns `predict_proba`, e.g. `0.78` probability of churning. The retention team then sets a **threshold**: anyone above `0.60` gets a discount offer. If too many happy customers are getting needless discounts (wasted money), they raise the threshold to `0.75`. If too many at-risk customers slip through and cancel, they lower it. The model stays the same — only the cutoff moves. That is classification as a business dial, not a black box.

## Python code example

```python
# Binary classification with logistic regression, end to end, on inline data.
import numpy as np
from sklearn.linear_model import LogisticRegression

# Features: [email length in words, number of links]. Inline so it runs anywhere.
X = np.array([
    [40, 0], [55, 1], [30, 0], [60, 1], [45, 0],   # short, few links -> ham
    [120, 6], [140, 8], [110, 5], [130, 7], [125, 6] # long, many links -> spam
])
# Labels: 0 = ham (not spam), 1 = spam
y = np.array([0, 0, 0, 0, 0, 1, 1, 1, 1, 1])

clf = LogisticRegression()
clf.fit(X, y)                 # learns a decision boundary from the 10 examples

# Two brand-new emails the model has never seen:
new_emails = np.array([
    [50, 1],    # short, 1 link  -> probably ham
    [115, 6],   # long, 6 links  -> probably spam
])

# predict_proba gives [P(ham), P(spam)] for each row; we keep the spam column.
proba_spam = clf.predict_proba(new_emails)[:, 1]
labels = clf.predict(new_emails)          # hard 0/1 decision at the 0.5 threshold

for (length, links), p, label in zip(new_emails, proba_spam, labels):
    name = "SPAM" if label == 1 else "ham "
    print(f"len={length:>3} links={links}  ->  P(spam)={p:0.2f}  decision={name}")

# Now show that the THRESHOLD is a choice, not a law. Be stricter: block only at 0.80+.
strict = (proba_spam >= 0.80).astype(int)
print("\nStrict threshold (0.80):", strict)  # fewer emails flagged as spam
```

Expected output (probabilities approximate):

```
len= 50 links=1  ->  P(spam)=0.01  decision=ham 
len=115 links=6  ->  P(spam)=0.99  decision=SPAM

Strict threshold (0.80): [0 1]
```

The model learned the line on its own, returned a probability for each new email, and the same predictions can be re-thresholded without retraining.

## Common mistakes

- **Using a regression model for a category.** `LinearRegression` will happily output `0.3` or `1.6` for a class label — meaningless. Use a classifier (`LogisticRegression`, trees, etc.) when the answer is a bucket.
- **Trusting accuracy on imbalanced classes.** With 95% one class, "always predict the majority" looks accurate but is useless. Check precision and recall, not just accuracy.
- **Leaving the threshold at 0.5 by reflex.** The right cutoff depends on which error is costlier. Pull `predict_proba` and choose the threshold deliberately.
- **Forgetting to scale features for distance/penalty-based models.** Logistic regression with regularization (and kNN) is sensitive to feature ranges; unscaled features can distort the boundary. (More on this in the regularization and pipelines lessons.)
- **Reading `predict_proba` columns in the wrong order.** Column order follows `clf.classes_`. For labels `[0, 1]`, column `1` is the positive class — always confirm rather than assume.

## Before you continue
- [ ] I can state the difference between classification (predicts a category) and regression (predicts a number).
- [ ] I can describe a decision boundary as the line that separates the predicted classes.
- [ ] I know that a classifier outputs a probability first, and a threshold turns it into a decision.
- [ ] I can explain why accuracy alone is misleading when one class is rare.
- [ ] I can read `predict_proba` output and pick a threshold other than 0.5 on purpose.

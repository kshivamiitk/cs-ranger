# Solved — Using Logistic Regression for Spam Detection

> A spam filter has to do two jobs at once: catch the junk *and* explain itself, because nobody trusts a black box that quietly deletes their email. Logistic regression does both — it hands you a spam *probability* and a per-feature story of what made a message look spammy.

## Problem statement

Each incoming message has been boiled down to four cheap-to-compute numeric features — `num_links` (how many URLs it contains), `num_caps_words` (count of ALL-CAPS words like "FREE" or "URGENT"), `has_money_word` (1 if it mentions cash/prize/free/$, else 0), and `msg_len` (length in characters) — and a label `label` (1 = spam, 0 = ham/legitimate). Build a model that, given those four numbers, outputs **the probability a message is spam** and a yes/no flag.

Three things matter beyond raw accuracy. First, we want to read off **which features push a message toward spam** (the coefficients), because a spam filter that can be explained can be audited and tuned. Second, we want to **score brand-new messages** with a calibrated probability, not just a label. Third — and this is the asymmetry that defines spam filtering — a **false positive (a real email sent to junk) is far more painful than a false negative (one spam in the inbox)**, so we read precision and recall carefully rather than trusting accuracy alone.

## Why this problem matters

Spam detection is the canonical "interpretable classifier" problem, and logistic regression is the workhorse precisely because every coefficient has a plain-English meaning: `exp(coef)` is the multiplier on the spam *odds* per one-unit jump in a feature. That lets you tell a stakeholder "a message with a money word is ~2.3x more likely to be spam, all else equal" — the kind of sentence that gets a filter rule approved. The same machinery (engineered features → logistic regression → probability + coefficients) powers fraud scoring, lead ranking, and medical risk models. And because the business cost of the two error types is wildly different, the lesson is also about *reading the confusion matrix in context*, not chasing a single accuracy number.

## Tiny dataset or sample data

A small, realistic slice. The full inline set below has **24 rows**, shape `(24, 5)`, columns `num_links, num_caps_words, has_money_word, msg_len, label`:

| num_links | num_caps_words | has_money_word | msg_len | label |
|----------:|---------------:|---------------:|--------:|------:|
|         3 |              5 |              1 |     180 |     1 |
|         2 |              4 |              1 |     150 |     1 |
|         1 |              0 |              0 |      90 |     1 |
|         0 |              0 |              0 |      60 |     0 |
|         0 |              0 |              1 |      40 |     0 |
|         1 |              0 |              0 |     150 |     0 |

The pattern baked into the data: **more links + more caps words + a money word pushes spam up**; clean, short, link-free personal notes pull it down. But notice it's deliberately *not* perfectly separable — there's a low-signal spam (`num_links=1, caps=0, money=0`) and a ham that happens to mention money (`has_money_word=1, label=0`). Those overlap cases are what make the precision/recall discussion real.

## Step-by-step reasoning

1. **Decide what "positive" means and which error hurts.** Positive = spam. A **false positive** (real mail junked) is the costly error here, so we will watch **precision on the spam class** closely — though we also track recall, because spam that slips through is annoying.
2. **Scale the numeric features.** `msg_len` runs 38–210 while `num_links` runs 0–4. Without scaling, the big-numbered feature would dominate the coefficient magnitudes and `exp(coef)` would no longer be a fair "per standard deviation" odds multiplier. So we standardize first.
3. **Use a `Pipeline` so scaling never leaks.** Bundling `StandardScaler → LogisticRegression` into one object means `.fit(X_train)` computes the mean/std on **training data only**; the test fold is transformed with those same training statistics. Fitting the scaler on all the data first would leak test information and inflate the scores.
4. **Read coefficients as odds multipliers.** Logistic regression is linear in the **log-odds**: `log(p/(1-p)) = w·x + b`. So a positive coefficient raises spam odds, negative lowers them, and `exp(coef)` is the multiplier per one-standard-deviation increase. Sorting features by `|coef|` ranks them by influence.
5. **Score new messages with probabilities, then evaluate honestly.** `predict_proba` gives `P(spam)`; the default 0.5 threshold turns it into a label. On the held-out set we read the **confusion matrix** and **per-class precision/recall** instead of celebrating one accuracy number — because the false negative we'll see is exactly the realistic failure mode of a real filter.

## Python solution

```python
import io
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

# --- 1. Inline data (no download). Each row is one message reduced to four
#        engineered numeric features. label: 1 = spam, 0 = ham. ---
# num_links     : count of URLs in the message
# num_caps_words: count of ALL-CAPS words (FREE, URGENT, WIN, ...)
# has_money_word: 1 if it mentions cash/prize/free/$, else 0
# msg_len       : length of the message in characters
csv = """num_links,num_caps_words,has_money_word,msg_len,label
3,5,1,180,1
2,4,1,150,1
4,6,1,210,1
2,3,1,120,1
3,5,1,160,1
1,2,1,95,1
2,4,1,140,1
3,3,1,175,1
2,5,1,130,1
1,1,1,80,1
0,1,1,70,1
1,0,0,90,1
0,0,0,60,0
0,1,0,45,0
0,0,0,90,0
0,0,0,38,0
0,1,0,72,0
0,0,0,55,0
1,0,0,120,0
0,0,1,40,0
0,1,0,66,0
0,0,0,48,0
1,0,0,150,0
0,0,0,52,0
"""
df = pd.read_csv(io.StringIO(csv))
print("Shape:", df.shape, "| spam rate:", round(df["label"].mean(), 2))

features = ["num_links", "num_caps_words", "has_money_word", "msg_len"]
X = df[features]
y = df["label"].values

# Stratify so both spam and ham land in train AND test on this small set.
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.30, random_state=0, stratify=y)

# --- 2. Scale + fit, all inside one leak-proof Pipeline. ---
clf = Pipeline([
    ("scale", StandardScaler()),                       # fit on TRAIN only
    ("lr", LogisticRegression(max_iter=1000, random_state=0)),
])
clf.fit(X_tr, y_tr)
print("Test accuracy:", round(clf.score(X_te, y_te), 3))

# --- 3. Which features push a message toward SPAM? Read the coefficients. ---
coefs = clf.named_steps["lr"].coef_[0]
print("\nFeature -> coef (log-odds, per std)  |  odds multiplier exp(coef)")
for name, c in sorted(zip(features, coefs), key=lambda t: -abs(t[1])):
    print(f"  {name:16s} coef={c:+.2f}   odds x{np.exp(c):.2f}")

# --- 4. Score two brand-new messages described by the same four features. ---
new = pd.DataFrame(
    [[3, 5, 1, 175],    # many links, lots of caps, money word -> looks spammy
     [0, 0, 0, 70]],    # clean short personal note
    columns=features)
proba = clf.predict_proba(new)[:, 1]                   # P(spam)
pred = clf.predict(new)
print("\nScoring two new messages:")
for row, p, k in zip(new.values.tolist(), proba, pred):
    tag = "SPAM" if k == 1 else "HAM "
    print(f"  features={row}  P(spam)={p:.3f} -> {tag}")

# --- 5. Evaluate honestly: precision/recall + confusion matrix, not just acc.
y_pred = clf.predict(X_te)
print("\nClassification report (held-out messages):")
print(classification_report(y_te, y_pred, target_names=["ham", "spam"],
                            digits=2, zero_division=0))
print("Confusion matrix [ [TN FP] [FN TP] ]:\n",
      confusion_matrix(y_te, y_pred, labels=[0, 1]))
```

## Expected output

```
Shape: (24, 5) | spam rate: 0.5
Test accuracy: 0.875

Feature -> coef (log-odds, per std)  |  odds multiplier exp(coef)
  num_links        coef=+0.97   odds x2.64
  has_money_word   coef=+0.84   odds x2.31
  num_caps_words   coef=+0.55   odds x1.74
  msg_len          coef=+0.30   odds x1.36

Scoring two new messages:
  features=[3, 5, 1, 175]  P(spam)=0.979 -> SPAM
  features=[0, 0, 0, 70]  P(spam)=0.111 -> HAM

Classification report (held-out messages):
              precision    recall  f1-score   support

         ham       0.80      1.00      0.89         4
        spam       1.00      0.75      0.86         4

    accuracy                           0.88         8
   macro avg       0.90      0.88      0.87         8
weighted avg       0.90      0.88      0.87         8

Confusion matrix [ [TN FP] [FN TP] ]:
 [[4 0]
 [1 3]]
```

## Explanation of the output

- **The coefficients tell the whole story.** All four are **positive**, meaning every feature pushes a message toward spam — exactly the pattern we baked in. `num_links` is the strongest signal (`coef=+0.97`, `odds x2.64`: each +1 standard deviation in link count multiplies the spam odds by ~2.6x), with `has_money_word` close behind (`odds x2.31`). `msg_len` is the weakest. Because we scaled first, those multipliers are comparable across features.
- **The two new messages score sensibly.** The link-heavy, caps-heavy, money-word message gets `P(spam)=0.979` and is flagged SPAM; the clean short note gets `P(spam)=0.111` and stays HAM. The probability, not just the label, is what a real filter would log and act on.
- **The honest evaluation is the lesson.** Accuracy is **0.875**, not a suspiciously perfect 1.00. The confusion matrix `[[4 0] [1 3]]` reads as: **TN=4** (4 ham correctly kept), **FP=0** (zero real emails junked — perfect spam precision, exactly what we want), **FN=1** (one spam slipped through), **TP=3**. That single false negative is the low-signal spam (`num_links=1, caps=0, money=0`) — it genuinely looks like ham, so the model lets it pass. For a spam filter that's the *good* failure mode: spam **precision = 1.00** (we never lose a real email) at the cost of **recall = 0.75** (one junk message reaches the inbox). Reversed costs would call for a different threshold.

## Common mistakes

1. **Fitting `StandardScaler` on all the data before splitting.** That leaks the test fold's mean/std into training and inflates your reported scores. Fix: scale **inside the Pipeline**, which only sees the training fold during `.fit`.
2. **Comparing raw coefficients on unscaled features.** Without scaling, `msg_len`'s coefficient looks tiny just because the feature spans hundreds of units, not because it's unimportant. Fix: standardize first so `exp(coef)` is a fair "per standard deviation" odds multiplier.
3. **Trusting accuracy on an asymmetric problem.** Two filters can both score 88% accurate while one junks real email and the other lets spam through — wildly different in practice. Fix: read **precision and recall per class** plus the confusion matrix, and decide which error you can tolerate.
4. **Confusing the probability with the label.** `predict` applies a hard 0.5 cutoff; `predict_proba[:, 1]` gives the calibrated `P(spam)` you actually want for logging, thresholding, or ranking. Fix: keep the probability and choose the threshold deliberately.
5. **Reading the confusion matrix backward.** sklearn's matrix is rows = actual, columns = predicted, ordered `labels=[0, 1]`, so `.ravel()` is `TN, FP, FN, TP`. Fix: always pass `labels=[0, 1]` and sanity-check the corner counts.

## Extension challenge

1. Lower the decision threshold to 0.35 (`(proba >= 0.35)`) and recompute the confusion matrix. Does recall on spam rise to 1.00? What happens to the false-positive count, and is that an acceptable trade for *this* application?
2. Swap the engineered features for raw text using `CountVectorizer` or `TfidfVectorizer` on a handful of inline messages, feed that into the same `LogisticRegression`, and inspect which **words** get the largest positive coefficients.
3. Add `class_weight="balanced"` and compare the coefficients and recall to the unweighted model — then explain why up-weighting the spam class behaves a bit like lowering the threshold.

## Matching animation

**Logistic Regression Decision Boundary Explorer** — drag the weight and bias sliders to tilt the straight boundary line and watch each message recolor by its sigmoid spam probability, with the fuzzy band near the line marking the model's uncertainty. Hit **Fit** to let gradient descent settle on a boundary, then see how the 0.5 contour decides spam-vs-ham. It makes concrete why each coefficient is just the "push" a feature gives toward the spam side of that line.

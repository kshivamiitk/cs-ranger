# Lab — Classify Flowers and Customer Churn

## Objective

You'll build two complete classifiers from end to end and learn to *compare* them honestly. In **Part A** you train a multiclass logistic regression on the classic iris dataset and read its per-class probabilities. In **Part B** you load a small, realistic **customer-churn** table (inline, no download), train a `RandomForestClassifier`, and compare its accuracy to a logistic-regression baseline. By the end you'll be able to take any small tabular dataset, fit two different models, and say which one to ship and why.

## Dataset

**Part A — Iris.** 150 flowers, 4 numeric features (sepal/petal length & width), 3 species (setosa, versicolor, virginica). Loaded from sklearn, fully offline.

**Part B — Customer churn.** A 20-row inline CSV (via `io.StringIO`) of telecom-style customers. Columns:

| column           | meaning                                  |
|------------------|------------------------------------------|
| tenure_months    | how long they've been a customer         |
| monthly_charge   | their monthly bill in dollars            |
| support_calls    | support tickets in the last 90 days      |
| has_contract     | 1 if on an annual contract, else 0       |
| churned          | **target**: 1 if they left, else 0       |

The pattern baked into the data: short tenure, high charges, many support calls, and no contract → more likely to churn. A good model should recover that.

## Steps

**Step 1 — Part A: load iris and split.** Stratify so all three species appear in train and test.

```python
import numpy as np
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression

iris = load_iris()
X, y = iris.data, iris.target
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y)
print("Train/test sizes:", X_tr.shape[0], X_te.shape[0])   # 105 45
```

**Step 2 — Part A: fit multiclass logistic regression and score it.** The same `LogisticRegression` handles 3 classes automatically.

```python
flower_clf = LogisticRegression(max_iter=1000).fit(X_tr, y_tr)
print("Iris test accuracy:", round(flower_clf.score(X_te, y_te), 3))   # ~0.978
print("Classes:", iris.target_names)                                   # setosa versicolor virginica
```

**Step 3 — Part A: inspect a probability row.** Multiclass `predict_proba` returns one probability per class; they sum to 1.

```python
probs = flower_clf.predict_proba(X_te[:1])
print("P per class for first test flower:", np.round(probs[0], 3))
print("Predicted species:", iris.target_names[flower_clf.predict(X_te[:1])[0]])
# e.g. P per class -> [0.0 0.97 0.03], predicted 'versicolor'
```

**Step 4 — Part B: build the churn table inline.** No file needed — `io.StringIO` makes pandas read a string as if it were a CSV.

```python
import io
import pandas as pd

csv = """tenure_months,monthly_charge,support_calls,has_contract,churned
2,95,5,0,1
1,80,4,0,1
3,70,3,0,1
4,99,6,0,1
2,88,4,0,1
1,92,5,0,1
5,60,2,0,1
30,40,0,1,0
45,55,1,1,0
60,35,0,1,0
24,50,1,1,0
36,45,0,1,0
50,30,0,1,0
40,65,1,1,0
12,75,3,0,1
18,42,1,1,0
6,85,4,0,1
55,38,0,1,0
8,90,5,0,1
33,48,1,1,0
"""
df = pd.read_csv(io.StringIO(csv))
print(df.shape)                 # (20, 5)
print("Churn rate:", df["churned"].mean())   # 0.45
```

**Step 5 — Part B: split features from target and train two models.** We compare a random forest against a logistic-regression baseline on the *same* split.

```python
from sklearn.ensemble import RandomForestClassifier

Xc = df.drop(columns="churned").values
yc = df["churned"].values
Xc_tr, Xc_te, yc_tr, yc_te = train_test_split(
    Xc, yc, test_size=0.3, random_state=0, stratify=yc)

forest = RandomForestClassifier(n_estimators=200, random_state=0).fit(Xc_tr, yc_tr)
baseline = LogisticRegression(max_iter=1000).fit(Xc_tr, yc_tr)

print("Random forest accuracy:", round(forest.score(Xc_te, yc_te), 3))
print("Logistic baseline accuracy:", round(baseline.score(Xc_te, yc_te), 3))
```

**Step 6 — Part B: interpret what drove churn.** The forest's feature importances should confirm the pattern we baked in.

```python
cols = df.drop(columns="churned").columns
order = np.argsort(forest.feature_importances_)[::-1]
for i in order:
    print(f"  {cols[i]:16s} importance={forest.feature_importances_[i]:.3f}")
```

## Expected output

- **Part A** should reach roughly **0.96–1.00** test accuracy — iris is easy and nearly linearly separable, so logistic regression nails it. The probability row for a confident flower will have one value near 1.0 and the others near 0; a borderline versicolor/virginica flower will split probability between those two, which is the model honestly telling you it's unsure.
- **Part B** is a tiny dataset, so exact numbers wobble with the split, but both models should classify most held-out customers correctly (often 0.83–1.0). The point is the *comparison*: the random forest typically matches or beats the linear baseline here because churn depends on a combination of features (high charges *and* no contract), which trees capture as interacting splits.
- **Feature importances** should rank `has_contract`, `tenure_months`, and `support_calls` near the top — exactly the signal we planted. If they do, your model "found" the real driver, which is the story you'd tell stakeholders: *"Customers without an annual contract and with frequent support calls are our churn risk."*

## Extension challenge

1. Add a 5-fold `cross_val_score` (next module's tool) on the iris model and report mean ± std — a single split can flatter or punish a model by luck.
2. On the churn data, lower the decision threshold: use `forest.predict_proba(Xc_te)[:, 1] > 0.3` instead of `predict`. Does it catch more churners? At what cost? (This previews precision/recall trade-offs.)
3. Replace the random forest with a `KNeighborsClassifier` wrapped in a `StandardScaler` pipeline and compare. Why does scaling matter more for KNN than for the forest?

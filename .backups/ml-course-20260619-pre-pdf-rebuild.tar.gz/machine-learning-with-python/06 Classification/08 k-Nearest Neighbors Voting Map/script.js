"use strict";

/* ------------------------------------------------------------------ *
 * k-Nearest Neighbors Voting Map
 *
 * Classify a query point by majority vote of its k nearest neighbors
 * (Euclidean distance, ties broken by the nearer neighbor).
 * Points live in canvas pixel coordinates so distance == screen distance.
 * ------------------------------------------------------------------ */

const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const W = canvas.width;    // 760 internal resolution
const H = canvas.height;   // 520

// DOM
const kSlider = document.getElementById("k");
const kVal = document.getElementById("kVal");
const followChk = document.getElementById("follow");
const regionsChk = document.getElementById("regions");
const elPred = document.getElementById("rPred");
const elVotes = document.getElementById("rVotes");
const elConf = document.getElementById("rConf");
const elK = document.getElementById("rK");

// Class palette + names (kept consistent with the LearnRift theme).
const COLORS = ["#a78bfa", "#22d3ee", "#34d399"];
const NAMES = ["A", "B", "C"];

// State
let points = [];            // [{x, y, label}]
let nClasses = 3;           // 2 or 3
let k = parseInt(kSlider.value, 10);
let query = { x: W * 0.5, y: H * 0.5 };
let dragging = false;
let regionCache = null;     // offscreen-rendered decision map (ImageData)
let regionDirty = true;

const MARGIN = 40;

function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

// Box-Muller standard normal
function gaussian(mean, sd) {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  const z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  return mean + z * sd;
}

// Build ~30 points as a few Gaussian clusters, labels = class index.
function makeData() {
  points = [];
  const perClass = nClasses === 2 ? 15 : 10;   // 30 total either way
  // cluster centers spread across the canvas
  const centers = nClasses === 2
    ? [{ x: W * 0.32, y: H * 0.62 }, { x: W * 0.68, y: H * 0.38 }]
    : [{ x: W * 0.28, y: H * 0.30 }, { x: W * 0.72, y: H * 0.32 }, { x: W * 0.50, y: H * 0.74 }];
  const sd = 52;
  for (let c = 0; c < nClasses; c++) {
    for (let i = 0; i < perClass; i++) {
      points.push({
        x: clamp(gaussian(centers[c].x, sd), MARGIN, W - MARGIN),
        y: clamp(gaussian(centers[c].y, sd), MARGIN, H - MARGIN),
        label: c,
      });
    }
  }
  regionDirty = true;
}

// Core kNN: return {pred, votes:[...], neighbors:[{idx,d}], conf}
function classify(qx, qy, kk) {
  // distance to every point
  const dists = points.map((p, i) => {
    const dx = p.x - qx, dy = p.y - qy;
    return { idx: i, d: Math.sqrt(dx * dx + dy * dy) };
  });
  dists.sort((a, b) => a.d - b.d);
  const kept = dists.slice(0, Math.min(kk, dists.length));

  const votes = new Array(nClasses).fill(0);
  for (const n of kept) votes[points[n.idx].label]++;

  // majority; tie -> the class of the single nearest neighbor among tied
  let best = 0, bestCount = -1;
  for (let c = 0; c < nClasses; c++) {
    if (votes[c] > bestCount) { bestCount = votes[c]; best = c; }
  }
  // tie-break: if another class matches bestCount, pick whichever appears
  // first in the nearest-neighbor ordering (closest wins).
  const tied = [];
  for (let c = 0; c < nClasses; c++) if (votes[c] === bestCount) tied.push(c);
  if (tied.length > 1) {
    for (const n of kept) {
      if (tied.indexOf(points[n.idx].label) !== -1) { best = points[n.idx].label; break; }
    }
  }
  const conf = kept.length ? bestCount / kept.length : 0;
  return { pred: best, votes: votes, neighbors: kept, conf: conf };
}

// ---- Decision-region shading (coarse grid for speed) ----
function buildRegions() {
  // Render to an offscreen ImageData at a coarse step, then we scale by drawing rects.
  regionCache = [];
  const step = 12;  // pixel block size for the coarse map
  for (let py = 0; py < H; py += step) {
    for (let px = 0; px < W; px += step) {
      const res = classify(px + step / 2, py + step / 2, k);
      regionCache.push({ x: px, y: py, w: step, h: step, label: res.pred });
    }
  }
  regionDirty = false;
}

// ---- Rendering ----
function render() {
  ctx.clearRect(0, 0, W, H);

  if (regionsChk.checked) {
    if (regionDirty || !regionCache) buildRegions();
    for (const cell of regionCache) {
      ctx.fillStyle = hexToRgba(COLORS[cell.label], 0.18);
      ctx.fillRect(cell.x, cell.y, cell.w + 1, cell.h + 1);
    }
  }

  drawFrame();

  const res = classify(query.x, query.y, k);

  // lines from query to each of the k neighbors
  ctx.save();
  ctx.lineWidth = 1.6;
  for (const n of res.neighbors) {
    const p = points[n.idx];
    ctx.strokeStyle = hexToRgba(COLORS[p.label], 0.7);
    ctx.beginPath();
    ctx.moveTo(query.x, query.y);
    ctx.lineTo(p.x, p.y);
    ctx.stroke();
  }
  // a circle through the farthest selected neighbor = the "kNN radius"
  if (res.neighbors.length) {
    const rMax = res.neighbors[res.neighbors.length - 1].d;
    ctx.strokeStyle = "rgba(255,255,255,0.18)";
    ctx.setLineDash([4, 5]);
    ctx.beginPath();
    ctx.arc(query.x, query.y, rMax, 0, Math.PI * 2);
    ctx.stroke();
    ctx.setLineDash([]);
  }
  ctx.restore();

  // data points (selected neighbors get a bright ring)
  const selected = new Set(res.neighbors.map((n) => n.idx));
  for (let i = 0; i < points.length; i++) {
    const p = points[i];
    ctx.beginPath();
    ctx.arc(p.x, p.y, 7, 0, Math.PI * 2);
    ctx.fillStyle = COLORS[p.label];
    ctx.fill();
    if (selected.has(i)) {
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = "#ffffff";
      ctx.stroke();
    }
  }

  // the query point (white, predicted-class halo)
  ctx.save();
  const halo = ctx.createRadialGradient(query.x, query.y, 2, query.x, query.y, 18);
  halo.addColorStop(0, "#ffffff");
  halo.addColorStop(0.45, hexToRgba(COLORS[res.pred], 0.9));
  halo.addColorStop(1, hexToRgba(COLORS[res.pred], 0));
  ctx.fillStyle = halo;
  ctx.beginPath();
  ctx.arc(query.x, query.y, 18, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#ffffff";
  ctx.beginPath();
  ctx.arc(query.x, query.y, 6.5, 0, Math.PI * 2);
  ctx.fill();
  ctx.lineWidth = 2;
  ctx.strokeStyle = COLORS[res.pred];
  ctx.stroke();
  ctx.restore();

  drawLegend();
  updateReadout(res);
}

function drawFrame() {
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.lineWidth = 1;
  for (let gx = MARGIN; gx <= W - MARGIN; gx += (W - 2 * MARGIN) / 6) {
    ctx.beginPath(); ctx.moveTo(gx, MARGIN); ctx.lineTo(gx, H - MARGIN); ctx.stroke();
  }
  for (let gy = MARGIN; gy <= H - MARGIN; gy += (H - 2 * MARGIN) / 5) {
    ctx.beginPath(); ctx.moveTo(MARGIN, gy); ctx.lineTo(W - MARGIN, gy); ctx.stroke();
  }
  ctx.fillStyle = "#94a3b8";
  ctx.font = "12px Inter, sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("feature 1 →", MARGIN, H - 16);
  ctx.save();
  ctx.translate(20, H - MARGIN);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText("feature 2 →", 0, 0);
  ctx.restore();
  ctx.restore();
}

function drawLegend() {
  ctx.save();
  ctx.font = "12px Inter, sans-serif";
  ctx.textAlign = "left";
  let ly = MARGIN + 4;
  const lx = W - 120;
  for (let c = 0; c < nClasses; c++) {
    ctx.fillStyle = COLORS[c];
    ctx.beginPath();
    ctx.arc(lx, ly, 6, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = "#e2e8f0";
    ctx.fillText("class " + NAMES[c], lx + 12, ly + 4);
    ly += 22;
  }
  ctx.restore();
}

function updateReadout(res) {
  elPred.textContent = "class " + NAMES[res.pred];
  elPred.style.color = COLORS[res.pred];
  const parts = [];
  for (let c = 0; c < nClasses; c++) parts.push(NAMES[c] + ":" + res.votes[c]);
  elVotes.textContent = parts.join("  ");
  elConf.textContent = Math.round(res.conf * 100) + "%";
  elK.textContent = String(k);
}

// ---- helpers ----
function hexToRgba(hex, a) {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return "rgba(" + r + "," + g + "," + b + "," + a + ")";
}

function eventToCanvas(evt) {
  const rect = canvas.getBoundingClientRect();
  const sx = canvas.width / rect.width;
  const sy = canvas.height / rect.height;
  return {
    x: clamp((evt.clientX - rect.left) * sx, 0, W),
    y: clamp((evt.clientY - rect.top) * sy, 0, H),
  };
}

// ---- Controls ----
kSlider.addEventListener("input", () => {
  k = parseInt(kSlider.value, 10);
  kVal.textContent = String(k);
  regionDirty = true;   // regions depend on k
  render();
});

followChk.addEventListener("change", render);
regionsChk.addEventListener("change", () => { regionDirty = true; render(); });

document.getElementById("newdata").addEventListener("click", () => {
  makeData();
  render();
});

document.getElementById("classes").addEventListener("click", () => {
  nClasses = nClasses === 2 ? 3 : 2;
  makeData();
  render();
});

// Drag or follow-the-mouse for the query point.
canvas.addEventListener("pointerdown", (e) => {
  dragging = true;
  canvas.classList.add("dragging");
  query = eventToCanvas(e);
  render();
  canvas.setPointerCapture(e.pointerId);
});

canvas.addEventListener("pointermove", (e) => {
  if (dragging || followChk.checked) {
    query = eventToCanvas(e);
    render();
  }
});

function endDrag() { dragging = false; canvas.classList.remove("dragging"); }
canvas.addEventListener("pointerup", endDrag);
canvas.addEventListener("pointercancel", endDrag);
canvas.addEventListener("pointerleave", () => { dragging = false; canvas.classList.remove("dragging"); });

// ---- Init ----
makeData();
kVal.textContent = String(k);
render();

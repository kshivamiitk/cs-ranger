# Logistic Regression and Decision Boundaries

> Despite the name, logistic regression is a *classifier* — it's the workhorse first model you should reach for on almost any binary problem, and it's interpretable enough to explain to your boss.

## What you'll learn
- What the **sigmoid** function does and why it turns any number into a probability.
- **Log-odds** explained in plain words — what logistic regression's coefficients actually mean.
- How to fit `LogisticRegression` on real sklearn data and read its `predict_proba`.
- How to draw a **2D decision boundary** so you can *see* what the model learned.

## Intuition

A plain linear model computes a weighted sum of features: `z = w1*x1 + w2*x2 + ... + b`. That `z` can be any number from minus to plus infinity — useless as a probability, which must live between 0 and 1. The fix is to squash `z` through the **sigmoid** function:

```
sigmoid(z) = 1 / (1 + e^(-z))
```

The sigmoid is an S-shaped curve. Feed it a big positive `z` and it returns something near 1; a big negative `z` returns near 0; a `z` of 0 returns exactly 0.5. So logistic regression does two steps: (1) compute a linear score `z`, (2) squash it into a probability. The probability is `P(class = 1)`. To get a label, compare it to a threshold (default 0.5) — which is the same as asking "is `z` above 0?". That `z = 0` surface *is the decision boundary*, and because `z` is linear in the features, **the boundary is a straight line** (a plane in higher dimensions).

**Log-odds, in words.** The "odds" of an event are `P / (1 - P)` — "3-to-1 in favor" means odds of 3. Logistic regression is linear not in probability but in the **log of the odds**: `log(P / (1-P)) = z`. That's why each coefficient `w_i` has a crisp meaning: *increasing feature i by one unit adds `w_i` to the log-odds*, i.e. multiplies the odds by `e^(w_i)`. A positive coefficient pushes a sample toward class 1; a negative one pushes toward class 0; the magnitude says how strongly. This interpretability is why hospitals, banks, and credit bureaus still love logistic regression.

## Python in practice

First, fit on real data and inspect probabilities and coefficients:

```python
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split

X, y = load_breast_cancer(return_X_y=True)
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.25, random_state=0, stratify=y)

# Scaling helps logistic regression converge and makes coefficients comparable.
scaler = StandardScaler().fit(X_tr)
X_tr_s, X_te_s = scaler.transform(X_tr), scaler.transform(X_te)

clf = LogisticRegression(max_iter=5000).fit(X_tr_s, y_tr)
print("Test accuracy:", round(clf.score(X_te_s, y_te), 3))   # ~0.97

# Probabilities, not just labels:
p = clf.predict_proba(X_te_s[:3])[:, 1]   # P(benign)
print("P(benign) for 3 samples:", np.round(p, 3))

# Coefficients are log-odds weights. e^coef = odds multiplier per +1 std of feature.
feat = load_breast_cancer().feature_names
top = np.argsort(np.abs(clf.coef_[0]))[-3:]
for i in top:
    print(f"{feat[i]:25s} coef={clf.coef_[0][i]:+.2f}  odds x{np.exp(clf.coef_[0][i]):.2f}")
```

Expected output (approximate):

```
Test accuracy: 0.972
P(benign) for 3 samples: [0.999 0.002 0.995]
worst radius              coef=-1.45  odds x0.23
...
```

Now the payoff — **plotting a 2D decision boundary**. We pick two features so the boundary is visible on a flat plane, then color the background by what the model predicts at every point:

```python
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression

# Two informative features so we can actually plot the boundary in 2D.
X, y = make_classification(n_samples=300, n_features=2, n_redundant=0,
                           n_clusters_per_class=1, class_sep=1.2, random_state=7)
clf = LogisticRegression().fit(X, y)

# Build a fine grid covering the data, predict the class at every grid point.
x_min, x_max = X[:, 0].min() - 1, X[:, 0].max() + 1
y_min, y_max = X[:, 1].min() - 1, X[:, 1].max() + 1
xx, yy = np.meshgrid(np.linspace(x_min, x_max, 300),
                     np.linspace(y_min, y_max, 300))
grid = np.c_[xx.ravel(), yy.ravel()]
Z = clf.predict_proba(grid)[:, 1].reshape(xx.shape)   # probability surface

plt.contourf(xx, yy, Z, levels=20, cmap="coolwarm", alpha=0.7)  # shaded probability
plt.contour(xx, yy, Z, levels=[0.5], colors="black")            # the 0.5 boundary
plt.scatter(X[:, 0], X[:, 1], c=y, cmap="coolwarm", edgecolor="k", s=25)
plt.title("Logistic regression decision boundary")
plt.xlabel("feature 1"); plt.ylabel("feature 2")
plt.show()
```

You'll see a smooth color gradient (the probability surface) with one straight black line at `P = 0.5`. That straight line is the boundary; the gradient shows confidence rising as you move away from it.

## Common mistakes

- **Not scaling features.** Logistic regression with `solver='lbfgs'` may fail to converge or give a `ConvergenceWarning` on unscaled data. Standardize, or raise `max_iter`.
- **Expecting curved boundaries from plain logistic regression.** It's linear. If the data needs a curve, add polynomial features (`PolynomialFeatures`) or switch models.
- **Reading raw coefficients without scaling.** Coefficient magnitudes are only comparable when features share a scale; otherwise a big coefficient may just mean a tiny-unit feature.
- **Confusing `predict` with `predict_proba`.** `predict` gives 0/1 labels at threshold 0.5; `predict_proba` gives the probabilities you can threshold yourself.
- **Plotting a boundary with more than 2 features.** You can only draw a 2D boundary from 2 features. To visualize, select two features or reduce dimensions first.

## Small exercise

Take the boundary-plotting code and change `class_sep=1.2` to `class_sep=0.5`. Re-run and look at the scatter: the two classes now overlap. Notice the boundary line barely moves but many points end up on the "wrong" side — that's irreducible error no straight line can fix. Then try `class_sep=2.5` and see the classes pull cleanly apart.

## Before you continue
- [ ] I can explain what the sigmoid does and why it's needed.
- [ ] I can say, in plain words, what a logistic regression coefficient means (log-odds / odds multiplier).
- [ ] I can fit `LogisticRegression` and read both `predict` and `predict_proba`.
- [ ] I understand why its decision boundary is a straight line.

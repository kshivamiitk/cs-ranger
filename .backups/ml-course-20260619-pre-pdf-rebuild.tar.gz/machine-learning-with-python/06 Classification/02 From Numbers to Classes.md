# From Numbers to Classes

> Regression answers "how much?"; classification answers "which one?" — and that single difference changes your model, your output, and the way you measure success.

## What you'll learn
- The precise difference between regression and classification, and how to tell which problem you have.
- What a *decision boundary* is and why every classifier is really drawing one.
- The difference between a predicted **probability** and a predicted **label**, and why you usually want both.
- What separates **binary** from **multiclass** problems, and how the same algorithm handles each.

## Intuition

You already met regression: the model outputs a **number** on a continuous scale — a price, a temperature, a salary. Classification is different. The model outputs a **category** from a fixed, finite list — *spam* or *not spam*, *cat* / *dog* / *horse*, *churn* or *stay*.

Here is the mental picture. Imagine plotting your training examples as dots on a 2D plane, where the two axes are two features (say, tumor radius and texture). Each dot is colored by its class. A classifier's job is to **draw a line — or a curve — that separates the colors**. That separating line is the **decision boundary**. Everything on one side is predicted as class A; everything on the other side as class B. Training a classifier *is* the search for a good boundary.

Different algorithms draw the boundary differently: logistic regression draws a straight line, a decision tree draws stair-steps (axis-aligned rectangles), k-nearest-neighbors draws a wobbly boundary that hugs the data. Same goal, different pen.

There is a subtlety that trips up beginners. Most classifiers don't *only* output a label — internally they compute a **probability** (or a score) for each class, then pick the highest. "70% spam" becomes the label "spam" only because 70% crossed a **threshold** (usually 0.5). Keeping the probability around is valuable: it tells you *how confident* the model is, and lets you move the threshold later when one kind of mistake is costlier than another (a topic we'll hammer in the Model Evaluation module).

**Binary vs multiclass.** If there are exactly two classes, it's *binary* (yes/no, 0/1). If there are three or more, it's *multiclass* (iris setosa / versicolor / virginica). Scikit-learn handles both with the same API; under the hood, multiclass is often solved by training several binary classifiers (one-vs-rest) and letting them vote.

## Python in practice

Let's see the three ideas — labels, probabilities, and the binary-vs-multiclass distinction — in a few lines, using sklearn's built-in datasets so it runs offline.

```python
import numpy as np
from sklearn.datasets import load_breast_cancer, load_iris
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

# --- Binary classification: tumor malignant (0) vs benign (1) ---
data = load_breast_cancer()
Xb, yb = data.data, data.target          # 569 samples, 30 numeric features
Xb_tr, Xb_te, yb_tr, yb_te = train_test_split(
    Xb, yb, test_size=0.25, random_state=0, stratify=yb)

clf = LogisticRegression(max_iter=5000)  # more iterations so it converges
clf.fit(Xb_tr, yb_tr)

# A LABEL is the final category; a PROBABILITY is the confidence behind it.
labels = clf.predict(Xb_te[:5])          # e.g. [1 0 1 1 0]
probs  = clf.predict_proba(Xb_te[:5])    # each row: [P(class0), P(class1)]
print("Predicted labels:", labels)
print("P(benign) for those 5:", np.round(probs[:, 1], 3))

# --- Multiclass: 3 iris species, SAME API, no code change in spirit ---
iris = load_iris()
multi = LogisticRegression(max_iter=1000).fit(iris.data, iris.target)
print("Number of classes the model knows:", multi.classes_)        # [0 1 2]
print("One multiclass probability row:", np.round(multi.predict_proba(iris.data[:1]), 3))
```

Expected output (numbers approximate):

```
Predicted labels: [1 0 1 1 0]
P(benign) for those 5: [0.995 0.004 0.981 0.93  0.012]
Number of classes the model knows: [0 1 2]
One multiclass probability row: [[0.98 0.02 0.   ]]
```

Read the probabilities: a sample at 0.995 is a confident "benign"; one at 0.93 is benign but slightly less sure. The label hides that nuance — the probability reveals it. In the multiclass row, the three numbers sum to 1.0 and the model is 98% sure it's class 0.

## Common mistakes

- **Using a regression model (or metric) on a category.** Predicting `0`, `1`, `2` for three species and measuring "mean squared error" is wrong — class 2 isn't "twice" class 1. Use a classifier and accuracy/precision/recall instead.
- **Treating the 0.5 threshold as sacred.** 0.5 is just the default. For rare, costly events (fraud, disease) you often *lower* it to catch more positives. The probability is the real output; the label is a choice on top of it.
- **Throwing away `predict_proba`.** Calling only `predict` discards confidence information you'll need for ROC curves, thresholds, and ranking.
- **Assuming a straight boundary always works.** If classes interlock (a spiral, concentric rings), a linear boundary can't separate them; you'll need trees, KNN, or feature transforms.
- **Forgetting `stratify=y` on the split.** Without it, a random split can leave a class underrepresented in the test set, distorting your evaluation.

## Small exercise

Run the binary block above, then print `clf.predict_proba(Xb_te)[:, 1]` for the whole test set and count how many samples have a benign-probability between 0.4 and 0.6. These are the model's "unsure" cases — the ones most likely to flip if you nudge the threshold. (Hint: `np.mean((p > 0.4) & (p < 0.6))` gives the fraction.)

## Before you continue
- [ ] I can state the difference between regression and classification in one sentence.
- [ ] I can explain what a decision boundary is and why training finds one.
- [ ] I can describe how a probability becomes a label via a threshold.
- [ ] I know the difference between a binary and a multiclass problem.

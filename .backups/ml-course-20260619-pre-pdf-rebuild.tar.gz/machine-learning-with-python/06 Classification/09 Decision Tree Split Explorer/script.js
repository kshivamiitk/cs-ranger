"use strict";

/* ------------------------------------------------------------------ *
 * Decision Tree Split Explorer
 *
 * Two classes of 2D points live in x,y in [-5, 5]. A decision tree
 * carves the plane with AXIS-ALIGNED cuts (a vertical line at x = t, or
 * a horizontal line at y = t). We measure how good a cut is with the
 * drop in Gini impurity it produces.
 *
 *   Gini(node) = 1 - sum_k p_k^2          (p_k = fraction of class k)
 *      -> 0   for a pure node (all one class)
 *      -> 0.5 for a perfect 50/50 binary mix
 *
 *   low side  = points with feature <  threshold
 *   high side = points with feature >= threshold
 *
 *   weighted child Gini = (n_low/n)*Gini_low + (n_high/n)*Gini_high
 *   impurity drop       = Gini_parent - weighted child Gini   (>= 0)
 *
 * A tree greedily picks the (feature, threshold) with the largest drop.
 * Depth 2 applies a SECOND cut (on the perpendicular feature) to just
 * one child region, which can carve a boundary a single cut never could.
 * ------------------------------------------------------------------ */

// Class identifiers + their colours.
const CLASS_A = 0; // cyan
const CLASS_B = 1; // amber
const COLORS = {
  [CLASS_A]: "#22d3ee",
  [CLASS_B]: "#fbbf24",
};
const FILLS = {
  [CLASS_A]: "rgba(34, 211, 238, 0.10)",
  [CLASS_B]: "rgba(251, 191, 36, 0.10)",
};

// ----- Deterministic seeded PRNG (LCG) so a given seed -> the same data -----
function makeRng(seed) {
  let s = (seed >>> 0) || 1;
  return () => {
    // 32-bit LCG (Numerical Recipes constants), normalised to [0,1)
    s = (Math.imul(s, 1664525) + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

// ----- Generate ~70 points in two only-partly-separable blobs -----
// Class A clusters lower-left, class B clusters upper-right, with enough
// spread (and a sprinkle of "noise" points) that no single cut is clean.
function makePoints(seed) {
  const rnd = makeRng(seed);
  // Box-Muller standard normal from the uniform PRNG.
  const gauss = () => {
    const u = Math.max(rnd(), 1e-9), v = rnd();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  };
  const clampW = (z) => Math.max(-4.8, Math.min(4.8, z));

  const pts = [];
  const nA = 36, nB = 36;
  // Class A: centred around (-1.6, -1.4)
  for (let i = 0; i < nA; i++) {
    pts.push({
      x: clampW(-1.6 + gauss() * 1.7),
      y: clampW(-1.4 + gauss() * 1.8),
      c: CLASS_A,
    });
  }
  // Class B: centred around (1.7, 1.5)
  for (let i = 0; i < nB; i++) {
    pts.push({
      x: clampW(1.7 + gauss() * 1.7),
      y: clampW(1.5 + gauss() * 1.8),
      c: CLASS_B,
    });
  }
  // A few label-swapped "noise" points so the classes overlap a little.
  const noise = 8;
  for (let i = 0; i < noise; i++) {
    const flip = pts[Math.floor(rnd() * pts.length)];
    pts.push({
      x: clampW(flip.x + gauss() * 0.7),
      y: clampW(flip.y + gauss() * 0.7),
      c: flip.c === CLASS_A ? CLASS_B : CLASS_A,
    });
  }
  return pts;
}

// ----- Gini helpers -----
function gini(pts) {
  const n = pts.length;
  if (n === 0) return 0;
  let a = 0;
  for (const p of pts) if (p.c === CLASS_A) a++;
  const pa = a / n;
  const pb = 1 - pa;
  return 1 - (pa * pa + pb * pb);
}

function majority(pts) {
  let a = 0, b = 0;
  for (const p of pts) (p.c === CLASS_A ? a++ : b++);
  if (a === 0 && b === 0) return null;
  return a >= b ? CLASS_A : CLASS_B;
}

// Split a set of points by feature ("x"|"y") at threshold t.
function splitBy(pts, feat, t) {
  const low = [], high = [];
  for (const p of pts) ((p[feat] < t) ? low : high).push(p);
  return { low, high };
}

// Evaluate one cut over `pts`; returns the Gini breakdown + impurity drop.
function evalSplit(pts, feat, t) {
  const n = pts.length;
  const parent = gini(pts);
  const { low, high } = splitBy(pts, feat, t);
  const gLow = gini(low);
  const gHigh = gini(high);
  const weighted = n === 0
    ? 0
    : (low.length / n) * gLow + (high.length / n) * gHigh;
  return {
    parent,
    gLow,
    gHigh,
    weighted,
    drop: parent - weighted,
    nLow: low.length,
    nHigh: high.length,
    low,
    high,
  };
}

// Scan thresholds for `feat` over `pts`, return the threshold (snapped to a
// midpoint between sorted feature values) with the largest impurity drop.
function bestThreshold(pts, feat) {
  if (pts.length < 2) return { t: 0, drop: 0 };
  const vals = pts.map((p) => p[feat]).sort((m, n) => m - n);
  let bestT = 0, bestDrop = -Infinity;
  for (let i = 0; i < vals.length - 1; i++) {
    if (vals[i + 1] === vals[i]) continue;
    const t = (vals[i] + vals[i + 1]) / 2; // midpoint candidate
    const d = evalSplit(pts, feat, t).drop;
    if (d > bestDrop) { bestDrop = d; bestT = t; }
  }
  return { t: bestT, drop: bestDrop };
}

// ----- World / plot domain -----
const X_LO = -5, X_HI = 5, Y_LO = -5, Y_HI = 5;
const PAD = { l: 52, r: 22, t: 24, b: 44 };
const OTHER = { x: "y", y: "x" }; // perpendicular feature for depth 2

// ----- DOM -----
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");

const feat1Seg = document.getElementById("feat1");
const thr1Input = document.getElementById("thr1");
const thr1Val = document.getElementById("thr1Val");

const enable2 = document.getElementById("enable2");
const child2Seg = document.getElementById("child2");
const thr2Input = document.getElementById("thr2");
const thr2Val = document.getElementById("thr2Val");
const feat2Lbl = document.getElementById("feat2Lbl");

const elParent = document.getElementById("rParent");
const elLeft = document.getElementById("rLeft");
const elRight = document.getElementById("rRight");
const elChild = document.getElementById("rChild");
const elDrop = document.getElementById("rDrop");

// ----- State -----
let SEED = 20260618;
let POINTS = makePoints(SEED);

let feat1 = "x";            // "x" -> vertical cut, "y" -> horizontal cut
let thr1 = parseFloat(thr1Input.value);
let useDepth2 = false;
let child2 = "low";         // which child of split 1 gets the 2nd cut
let thr2 = parseFloat(thr2Input.value);
let snapAnim = null;        // rAF id while animating the snap

// ----- Coordinate transforms -----
function plotW() { return canvas.width - PAD.l - PAD.r; }
function plotH() { return canvas.height - PAD.t - PAD.b; }
function xToPx(x) { return PAD.l + ((x - X_LO) / (X_HI - X_LO)) * plotW(); }
function yToPx(y) { return PAD.t + (1 - (y - Y_LO) / (Y_HI - Y_LO)) * plotH(); }
function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

// The depth-2 feature is always perpendicular to split 1.
function feat2() { return OTHER[feat1]; }

// ===================================================================
// Rendering
// ===================================================================
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawRegions();
  drawGrid();
  drawSplitLines();
  drawPoints();
  drawLegend();
  updateReadout();
}

// Faintly shade the half-planes / leaf regions by majority class.
function drawRegions() {
  const x0 = xToPx(X_LO), x1 = xToPx(X_HI);
  const y0 = yToPx(Y_HI), y1 = yToPx(Y_LO); // pixel top / bottom

  const { low, high } = splitBy(POINTS, feat1, thr1);

  if (!useDepth2) {
    // Two half-planes shaded by their majority class.
    shadeRect(x0, y0, x1, y1, feat1, thr1, "low", majority(low));
    shadeRect(x0, y0, x1, y1, feat1, thr1, "high", majority(high));
    return;
  }

  // Depth 2: the chosen child is cut again on the perpendicular feature,
  // producing up to three leaf regions. The other child stays one leaf.
  const f2 = feat2();
  const childPts = child2 === "low" ? low : high;
  const otherPts = child2 === "low" ? high : low;
  const { low: cLow, high: cHigh } = splitBy(childPts, f2, thr2);

  // Untouched sibling half-plane.
  shadeRect(x0, y0, x1, y1, feat1, thr1, child2 === "low" ? "high" : "low",
    majority(otherPts));
  // The two grandchildren of the split child.
  shadeChild(feat1, thr1, child2, f2, thr2, "low", majority(cLow));
  shadeChild(feat1, thr1, child2, f2, thr2, "high", majority(cHigh));
}

// Shade one side of split 1 across the whole perpendicular extent.
function shadeRect(x0, y0, x1, y1, feat, t, side, cls) {
  if (cls === null) return;
  ctx.save();
  ctx.fillStyle = FILLS[cls];
  const tp = clamp(t, X_LO, X_HI);
  if (feat === "x") {
    const xt = xToPx(tp);
    if (side === "low") ctx.fillRect(x0, y0, xt - x0, y1 - y0);
    else ctx.fillRect(xt, y0, x1 - xt, y1 - y0);
  } else {
    const yt = yToPx(tp);
    // "low" feature value = smaller y = lower on plane = larger pixel-y.
    if (side === "low") ctx.fillRect(x0, yt, x1 - x0, y1 - yt);
    else ctx.fillRect(x0, y0, x1 - x0, yt - y0);
  }
  ctx.restore();
}

// Shade a grandchild: a sub-rectangle of split 1's `child` side, divided
// by the perpendicular split 2 at threshold t2.
function shadeChild(feat, t1, child, f2, t2, side2, cls) {
  if (cls === null) return;
  ctx.save();
  ctx.fillStyle = FILLS[cls];

  // Pixel bounds of split 1's chosen child rectangle.
  let rx0 = xToPx(X_LO), rx1 = xToPx(X_HI);
  let ry0 = yToPx(Y_HI), ry1 = yToPx(Y_LO);
  const t1p = clamp(t1, X_LO, X_HI);
  if (feat === "x") {
    const xt = xToPx(t1p);
    if (child === "low") rx1 = xt; else rx0 = xt;
  } else {
    const yt = yToPx(t1p);
    if (child === "low") ry0 = yt; else ry1 = yt; // low feature => bottom
  }

  // Now divide that rectangle by the perpendicular feature f2 at t2.
  const t2p = clamp(t2, X_LO, X_HI);
  if (f2 === "x") {
    const xt = clamp(xToPx(t2p), rx0, rx1);
    if (side2 === "low") ctx.fillRect(rx0, ry0, xt - rx0, ry1 - ry0);
    else ctx.fillRect(xt, ry0, rx1 - xt, ry1 - ry0);
  } else {
    const yt = clamp(yToPx(t2p), ry0, ry1);
    if (side2 === "low") ctx.fillRect(rx0, yt, rx1 - rx0, ry1 - yt);
    else ctx.fillRect(rx0, ry0, rx1 - rx0, yt - ry0);
  }
  ctx.restore();
}

function drawGrid() {
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.fillStyle = "#94a3b8";
  ctx.lineWidth = 1;
  ctx.font = "12px ui-monospace, Menlo, monospace";

  for (let x = X_LO; x <= X_HI + 1e-9; x += 1) {
    const px = xToPx(x);
    ctx.beginPath();
    ctx.moveTo(px, PAD.t);
    ctx.lineTo(px, canvas.height - PAD.b);
    ctx.stroke();
    ctx.textAlign = "center";
    ctx.fillText(String(x), px, canvas.height - PAD.b + 18);
  }
  for (let y = Y_LO; y <= Y_HI + 1e-9; y += 1) {
    const py = yToPx(y);
    ctx.beginPath();
    ctx.moveTo(PAD.l, py);
    ctx.lineTo(canvas.width - PAD.r, py);
    ctx.stroke();
    ctx.textAlign = "right";
    ctx.fillText(String(y), PAD.l - 8, py + 4);
  }

  // origin axes a touch brighter
  ctx.strokeStyle = "rgba(255,255,255,0.14)";
  ctx.beginPath();
  ctx.moveTo(xToPx(0), PAD.t); ctx.lineTo(xToPx(0), canvas.height - PAD.b);
  ctx.moveTo(PAD.l, yToPx(0)); ctx.lineTo(canvas.width - PAD.r, yToPx(0));
  ctx.stroke();

  ctx.fillStyle = "#e2e8f0";
  ctx.font = "13px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("x", (PAD.l + canvas.width - PAD.r) / 2, canvas.height - 8);
  ctx.translate(15, (PAD.t + canvas.height - PAD.b) / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText("y", 0, 0);
  ctx.restore();
}

// Gradient violet->cyan cut line, like the regression reference.
function strokeCut(x1, y1, x2, y2, lw) {
  const grad = ctx.createLinearGradient(x1, y1, x2, y2);
  grad.addColorStop(0, "#a78bfa");
  grad.addColorStop(1, "#22d3ee");
  ctx.strokeStyle = grad;
  ctx.lineWidth = lw;
  ctx.beginPath();
  ctx.moveTo(x1, y1);
  ctx.lineTo(x2, y2);
  ctx.stroke();
}

function drawSplitLines() {
  ctx.save();
  ctx.lineCap = "round";

  // --- Split 1: full-length axis-aligned cut ---
  const t1 = clamp(thr1, X_LO, X_HI);
  if (feat1 === "x") {
    const px = xToPx(t1);
    strokeCut(px, PAD.t, px, canvas.height - PAD.b, 3);
  } else {
    const py = yToPx(t1);
    strokeCut(PAD.l, py, canvas.width - PAD.r, py, 3);
  }

  // --- Split 2: shorter segment confined to the chosen child region ---
  if (useDepth2) {
    const f2 = feat2();
    const t2 = clamp(thr2, X_LO, X_HI);
    ctx.setLineDash([7, 5]);

    if (f2 === "x") {
      // vertical 2nd cut, confined vertically to the chosen y-band child
      const px = xToPx(t2);
      let yA = PAD.t, yB = canvas.height - PAD.b;
      const yt = yToPx(t1);
      if (child2 === "low") yA = yt; else yB = yt; // low feature => bottom
      strokeCut(px, Math.min(yA, yB), px, Math.max(yA, yB), 2.5);
    } else {
      // horizontal 2nd cut, confined horizontally to the chosen x-band child
      const py = yToPx(t2);
      let xA = PAD.l, xB = canvas.width - PAD.r;
      const xt = xToPx(t1);
      if (child2 === "low") xB = xt; else xA = xt;
      strokeCut(Math.min(xA, xB), py, Math.max(xA, xB), py, 2.5);
    }
    ctx.setLineDash([]);
  }
  ctx.restore();
}

function drawPoints() {
  ctx.save();
  for (const p of POINTS) {
    const px = xToPx(p.x), py = yToPx(p.y);
    ctx.fillStyle = COLORS[p.c];
    ctx.beginPath();
    ctx.arc(px, py, 4.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "rgba(11,11,16,0.9)";
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }
  ctx.restore();
}

function drawLegend() {
  ctx.save();
  ctx.font = "12px Inter, sans-serif";
  ctx.textBaseline = "middle";
  const items = [
    { c: CLASS_A, label: "class A" },
    { c: CLASS_B, label: "class B" },
  ];
  // measure to right-align the legend box
  let widest = 0;
  for (const it of items) widest = Math.max(widest, ctx.measureText(it.label).width);
  const boxW = widest + 34;
  const x = canvas.width - PAD.r - boxW;
  let y = PAD.t + 12;

  ctx.fillStyle = "rgba(11,11,16,0.55)";
  ctx.strokeStyle = "rgba(255,255,255,0.10)";
  ctx.lineWidth = 1;
  roundRect(x - 10, PAD.t + 2, boxW + 4, items.length * 20 + 8, 8);
  ctx.fill();
  ctx.stroke();

  for (const it of items) {
    ctx.fillStyle = COLORS[it.c];
    ctx.beginPath();
    ctx.arc(x, y, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "rgba(11,11,16,0.9)";
    ctx.lineWidth = 1.5;
    ctx.stroke();
    ctx.fillStyle = "#e2e8f0";
    ctx.fillText(it.label, x + 12, y + 1);
    y += 20;
  }
  ctx.restore();
}

function roundRect(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

// ===================================================================
// Readout
// ===================================================================
function setPure(el, val) {
  el.textContent = val.toFixed(3);
  el.classList.toggle("pure", val < 1e-9);
}

function updateReadout() {
  const r = evalSplit(POINTS, feat1, thr1);
  setPure(elParent, r.parent);
  setPure(elLeft, r.gLow);
  setPure(elRight, r.gHigh);
  setPure(elChild, r.weighted);

  elDrop.textContent = r.drop.toFixed(3);
  // Highlight when this cut is (essentially) the best one for the feature.
  const best = bestThreshold(POINTS, feat1);
  elDrop.className = "v";
  if (r.drop > 1e-6 && r.drop >= best.drop - 1e-4) elDrop.classList.add("good");
}

// ===================================================================
// Controls
// ===================================================================
function setActive(seg, btn) {
  for (const b of seg.querySelectorAll(".segbtn")) b.classList.remove("active");
  btn.classList.add("active");
}

feat1Seg.addEventListener("click", (e) => {
  const btn = e.target.closest(".segbtn");
  if (!btn || btn.disabled) return;
  if (snapAnim) { cancelAnimationFrame(snapAnim); snapAnim = null; }
  feat1 = btn.dataset.feat;
  setActive(feat1Seg, btn);
  feat2Lbl.textContent = feat2(); // depth-2 uses the perpendicular feature
  render();
});

thr1Input.addEventListener("input", () => {
  if (snapAnim) { cancelAnimationFrame(snapAnim); snapAnim = null; }
  thr1 = parseFloat(thr1Input.value);
  thr1Val.textContent = thr1.toFixed(2);
  render();
});

function setDepth2Enabled(on) {
  useDepth2 = on;
  thr2Input.disabled = !on;
  for (const b of child2Seg.querySelectorAll(".segbtn")) b.disabled = !on;
  render();
}

enable2.addEventListener("change", () => setDepth2Enabled(enable2.checked));

child2Seg.addEventListener("click", (e) => {
  const btn = e.target.closest(".segbtn");
  if (!btn || btn.disabled) return;
  child2 = btn.dataset.child;
  setActive(child2Seg, btn);
  render();
});

thr2Input.addEventListener("input", () => {
  thr2 = parseFloat(thr2Input.value);
  thr2Val.textContent = thr2.toFixed(2);
  render();
});

// ----- Snap split 1 to the best threshold (animated) -----
function snapToBest() {
  if (snapAnim) cancelAnimationFrame(snapAnim);
  const target = bestThreshold(POINTS, feat1).t;
  const from = thr1;
  const dur = 650;
  const t0 = performance.now();
  function frame(t) {
    const k = clamp((t - t0) / dur, 0, 1);
    const e = 1 - Math.pow(1 - k, 3); // ease-out cubic
    thr1 = from + (target - from) * e;
    thr1Input.value = clamp(thr1, parseFloat(thr1Input.min), parseFloat(thr1Input.max));
    thr1Val.textContent = thr1.toFixed(2);
    render();
    if (k < 1) {
      snapAnim = requestAnimationFrame(frame);
    } else {
      thr1 = target;
      thr1Input.value = clamp(thr1, parseFloat(thr1Input.min), parseFloat(thr1Input.max));
      thr1Val.textContent = thr1.toFixed(2);
      render();
      snapAnim = null;
    }
  }
  snapAnim = requestAnimationFrame(frame);
}
document.getElementById("best").addEventListener("click", snapToBest);

// ----- New data: reseed deterministically and reset the splits -----
document.getElementById("newdata").addEventListener("click", () => {
  if (snapAnim) { cancelAnimationFrame(snapAnim); snapAnim = null; }
  SEED = (Math.imul(SEED, 1664525) + 1013904223) >>> 0; // next seed, still deterministic chain
  POINTS = makePoints(SEED);
  thr1 = 0; thr1Input.value = "0"; thr1Val.textContent = "0.00";
  thr2 = 0; thr2Input.value = "0"; thr2Val.textContent = "0.00";
  render();
});

// ===================================================================
// Init
// ===================================================================
thr1Val.textContent = thr1.toFixed(2);
thr2Val.textContent = thr2.toFixed(2);
feat2Lbl.textContent = feat2();
setDepth2Enabled(false);
render();

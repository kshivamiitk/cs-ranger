# Trees, Forests, and k-Nearest Neighbors

> When a straight line won't separate your classes, these three models carve up space in cleverer ways — and one of them (random forest) is the strongest off-the-shelf classifier most beginners will ever need.

## What you'll learn
- How a **decision tree** classifies by asking a sequence of yes/no questions (splits).
- Why a **random forest** — many trees voting — beats a single tree, in plain ensemble intuition.
- How **k-nearest-neighbors (KNN)** classifies by distance and majority vote, with no training in the usual sense.
- When each model shines, and how to read a tree's `feature_importances_`.

## Intuition

**Decision tree — twenty questions.** A tree classifies the way you'd play twenty questions: "Is petal length < 2.5cm? If yes → setosa. If no → is petal width < 1.8cm? ..." Each internal node is a **split**: pick one feature and a threshold that best separates the classes (measured by *Gini impurity* or *entropy* — how mixed the groups are). The data flows down to a leaf, and the leaf's majority class is the prediction. Because every split is on a single feature, the decision boundary is made of **axis-aligned steps** — boxes, not diagonal lines. Trees are wonderfully interpretable but, left unconstrained, they keep splitting until each leaf is pure, memorizing the training data — classic overfitting.

**Random forest — the wisdom of many trees.** A single tree is twitchy: change a few training points and the splits jump around (high variance). The fix is an **ensemble**. Train hundreds of trees, each on a random bootstrap sample of the rows *and* a random subset of features at each split, then let them **vote**. Individual trees still overfit, but their errors are uncorrelated, so averaging cancels the noise — like polling 500 slightly-wrong people and trusting the consensus. Random forests are robust, need little tuning, handle mixed feature scales, and are often the best first thing to try.

**KNN — you are who you stand next to.** KNN does almost nothing at "training" time: it just stores the data. To classify a new point, it finds the `k` closest training points (by Euclidean distance) and takes a **majority vote** of their labels. Small `k` (e.g. 1) gives a jagged, noise-sensitive boundary; large `k` smooths it out but can blur real structure. KNN is intuitive and makes no assumptions about the boundary shape, but it's slow at prediction time on big data and **demands feature scaling** — a feature measured in thousands would otherwise dominate the distance.

**When each shines:** logistic regression for linearly separable, interpretable problems; **decision tree** when you must *explain* the rule; **random forest** as a strong, low-effort default on tabular data; **KNN** for small datasets with a meaningful notion of "closeness".

## Python in practice

We'll train all three on `load_wine` (3 classes, 13 numeric features) and compare, then read feature importances.

```python
import numpy as np
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier

X, y = load_wine(return_X_y=True)
feat = load_wine().feature_names
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.25, random_state=1, stratify=y)

models = {
    "DecisionTree": DecisionTreeClassifier(max_depth=4, random_state=1),
    "RandomForest": RandomForestClassifier(n_estimators=300, random_state=1),
    # KNN needs scaling, so wrap it in a pipeline that scales then classifies.
    "KNN (k=5)":    make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=5)),
}

for name, m in models.items():
    m.fit(X_tr, y_tr)
    print(f"{name:14s} test accuracy: {m.score(X_te, y_te):.3f}")
```

Expected output (approximate):

```
DecisionTree   test accuracy: 0.911
RandomForest   test accuracy: 0.978
KNN (k=5)      test accuracy: 0.956
```

The forest usually edges out the single tree because it averages away the tree's variance. Now read which features drove the decisions — only tree-based models expose this:

```python
rf = models["RandomForest"]
order = np.argsort(rf.feature_importances_)[::-1]   # most important first
print("Top 4 features the forest relied on:")
for i in order[:4]:
    print(f"  {feat[i]:28s} importance={rf.feature_importances_[i]:.3f}")
```

Expected (approximate):

```
Top 4 features the forest relied on:
  proline                      importance=0.180
  flavanoids                   importance=0.165
  color_intensity              importance=0.150
  od280/od315_of_diluted_wines importance=0.130
```

`feature_importances_` sums to 1.0 across all features; a higher value means the forest used that feature to make more (and more decisive) splits. It's a quick, free explanation of *what the model pays attention to* — gold for a portfolio write-up.

## Common mistakes

- **Letting a tree grow unbounded.** A tree with no `max_depth` or `min_samples_leaf` will hit ~100% train accuracy and far less on test. Constrain it, or use a forest.
- **Skipping scaling for KNN.** KNN uses raw distances; an unscaled large-range feature swamps the rest. Always scale (the pipeline above does it for you).
- **Reading single-tree feature importances as gospel.** They can be unstable and biased toward high-cardinality features. Prefer the forest's averaged importances, or permutation importance.
- **Picking `k=1` for KNN by default.** It memorizes and is noise-sensitive. Tune `k` (odd values avoid ties in binary problems) with cross-validation.
- **Assuming more trees overfit.** Adding trees to a random forest doesn't increase overfitting — it stabilizes the estimate. It just costs more time/memory.

## Small exercise

Change the decision tree to `DecisionTreeClassifier(random_state=1)` (no `max_depth`) and re-check its **train** accuracy with `m.score(X_tr, y_tr)` versus its test accuracy. You should see ~1.0 on train but lower on test — the textbook signature of overfitting. Then confirm the random forest's train/test gap is much smaller.

## Before you continue
- [ ] I can describe how a decision tree splits data and why its boundary is stair-stepped.
- [ ] I can explain the ensemble intuition: why many voting trees beat one.
- [ ] I can explain KNN's "majority vote of nearest neighbors" and why it needs scaling.
- [ ] I can read `feature_importances_` and say what it means.

# Backpropagation and Training Intuition

> Backpropagation sounds intimidating, but the idea is simple: measure how wrong the network is, figure out which weights to blame, and nudge each one a little in the right direction — then repeat thousands of times.

## What you'll learn
- What a **loss function** is and why training means *minimizing* it.
- The intuition behind **gradients** and gradient descent (downhill on a landscape).
- How **backpropagation** uses the chain rule to assign blame to every weight — without heavy math.
- What **learning rate**, **epochs**, and **batches** actually control.
- Why deep networks are data-hungry compared to simpler models.

## Intuition
A freshly built network has random weights, so its predictions are garbage. Training is the loop that fixes them. It has three repeating steps:

1. **Forward pass.** Run inputs through the network to get predictions (you did this last lesson).
2. **Measure the error.** A **loss function** scores how far the predictions are from the true answers — one number, where lower is better. For classification it's usually cross-entropy; for regression, mean squared error.
3. **Update the weights.** Adjust every weight a little so that next time the loss is lower.

The trick in step 3 is knowing *which direction* to move each weight. Picture the loss as a hilly landscape and the network's current weights as a marble sitting somewhere on it. You want to roll the marble downhill toward the lowest valley (smallest loss). The **gradient** is just the slope under the marble — it points uphill, so you step in the *opposite* direction. That's **gradient descent**: repeatedly take small downhill steps.

But a network has thousands of weights, all tangled together. How do you find the slope for each one? **Backpropagation.** It starts at the output (where the error is obvious), then walks *backward* through the layers, using the **chain rule** to ask, layer by layer, "how much did *this* weight contribute to the final error?" Weights that pushed the prediction the wrong way get the blame; weights that helped get rewarded. The chain rule is what lets the error at the very end flow backward and assign a precise share of blame to a weight buried in the first layer.

Three knobs control how this loop behaves:

- **Learning rate** — the size of each downhill step. Too big and the marble overshoots the valley and bounces around; too small and training crawls. It's the single most important hyperparameter to tune.
- **Epoch** — one full pass over the entire training set. You typically need many epochs (dozens to hundreds) because each pass only nudges the weights a little.
- **Batch** — instead of computing the gradient on all data at once (slow) or one example at a time (noisy), we use small **batches** (e.g. 32 examples). This is *stochastic gradient descent*: faster, and the slight noise can even help escape bad spots.

Why are deep networks data-hungry? Because they have so many weights. A model with thousands or millions of parameters has enormous flexibility — which means it can easily *memorize* a small dataset (overfit) instead of learning the real pattern. It needs lots of examples to pin all those weights down to something that generalizes. Simpler models (logistic regression, small trees) have far fewer knobs, so they learn useful patterns from much less data. That's exactly why earlier in this course you got strong results with small datasets and simple models — and why you'd reach for a big neural net only when you have lots of data and a genuinely complex pattern.

## The training loop, in plain pseudocode

```
initialize all weights randomly
repeat for many epochs:
    for each batch of training examples:
        predictions = forward_pass(batch)          # step 1
        loss        = loss_fn(predictions, labels)  # step 2: how wrong?
        gradients   = backprop(loss)                # which weights to blame?
        weights     = weights - learning_rate * gradients   # step 3: step downhill
```

That final line is the whole heart of training: **move each weight a small step in the direction that reduces the loss.** Everything else is bookkeeping around it.

## Watching loss go down (with scikit-learn)

You don't have to hand-code backprop to *see* it work. scikit-learn's `MLPClassifier` runs this exact loop internally and records the loss at each iteration:

```python
import numpy as np
from sklearn.neural_network import MLPClassifier
from sklearn.datasets import make_moons

# Two interleaving half-moons: a nonlinear pattern a single neuron can't separate
X, y = make_moons(n_samples=400, noise=0.2, random_state=0)

net = MLPClassifier(
    hidden_layer_sizes=(8,),   # one hidden layer of 8 neurons
    activation="relu",
    learning_rate_init=0.05,   # the step size knob
    max_iter=400,              # up to 400 epochs
    random_state=0,
)
net.fit(X, y)

# loss_curve_ is the loss after each epoch -> it should DECREASE over time
curve = net.loss_curve_
print(f"loss at epoch   1: {curve[0]:.4f}")
print(f"loss at epoch  20: {curve[min(19, len(curve)-1)]:.4f}")
print(f"loss at last epoch: {curve[-1]:.4f}")
print(f"final train accuracy: {net.score(X, y):.3f}")
# The loss starts high and falls toward a small value as training proceeds;
# accuracy climbs well above 0.9 because the hidden layer can bend the boundary.
```

```python
# Turn the learning rate WAY up to see instability: the loss can jump around
shaky = MLPClassifier(hidden_layer_sizes=(8,), learning_rate_init=2.0,
                      max_iter=400, random_state=0).fit(X, y)
print("high-LR final loss:", round(shaky.loss_curve_[-1], 4))
# Often a worse / noisier final loss than the 0.05 run -> the step was too big.
```

Compare the two runs: a sensible learning rate (0.05) slides smoothly downhill; a huge one (2.0) tends to overshoot and settle at a worse loss. That single experiment captures why the learning rate matters so much.

## Common mistakes
- **Thinking backprop is a different algorithm from "training".** Backprop is just the efficient method for *computing the gradients* that gradient descent then uses to update weights. They're two halves of one loop.
- **Picking a giant learning rate "to train faster".** Too large a step overshoots the minimum and the loss bounces or diverges. Start small (e.g. 0.01–0.1) and adjust.
- **Stopping after one epoch.** One pass barely moves the weights. Real training needs many epochs; watch the loss curve flatten before you stop.
- **Throwing a deep network at tiny data.** With few examples, a big network memorizes the training set (overfits) and fails on new data. Prefer a simpler model, or get more data, or regularize.
- **Ignoring the loss curve.** If loss isn't decreasing, something is wrong (learning rate, scaling, or the data). The loss curve is your single best diagnostic.

## Small exercise
1. Run the `make_moons` example and print the full `net.loss_curve_` (or just its first and last 5 values). Confirm the loss generally decreases.
2. Try three learning rates — `0.001`, `0.05`, `1.0` — keeping everything else fixed. Which gives the lowest final loss? Which is too slow, and which is unstable?
3. In one sentence each, define *epoch*, *batch*, and *learning rate* in your own words.

## Before you continue
- [ ] I can describe the training loop: forward pass → loss → backprop → weight update, repeated.
- [ ] I can explain a gradient as the slope we step *down* to reduce loss.
- [ ] I can say what the learning rate, epochs, and batches each control.
- [ ] I can explain why deep networks usually need a lot of data.

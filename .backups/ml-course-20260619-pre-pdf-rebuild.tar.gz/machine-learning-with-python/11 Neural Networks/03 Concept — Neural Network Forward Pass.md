# Neural Network Forward Pass

> A neural network's prediction is just multiply, add, squish — repeated layer by layer from input to output. The forward pass is that whole journey.

## What is this?

The **forward pass** is how a neural network turns an input into a prediction. Data flows **left to right** — from the input layer, through any hidden layers, to the output layer — and at every neuron the exact same two-step recipe runs:

1. **Weighted sum:** `z = (w1*x1 + w2*x2 + ... + wn*xn) + b`. Each input `x` is multiplied by a **weight** `w` (how much that input matters), the products are added up, and a **bias** `b` is added (a constant nudge).
2. **Activation:** `a = activation(z)`. The sum `z` is passed through a nonlinear function (like ReLU or sigmoid) that "squishes" or bends it.

A **layer** is just many neurons doing this in parallel. The activations coming *out* of one layer become the inputs *into* the next layer, and you repeat the recipe until you reach the output. That's the entire forward pass: **multiply, add, squish — layer after layer.**

The **output layer** uses an activation matched to the task:
- **sigmoid** for binary yes/no (squishes to a probability between 0 and 1),
- **softmax** for picking one of several classes (a set of probabilities that sum to 1),
- **linear** (no activation) for predicting a raw number (regression).

## Why do we need it?

The forward pass *is* the model making a prediction — without it there's nothing to predict with, and nothing for training to improve. But the part that's easy to overlook is the **activation function**, and it's the reason neural networks are powerful at all.

Here's the catch: **stacking linear layers gives you nothing but another linear layer.** If you take a weighted sum, then feed it into another weighted sum, then another, the whole thing collapses algebraically into a single weighted sum. Ten linear layers = one linear layer = a plain line. The **nonlinearity** in the activation is what breaks that collapse. It lets each layer bend the data, so stacked layers can carve out curves, corners, and complex decision boundaries that a straight line never could. No nonlinearity, no deep learning — just an expensive linear model.

## Where it's used in real ML

- **Every prediction from every neural network** runs a forward pass — image classifiers, language models, recommendation systems, all of it.
- **Training** runs a forward pass first (to get a prediction and measure the error) before backpropagation adjusts the weights — so understanding it is the prerequisite for understanding learning.
- **Inference / deployment** is *just* the forward pass: a trained model in production does nothing but run inputs forward to outputs, millions of times.
- **Debugging** — when a network outputs garbage, you trace the forward pass layer by layer (often by printing activations) to find where values explode, vanish, or saturate.

## What breaks if you ignore it

- **Forget the nonlinearity → your deep network is secretly a line.** Stack all-linear layers and the model can't learn anything a single linear regression couldn't. It will underfit badly and you'll wonder why "more layers" did nothing.
- **Wrong output activation → nonsensical predictions.** Use linear output for a yes/no task and you'll get values like -3.2 or 8.7 instead of a probability. Use sigmoid for regression and you'll cap every prediction between 0 and 1.
- **Misalign the shapes → it crashes or silently does the wrong math.** The weighted sum only works if each layer's weights line up with the size of the inputs it receives. Get the dimensions wrong and the matrix multiply errors out (or worse, broadcasts into nonsense).

## Mental model

Think of an **assembly line of inspectors**, each passing a verdict down the line.

```
 inputs        hidden layer            output
              (each neuron:
 x1 ---\       multiply, add,            \
 x2 ----+----> then squish )  --a1-->     \
 x3 ---/       [n1] [n2] [n3]   --a2-->     [out] --> prediction
               every neuron sees   --a3-->  (squish for
               ALL the inputs               the task)
        weights w   bias b      activations a
        "how much   "a constant  "the squished
         it matters"  nudge"       result passed on"
```

Each inspector (neuron) takes everything from the previous station, weighs each item by how much it cares about it, adds its own fixed offset, then makes a judgment call (the squish). It hands that single number forward. The next station treats those judgments as its raw materials. By the final station, all those small weighted-and-squished decisions have combined into one prediction. The forward pass is one pass down this assembly line.

## Example 1 — Tiny toy example

Let's compute **one neuron** by hand. It has 2 inputs, 2 weights, and a bias, and uses a **sigmoid** activation.

Inputs and parameters:
```
x1 = 2.0,  x2 = 3.0
w1 = 0.5,  w2 = -1.0
b  = 1.0
```

**Step 1 — weighted sum:**
```
z = w1*x1 + w2*x2 + b
z = (0.5 * 2.0) + (-1.0 * 3.0) + 1.0
z = 1.0 + (-3.0) + 1.0
z = -1.0
```

**Step 2 — activation (sigmoid):** `sigmoid(z) = 1 / (1 + e^(-z))`
```
sigmoid(-1.0) = 1 / (1 + e^(1.0))
              = 1 / (1 + 2.718)
              = 1 / 3.718
              = 0.269
```

So this neuron outputs **≈ 0.269**. That's the complete forward pass for a single neuron: multiply each input by its weight, add them with the bias to get `z = -1.0`, then squish through sigmoid to get `0.269`. A whole network is just thousands of these little calculations chained together.

## Example 2 — Practical ML example

Now scale that up to a realistic shape: classifying handwritten digits. Suppose each image is **784 pixels** (a flattened 28×28 image), and you have a small network:

- **Input layer:** 784 values (the pixel brightnesses).
- **Hidden layer:** 128 neurons, each doing `z = (weights · pixels) + bias`, then a **ReLU** activation (`max(0, z)` — keep positives, zero out negatives). Out come 128 activations.
- **Output layer:** 10 neurons (one per digit 0–9), then **softmax** to turn the 10 raw scores into 10 probabilities that sum to 1.

The forward pass for one image: the 784 pixels get multiplied and summed against the hidden layer's weights and biases, ReLU squishes the 128 results, those 128 activations become the inputs to the output layer, and softmax converts the final 10 numbers into probabilities like `{0: 0.01, ..., 7: 0.92, ...}`. The network's prediction is the digit with the highest probability — here, **7**. Every layer used the *exact same* multiply-add-squish recipe from Example 1; only the sizes and the activation choices changed. ReLU in the middle provides the nonlinearity; softmax at the end matches the "pick one of ten classes" task.

## Python code example

```python
import numpy as np

# Tiny network: 3 inputs -> 1 hidden layer (4 neurons, ReLU) -> 1 output (sigmoid).
# We set weights/biases by hand (in real training these would be LEARNED).

# --- Inline input: one example with 3 features ---
x = np.array([1.0, 2.0, -1.0])               # shape (3,)

# --- Layer 1 (hidden): weights shape (3 inputs, 4 neurons), one bias per neuron ---
W1 = np.array([[ 0.2,  0.8, -0.5,  0.1],
               [ 0.5, -0.3,  0.7,  0.4],
               [-0.6,  0.2,  0.3, -0.9]])     # shape (3, 4)
b1 = np.array([0.1, -0.2, 0.05, 0.3])         # shape (4,)

# --- Layer 2 (output): weights shape (4 inputs, 1 neuron), one bias ---
W2 = np.array([[0.7], [-1.1], [0.5], [0.9]])  # shape (4, 1)
b2 = np.array([0.2])                          # shape (1,)

def relu(z):
    return np.maximum(0, z)                   # keep positives, zero the rest

def sigmoid(z):
    return 1 / (1 + np.exp(-z))               # squish to a probability (0..1)

# --- Forward pass, left to right ---
# Hidden layer: weighted sum (multiply + add bias), then ReLU activation.
z1 = x @ W1 + b1            # the @ is the multiply-and-sum for all 4 neurons at once
a1 = relu(z1)
print("hidden pre-activation z1:", np.round(z1, 3))
print("hidden activations  a1:", np.round(a1, 3), "<- negatives zeroed by ReLU")

# Output layer: weighted sum on the hidden activations, then sigmoid for a probability.
z2 = a1 @ W2 + b2
a2 = sigmoid(z2)
print("output pre-activation z2:", np.round(z2, 3))
print("final prediction (probability):", np.round(a2, 3))
print("class:", "1 (yes)" if a2[0] >= 0.5 else "0 (no)")
```

This prints the hidden layer's pre-activations, the ReLU'd activations (note negatives become 0), and the final sigmoid probability. The `@` operator does the multiply-and-add for a whole layer of neurons in one line — the same `z = Σ(w·x) + b` from the toy example, just vectorized.

## Common mistakes

- **Stacking layers with no activation between them.** Without a nonlinearity, the whole network collapses to a single linear layer. Always put a nonlinear activation (ReLU, etc.) between linear steps.
- **Picking the wrong output activation.** Sigmoid for binary, softmax for multi-class, linear (none) for regression. Mismatch it and your outputs are meaningless for the task.
- **Mismatched weight shapes between layers.** Each layer's weight matrix must accept the size of the activations the previous layer produces. A shape mismatch crashes the matrix multiply (or silently broadcasts wrong).
- **Forgetting the bias term.** Dropping `b` forces every neuron's decision boundary through the origin, which severely limits what the network can fit. Keep the bias.
- **Confusing pre-activation `z` with the activation `a`.** `z` is the raw weighted sum; `a` is `z` after the squish. The *next* layer uses `a`, not `z` — mixing them up breaks the forward pass.

## Before you continue
- [ ] I can write the two-step recipe for one neuron: weighted sum (`z`), then activation (`a`).
- [ ] I can explain why stacking linear layers with no nonlinearity is pointless.
- [ ] I can pick the right output activation for binary, multi-class, and regression tasks.
- [ ] I computed the toy neuron by hand and got the same answer the formula gives.
- [ ] I can trace data flowing left to right through a hidden layer to an output prediction.

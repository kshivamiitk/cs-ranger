# Lab — Train a Small Neural Net

## Objective
Train your first real neural network — a scikit-learn `MLPClassifier` — to recognize handwritten digits. You will scale the features, train the network, evaluate it with accuracy and a confusion matrix, experiment with the `hidden_layer_sizes` to see how network capacity changes results, and (optionally) compute a single forward pass by hand in NumPy to connect the code to the math from the lessons. Everything runs offline on a built-in dataset.

## Dataset
We use `load_digits` from scikit-learn: 1,797 tiny 8×8 grayscale images of handwritten digits 0–9. Each image is flattened into 64 pixel features (values 0–16), and the label is the digit it shows.

| property | value |
|---|---|
| samples | 1,797 |
| features | 64 (an 8×8 image flattened) |
| classes | 10 (digits 0 through 9) |
| pixel range | 0 (white) to 16 (dark) |

A multi-class problem with a nonlinear pattern — perfect for a small neural net. (No download needed; it ships with scikit-learn.)

## Steps

**Step 1 — Load the data and look at it.** Confirm the shapes and peek at one image as numbers.

```python
import numpy as np
from sklearn.datasets import load_digits

digits = load_digits()
X, y = digits.data, digits.target

print("X shape:", X.shape)     # (1797, 64)  -> 1797 images, 64 pixels each
print("y shape:", y.shape)     # (1797,)
print("classes:", np.unique(y))  # [0 1 2 3 4 5 6 7 8 9]

# One example reshaped back to its 8x8 grid (pixel intensities 0..16)
print(X[0].reshape(8, 8).astype(int))
print("its label:", y[0])      # this image is the digit 0
```

**Step 2 — Split into train and test sets.** Stratify so every digit is represented in both splits.

```python
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)
print("train:", X_train.shape[0], " test:", X_test.shape[0])
# train: 1347  test: 450
```

**Step 3 — Scale the features.** Neural nets train far better when inputs are on a similar, small scale. `StandardScaler` centers each feature to mean 0, variance 1. Fit on train only, then apply to both.

```python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)   # learn mean/std from TRAIN, then scale
X_test_s = scaler.transform(X_test)         # apply the SAME transform to test
print("after scaling, train mean ~0:", round(float(X_train_s.mean()), 4))
# after scaling, train mean ~0: 0.0
```

**Step 4 — Build and train the network.** One hidden layer of 32 ReLU neurons. `max_iter` is the cap on training epochs.

```python
from sklearn.neural_network import MLPClassifier

mlp = MLPClassifier(
    hidden_layer_sizes=(32,),   # one hidden layer, 32 neurons
    activation="relu",
    max_iter=300,
    random_state=42,
)
mlp.fit(X_train_s, y_train)
print("epochs run:", mlp.n_iter_)
print("final training loss:", round(mlp.loss_, 4))
# Loss should be small; n_iter_ is how many epochs it took to converge.
```

**Step 5 — Evaluate accuracy.** Score on the held-out test set.

```python
from sklearn.metrics import accuracy_score

y_pred = mlp.predict(X_test_s)
print("Test accuracy:", round(accuracy_score(y_test, y_pred), 4))
# Expect roughly 0.96-0.98 on digits with this setup.
```

**Step 6 — Confusion matrix.** See exactly which digits get confused for which.

```python
from sklearn.metrics import confusion_matrix, classification_report

cm = confusion_matrix(y_test, y_pred)
print(cm)            # rows = true digit, columns = predicted digit
print()
print(classification_report(y_test, y_pred))
# The diagonal should be large (correct). Off-diagonal cells reveal mistakes,
# e.g. a few 8s predicted as 1s, or 9s as 7s -> visually similar digits.

# Optional: a labeled heatmap (matplotlib, still offline)
import matplotlib.pyplot as plt
from sklearn.metrics import ConfusionMatrixDisplay
ConfusionMatrixDisplay(cm, display_labels=range(10)).plot(cmap="viridis")
plt.title("Digit confusion matrix")
plt.show()
```

**Step 7 — Vary the hidden layer size and compare.** Capacity is controlled by the hidden neurons. Train several sizes and watch accuracy change.

```python
for size in [(4,), (16,), (64,), (64, 32)]:
    m = MLPClassifier(hidden_layer_sizes=size, activation="relu",
                      max_iter=300, random_state=42)
    m.fit(X_train_s, y_train)
    acc = m.score(X_test_s, y_test)
    print(f"hidden_layer_sizes={str(size):>10}  test acc={acc:.4f}")
# Tiny (4,) underfits (too little capacity for 10 digits).
# (16,)/(64,) do well. (64,32) adds a second layer -> similar or slightly better.
# More capacity is not always better once you have enough.
```

**Step 8 (Optional) — One forward pass by hand.** Pull the trained weights out of the MLP and reproduce a single prediction in pure NumPy, proving the network is just dot products + activations from the lessons.

```python
# MLP stores per-layer weight matrices (coefs_) and biases (intercepts_).
W1, W2 = mlp.coefs_          # (64, 32) and (32, 10)
b1, b2 = mlp.intercepts_     # (32,)    and (10,)

def relu(z):
    return np.maximum(0, z)

def softmax(z):
    z = z - z.max()
    e = np.exp(z)
    return e / e.sum()

x = X_test_s[0]                       # one already-scaled test image
h = relu(x @ W1 + b1)                 # hidden layer: 64 -> 32, ReLU
out = softmax(h @ W2 + b2)            # output layer: 32 -> 10, softmax
manual_pred = int(np.argmax(out))     # most probable digit

print("hand-computed prediction:", manual_pred)
print("sklearn prediction:      ", int(mlp.predict(x.reshape(1, -1))[0]))
print("true label:              ", int(y_test[0]))
# The hand-computed and sklearn predictions MATCH -> a forward pass is
# literally (x @ W + b) -> activation, repeated per layer.
```

## Expected output
- **Test accuracy** of roughly **0.96–0.98** with `(32,)` ReLU neurons. Digits is a clean, well-separated dataset, so a small net does very well.
- **Confusion matrix** with a strong diagonal (most predictions correct) and a sprinkle of off-diagonal mistakes between visually similar digits (e.g. 1↔8, 3↔9, 4↔9). Reading those cells tells you *which* digits the model finds hard.
- **Hidden-size sweep**: the smallest network `(4,)` clearly underperforms (not enough neurons to represent 10 digit shapes), while `(16,)`, `(64,)`, and `(64, 32)` cluster near the top. The lesson: add capacity until accuracy stops improving — beyond that you only risk overfitting and slower training.
- **Manual forward pass** prints the *same* digit as `mlp.predict`. That match is the payoff: it confirms the trained network is nothing more than the layer-by-layer `x @ W + b → activation` you computed by hand in lesson 2.

## Extension challenge
1. **Try `make_moons` instead.** Swap the dataset for `from sklearn.datasets import make_moons` with `n_samples=500, noise=0.2`. Train an `MLPClassifier(hidden_layer_sizes=(8,))` and plot the decision boundary. Then try `(1,)` hidden neuron — can a single neuron bend the moon shape?
2. **Watch the loss curve.** Plot `mlp.loss_curve_` and overlay runs with `learning_rate_init` set to `0.001`, `0.01`, and `0.5`. Which converges smoothly and which is unstable?
3. **Regularize.** Increase the `alpha` parameter (L2 penalty) from its default to `1.0` on a large network like `(128, 64)`. Does stronger regularization change the gap between training and test accuracy?

# Checkpoint — Neural Networks

## What you should now be able to do
- Describe a neuron as `activation(w · x + b)` and explain why logistic regression is a one-neuron network.
- Explain why nonlinear activations are what make stacking layers worthwhile.
- Organize weights and biases into per-layer matrices and compute a full forward pass in NumPy.
- Choose ReLU, sigmoid, or softmax appropriately for hidden vs output layers.
- Describe the training loop (forward → loss → backprop → update) and what learning rate, epochs, and batches control.
- Train and evaluate a scikit-learn `MLPClassifier`, including scaling, accuracy, and a confusion matrix.

## Review questions
1. Write the two operations a single neuron performs, in order.
2. In one sentence, why is a logistic regression model the same thing as a single sigmoid neuron?
3. Why does stacking purely *linear* layers (no activation between them) gain you nothing?
4. You're building a network that classifies an image into one of 10 categories. Which activation belongs on the output layer, and why not sigmoid?
5. For a 2-input → 4-hidden layer, what is the shape of the weight matrix `W`, and what shape does `x @ W` produce for a single example?
6. In gradient descent, the gradient points "uphill" on the loss landscape. Which direction do we move the weights, and why?
7. What does backpropagation actually compute, and what does the chain rule let it do?
8. Your learning rate is far too large. Describe what you'd likely see happen to the loss during training.
9. Why do deep neural networks typically need much more data than a logistic regression to perform well?
10. Why do we scale features (e.g. with `StandardScaler`) before training a neural net?

## Answers
<details>
<summary>Show answers</summary>

1. (a) A weighted sum of its inputs plus a bias: `z = w · x + b`. (b) An activation function applied to that sum: `a = activation(z)`.
2. A logistic regression computes `sigmoid(w · x + b)` — exactly a single neuron with a sigmoid activation. Its `coef_` and `intercept_` are that neuron's weights and bias.
3. A linear function of a linear function is still linear, so the whole stack mathematically collapses into a single equivalent linear layer. Without a nonlinearity between layers, depth adds no expressive power.
4. **Softmax**, because it turns the 10 raw scores into probabilities that sum to 1 (a proper "pick one of K" distribution). Sigmoid would give 10 independent probabilities that don't sum to 1, which doesn't represent a single mutually-exclusive choice.
5. `W` has shape `(2, 4)` — `(in_features, out_neurons)`. For a single example `x` of shape `(2,)`, `x @ W` has shape `(4,)`: one weighted sum per hidden neuron.
6. We move the weights in the **opposite** direction of the gradient (downhill), because we want to *decrease* the loss, and the gradient points toward increasing loss.
7. Backpropagation computes the **gradient of the loss with respect to every weight** — i.e., how much each weight contributed to the error. The chain rule lets it propagate the output error *backward* through each layer, multiplying local derivatives so even a weight in the first layer gets its correct share of the blame.
8. The loss bounces around, fails to settle, or even grows (diverges) — the steps overshoot the minimum repeatedly instead of descending into it.
9. Deep networks have very many parameters (weights), giving them huge flexibility. With little data they tend to memorize the training set (overfit) rather than learn the true pattern. More data is needed to constrain all those weights toward something that generalizes. Logistic regression has far fewer parameters, so it learns from much less data.
10. Neural nets train via gradient descent, which behaves much better when all features are on a similar, small scale. Unscaled features with very different ranges produce a distorted loss landscape and slow, unstable training. Scaling (mean 0, variance 1) makes the gradients well-conditioned and convergence faster.

</details>

## Hands-on tasks
1. **Hand-compute a neuron.** For `x = [1, -2]`, `w = [0.4, 0.5]`, `b = 0.3`, compute `z` and then `sigmoid(z)` (in Python or on paper). Verify your `z` is `0.4·1 + 0.5·(-2) + 0.3 = -0.3`.
2. **Two-layer forward pass.** Using NumPy, build a network with `W1` of shape `(2, 3)` and `W2` of shape `(3, 1)` (random small values), then compute a full forward pass for one input — ReLU on the hidden layer, sigmoid on the output. Print every intermediate value.
3. **Solve XOR.** Train an `MLPClassifier(hidden_layer_sizes=(4,), activation="tanh", max_iter=5000)` on the four XOR points and confirm it reaches accuracy 1.0, then show that a `LogisticRegression` cannot.
4. **Digit classifier.** Reuse the lab pipeline: scale `load_digits`, train an `MLPClassifier`, and print test accuracy plus the confusion matrix. Identify the two digits most often confused with each other.

## You're ready for the next module when…
- [ ] I can compute a forward pass for a small network by hand in NumPy.
- [ ] I can explain why nonlinear activations make depth meaningful, with XOR as an example.
- [ ] I can describe the training loop and what the learning rate controls.
- [ ] I can train, scale, and evaluate an `MLPClassifier` and read its confusion matrix.

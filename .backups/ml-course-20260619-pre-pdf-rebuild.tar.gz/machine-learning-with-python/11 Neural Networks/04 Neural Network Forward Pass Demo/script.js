"use strict";

// ============================================================
// A tiny MLP: 2 inputs -> 3 hidden (sigmoid) -> 1 output (sigmoid)
// The forward pass is computed entirely in JavaScript below.
// ============================================================

const canvas = document.getElementById("net");
const ctx = canvas.getContext("2d");

// Logical drawing size (canvas attribute size). CSS scales it responsively.
const W = canvas.width;   // 900
const H = canvas.height;  // 440

// ---- Theme colors (match LearnRift dark theme) ----
const COL = {
  text: "#e2e8f0",
  dim: "#94a3b8",
  violet: "#a78bfa",
  cyan: "#22d3ee",
  danger: "#f87171",
  success: "#34d399",
  node: "#1b1d27",
  border: "rgba(255,255,255,0.10)",
};

// ---- Network parameters ----
// weightsIH[h][i] = weight from input i -> hidden neuron h
// weightsHO[o][h] = weight from hidden neuron h -> output o
let weightsIH, biasH, weightsHO, biasO;

function randn() {
  // Box-Muller transform -> approx standard normal
  let u = 0, v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
}

function randomizeWeights() {
  weightsIH = [];          // 3 hidden neurons, each with 2 input weights
  biasH = [];
  for (let h = 0; h < 3; h++) {
    weightsIH.push([randn(), randn()]);
    biasH.push(randn() * 0.5);
  }
  weightsHO = [[randn(), randn(), randn()]]; // 1 output neuron, 3 hidden weights
  biasO = [randn() * 0.5];
}

// ---- Math ----
function sigmoid(z) {
  // Numerically stable: clamp extreme inputs so exp() can't overflow to Infinity.
  if (z >= 0) {
    const e = Math.exp(-z);
    return 1 / (1 + e);
  }
  const e = Math.exp(z);
  return e / (1 + e);
}

// Compute the full forward pass for the two current inputs.
function forwardPass(x1, x2) {
  const inputs = [x1, x2];

  // Hidden layer: z = w . x + b, then sigmoid
  const hiddenZ = [];
  const hiddenA = [];
  for (let h = 0; h < 3; h++) {
    let z = biasH[h];
    z += weightsIH[h][0] * inputs[0];
    z += weightsIH[h][1] * inputs[1];
    hiddenZ.push(z);
    hiddenA.push(sigmoid(z));
  }

  // Output layer: one neuron over the 3 hidden activations
  let zo = biasO[0];
  for (let h = 0; h < 3; h++) zo += weightsHO[0][h] * hiddenA[h];
  const outputA = sigmoid(zo);

  return { inputs, hiddenZ, hiddenA, outputA };
}

// ---- Layout: node positions ----
function buildLayout() {
  const padX = 120;
  const colX = [padX, W / 2, W - padX];   // input col, hidden col, output col

  const inputY = [H * 0.36, H * 0.64];
  const hiddenY = [H * 0.22, H * 0.5, H * 0.78];
  const outputY = [H * 0.5];

  return {
    input: inputY.map((y) => ({ x: colX[0], y })),
    hidden: hiddenY.map((y) => ({ x: colX[1], y })),
    output: outputY.map((y) => ({ x: colX[2], y })),
  };
}

let layout = buildLayout();

// ---- Edge color/width from a weight ----
function edgeStyle(weight) {
  const mag = Math.min(Math.abs(weight), 3) / 3;   // 0..1
  const color = weight >= 0 ? COL.cyan : COL.danger;
  const width = 1 + mag * 5;                         // 1..6 px
  const alpha = 0.25 + mag * 0.6;                    // 0.25..0.85
  return { color, width, alpha };
}

function withAlpha(hex, alpha) {
  // hex like "#22d3ee" -> rgba
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r},${g},${b},${alpha})`;
}

// ============================================================
// Animation state
// `progress` in [0,1]: 0 -> nothing flowed, 0.5 -> reached hidden,
// 1 -> reached output. Edges "fill" as the wave passes them.
// ============================================================
let progress = 1;            // start fully revealed (static view)
let animating = false;
let animStart = 0;
const ANIM_MS = 1400;

function draw(state) {
  ctx.clearRect(0, 0, W, H);

  // Layer labels
  ctx.fillStyle = COL.dim;
  ctx.font = "14px Inter, system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("Inputs", layout.input[0].x, 28);
  ctx.fillText("Hidden layer (sigmoid)", layout.hidden[0].x, 28);
  ctx.fillText("Output (sigmoid)", layout.output[0].x, 28);

  // ---- Edges input -> hidden (first half of the animation: 0 .. 0.5) ----
  const ihReveal = Math.min(progress / 0.5, 1);   // 0..1
  for (let h = 0; h < 3; h++) {
    for (let i = 0; i < 2; i++) {
      drawEdge(layout.input[i], layout.hidden[h], weightsIH[h][i], ihReveal);
    }
  }

  // ---- Edges hidden -> output (second half: 0.5 .. 1) ----
  const hoReveal = Math.max(0, Math.min((progress - 0.5) / 0.5, 1));
  for (let h = 0; h < 3; h++) {
    drawEdge(layout.hidden[h], layout.output[0], weightsHO[0][h], hoReveal);
  }

  // ---- Nodes ----
  // Inputs always show their value
  for (let i = 0; i < 2; i++) {
    drawNode(layout.input[i], state.inputs[i], COL.violet, `x${i + 1}`, true);
  }
  // Hidden nodes light up once the wave reaches them (progress >= 0.5)
  const hiddenActive = progress >= 0.5;
  for (let h = 0; h < 3; h++) {
    drawNode(layout.hidden[h], state.hiddenA[h], COL.cyan, `h${h + 1}`, hiddenActive);
  }
  // Output lights up at the end (progress >= 1)
  const outActive = progress >= 0.999;
  drawNode(layout.output[0], state.outputA, COL.success, "y", outActive);
}

function drawEdge(a, b, weight, reveal) {
  const { color, width, alpha } = edgeStyle(weight);
  // Partially reveal the edge by interpolating the endpoint.
  const ex = a.x + (b.x - a.x) * reveal;
  const ey = a.y + (b.y - a.y) * reveal;

  ctx.beginPath();
  ctx.moveTo(a.x, a.y);
  ctx.lineTo(ex, ey);
  ctx.strokeStyle = withAlpha(color, alpha);
  ctx.lineWidth = width;
  ctx.stroke();

  // A glowing pulse dot at the leading edge while it's still travelling.
  if (reveal > 0 && reveal < 1) {
    ctx.beginPath();
    ctx.arc(ex, ey, width + 1.5, 0, Math.PI * 2);
    ctx.fillStyle = withAlpha(color, 0.9);
    ctx.fill();
  }
}

function drawNode(pos, value, accent, label, active) {
  const r = 30;

  // Glow when active
  if (active) {
    ctx.beginPath();
    ctx.arc(pos.x, pos.y, r + 8, 0, Math.PI * 2);
    ctx.fillStyle = withAlpha(accent, 0.12);
    ctx.fill();
  }

  // Circle body
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, r, 0, Math.PI * 2);
  ctx.fillStyle = COL.node;
  ctx.fill();
  ctx.lineWidth = 2.5;
  ctx.strokeStyle = active ? accent : COL.border;
  ctx.stroke();

  // Value text (only once the node is active; otherwise a placeholder)
  ctx.fillStyle = active ? COL.text : COL.dim;
  ctx.font = "bold 15px Inter, system-ui, sans-serif";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const shown = active && isFinite(value) ? value.toFixed(2) : "·";
  ctx.fillText(shown, pos.x, pos.y);

  // Label below
  ctx.fillStyle = COL.dim;
  ctx.font = "12px Inter, system-ui, sans-serif";
  ctx.textBaseline = "alphabetic";
  ctx.fillText(label, pos.x, pos.y + r + 16);

  ctx.textBaseline = "alphabetic";
}

// ---- Render the current static state (no animation) ----
function renderStatic() {
  const state = currentState();
  draw(state);
  updateOutputLabel(state.outputA);
}

function currentState() {
  const x1 = clampInput(parseFloat(x1Slider.value));
  const x2 = clampInput(parseFloat(x2Slider.value));
  return forwardPass(x1, x2);
}

function clampInput(v) {
  if (!isFinite(v)) return 0;
  return Math.max(-2, Math.min(2, v));
}

function updateOutputLabel(out) {
  outVal.textContent = isFinite(out) ? out.toFixed(3) : "—";
}

// ---- Animation loop ----
function animate(ts) {
  if (!animStart) animStart = ts;
  const elapsed = ts - animStart;
  progress = Math.min(elapsed / ANIM_MS, 1);

  const state = currentState();
  draw(state);

  // Reveal the final output number only at the very end.
  if (progress >= 0.999) {
    updateOutputLabel(state.outputA);
  } else {
    outVal.textContent = "…";
  }

  if (progress < 1) {
    requestAnimationFrame(animate);
  } else {
    animating = false;
    runBtn.disabled = false;
  }
}

function runAnimation() {
  if (animating) return;
  animating = true;
  runBtn.disabled = true;
  animStart = 0;
  progress = 0;
  requestAnimationFrame(animate);
}

// ============================================================
// Wire up controls
// ============================================================
const x1Slider = document.getElementById("x1");
const x2Slider = document.getElementById("x2");
const x1val = document.getElementById("x1val");
const x2val = document.getElementById("x2val");
const runBtn = document.getElementById("runBtn");
const randBtn = document.getElementById("randBtn");
const outVal = document.getElementById("outVal");

function onSlider() {
  x1val.textContent = clampInput(parseFloat(x1Slider.value)).toFixed(2);
  x2val.textContent = clampInput(parseFloat(x2Slider.value)).toFixed(2);
  if (!animating) {
    progress = 1;          // show full graph live as you drag
    renderStatic();
  }
}

x1Slider.addEventListener("input", onSlider);
x2Slider.addEventListener("input", onSlider);

runBtn.addEventListener("click", runAnimation);

randBtn.addEventListener("click", () => {
  randomizeWeights();
  if (!animating) {
    progress = 1;
    renderStatic();
  }
});

// Keep layout correct if the canvas is resized by CSS on different screens.
window.addEventListener("resize", () => {
  layout = buildLayout();
  if (!animating) renderStatic();
});

// ---- Init ----
randomizeWeights();
onSlider();          // sets labels + draws initial static state

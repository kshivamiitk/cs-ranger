# From Linear Models to Neurons

> A neural network sounds exotic, but its building block is something you already know — a logistic regression is literally a single neuron, and a network is just many of them wired together.

## What you'll learn
- The anatomy of a single **neuron**: weighted sum + bias + activation.
- Why logistic regression *is* a one-neuron network (same math, new name).
- Why a plain stack of linear layers collapses into one line — and how **nonlinear activations** rescue it.
- How stacking neurons lets a network bend decision boundaries that one line never could.

## Intuition
Remember the dot product from earlier: take a feature vector, multiply each feature by a weight, sum it up, add a bias. That single number is the heart of almost every model you've built. A **neuron** does exactly that, then passes the result through one more step — an **activation function**:

```
z = w1*x1 + w2*x2 + ... + wn*xn + b      (weighted sum + bias)
a = activation(z)                          (squash/bend the result)
```

If you pick the **sigmoid** activation, `a = 1 / (1 + e^-z)`, you get a number between 0 and 1 — a probability. And that is *exactly* logistic regression. So a logistic regression model is a single neuron with a sigmoid activation. Nothing new; just a new vocabulary word for a thing you already trust.

So why bother with networks? Because one neuron can only draw one straight boundary. It can separate "spam vs not spam" if a single line through feature space does the job — but lots of real problems aren't linearly separable. The classic example is XOR: no straight line separates the diagonal pairs.

The fix is to **stack neurons in layers**. Feed the inputs to several neurons (a *hidden layer*), then feed *their* outputs into another neuron (the *output*). Here's the crucial subtlety: if every neuron were purely linear, stacking them would do nothing — a linear function of a linear function is still linear, so the whole tower collapses back to a single line. The magic ingredient is the **nonlinear activation** between layers. ReLU, sigmoid, and friends bend the signal, so each layer can warp space a little. Stack a few bends and the network can carve curved, even disconnected, decision regions that a single neuron could never express.

Mental model: **one neuron = one straight cut; a hidden layer of neurons + nonlinearity = the ability to bend and combine many cuts into a flexible shape.**

## Python in practice

First, prove the claim: a sigmoid neuron computed by hand gives the same answer as scikit-learn's logistic regression.

```python
import numpy as np

def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))

# One neuron: 2 inputs, hand-chosen weights + bias
x = np.array([0.6, -0.2])      # one example with 2 features
w = np.array([1.5,  2.0])      # one weight per input
b = -0.1                        # bias

z = x @ w + b                   # weighted sum + bias  (the dot product again)
a = sigmoid(z)                  # activation -> a probability in (0, 1)
print(f"z = {z:.3f}, output = {a:.3f}")
# z = 0.400, output = 0.599   -> the neuron predicts ~60% for the positive class
```

```python
# A logistic regression IS this neuron. Train one and read its weights/bias.
from sklearn.linear_model import LogisticRegression

X = np.array([[0.6, -0.2], [1.0, 1.0], [-0.5, -1.0], [0.2, 0.4]])
y = np.array([1, 1, 0, 1])

lr = LogisticRegression()
lr.fit(X, y)
print("learned weights:", lr.coef_[0])   # the neuron's w
print("learned bias:   ", lr.intercept_) # the neuron's b
# These coef_ / intercept_ ARE w and b for a sigmoid neuron;
# lr.predict_proba uses exactly z = X @ w + b, then sigmoid(z).
```

Now show *why* one neuron isn't enough — the XOR problem. A single linear model fails; a small network with a hidden layer (and nonlinearity) solves it.

```python
from sklearn.neural_network import MLPClassifier

# XOR: output is 1 only when the two inputs differ
X_xor = np.array([[0, 0], [0, 1], [1, 0], [1, 1]])
y_xor = np.array([0, 1, 1, 0])

# One neuron (logistic regression) -> cannot separate XOR
single = LogisticRegression().fit(X_xor, y_xor)
print("1 neuron accuracy:", single.score(X_xor, y_xor))
# 1 neuron accuracy: 0.5   (no straight line works -> coin flip)

# A small network: 1 hidden layer of 4 neurons with a nonlinear activation
net = MLPClassifier(hidden_layer_sizes=(4,), activation="tanh",
                    max_iter=5000, random_state=0).fit(X_xor, y_xor)
print("small net accuracy:", net.score(X_xor, y_xor))
# small net accuracy: 1.0   (hidden layer + nonlinearity bends the boundary)
```

The single neuron tops out at 50% on XOR — it's guessing. Add one hidden layer with a nonlinear activation and the same four points become perfectly separable. That jump from 0.5 to 1.0 is the entire reason neural networks exist.

## Common mistakes
- **Thinking neurons are mysterious.** A neuron is `activation(w·x + b)`. If you can compute a dot product, you understand a neuron.
- **Believing more layers always help.** Without a *nonlinear* activation, extra linear layers add nothing — the network mathematically collapses to one layer. Nonlinearity is what makes depth meaningful.
- **Expecting a single neuron to solve nonlinear problems.** One neuron = one straight boundary. If your data needs a curve, you need a hidden layer.
- **Confusing the activation with the loss.** The activation (sigmoid/ReLU) transforms a neuron's output; the loss measures how wrong the final prediction is. They're different jobs (loss is covered in lesson 3).
- **Forgetting the bias.** Dropping `+ b` forces every boundary through the origin. The bias lets the neuron shift its cut anywhere — almost always necessary.

## Small exercise
1. Compute a single sigmoid neuron's output by hand (on paper or in Python) for `x = [1, 2]`, `w = [0.5, -0.5]`, `b = 0.2`. (Hint: `z = 0.5*1 + (-0.5)*2 + 0.2 = -0.3`, so output `= sigmoid(-0.3) ≈ 0.426`.)
2. Run the XOR experiment above, but change `hidden_layer_sizes=(4,)` to `(1,)`. Does a *single* hidden neuron solve XOR? Why might it struggle?
3. In one sentence, explain to a friend why "a linear function of a linear function is still linear" means stacked layers need nonlinearity.

## Before you continue
- [ ] I can write out a neuron as `activation(w·x + b)` and compute its output.
- [ ] I can explain why logistic regression is a one-neuron network.
- [ ] I can explain why nonlinear activations are what make stacking layers worthwhile.
- [ ] I can give one example (e.g. XOR) of a problem a single neuron cannot solve but a small network can.

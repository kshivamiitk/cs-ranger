"use strict";

/* ====================================================================== *
 * Backpropagation Step Visualizer
 *
 * Network (tiny, fully connected):
 *   2 inputs  ->  2 hidden neurons (sigmoid)  ->  1 output neuron (sigmoid)
 *
 * Parameters:
 *   W1 : 2x2   W1[j][i] = weight from input i -> hidden j
 *   b1 : 2     bias of hidden neuron j
 *   W2 : 1x2   W2[j]    = weight from hidden j -> output
 *   b2 : 1     bias of the output neuron
 *
 * Single fixed training example:  x = [0.05, 0.95]  ->  target y = 1
 *
 * Activation:   sigmoid s(z) = 1 / (1 + e^-z),   s'(z) = s(z)(1 - s(z))
 * Loss:         L = 1/2 * (yhat - y)^2            (squared error)
 *
 * --- Exact gradients (chain rule, derived once, verified by descent) ---
 * Forward:
 *   z1[j] = sum_i W1[j][i]*x[i] + b1[j];   a1[j] = s(z1[j])
 *   z2    = sum_j W2[j]*a1[j] + b2;        yhat  = s(z2)
 * Output error:
 *   dOut  = dL/dz2 = (yhat - y) * s'(z2)            // = (yhat-y)*yhat*(1-yhat)
 * Backprop to hidden:
 *   dHid[j] = dL/dz1[j] = (dOut * W2[j]) * s'(z1[j])
 * Weight gradients (dL/dw = delta_downstream * activation_upstream):
 *   dW2[j] = dOut    * a1[j]      ;   db2   = dOut
 *   dW1[j][i] = dHid[j] * x[i]    ;   db1[j] = dHid[j]
 * Update (gradient descent):
 *   w <- w - lr * dL/dw
 * ====================================================================== */

// ----- Math helpers -----
function sigmoid(z) { return 1 / (1 + Math.exp(-z)); }
function dsigmoid(z) { const s = sigmoid(z); return s * (1 - s); }

// ----- Fixed training example -----
const X = [0.05, 0.95];   // two inputs
const Y = 1;              // target output

// ----- Deterministic initial weights (a seeded PRNG, frozen as INIT_*) ------
// We keep them fixed so every learner sees the identical starting picture.
function seededWeights() {
  let s = 20240611 >>> 0;
  const rnd = () => {                       // mulberry-ish LCG -> [-0.9, 0.9]
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return (s / 0x7fffffff) * 1.8 - 0.9;
  };
  return {
    W1: [[rnd(), rnd()], [rnd(), rnd()]],
    b1: [rnd(), rnd()],
    W2: [rnd(), rnd()],
    b2: rnd(),
  };
}
const INIT = seededWeights();
function cloneInit() {
  return {
    W1: [INIT.W1[0].slice(), INIT.W1[1].slice()],
    b1: INIT.b1.slice(),
    W2: INIT.W2.slice(),
    b2: INIT.b2,
  };
}

// ----- Network state -----
let net = cloneInit();
let lr = 0.5;
let epoch = 0;            // completed full forward+backward passes
let phase = 0;            // 0 ready, 1 forward, 2 loss, 3 dOut, 4 backHidden, 5 grads, 6 update
let lossHistory = [];     // for the sparkline
let trainAnim = null;     // rAF id while auto-training
let flashAnim = null;     // edge-recolor animation state

// Per-step cache so each phase can show the exact numbers from THIS pass.
let cache = null;

// ----- Forward pass (pure: returns all intermediate values) -----
function forward(n) {
  const z1 = [0, 0], a1 = [0, 0];
  for (let j = 0; j < 2; j++) {
    z1[j] = n.W1[j][0] * X[0] + n.W1[j][1] * X[1] + n.b1[j];
    a1[j] = sigmoid(z1[j]);
  }
  const z2 = n.W2[0] * a1[0] + n.W2[1] * a1[1] + n.b2;
  const yhat = sigmoid(z2);
  return { z1, a1, z2, yhat };
}
function loss(yhat) { const e = yhat - Y; return 0.5 * e * e; }

// ----- Full backprop: returns gradients for every parameter -----
function backprop(n, fwd) {
  const { z1, a1, z2, yhat } = fwd;
  const dOut = (yhat - Y) * dsigmoid(z2);                 // dL/dz2
  const dHid = [0, 0];
  for (let j = 0; j < 2; j++) {
    dHid[j] = (dOut * n.W2[j]) * dsigmoid(z1[j]);          // dL/dz1[j]
  }
  const dW2 = [dOut * a1[0], dOut * a1[1]];
  const db2 = dOut;
  const dW1 = [
    [dHid[0] * X[0], dHid[0] * X[1]],
    [dHid[1] * X[0], dHid[1] * X[1]],
  ];
  const db1 = [dHid[0], dHid[1]];
  return { dOut, dHid, dW2, db2, dW1, db1 };
}

// Apply one gradient-descent update in place.
function applyUpdate(n, g, rate) {
  for (let j = 0; j < 2; j++) {
    n.W2[j] -= rate * g.dW2[j];
    n.b1[j] -= rate * g.db1[j];
    for (let i = 0; i < 2; i++) n.W1[j][i] -= rate * g.dW1[j][i];
  }
  n.b2 -= rate * g.db2;
}

// One full training iteration used by Train (auto). Records loss.
function trainOneEpoch() {
  const fwd = forward(net);
  lossHistory.push(loss(fwd.yhat));
  const g = backprop(net, fwd);
  applyUpdate(net, g, lr);
  epoch++;
}

/* ====================================================================== *
 *  CANVAS LAYOUT + DRAWING
 * ====================================================================== */
const canvas = document.getElementById("net");
const ctx = canvas.getContext("2d");
const W = canvas.width, H = canvas.height;

// Node screen positions (world == pixel here).
const COL_X = { in: 150, hid: 450, out: 760 };
const NODES = {
  in:  [{ x: COL_X.in, y: 170 }, { x: COL_X.in, y: 330 }],
  hid: [{ x: COL_X.hid, y: 150 }, { x: COL_X.hid, y: 350 }],
  out: [{ x: COL_X.out, y: 250 }],
};
const R = 30;            // node radius
const COL = {
  text: "#e2e8f0", dim: "#94a3b8", panel: "#14151c",
  violet: "#a78bfa", cyan: "#22d3ee", success: "#34d399", danger: "#f87171",
};

// Map a weight to stroke colour + width.
function edgeStyle(w, glow) {
  const mag = Math.min(Math.abs(w), 4);
  const width = 1.2 + (mag / 4) * 7;                 // 1.2 .. 8.2 px
  const c = w >= 0 ? "52,211,153" : "248,113,113";   // green / red
  const alpha = glow ? 1 : 0.55;
  return { stroke: `rgba(${c},${alpha})`, width, glow };
}

function drawEdge(a, b, w, glow) {
  const st = edgeStyle(w, glow);
  ctx.save();
  ctx.lineWidth = st.width;
  ctx.strokeStyle = st.stroke;
  ctx.lineCap = "round";
  if (glow) { ctx.shadowColor = w >= 0 ? COL.success : COL.danger; ctx.shadowBlur = 14; }
  ctx.beginPath();
  ctx.moveTo(a.x + R, a.y);
  ctx.lineTo(b.x - R, b.y);
  ctx.stroke();
  ctx.restore();

  // weight label at the midpoint
  const mx = (a.x + b.x) / 2, my = (a.y + b.y) / 2 - 8;
  ctx.save();
  ctx.font = "11px ui-monospace, Menlo, monospace";
  ctx.textAlign = "center";
  ctx.fillStyle = glow ? COL.text : "rgba(148,163,184,0.85)";
  // slight backing so labels stay readable over edges
  const label = w.toFixed(2);
  const tw = ctx.measureText(label).width;
  ctx.fillStyle = "rgba(11,11,16,0.7)";
  ctx.fillRect(mx - tw / 2 - 3, my - 9, tw + 6, 14);
  ctx.fillStyle = glow ? COL.text : "rgba(148,163,184,0.9)";
  ctx.fillText(label, mx, my + 2);
  ctx.restore();
}

function drawNode(p, value, label, opts) {
  opts = opts || {};
  ctx.save();
  // halo when this layer is the active phase target
  if (opts.glow) {
    ctx.shadowColor = opts.glowColor || COL.cyan;
    ctx.shadowBlur = 22;
  }
  ctx.beginPath();
  ctx.arc(p.x, p.y, R, 0, Math.PI * 2);
  ctx.fillStyle = opts.fill || "#1b1d27";
  ctx.fill();
  ctx.lineWidth = opts.glow ? 3 : 1.6;
  ctx.strokeStyle = opts.stroke || "rgba(255,255,255,0.18)";
  ctx.stroke();
  ctx.shadowBlur = 0;

  // activation value inside the node
  if (value !== null && value !== undefined) {
    ctx.fillStyle = COL.text;
    ctx.font = "bold 14px ui-monospace, Menlo, monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(value.toFixed(2), p.x, p.y);
  }
  // label above
  if (label) {
    ctx.fillStyle = COL.dim;
    ctx.font = "12px Inter, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "alphabetic";
    ctx.fillText(label, p.x, p.y - R - 8);
  }
  ctx.restore();
}

// Small floating annotation (z value, delta value) beside a node.
function annotate(p, text, color, dx) {
  ctx.save();
  ctx.font = "11px ui-monospace, Menlo, monospace";
  ctx.fillStyle = color;
  ctx.textAlign = "left";
  ctx.textBaseline = "middle";
  ctx.fillText(text, p.x + (dx || R + 8), p.y + R + 4);
  ctx.restore();
}

function drawSparkline() {
  const x0 = 600, y0 = 40, w = 270, h = 90;
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.10)";
  ctx.lineWidth = 1;
  ctx.strokeRect(x0, y0, w, h);
  ctx.fillStyle = COL.dim;
  ctx.font = "11px Inter, sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("loss vs epoch", x0 + 4, y0 - 6);

  if (lossHistory.length > 1) {
    const maxL = Math.max(...lossHistory, 1e-6);
    const n = lossHistory.length;
    ctx.beginPath();
    for (let i = 0; i < n; i++) {
      const px = x0 + (i / (n - 1)) * w;
      const py = y0 + h - (lossHistory[i] / maxL) * (h - 6) - 3;
      if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
    }
    const grad = ctx.createLinearGradient(x0, 0, x0 + w, 0);
    grad.addColorStop(0, COL.violet);
    grad.addColorStop(1, COL.cyan);
    ctx.strokeStyle = grad;
    ctx.lineWidth = 2;
    ctx.stroke();
  } else {
    ctx.fillStyle = "rgba(148,163,184,0.6)";
    ctx.font = "11px Inter, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("press Train to plot", x0 + w / 2, y0 + h / 2);
  }
  ctx.restore();
}

// Decide which edges glow for the current phase.
//   phase 1 (forward) & 2 (loss): all edges glow left->right
//   phase 3 (dOut): output edges glow
//   phase 4 (back to hidden): hidden->out edges glow (error routing back)
//   phase 5/6: all glow
function edgeGlows(p) {
  return {
    layer1: p === 1 || p === 2 || p === 5 || p === 6,            // input->hidden
    layer2: p === 1 || p === 2 || p === 3 || p === 4 || p === 5 || p === 6, // hidden->out
  };
}

function render() {
  ctx.clearRect(0, 0, W, H);

  // Always compute the current forward pass so node values stay live.
  const f = cache ? cache.fwd : forward(net);
  const g = edgeGlows(phase);

  // Layer 1 edges: input -> hidden
  for (let j = 0; j < 2; j++)
    for (let i = 0; i < 2; i++)
      drawEdge(NODES.in[i], NODES.hid[j], net.W1[j][i], g.layer1);
  // Layer 2 edges: hidden -> output
  for (let j = 0; j < 2; j++)
    drawEdge(NODES.hid[j], NODES.out[0], net.W2[j], g.layer2);

  // Nodes -------------------------------------------------------------
  const hidGlow = phase === 4;          // backprop into hidden
  const outGlow = phase === 1 || phase === 2 || phase === 3;
  // inputs (fixed)
  drawNode(NODES.in[0], X[0], "x1", { fill: "#101b22" });
  drawNode(NODES.in[1], X[1], "x2", { fill: "#101b22" });
  // hidden
  for (let j = 0; j < 2; j++) {
    drawNode(NODES.hid[j], f.a1[j], "h" + (j + 1), {
      glow: hidGlow, glowColor: COL.violet,
      stroke: hidGlow ? COL.violet : undefined,
    });
    annotate(NODES.hid[j], "z=" + f.z1[j].toFixed(2), COL.dim, R + 6);
    if (cache && phase >= 4)
      annotate({ x: NODES.hid[j].x, y: NODES.hid[j].y + 14 },
        "δ=" + cache.grads.dHid[j].toFixed(3), COL.violet, R + 6);
  }
  // output
  drawNode(NODES.out[0], f.yhat, "ŷ (output)", {
    glow: outGlow, glowColor: COL.cyan,
    stroke: outGlow ? COL.cyan : undefined,
  });
  annotate(NODES.out[0], "z=" + f.z2.toFixed(2), COL.dim, R + 6);
  if (cache && phase >= 3)
    annotate({ x: NODES.out[0].x, y: NODES.out[0].y + 14 },
      "δ=" + cache.grads.dOut.toFixed(3), COL.cyan, R + 6);

  // target marker by the output
  ctx.save();
  ctx.fillStyle = COL.success;
  ctx.font = "12px Inter, sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("target y = " + Y, NODES.out[0].x - 20, NODES.out[0].y + R + 34);
  ctx.restore();

  drawSparkline();
  syncReadout(f);
}

/* ====================================================================== *
 *  DOM + READOUT
 * ====================================================================== */
const lrInput = document.getElementById("lr");
const lrVal = document.getElementById("lrVal");
const phaseBadge = document.getElementById("phaseBadge");
const stepNum = document.getElementById("stepNum");
const epochNum = document.getElementById("epochNum");
const ptag = document.getElementById("ptag");
const ptitle = document.getElementById("ptitle");
const pmath = document.getElementById("pmath");
const gradsTable = document.getElementById("gradsTable");
const rPred = document.getElementById("rPred");
const rTarget = document.getElementById("rTarget");
const rLoss = document.getElementById("rLoss");
const rEpoch = document.getElementById("rEpoch");
const rPhase = document.getElementById("rPhase");
const btnStep = document.getElementById("step");
const btnTrain = document.getElementById("train");
const btnReset = document.getElementById("reset");

// Weight rows for the gradient table (name, accessor).
const WEIGHT_ROWS = [
  { key: "W1_00", name: "W1[h1,x1]" },
  { key: "W1_01", name: "W1[h1,x2]" },
  { key: "W1_10", name: "W1[h2,x1]" },
  { key: "W1_11", name: "W1[h2,x2]" },
  { key: "W2_0",  name: "W2[out,h1]" },
  { key: "W2_1",  name: "W2[out,h2]" },
  { key: "b1_0",  name: "b1[h1]" },
  { key: "b1_1",  name: "b1[h2]" },
  { key: "b2",    name: "b2[out]" },
];

function buildGradTable() {
  // keep header (first child), drop the rest, rebuild rows
  while (gradsTable.children.length > 1) gradsTable.removeChild(gradsTable.lastChild);
  for (const row of WEIGHT_ROWS) {
    const el = document.createElement("div");
    el.className = "grow";
    el.dataset.key = row.key;
    el.innerHTML =
      '<span class="gname">' + row.name + "</span>" +
      '<span class="gval">-</span>' +
      '<span class="ggrad">-</span>' +
      '<span class="gnew">-</span>';
    gradsTable.appendChild(el);
  }
}

function currentWeight(key) {
  switch (key) {
    case "W1_00": return net.W1[0][0];
    case "W1_01": return net.W1[0][1];
    case "W1_10": return net.W1[1][0];
    case "W1_11": return net.W1[1][1];
    case "W2_0":  return net.W2[0];
    case "W2_1":  return net.W2[1];
    case "b1_0":  return net.b1[0];
    case "b1_1":  return net.b1[1];
    case "b2":    return net.b2;
  }
}
function gradFor(key, g) {
  switch (key) {
    case "W1_00": return g.dW1[0][0];
    case "W1_01": return g.dW1[0][1];
    case "W1_10": return g.dW1[1][0];
    case "W1_11": return g.dW1[1][1];
    case "W2_0":  return g.dW2[0];
    case "W2_1":  return g.dW2[1];
    case "b1_0":  return g.db1[0];
    case "b1_1":  return g.db1[1];
    case "b2":    return g.db2;
  }
}

function fmtGrad(span, v) {
  span.textContent = v.toFixed(4);
  span.className = "ggrad " + (v >= 0 ? "gpos" : "gneg");
}

// Fill the gradient table. `showGrad`/`showNew` toggle the later columns,
// `flash` highlights rows when the update lands.
function fillGradTable(showGrad, showNew, flash) {
  const g = cache ? cache.grads : null;
  for (const el of gradsTable.querySelectorAll(".grow")) {
    const key = el.dataset.key;
    const valEl = el.querySelector(".gval");
    const gradEl = el.querySelector(".ggrad");
    const newEl = el.querySelector(".gnew");
    const w = cache ? cache.preWeights[key] : currentWeight(key);
    valEl.textContent = w.toFixed(4);
    if (showGrad && g) fmtGrad(gradEl, gradFor(key, g)); else { gradEl.textContent = "-"; gradEl.className = "ggrad"; }
    if (showNew && g) {
      const nw = w - lr * gradFor(key, g);
      newEl.textContent = nw.toFixed(4);
    } else newEl.textContent = "-";
    el.classList.toggle("flash", !!flash && showNew);
  }
}

function syncReadout(f) {
  rPred.textContent = f.yhat.toFixed(4);
  rTarget.textContent = Y.toFixed(3);
  const L = loss(f.yhat);
  rLoss.textContent = L.toFixed(5);
  rLoss.className = "v" + (L < 0.01 ? " good" : "");
  rEpoch.textContent = String(epoch);
  epochNum.textContent = String(epoch);
}

const PHASE_NAMES = ["ready", "forward", "loss", "out-grad", "back-hidden", "weight-grads", "update"];

function setPhaseUI() {
  rPhase.textContent = PHASE_NAMES[phase];
  phaseBadge.textContent = PHASE_NAMES[phase];
  stepNum.textContent = String(phase);
  const back = phase === 3 || phase === 4 || phase === 5;
  ptag.className = "ptag" + (phase === 6 ? " done" : (back ? " back" : ""));
}

/* ====================================================================== *
 *  STEP-THROUGH STATE MACHINE
 *  Each Step advances exactly one phase. cache holds the numbers for the
 *  pass currently being explained (frozen until the update is applied).
 * ====================================================================== */
function startNewPass() {
  const fwd = forward(net);
  const grads = backprop(net, fwd);
  const preWeights = {};
  for (const row of WEIGHT_ROWS) preWeights[row.key] = currentWeight(row.key);
  cache = { fwd, grads, preWeights };
}

function step() {
  if (trainAnim) return;                 // ignore while auto-training
  if (phase === 0 || phase === 6) {
    // (re)start a fresh pass at the forward stage
    startNewPass();
    phase = 1;
  } else {
    phase++;
  }
  applyPhase();
}

function applyPhase() {
  const f = cache.fwd, g = cache.grads;
  switch (phase) {
    case 1: // FORWARD
      ptag.textContent = "1 FORWARD";
      ptitle.textContent = "Forward pass — compute activations left to right";
      pmath.innerHTML =
        "z1[j] = &Sigma; W1[j][i]&middot;x[i] + b1[j], &nbsp; a1 = &sigma;(z1); &nbsp;" +
        "z2 = &Sigma; W2[j]&middot;a1[j] + b2 &rarr; <b>&#375; = &sigma;(z2) = " + f.yhat.toFixed(4) + "</b>";
      fillGradTable(false, false, false);
      break;
    case 2: // LOSS
      ptag.textContent = "2 LOSS";
      ptitle.textContent = "Loss — how wrong is the prediction?";
      pmath.innerHTML =
        "L = &frac12;(&#375; &minus; y)&sup2; = &frac12;(" + f.yhat.toFixed(4) +
        " &minus; " + Y + ")&sup2; = <b>" + loss(f.yhat).toFixed(5) + "</b>";
      break;
    case 3: // OUTPUT GRADIENT
      ptag.textContent = "3 OUT-GRAD";
      ptitle.textContent = "Output error — start the chain rule at the output";
      pmath.innerHTML =
        "&delta;<sub>out</sub> = (&#375; &minus; y)&middot;&sigma;&prime;(z2) = (" +
        (f.yhat - Y).toFixed(4) + ")&middot;" + dsigmoid(f.z2).toFixed(4) +
        " = <b>" + g.dOut.toFixed(4) + "</b>";
      break;
    case 4: // BACKPROP TO HIDDEN
      ptag.textContent = "4 BACK-HIDDEN";
      ptitle.textContent = "Backprop — route the error back through W2, scale by σ′";
      pmath.innerHTML =
        "&delta;<sub>hid</sub>[j] = (&delta;<sub>out</sub>&middot;W2[j])&middot;&sigma;&prime;(z1[j]) &rarr; " +
        "<b>[" + g.dHid[0].toFixed(4) + ", " + g.dHid[1].toFixed(4) + "]</b>";
      break;
    case 5: // WEIGHT GRADIENTS
      ptag.textContent = "5 GRADS";
      ptitle.textContent = "Each weight's gradient = downstream δ × upstream activation";
      pmath.innerHTML =
        "&part;L/&part;w = &delta;<sub>downstream</sub> &times; activation<sub>upstream</sub> &nbsp;(see the table &rarr; the &part;L/&part;w column)";
      fillGradTable(true, false, false);
      break;
    case 6: // UPDATE
      ptag.textContent = "6 UPDATE";
      ptitle.textContent = "Update — nudge every weight down its gradient, then loop";
      pmath.innerHTML =
        "w &larr; w &minus; lr&middot;&part;L/&part;w &nbsp;(lr = " + lr.toFixed(2) +
        "). The new loss is <b>" + nextLossPreview().toFixed(5) + "</b> &mdash; lower!";
      fillGradTable(true, true, true);
      // actually commit the update + record loss for this epoch
      lossHistory.push(loss(f.yhat));
      applyUpdate(net, g, lr);
      epoch++;
      break;
  }
  setPhaseUI();
  render();
}

// Loss the network WILL have after committing the cached update (for the
// "lower!" preview shown in the update phase before we mutate `net`).
function nextLossPreview() {
  const trial = {
    W1: [net.W1[0].slice(), net.W1[1].slice()],
    b1: net.b1.slice(), W2: net.W2.slice(), b2: net.b2,
  };
  applyUpdate(trial, cache.grads, lr);
  return loss(forward(trial).yhat);
}

/* ====================================================================== *
 *  TRAIN (auto) — many full iterations, animating the loss drop
 * ====================================================================== */
function trainAuto() {
  if (trainAnim) return;
  cache = null; phase = 0; setPhaseUI();
  ptag.textContent = "TRAIN";
  ptag.className = "ptag back";
  ptitle.textContent = "Training… running forward + backward passes";
  pmath.innerHTML = "Watching the sparkline: each point is L after one full backprop step.";
  btnStep.disabled = true; btnTrain.disabled = true;
  const TOTAL = 400, PER_FRAME = 5;
  let done = 0;
  function frame() {
    for (let k = 0; k < PER_FRAME && done < TOTAL; k++, done++) trainOneEpoch();
    render();
    if (done < TOTAL) { trainAnim = requestAnimationFrame(frame); }
    else {
      trainAnim = null;
      btnStep.disabled = false; btnTrain.disabled = false;
      const f = forward(net);
      ptitle.textContent = "Done — loss fell to " + loss(f.yhat).toFixed(5);
      pmath.innerHTML = "Gradient descent converged &#375; toward the target. Press <b>Step</b> to inspect one more pass, or <b>Reset</b>.";
      ptag.textContent = "DONE"; ptag.className = "ptag done";
    }
  }
  trainAnim = requestAnimationFrame(frame);
}

function reset() {
  if (trainAnim) { cancelAnimationFrame(trainAnim); trainAnim = null; }
  net = cloneInit();
  epoch = 0; phase = 0; lossHistory = []; cache = null;
  btnStep.disabled = false; btnTrain.disabled = false;
  ptag.textContent = "READY"; ptag.className = "ptag";
  ptitle.textContent = "Press Step to begin the forward pass";
  pmath.innerHTML = "Loss is the squared error&nbsp; <b>L = &frac12;(&#375; &minus; y)&sup2;</b>. We will minimise it by gradient descent.";
  buildGradTable();
  fillGradTable(false, false, false);
  setPhaseUI();
  render();
}

/* ====================================================================== *
 *  WIRING
 * ====================================================================== */
lrInput.addEventListener("input", () => {
  lr = parseFloat(lrInput.value);
  lrVal.textContent = lr.toFixed(2);
  // if we're mid-step showing grads/update, refresh the "after update" preview
  if (cache && (phase === 5 || phase === 6)) {
    fillGradTable(true, phase === 6, phase === 6);
    if (phase === 6) {
      pmath.innerHTML = pmath.innerHTML.replace(/lr = [\d.]+/, "lr = " + lr.toFixed(2));
    }
  }
});
btnStep.addEventListener("click", step);
btnTrain.addEventListener("click", trainAuto);
btnReset.addEventListener("click", reset);

// ----- Init -----
lrVal.textContent = lr.toFixed(2);
buildGradTable();
fillGradTable(false, false, false);
setPhaseUI();
render();

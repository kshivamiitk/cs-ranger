"use strict";

/* ------------------------------------------------------------------ *
 * Neural Network Single Prediction Walkthrough
 *
 * A FIXED (already-trained) net, no training and no backprop here.
 * Architecture:   2 inputs  ->  3 hidden (ReLU)  ->  1 output (sigmoid)
 *
 * Each neuron computes the SAME recipe:
 *     z = sum(w_i * x_i) + b          (weighted sum + bias)
 *     a = activation(z)               (ReLU for hidden, sigmoid for output)
 *
 * The "Step" button walks ONE neuron at a time, left -> right, and the
 * readout / formula panel spells out the arithmetic with the live slider
 * values so a single prediction is completely concrete and traceable.
 * ------------------------------------------------------------------ */

// ---- Fixed, hand-picked weights (deterministic; never change) -------
// W1[j] = incoming weights for hidden neuron j, one per input [w_x1, w_x2]
const W1 = [
  [0.8, -0.5],
  [-0.6, 0.9],
  [0.4, 0.7],
];
const B1 = [0.1, -0.2, 0.05];      // hidden biases
const W2 = [1.2, -1.5, 0.9];       // output weights, one per hidden neuron
const B2 = -0.3;                   // output bias

// ---- Activations (the math we are teaching) -------------------------
function relu(z) { return z > 0 ? z : 0; }
function sigmoid(z) { return 1 / (1 + Math.exp(-z)); }

// ---- Number formatting helpers --------------------------------------
function f2(v) { return v.toFixed(2); }
function f3(v) { return v.toFixed(3); }
// signed, parenthesised for negatives: 0.42  /  (-0.30)
function sgn(v) { return v < 0 ? "(" + f2(v) + ")" : f2(v); }

// ---- Forward pass for the current inputs ----------------------------
// Returns every intermediate value so the walkthrough can quote them.
function forward(x1, x2) {
  const x = [x1, x2];
  const hidden = [];                 // { z, a, off }
  for (let j = 0; j < 3; j++) {
    const z = W1[j][0] * x[0] + W1[j][1] * x[1] + B1[j];
    const a = relu(z);
    hidden.push({ z: z, a: a, off: z <= 0 });
  }
  let zo = B2;
  for (let j = 0; j < 3; j++) zo += W2[j] * hidden[j].a;
  const p = sigmoid(zo);
  return { x: x, hidden: hidden, zo: zo, p: p, cls: p >= 0.5 ? 1 : 0 };
}

// ====================================================================
//  DOM
// ====================================================================
const canvas = document.getElementById("net");
const ctx = canvas.getContext("2d");
const x1Input = document.getElementById("x1");
const x2Input = document.getElementById("x2");
const x1Val = document.getElementById("x1Val");
const x2Val = document.getElementById("x2Val");
const btnStep = document.getElementById("step");
const btnRun = document.getElementById("runAll");
const btnReset = document.getElementById("reset");
const elPhase = document.getElementById("phase");
const elStep = document.getElementById("rStep");
const elNeuron = document.getElementById("rNeuron");
const elZ = document.getElementById("rZ");
const elOut = document.getElementById("rOut");
const elPred = document.getElementById("rPred");
const elFormula = document.getElementById("formula");

// ====================================================================
//  State
//  step 0      -> nothing computed yet (inputs only)
//  step 1..3   -> hidden neuron (step-1) just computed
//  step 4      -> output neuron computed (final prediction)
// ====================================================================
const TOTAL = 4;                   // 3 hidden + 1 output
let step = 0;
let state = forward(currentX1(), currentX2());
let runTimer = null;               // setInterval id while "Run all" plays

function currentX1() { return parseFloat(x1Input.value); }
function currentX2() { return parseFloat(x2Input.value); }

// ====================================================================
//  Diagram geometry  (canvas internal coords are 900 x 500)
// ====================================================================
const LAYER_X = [150, 450, 760];   // input col, hidden col, output col
const INPUT_Y = [180, 320];
const HIDDEN_Y = [120, 250, 380];
const OUTPUT_Y = [250];
const R_NODE = 30;

function inputPos(i) { return { x: LAYER_X[0], y: INPUT_Y[i] }; }
function hiddenPos(j) { return { x: LAYER_X[1], y: HIDDEN_Y[j] }; }
function outputPos() { return { x: LAYER_X[2], y: OUTPUT_Y[0] }; }

// Which hidden neuron (if any) is "active" at the current step.
function activeHidden() { return step >= 1 && step <= 3 ? step - 1 : -1; }
function outputActive() { return step === 4; }

// ====================================================================
//  Rendering
// ====================================================================
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawEdges();
  drawInputNodes();
  drawHiddenNodes();
  drawOutputNode();
  drawLayerLabels();
}

function edge(from, to, weight, opts) {
  const active = opts && opts.active;
  const dim = opts && opts.dim;
  ctx.save();
  ctx.beginPath();
  ctx.moveTo(from.x + R_NODE, from.y);
  ctx.lineTo(to.x - R_NODE, to.y);
  if (active) {
    ctx.strokeStyle = weight >= 0 ? "rgba(52,211,153,0.95)" : "rgba(248,113,113,0.95)";
    ctx.lineWidth = 3.2;
    ctx.shadowColor = weight >= 0 ? "rgba(52,211,153,0.5)" : "rgba(248,113,113,0.5)";
    ctx.shadowBlur = 8;
  } else {
    ctx.strokeStyle = dim ? "rgba(255,255,255,0.06)" : "rgba(255,255,255,0.14)";
    ctx.lineWidth = 1.4;
  }
  ctx.stroke();
  ctx.restore();

  // weight label at the midpoint
  const mx = (from.x + to.x) / 2;
  const my = (from.y + to.y) / 2 - 6;
  ctx.save();
  ctx.font = active ? "bold 13px ui-monospace, Menlo, monospace" : "12px ui-monospace, Menlo, monospace";
  ctx.fillStyle = active ? (weight >= 0 ? "#34d399" : "#f87171") : "rgba(148,163,184,0.7)";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  const txt = "w=" + f2(weight);
  if (active) {
    const w = ctx.measureText(txt).width + 10;
    ctx.fillStyle = "rgba(11,11,16,0.85)";
    roundRect(mx - w / 2, my - 9, w, 18, 5);
    ctx.fill();
    ctx.fillStyle = weight >= 0 ? "#34d399" : "#f87171";
  }
  ctx.fillText(txt, mx, my);
  ctx.restore();
}

function drawEdges() {
  const ah = activeHidden();
  const oa = outputActive();
  // input -> hidden
  for (let j = 0; j < 3; j++) {
    const hp = hiddenPos(j);
    for (let i = 0; i < 2; i++) {
      const active = ah === j;            // only the active neuron's inputs glow
      const dim = !active && (ah !== -1 || oa);
      edge(inputPos(i), hp, W1[j][i], { active: active, dim: dim });
    }
  }
  // hidden -> output
  for (let j = 0; j < 3; j++) {
    const active = oa;
    const dim = !active && !oa && activeHidden() !== -1;
    edge(hiddenPos(j), outputPos(), W2[j], { active: active, dim: dim });
  }
}

function node(pos, opts) {
  const { title, value, sub, color, active, done } = opts;
  ctx.save();
  ctx.beginPath();
  ctx.arc(pos.x, pos.y, R_NODE, 0, Math.PI * 2);
  if (active) {
    ctx.fillStyle = "rgba(167,139,250,0.22)";
    ctx.shadowColor = "rgba(167,139,250,0.6)";
    ctx.shadowBlur = 20;
  } else if (done) {
    ctx.fillStyle = "rgba(34,211,238,0.12)";
  } else {
    ctx.fillStyle = "rgba(255,255,255,0.04)";
  }
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.lineWidth = active ? 3 : 2;
  ctx.strokeStyle = active ? "#a78bfa" : (done ? "#22d3ee" : (color || "rgba(255,255,255,0.18)"));
  ctx.stroke();

  // node title above
  ctx.fillStyle = "#94a3b8";
  ctx.font = "12px ui-monospace, Menlo, monospace";
  ctx.textAlign = "center";
  ctx.textBaseline = "middle";
  ctx.fillText(title, pos.x, pos.y - R_NODE - 14);

  // current value inside
  ctx.font = "bold 14px ui-monospace, Menlo, monospace";
  ctx.fillStyle = value === null ? "rgba(226,232,240,0.35)" : "#e2e8f0";
  ctx.fillText(value === null ? "?" : value, pos.x, pos.y);

  // sub label below value (e.g. activation type)
  if (sub) {
    ctx.font = "10px ui-monospace, Menlo, monospace";
    ctx.fillStyle = "rgba(148,163,184,0.85)";
    ctx.fillText(sub, pos.x, pos.y + R_NODE + 14);
  }
  ctx.restore();
}

function drawInputNodes() {
  node(inputPos(0), { title: "x1", value: f2(state.x[0]), color: "#22d3ee", done: true });
  node(inputPos(1), { title: "x2", value: f2(state.x[1]), color: "#22d3ee", done: true });
}

function drawHiddenNodes() {
  const ah = activeHidden();
  for (let j = 0; j < 3; j++) {
    const computed = step >= j + 1;     // hidden j is done once we passed its step
    const active = ah === j;
    node(hiddenPos(j), {
      title: "h" + (j + 1),
      value: computed ? f2(state.hidden[j].a) : null,
      sub: "ReLU",
      active: active,
      done: computed && !active,
    });
  }
}

function drawOutputNode() {
  const computed = step >= 4;
  node(outputPos(), {
    title: "output",
    value: computed ? f3(state.p) : null,
    sub: "sigmoid",
    active: outputActive(),
    done: computed && !outputActive(),
  });
  if (computed) {
    ctx.save();
    ctx.font = "bold 13px Inter, sans-serif";
    ctx.fillStyle = state.cls === 1 ? "#34d399" : "#f87171";
    ctx.textAlign = "center";
    ctx.fillText("class " + state.cls, outputPos().x, outputPos().y + R_NODE + 30);
    ctx.restore();
  }
}

function drawLayerLabels() {
  ctx.save();
  ctx.font = "12px Inter, sans-serif";
  ctx.fillStyle = "rgba(148,163,184,0.7)";
  ctx.textAlign = "center";
  ctx.fillText("inputs", LAYER_X[0], 460);
  ctx.fillText("hidden layer (ReLU)", LAYER_X[1], 460);
  ctx.fillText("output (sigmoid)", LAYER_X[2], 460);
  ctx.restore();
}

function roundRect(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

// ====================================================================
//  Readout + spelled-out formula
// ====================================================================
function updatePanel() {
  elStep.textContent = step + " / " + TOTAL;

  if (step === 0) {
    elNeuron.textContent = "—";
    elZ.textContent = "—";
    elOut.textContent = "—";
    elOut.className = "v";
    elPred.textContent = "—";
    elPred.className = "v";
    elFormula.innerHTML =
      'Inputs locked in: <b>x1 = ' + f2(state.x[0]) + '</b>, <b>x2 = ' + f2(state.x[1]) +
      '</b>. Press <b>Step</b> to compute hidden neuron <b>h1</b>.';
    return;
  }

  if (step <= 3) {
    const j = step - 1;
    const h = state.hidden[j];
    const w0 = W1[j][0], w1 = W1[j][1], b = B1[j];
    elNeuron.textContent = "h" + (j + 1) + " (ReLU)";
    elZ.textContent = f2(h.z);
    elOut.textContent = f2(h.a);
    elOut.className = "v " + (h.off ? "zero" : "good");
    elPred.textContent = "—";
    elPred.className = "v";

    const sumExpr =
      sgn(w0) + "·" + f2(state.x[0]) + " + " +
      sgn(w1) + "·" + f2(state.x[1]) + " + " + sgn(b);
    const reluTxt = h.off
      ? '<span class="off">0.00</span>  <span class="lbl" style="display:inline">(z &le; 0 → neuron off)</span>'
      : '<span class="res">' + f2(h.a) + '</span>';
    elFormula.innerHTML =
      '<span class="lbl">Step ' + step + ' — hidden neuron h' + (j + 1) + '</span>' +
      'z = <em>w1</em>·x1 + <em>w2</em>·x2 + <em>b</em><br>' +
      'z = ' + sumExpr + ' = <b>' + f2(h.z) + '</b><br>' +
      'h' + (j + 1) + ' = ReLU(' + f2(h.z) + ') = max(0, ' + f2(h.z) + ') = ' + reluTxt;
    return;
  }

  // step === 4 : output neuron
  elNeuron.textContent = "output (sigmoid)";
  elZ.textContent = f2(state.zo);
  elOut.textContent = f3(state.p);
  elOut.className = "v good";
  elPred.textContent = state.p.toFixed(3) + " → class " + state.cls;
  elPred.className = "v " + (state.cls === 1 ? "cls1" : "cls0");

  const oExpr =
    sgn(W2[0]) + "·" + f2(state.hidden[0].a) + " + " +
    sgn(W2[1]) + "·" + f2(state.hidden[1].a) + " + " +
    sgn(W2[2]) + "·" + f2(state.hidden[2].a) + " + " + sgn(B2);
  elFormula.innerHTML =
    '<span class="lbl">Step 4 — output neuron</span>' +
    'z = <em>w1</em>·h1 + <em>w2</em>·h2 + <em>w3</em>·h3 + <em>b</em><br>' +
    'z = ' + oExpr + ' = <b>' + f2(state.zo) + '</b><br>' +
    'p = sigmoid(' + f2(state.zo) + ') = 1 / (1 + e^−(' + f2(state.zo) + ')) = ' +
    '<span class="res">' + f3(state.p) + '</span><br>' +
    'p ' + (state.cls === 1 ? '≥' : '<') + ' 0.5  →  predicted <b>class ' + state.cls + '</b>';
}

function updatePhase() {
  if (step === 0) elPhase.textContent = "Ready — press Step to start.";
  else if (step <= 3) elPhase.textContent = "Hidden layer — neuron " + step + " of 3.";
  else elPhase.textContent = "Done — forward pass complete.";
  btnStep.disabled = step >= TOTAL && !runTimer ? true : false;
  if (step >= TOTAL) btnStep.disabled = true;
}

// ====================================================================
//  Controls
// ====================================================================
function recompute() {
  // recompute the forward pass from the live sliders; keeps current step
  state = forward(currentX1(), currentX2());
}

function refresh() {
  render();
  updatePanel();
  updatePhase();
}

function doStep() {
  if (step >= TOTAL) return;
  step += 1;
  refresh();
}

function reset() {
  if (runTimer) { clearInterval(runTimer); runTimer = null; }
  step = 0;
  recompute();
  btnRun.disabled = false;
  refresh();
}

function runAll() {
  if (runTimer) { clearInterval(runTimer); runTimer = null; }
  // restart from the beginning, then animate each neuron quickly
  step = 0;
  recompute();
  refresh();
  btnRun.disabled = true;
  btnStep.disabled = true;
  runTimer = setInterval(() => {
    if (step >= TOTAL) {
      clearInterval(runTimer);
      runTimer = null;
      btnRun.disabled = false;
      updatePhase();
      return;
    }
    step += 1;
    refresh();
  }, 650);
}

function onSlider() {
  x1Val.textContent = f2(currentX1());
  x2Val.textContent = f2(currentX2());
  // changing an input invalidates the walkthrough -> restart at step 0
  if (runTimer) { clearInterval(runTimer); runTimer = null; btnRun.disabled = false; }
  step = 0;
  recompute();
  refresh();
}

x1Input.addEventListener("input", onSlider);
x2Input.addEventListener("input", onSlider);
btnStep.addEventListener("click", doStep);
btnRun.addEventListener("click", runAll);
btnReset.addEventListener("click", reset);

// ====================================================================
//  Init
// ====================================================================
x1Val.textContent = f2(currentX1());
x2Val.textContent = f2(currentX2());
recompute();
refresh();

# Solved — Explaining One Neural Network Prediction

> A neural network is not a magic box — for any single input it is just a short chain of multiplications, additions, and squashing functions. Here we open the box and explain every number behind one prediction.

## Problem statement

You are handed a small, **already-trained** binary classifier and one customer's feature vector. A teammate asks the fair question every reviewer eventually asks: *"Why did the model output that number?"* Your job is to answer it concretely — to trace the input through the network and explain, value by value, how it became the final probability `0.62`.

The network is fixed: **2 inputs → 2 hidden neurons (ReLU) → 1 output neuron (sigmoid)**. The weights are hardcoded (someone trained them earlier and froze them). **No training happens in this lesson** — there is no loss, no gradient, no `.fit()`. We only run the **forward pass**: data flowing left to right until a single probability falls out the end. The deliverable is not a model; it is an *explanation* you could read aloud to a skeptic.

## Why this problem matters

"Explainability" sounds like an advanced topic, but the most important explanation skill is the most basic one: being able to hand-compute a single prediction and say what each intermediate number means. If you can do this for a 2→2→1 net, you understand exactly what a 200-layer net is doing — just more of the same arithmetic. It is also the fastest way to debug. When a network outputs something insane, the bug is almost always a wrong weight matrix shape, a missing bias, or an activation on the wrong layer — all things you catch by printing `z` and `a` for one example. Finally, "the model said 0.62" is not an explanation a stakeholder trusts; "this customer scored high because hidden neuron H1 lit up on their first feature, and H1 strongly pushes the output up" is.

## Tiny dataset or sample data

There is no dataset to train on — the network is frozen. The "data" here is **one input example plus the fixed weights** that define the network. Input shape `(2,)`; the network has shapes `W1 (2,2)`, `b1 (2,)`, `W2 (2,)`, `b2 scalar`.

| symbol | meaning | value |
|--------|---------|-------|
| `x` | one input (x1, x2) — shape `(2,)` | `[0.60, 0.40]` |
| `W1` | hidden-layer weights, one row per hidden neuron — shape `(2, 2)` | `[[1.5, -2.0], [-1.0, 1.0]]` |
| `b1` | hidden-layer biases — shape `(2,)` | `[0.5, -0.3]` |
| `W2` | output weights, one per hidden neuron — shape `(2,)` | `[2.0, 1.0]` |
| `b2` | output bias — scalar | `-0.7` |

Read `W1` row by row: hidden neuron **H1** uses weights `[1.5, -2.0]`, hidden neuron **H2** uses `[-1.0, 1.0]`. The single output neuron reads the two hidden outputs with weights `[2.0, 1.0]` — so it "trusts" H1 twice as much as H2.

## Step-by-step reasoning

1. **Every neuron is the same recipe.** A neuron multiplies each incoming value by its weight, sums those products, adds a bias → that sum is `z`. Then it squashes `z` through an activation. The whole network is this recipe repeated; nothing else.
2. **Compute the hidden weighted sums first.** `z1 = W1 @ x + b1`. Because `W1` has one row per hidden neuron, the matrix-vector product gives both hidden `z` values at once. By hand, H1 = `1.5*0.6 + (-2.0)*0.4 + 0.5 = +0.6` and H2 = `-1.0*0.6 + 1.0*0.4 - 0.3 = -0.5`.
3. **Apply ReLU to the hidden layer.** `a1 = max(0, z1)`. H1's `z` is positive, so it passes through unchanged: `0.6`. H2's `z` is **negative**, so ReLU clips it to `0.0` — the neuron "switches off" and contributes nothing downstream. This on/off gating is the network's nonlinearity; it is *why* the network can learn shapes a straight line cannot.
4. **Compute the output weighted sum.** `z2 = W2 @ a1 + b2 = 2.0*0.6 + 1.0*0.0 - 0.7 = +0.5`. Notice H2 is multiplied in, but since it switched off (`0.0`), it had zero say in this particular prediction. The output here is driven almost entirely by H1.
5. **Squash the output with sigmoid → a probability.** `sigmoid(0.5) = 1/(1+e^-0.5) ≈ 0.6225`. Sigmoid maps any real number into `(0, 1)`, so we can read it as `P(class = 1)`. Because it is `≥ 0.5`, the decision is **class 1**. The `0.62` is not arbitrary — it traces straight back to H1 lighting up on this input.

## Python solution

```python
import numpy as np

# ----------------------------------------------------------------------
# A tiny, ALREADY-TRAINED network. Nothing here learns; the weights are
# frozen. Architecture: 2 inputs -> 2 hidden neurons (ReLU) -> 1 sigmoid output.
# We will push ONE input through it and explain every number.
# ----------------------------------------------------------------------

# ---- Activations ----
def relu(z):
    return np.maximum(0.0, z)          # keep positives, clip negatives to 0

def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))    # squash any real number into (0, 1)

# ---- Frozen weights (hand-picked, not trained) ----
# Layer 1: each ROW is the weight vector of one hidden neuron.
# Hidden neuron H1 reads x1, x2 with weights [ 1.5, -2.0], bias  0.5
# Hidden neuron H2 reads x1, x2 with weights [-1.0,  1.0], bias -0.3
W1 = np.array([[ 1.5, -2.0],
               [-1.0,  1.0]])          # shape (2 hidden, 2 inputs)
b1 = np.array([0.5, -0.3])             # one bias per hidden neuron

# Layer 2: one output neuron reading the two hidden outputs.
W2 = np.array([2.0, 1.0])              # weight per hidden neuron -> output
b2 = -0.7                              # output bias

# ---- The ONE input we will explain ----
x = np.array([0.6, 0.4])               # x1 = 0.6, x2 = 0.4
print("INPUT          x =", x, "  (x1=%.2f, x2=%.2f)" % (x[0], x[1]))
print("-" * 60)

# ---- Step 1: hidden weighted sums z1 = W1 . x + b1 ----
z1 = W1 @ x + b1
print("HIDDEN weighted sums (z1 = W1 . x + b1):")
print("  H1: 1.5*%.2f + (-2.0)*%.2f + 0.5  = %+.3f" % (x[0], x[1], z1[0]))
print("  H2: -1.0*%.2f +  1.0*%.2f + (-0.3) = %+.3f" % (x[0], x[1], z1[1]))

# ---- Step 2: hidden activations a1 = ReLU(z1) ----
a1 = relu(z1)
print("HIDDEN activations (a1 = ReLU(z1)):")
print("  H1: ReLU(%+.3f) = %.3f" % (z1[0], a1[0]))
print("  H2: ReLU(%+.3f) = %.3f   <- negative z, neuron switches OFF" % (z1[1], a1[1]))
print("-" * 60)

# ---- Step 3: output weighted sum z2 = W2 . a1 + b2 ----
z2 = W2 @ a1 + b2
print("OUTPUT weighted sum (z2 = W2 . a1 + b2):")
print("  z2: 2.0*%.3f + 1.0*%.3f + (-0.7) = %+.3f" % (a1[0], a1[1], z2))

# ---- Step 4: output activation = sigmoid(z2) ----
p = sigmoid(z2)
print("OUTPUT activation (sigmoid(z2)):")
print("  sigmoid(%+.3f) = %.4f" % (z2, p))
print("-" * 60)

# ---- Final decision ----
label = 1 if p >= 0.5 else 0
print("PREDICTED PROBABILITY P(class=1) = %.4f" % p)
print("DECISION at threshold 0.5        ->  class %d" % label)
```

## Expected output

```
INPUT          x = [0.6 0.4]   (x1=0.60, x2=0.40)
------------------------------------------------------------
HIDDEN weighted sums (z1 = W1 . x + b1):
  H1: 1.5*0.60 + (-2.0)*0.40 + 0.5  = +0.600
  H2: -1.0*0.60 +  1.0*0.40 + (-0.3) = -0.500
HIDDEN activations (a1 = ReLU(z1)):
  H1: ReLU(+0.600) = 0.600
  H2: ReLU(-0.500) = 0.000   <- negative z, neuron switches OFF
------------------------------------------------------------
OUTPUT weighted sum (z2 = W2 . a1 + b2):
  z2: 2.0*0.600 + 1.0*0.000 + (-0.7) = +0.500
OUTPUT activation (sigmoid(z2)):
  sigmoid(+0.500) = 0.6225
------------------------------------------------------------
PREDICTED PROBABILITY P(class=1) = 0.6225
DECISION at threshold 0.5        ->  class 1
```

## Explanation of the output

Walk it backward — the explanation is the whole point:

- **`H1: z = +0.600`.** This customer's `x1` (weight `+1.5`) pulled H1 up; `x2` (weight `-2.0`) pulled it down, but not enough to cancel it out, so H1 ended positive.
- **`H1 activation = 0.600`.** ReLU left it unchanged because it was already positive. H1 is "on."
- **`H2: z = -0.500` → activation `0.000`.** H2's weighted sum came out negative, so ReLU **clipped it to zero**. This is the most important number in the trace: H2 is **switched off** for this input and contributes *nothing* to the final score. A different input could flip H2 on, which is exactly how a tiny net represents different "regions" of input space.
- **`z2 = +0.500`.** The output neuron computed `2.0 × 0.600 + 1.0 × 0.000 − 0.7`. Because H2 was off, the output is essentially "H1 (×2) minus the bias." The model's decision here rests almost entirely on H1.
- **`sigmoid(0.5) = 0.6225`.** Sigmoid converts the raw score `0.5` into a probability. A raw score of `0` would map to exactly `0.5`; our `+0.5` is modestly positive, so the probability is modestly above half — **0.62**, not a confident `0.95`.
- **Decision: class 1.** Because `0.62 ≥ 0.5`. So the honest one-sentence explanation is: *"The model is leaning yes (62%) mostly because hidden neuron H1 activated on this customer's first feature; the second hidden neuron contributed nothing this time."*

## Common mistakes

1. **Transposing the weight matrix.** If you store `W1` as `(inputs, hidden)` but compute `W1 @ x` as if it were `(hidden, inputs)`, you get a shape error or — worse — a silently wrong number. **Fix:** decide a convention (here each *row* of `W1` is one neuron, so `W1 @ x` is correct) and print `.shape` of every array the first time.
2. **Forgetting the bias.** Computing `z = W @ x` and skipping `+ b` shifts every neuron and changes the prediction. **Fix:** a neuron is always `weights·inputs + bias`; the bias is not optional.
3. **Putting sigmoid on the hidden layer (or ReLU on the output).** Hidden layers here use ReLU; the binary output uses sigmoid. Swap them and the ReLU output is no longer a probability, and the sigmoid hidden layer can never produce a true zero (so no neuron ever "switches off"). **Fix:** ReLU in hidden layers, sigmoid for a single binary output.
4. **Reading the raw `z2 = 0.5` as the probability.** `0.5` is a *score* (log-odds), not a probability; it only becomes a probability after sigmoid. **Fix:** always squash the output before interpreting it as `P(class=1)`.
5. **Claiming the forward pass "learned" something.** Nothing was trained here — the weights were frozen the whole time. **Fix:** remember the forward pass only *computes a prediction* from existing weights; learning is the separate backward pass.

## Extension challenge

1. Re-run with `x = np.array([0.9, 0.1])`. Predict first whether H2 stays off, then check: does the final probability go up or down, and which hidden neuron drove the change?
2. Find an input that switches **H1 off and H2 on** (hint: make `x2` much larger than `x1`). Trace it by hand and confirm the output is now driven by H2 instead.
3. Add a tiny "attribution": for the printed prediction, compute each hidden neuron's contribution to `z2` as `W2[i] * a1[i]` and print them sorted. Which neuron contributed the most, and does it match your verbal explanation?

## Matching animation

**Neural Network Single Prediction Walkthrough** (`51 Animation — Neural Network Single Prediction Walkthrough`) — set the `x1` and `x2` sliders to `0.60` and `0.40` to match this lesson exactly, then press **Step** to light up one neuron at a time and watch the same arithmetic you computed by hand appear edge by edge, including H2 clipping to zero. For the earlier conceptual version with random weights, see the **Neural Network Forward Pass Demo** (`04 Neural Network Forward Pass Demo`). Together they make the chain of dot-products-and-activations feel mechanical rather than mysterious — which is exactly the mindset that lets you explain any single prediction.

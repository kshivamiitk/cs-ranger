# Backpropagation

> Backpropagation is the bookkeeping trick that figures out, for every weight in a network, exactly how much it's to blame for the error — by carrying the blame backward from the output, one layer at a time.

## What is this?

Backpropagation is an **algorithm for computing gradients** — it answers the question "if I nudge *this* weight up a tiny bit, does the loss go up or down, and by how much?" for every weight in the network at once.

A neural network runs in two directions. **Forward**, inputs flow through the layers and out comes a prediction; you compare it to the true answer with a loss function and get one number that says how wrong you were. **Backward**, backpropagation takes that single error and walks it back through the layers, using the **chain rule** from calculus to split the blame among all the weights. Weights that pushed the prediction the wrong way get a gradient telling them to move down; weights that helped get the opposite.

The whole training loop is four beats:

```
forward  ->  loss  ->  backward (backprop)  ->  update
```

Here is the one idea people miss: **backprop only computes the gradients. It does not change a single weight.** The changing is done by gradient descent, with the same update rule from the gradient-descent lesson:

```
w  <-  w  -  learning_rate * gradient
```

Backprop hands gradient descent the slopes; gradient descent takes the step. Two halves of one loop.

## Why do we need it?

A neural network can have thousands or millions of weights, all tangled: every weight in layer 1 affects every neuron in layer 2, which affects the output, which affects the loss. To improve, gradient descent needs the slope of the loss with respect to *each* weight. The honest-but-hopeless way is to wiggle each weight by hand, re-run the whole forward pass, and see how the loss changed — for a million weights, that's a million forward passes per single step. Training would take geological time.

Backpropagation gets *all* of those gradients in essentially **one forward pass plus one backward pass**, no matter how many weights there are. It does this by reusing the chain rule cleverly: the blame computed at layer 3 is exactly what layer 2 needs to compute its own blame, which is exactly what layer 1 needs. Each layer's result feeds the next one back. That reuse is what makes training deep networks feasible at all. Without it, modern deep learning simply would not exist.

## Where it's used in real ML

- **Every deep neural network** — image classifiers, speech recognizers, recommendation models, and the large language models behind chat assistants are all trained by backprop + gradient descent. It is the engine under all of deep learning.
- **scikit-learn's `MLPClassifier` / `MLPRegressor`** — these run backprop internally; `loss_curve_` is literally the loss after each backprop-driven update.
- **PyTorch and TensorFlow** — their headline feature, *autograd* / automatic differentiation, is backprop done automatically so you never hand-derive a gradient. You write the forward pass; the framework figures out the backward pass.
- **Fine-tuning** — adapting a big pretrained model to your data still runs backprop, just on fewer weights or fewer steps.

## What breaks if you ignore it

- **Non-differentiable activations stall it.** Backprop needs a *slope* at every step, so each operation must be differentiable. Use a hard step function (output flips from 0 to 1 with no slope in between) and the gradient is zero almost everywhere — there's no downhill direction to follow, and learning freezes. This is exactly why smooth activations (sigmoid, tanh, ReLU) exist.
- **Vanishing gradients in deep stacks.** The chain rule *multiplies* a slope at every layer. If those slopes are small (sigmoid maxes out at 0.25), multiplying many of them shrinks the gradient toward zero by the time it reaches the early layers. Those layers barely move, and the network "learns" only its last few layers. ReLU and careful initialization were invented largely to fight this.
- **Exploding gradients.** The mirror problem: if the multiplied slopes are large, the gradient blows up, the update overshoots wildly, and the loss goes to `NaN`. *Gradient clipping* caps it.
- **Forgetting it's coupled to the learning rate.** Backprop gives the right *direction*; the learning rate decides the step *size*. Perfect gradients with a terrible learning rate still fail to train.

## Mental model

Picture a relay team that lost a race, and the coach assigning blame for the lost seconds — starting from the finish line and walking backward up the track:

```
   INPUT        layer 1        layer 2        OUTPUT        TRUE
   x  ───►  [w1] ──► h1 ──► [w2] ──► h2 ──► [w3] ──► ŷ      y
                                                      │      │
   FORWARD: data flows left ──► right, ending in a    └──┬───┘
            prediction ŷ                                 ▼
                                                      LOSS = how wrong
   BACKWARD: blame flows right ──► left.            ◄──────┘
            "How much did each weight add to the loss?"
        each w gets a gradient ──► gradient descent nudges it down
```

Forward, the runners pass the baton down the track and you time the finish (the loss). Backward, the coach starts at the finish line and asks the last runner "how much of the lost time was you?", then passes that answer up to the previous runner to compute *their* share, and so on to the start. The chain rule is how each runner's blame is computed from the blame of the runner after them. Nobody is judged in isolation — everyone's blame is built from the blame already passed back.

## Example 1 — Tiny toy example

The whole network is one weight. Prediction `ŷ = w * x`, loss is squared error `L = (ŷ - y)²`. One training example: `x = 2`, true answer `y = 10`, current weight `w = 3`.

**Forward pass:**
- `ŷ = w * x = 3 * 2 = 6`
- `L = (ŷ - y)² = (6 - 10)² = 16`

**Backward pass — chain rule.** We want `dL/dw` (how the loss changes as `w` changes). The chain links `L → ŷ → w`, so multiply the slopes along the chain:

```
dL/dw  =  dL/dŷ  ×  dŷ/dw
```

- `dL/dŷ = 2 * (ŷ - y) = 2 * (6 - 10) = -8`   (slope of the squared-error loss)
- `dŷ/dw = x = 2`                              (since ŷ = w·x, its slope in w is x)
- `dL/dw = (-8) × (2) = -16`

That `-16` is the gradient. **Now gradient descent takes the step** (learning rate 0.1):

```
w  <-  w - 0.1 * (-16)  =  3 + 1.6  =  4.6
```

Sanity check: `w` went *up* (good — we need `ŷ` bigger to reach 10). New prediction `ŷ = 4.6 * 2 = 9.2`, new loss `(9.2 - 10)² = 0.64`, down from 16. One forward, one backward, one update — that's the entire loop on a network of one weight.

## Example 2 — Practical ML example

Now a real network: a small multilayer perceptron learning the "two interleaving half-moons" dataset — a curvy boundary a straight line can't separate. The network has an input layer, one hidden layer of 8 neurons with ReLU, and an output neuron; that's a few dozen weights.

Training repeats the same four beats, now for *every* weight at once: **forward** the batch to get predictions, compute the **loss** (cross-entropy), run **backprop** to get a gradient for all ~dozens of weights in one backward sweep, then **update** them all with the learning rate. Each pass over the data is an *epoch*.

What you watch is the loss curve. Early on the random weights give a high loss — say `0.69`. Backprop hands gradient descent the directions, the weights slide, and over the epochs the loss falls: `0.69 → 0.41 → 0.22 → 0.11 → ...`, flattening as it converges, while accuracy climbs past 0.95 because the hidden layer can now *bend* the decision boundary around the moons. You never derived a single gradient by hand — the framework's autograd ran backprop for you. The one thing to internalize: backprop computed *which way* each weight should move; gradient descent did the actual moving.

## Python code example

```python
import numpy as np

# ---- A network with ONE weight, trained by backprop + gradient descent. ----
# Model:  y_pred = w * x      Loss: squared error  L = (y_pred - y)^2
# One example so the math is fully visible.
x, y_true = 2.0, 10.0
w = 3.0           # starting weight (deliberately wrong)
lr = 0.1          # learning rate (step size, used by gradient descent, NOT backprop)

print("step |   w    | y_pred |  loss  | gradient dL/dw")
print("-" * 50)
for step in range(1, 9):
    # ---- FORWARD pass: data -> prediction -> loss ----
    y_pred = w * x
    loss = (y_pred - y_true) ** 2

    # ---- BACKWARD pass (backprop): chain rule gives dL/dw ----
    #   dL/dy_pred = 2 * (y_pred - y_true)   (slope of squared error)
    #   dy_pred/dw = x                       (since y_pred = w * x)
    dL_dy = 2.0 * (y_pred - y_true)
    dy_dw = x
    grad = dL_dy * dy_dw          # chain rule: multiply the slopes along the path

    print(f"{step:4d} | {w:6.3f} | {y_pred:6.3f} | {loss:6.3f} | {grad:+.3f}")

    # ---- UPDATE: gradient descent takes the step. Backprop did NOT do this. ----
    w = w - lr * grad

print("-" * 50)
print(f"Final w = {w:.3f}  ->  prediction = {w * x:.3f}  (target was {y_true})")

# Expected output (numbers approximate):
# step |   w    | y_pred |  loss  | gradient dL/dw
# --------------------------------------------------
#    1 |  3.000 |  6.000 | 16.000 | -16.000
#    2 |  4.600 |  9.200 |  0.640 |  -3.200
#    3 |  4.920 |  9.840 |  0.026 |  -0.640
#    ...
#    8 |  5.000 | 10.000 |  0.000 |  -0.000
# --------------------------------------------------
# Final w = 5.000  ->  prediction = 10.000  (target was 10.0)
# The loss collapses toward 0 as w climbs to the value that makes y_pred = y_true.
```

The gradient shrinks as we approach the answer — near the bottom of the loss bowl the slope flattens, so the steps get tiny. That's backprop and gradient descent working together: backprop reported the slope each step, gradient descent walked down it.

## Common mistakes

- **Thinking backprop updates the weights.** It doesn't — it only *computes gradients*. Gradient descent (the `w -= lr * grad` line) does the updating. They're two distinct halves of the loop, and conflating them hides where a bug actually is.
- **Adding the gradient instead of subtracting.** The update is `w - lr * grad` (downhill). Use `+` and you climb the loss; it grows every step.
- **Using a non-differentiable activation and wondering why nothing learns.** A hard step has zero slope almost everywhere, so backprop's gradients are zero and no weight moves. Use a smooth activation (ReLU, sigmoid, tanh).
- **Blaming the data for vanishing/exploding gradients.** A deep net whose early layers won't budge, or a loss that explodes to `NaN`, is usually the chain rule multiplying many small or large slopes — fix it with ReLU, better initialization, or gradient clipping, not by hunting the dataset first.
- **Stopping after one epoch.** One backward pass barely moves the weights. Real training needs many epochs; watch the loss curve flatten before you stop.

## Before you continue
- [ ] I can state the four beats: forward → loss → backward (backprop) → update.
- [ ] I can explain that backprop computes gradients and gradient descent applies them.
- [ ] I can compute `dL/dw` for a one-weight network by hand using the chain rule.
- [ ] I can say why activations must be differentiable for backprop to work.
- [ ] I can explain vanishing gradients as the chain rule multiplying many small slopes.

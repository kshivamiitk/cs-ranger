# Forward Pass, Activations, and Layers

> The "forward pass" is just data flowing left to right through layers of dot products and activations — and you can compute one entirely by hand with a few lines of NumPy.

## What you'll learn
- How **weights** and **biases** are organized into matrices per layer.
- The three activations you'll meet constantly: **ReLU**, **sigmoid**, **softmax** — and when each is used.
- How a **forward pass** turns inputs into a prediction, one layer at a time.
- How to compute a complete forward pass for a tiny network by hand in NumPy.

## Intuition
A layer is just *many neurons computed at once*. Instead of one weight vector, a layer has a **weight matrix** `W` (one row or column per neuron) and a **bias vector** `b`. The whole layer's output is one matrix operation:

```
z = x @ W + b          # weighted sums for every neuron in the layer, in one shot
a = activation(z)      # apply the activation elementwise
```

The output `a` of one layer becomes the input `x` of the next. Chain a few of these together and you have a network. Running data through this chain — input to output — is the **forward pass**. (Training, covered next lesson, adds a *backward* pass that adjusts the weights.)

The activation function sits between layers and decides the "shape" of each neuron's response:

- **ReLU** — `max(0, z)`. Keeps positives, zeroes out negatives. Cheap, avoids the "vanishing gradient" problem, and is the default for hidden layers in modern networks.
- **Sigmoid** — `1/(1+e^-z)`. Squashes to `(0, 1)`. Used for the output of a *binary* classifier, where you want a single probability.
- **Softmax** — turns a vector of raw scores into probabilities that sum to 1. Used for the output of a *multi-class* classifier (e.g. "which of 10 digits?"). It exponentiates each score and normalizes.

A clean rule of thumb: **ReLU in the hidden layers; sigmoid for one binary output; softmax for multi-class output.**

## Python in practice

Define the three activations:

```python
import numpy as np

def relu(z):
    return np.maximum(0, z)

def sigmoid(z):
    return 1.0 / (1.0 + np.exp(-z))

def softmax(z):
    z = z - np.max(z)            # subtract max for numerical stability (avoids overflow)
    e = np.exp(z)
    return e / e.sum()

print(relu(np.array([-2.0, 0.0, 3.0])))     # [0. 0. 3.]
print(sigmoid(np.array([-2.0, 0.0, 2.0])))  # [0.119 0.5   0.881]
print(softmax(np.array([1.0, 2.0, 3.0])))   # [0.09 0.244 0.665]  (sums to 1.0)
```

Now a full forward pass **by hand** for a tiny network: 3 inputs → a hidden layer of 4 ReLU neurons → 1 sigmoid output.

```python
import numpy as np
rng = np.random.default_rng(0)

# One input example with 3 features
x = np.array([0.5, -1.0, 2.0])      # shape (3,)

# ---- Layer 1: 3 inputs -> 4 hidden neurons ----
W1 = rng.normal(size=(3, 4)) * 0.5  # weight matrix: (in_features, out_neurons)
b1 = np.zeros(4)                     # one bias per hidden neuron

z1 = x @ W1 + b1                     # (3,) @ (3,4) -> (4,)  weighted sums
a1 = relu(z1)                        # ReLU activation -> (4,) hidden outputs
print("hidden pre-activation z1:", np.round(z1, 3))
print("hidden output       a1:", np.round(a1, 3))   # negatives became 0

# ---- Layer 2: 4 hidden -> 1 output neuron ----
W2 = rng.normal(size=(4, 1)) * 0.5  # (hidden, output)
b2 = np.zeros(1)

z2 = a1 @ W2 + b2                    # (4,) @ (4,1) -> (1,)
output = sigmoid(z2)                 # sigmoid -> probability in (0, 1)
print("final output (probability):", float(output[0]))
# Example run -> something like 0.5xx; the exact value depends on the random weights.
```

Trace the shapes — that's the whole game:
- `x` is `(3,)`. Layer 1's `W1` is `(3, 4)`, so `x @ W1` is `(4,)`: four hidden values.
- ReLU clips the negatives to zero; that's the nonlinearity.
- Layer 2's `W2` is `(4, 1)`, so `a1 @ W2` is `(1,)`: one number.
- Sigmoid turns that number into a probability.

That single number is the prediction. No training happened — we just *ran data forward* through fixed weights. Training is the process of nudging `W1, b1, W2, b2` so this forward pass produces good answers (next lesson).

A multi-class output swaps the last step for softmax:

```python
# Suppose the final layer produced raw scores for 3 classes:
scores = np.array([2.0, 0.5, -1.0])
probs = softmax(scores)
print(np.round(probs, 3))        # [0.78 0.174 0.046]  -> class 0 most likely
print("sum =", probs.sum())      # sum = 1.0
print("prediction:", int(np.argmax(probs)))   # prediction: 0
```

## Common mistakes
- **Shape mismatches.** `x @ W` requires `x`'s last dimension to equal `W`'s first. Print `.shape` of both whenever you get a `ValueError`.
- **Using sigmoid for multi-class output.** Sigmoid gives one independent probability per neuron; they won't sum to 1. For "pick one of K classes", use softmax.
- **Forgetting numerical stability in softmax.** `np.exp(large_number)` overflows to `inf`. Subtracting the max first (as above) fixes it without changing the result.
- **Putting an activation on the wrong layer.** Hidden layers usually get ReLU; the *output* layer's activation depends on the task (sigmoid for binary, softmax for multi-class, none for regression).
- **Believing the forward pass learns.** A forward pass only computes a prediction from current weights. Learning happens in the backward pass that updates those weights.

## Small exercise
1. Take the tiny network code above and change `x` to `np.array([1.0, 1.0, 1.0])`. Print `a1` — how many of the four hidden neurons output exactly `0`? (Those are the ones whose weighted sum was negative.)
2. Replace the hidden activation `relu` with `sigmoid` and re-run. How do the hidden outputs `a1` change in range?
3. For `scores = [3.0, 3.0, 3.0]`, predict (without running it) what `softmax(scores)` returns, then verify. (Hint: equal scores → equal probabilities → `[0.333, 0.333, 0.333]`.)

## Before you continue
- [ ] I can write a layer as `activation(x @ W + b)` and trace the shapes.
- [ ] I can compute a full forward pass for a 2-layer network in NumPy.
- [ ] I can say when to use ReLU, sigmoid, and softmax.
- [ ] I understand that a forward pass only *predicts* — it does not learn.

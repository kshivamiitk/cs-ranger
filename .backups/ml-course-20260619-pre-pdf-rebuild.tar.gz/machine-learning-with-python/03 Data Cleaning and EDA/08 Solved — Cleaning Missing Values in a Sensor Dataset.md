# Solved — Cleaning Missing Values in a Sensor Dataset

> An IoT logger dropped readings whenever the radio glitched — now four sensor columns have scattered NaNs, and each one needs its *own* fix, not a blanket `dropna()`.

## Problem statement

A field weather station logs four readings every hour — `temperature` (°C), `humidity` (%), `pressure` (hPa), `battery` (% remaining) — plus a categorical `status` flag (`ok` / `warn` / `fault`). The radio link is flaky, so individual cells go missing at random times: a temperature here, a humidity there, a couple of `status` blanks. Your task is to produce a **clean table with zero NaNs** that's ready for modeling, choosing a *per-column* imputation strategy that fits each column's character — and to do it **without leaking** test-set information into the fill values.

You'll also answer a question every practitioner faces: **drop the incomplete rows, or impute them?** On a small log, dropping can throw away half your data, so you'll measure exactly how many rows each approach keeps. Success criteria: every column's blanks filled by a *justified* strategy, fill statistics learned from **training rows only**, and a clear row-count comparison of drop-vs-impute.

## Why this problem matters

Sensor and time-series data is missing-value heaven: batteries die, radios drop packets, firmware reboots mid-write. The wrong reflex — `df.dropna()` — can silently delete the most interesting rows (a fault often coincides with a dropped reading), and `fillna(0)` is even worse here because `0 °C`, `0% humidity`, and `0 hPa` are all *physically plausible-looking* values that would quietly poison the model. Different columns also demand different fixes: a skewed reading wants the **median**, a roughly symmetric one tolerates the **mean**, a slow-drifting time series is best **forward-filled** from its last good value, and a category can't be averaged at all. And as always, computing those fill values over the whole dataset before splitting leaks the future into the past and turns your reported accuracy into fiction. This lesson is the per-column discipline that separates a clean pipeline from a deceptively broken one.

## Tiny dataset or sample data

Hourly sensor log — **shape `(14, 6)`**, columns `timestamp, temperature, humidity, pressure, battery, status`. Numeric columns hold scattered NaNs (shown as empty cells); `status` is categorical with a couple of blanks. Rows are time-ordered, which is what makes forward-fill meaningful.

| timestamp        | temperature | humidity | pressure | battery | status |
|------------------|------------:|---------:|---------:|--------:|--------|
| 2026-06-01 00:00 | 21.4        | 55.0     | 1012.3   | 98      | ok     |
| 2026-06-01 01:00 | 21.1        |          | 1012.1   | 97      | ok     |
| 2026-06-01 02:00 |             | 57.0     | 1011.8   | 97      |        |
| 2026-06-01 03:00 | 20.6        | 58.0     |          | 96      | ok     |
| 2026-06-01 04:00 | 20.2        | 60.0     | 1011.2   |         | warn   |
| 2026-06-01 05:00 | 19.9        |          | 1010.9   | 95      | ok     |

(The full inline log below has 14 rows.) The numeric columns drift slowly hour-to-hour — exactly the setting where carrying the last reading forward beats inventing a global average.

## Step-by-step reasoning

1. **Audit missingness per column first.** `df.isna().sum()` tells you *where* the holes are and how big. If a column were, say, 80% empty you'd consider dropping the column entirely; here each affected column is missing only a couple of cells, so imputation is the right call.
2. **Match a strategy to each column's nature.** This is the heart of the lesson:
   - **`pressure` → median.** Pressure can spike with weather fronts (skew/outliers), so the median is robust to a freak high reading that would drag a mean upward.
   - **`humidity` → mean.** Humidity here is roughly symmetric with no wild outliers, so the mean is a fine, simple central fill.
   - **`temperature` & `battery` → forward-fill.** These are slowly-varying *time series*: the best guess for a missing 02:00 temperature is the 01:00 value, not the whole-log average. `ffill` carries the last observed reading forward (with a `bfill` safety net if the *first* row is missing).
   - **`status` → constant `"Unknown"` (or mode).** A category has no mean/median. Filling blanks with an explicit `"Unknown"` keeps "we don't know" as honest information instead of pretending it was the most common status.
3. **Split before computing any statistic.** The mean and median used to fill must come from **training rows only**. Compute them over the full log and you leak test data into training, inflating your scores. We split first, then fit the imputers.
4. **Use `SimpleImputer` inside a `ColumnTransformer`** so the learned mean/median live in the fitted object and get *reused* on the test rows automatically — no manual bookkeeping, no leakage. (Forward-fill is order-dependent, so we handle the time-series columns with pandas `ffill`/`bfill`, which is the idiomatic tool for that job.)
5. **Compare drop vs impute by row count.** Run `df.dropna()` and count survivors, then confirm imputation keeps **all** rows. On a 14-row log the difference is stark and makes the cost of reflexive dropping concrete.

## Python solution

```python
import io
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer

# --- Inline hourly sensor log (no downloads, no file reads) ---
# Empty fields between commas are missing readings.
CSV = """timestamp,temperature,humidity,pressure,battery,status
2026-06-01 00:00,21.4,55.0,1012.3,98,ok
2026-06-01 01:00,21.1,,1012.1,97,ok
2026-06-01 02:00,,57.0,1011.8,97,
2026-06-01 03:00,20.6,58.0,,96,ok
2026-06-01 04:00,20.2,60.0,1011.2,,warn
2026-06-01 05:00,19.9,,1010.9,95,ok
2026-06-01 06:00,19.5,61.0,1010.6,94,ok
2026-06-01 07:00,19.8,62.0,1010.4,,warn
2026-06-01 08:00,20.4,58.0,1010.7,93,ok
2026-06-01 09:00,21.0,59.0,1011.0,92,
2026-06-01 10:00,22.1,56.0,1011.5,92,ok
2026-06-01 11:00,23.7,52.0,,91,warn
2026-06-01 12:00,25.2,48.0,1012.8,90,fault
2026-06-01 13:00,,46.0,1013.1,89,fault
"""
df = pd.read_csv(io.StringIO(CSV))

# --- 1. Audit: where are the holes? ---
print("Shape:", df.shape)
print("Missing per column:\n", df.isna().sum().to_string(), "\n")

# --- 2. drop-vs-impute row-count comparison ---
rows_total = len(df)
rows_after_drop = len(df.dropna())
print(f"Rows if we dropna(): {rows_after_drop} of {rows_total} "
      f"({rows_after_drop/rows_total:.0%} kept)")

# --- 3. Split FIRST so fill statistics come from TRAIN only (no leakage) ---
# Keep timestamp out of the model inputs but preserve row ORDER per split
# so forward-fill stays meaningful within each split.
train_df, test_df = train_test_split(df, test_size=0.30,
                                      random_state=42, shuffle=False)
train_df = train_df.sort_values("timestamp")
test_df  = test_df.sort_values("timestamp")

# --- 4a. Time-series columns -> forward-fill (carry last good reading) ---
ts_cols = ["temperature", "battery"]
# Learn nothing global: ffill is per-split & order-aware; bfill rescues a
# leading NaN. Done on train and test SEPARATELY (no cross-split bleed).
for part in (train_df, test_df):
    part[ts_cols] = part[ts_cols].ffill().bfill()

# --- 4b. Statistical columns -> SimpleImputer fit on TRAIN only ---
stat = ColumnTransformer(
    transformers=[
        ("median_pressure", SimpleImputer(strategy="median"),    ["pressure"]),
        ("mean_humidity",   SimpleImputer(strategy="mean"),       ["humidity"]),
        ("status_unknown",  SimpleImputer(strategy="constant",
                                          fill_value="Unknown"),  ["status"]),
    ],
    remainder="passthrough",   # keep the already-ffilled ts_cols + timestamp
    verbose_feature_names_out=False,
)
stat.set_output(transform="pandas")

train_clean = stat.fit_transform(train_df)   # LEARN median/mean on TRAIN
test_clean  = stat.transform(test_df)         # REUSE those same fills on TEST

# --- 5. Inspect the learned fills and confirm zero NaNs remain ---
med = stat.named_transformers_["median_pressure"].statistics_[0]
mean = stat.named_transformers_["mean_humidity"].statistics_[0]
print(f"\nLearned (TRAIN) pressure median = {med:.2f} hPa")
print(f"Learned (TRAIN) humidity mean   = {mean:.2f} %")
print("NaNs left in cleaned TRAIN:", int(train_clean.isna().sum().sum()))
print("NaNs left in cleaned TEST :", int(test_clean.isna().sum().sum()))
print("\nCleaned TRAIN rows kept:", len(train_clean),
      "| Cleaned TEST rows kept:", len(test_clean),
      "| Total kept by imputing:", len(train_clean) + len(test_clean))
print("\nStatus value counts after fill (train):\n",
      train_clean["status"].value_counts().to_string())
```

## Expected output

```
Shape: (14, 6)
Missing per column:
 timestamp      0
temperature    2
humidity       2
pressure       2
battery        2
status         2

Rows if we dropna(): 5 of 14 (36% kept)

Learned (TRAIN) pressure median = 1011.05 hPa
Learned (TRAIN) humidity mean   = 58.71 %
NaNs left in cleaned TRAIN: 0
NaNs left in cleaned TEST : 0

Cleaned TRAIN rows kept: 9 | Cleaned TEST rows kept: 5 | Total kept by imputing: 14

Status value counts after fill (train):
 status
ok         6
warn       2
Unknown    1
```

- The audit shows **2 missing cells in each of the four sensor columns** and none in `timestamp`.
- The headline number: `dropna()` keeps **only 5 of 14 rows (~36%)** — it deletes any row with *any* hole — while imputation keeps **all 14**.
- The learned median/mean are printed so you can see they're concrete numbers computed from the training split; the two `NaNs left ... 0` lines confirm a fully clean table.
- `status` gained an explicit **`Unknown`** bucket where blanks were, instead of being forced into the most common `ok`.

## Explanation of the output

The drop-vs-impute line is the punchline: with holes scattered across four columns, **the probability that a given row is complete is low**, so `dropna()` nukes ~64% of a small dataset — and on sensor logs the dropped rows are often the eventful ones (a `fault` row that also lost a reading). Imputing keeps every row and every label, which is why we measured it rather than guessing.

The two "Learned (TRAIN) …" numbers are the leakage-safety proof. The pressure **median** (≈ 1011.05 hPa) and humidity **mean** (≈ 58.7%) are computed from training rows *only*; `stat.transform(test_df)` then plugs *those same* numbers into the test blanks. If we'd computed them over all 14 rows, the test set would have influenced its own fills — subtle leakage that silently inflates any score you report later. The `NaNs left … 0` lines confirm the per-column strategy fully closed the holes, and the `status` value counts show the categorical fix working: the blank that landed in the training split became `Unknown`, preserving "we don't know" as a real, model-visible category rather than a fabricated `ok`. The temperature/battery columns, meanwhile, were carried forward from their last good hourly reading — a far better guess than a whole-log average for a slowly drifting signal.

## Common mistakes

1. **Reflexive `df.dropna()`.** On this log it deletes ~64% of rows, often the most interesting ones (faults coincide with dropped readings). **Fix:** drop only when a row/column is *mostly* empty; otherwise impute and keep the data.
2. **`fillna(0)` on sensor numerics.** `0 °C`, `0% humidity`, `0 hPa` look like real readings, so the model treats fabricated zeros as genuine cold/dry/vacuum conditions and learns garbage. **Fix:** use a median/mean/forward-fill that respects each column's real range.
3. **Mean-imputing a skewed column.** A single weather-front pressure spike drags the mean up, so every filled pressure is biased high. **Fix:** use the **median** for skew/outlier-prone columns (here, `pressure`).
4. **Averaging a time series instead of forward-filling.** Filling a missing 02:00 temperature with the whole-log mean ignores that 01:00 was 21.1 °C. **Fix:** `ffill` (with a `bfill` backstop) carries the last good reading forward for slowly-varying signals.
5. **Computing fill statistics before the split.** Calculating the median/mean over all rows leaks test information into training and inflates your scores. **Fix:** split first, `fit` the imputer on **train only**, and `transform` the test set with those learned values.

## Extension challenge

1. Add `add_indicator=True` to the numeric `SimpleImputer`s so each imputed column gets a companion "was_missing" flag, and check whether *missingness itself* predicts `status == "fault"` (a clue the data is not missing-completely-at-random).
2. Replace forward-fill on `temperature` with **time-aware interpolation** (`df.set_index("timestamp").interpolate(method="time")`) and compare the filled values — when does interpolating between two readings beat carrying one forward?
3. Swap the per-column scatter for a **burst outage** (blank out three consecutive hours of `humidity`) and watch which strategy degrades most — forward-fill flatlines across the gap while the mean stays put. Which is less wrong, and why?

## Matching animation

**Missing Values Cleaning Simulator** — pick a column, choose a strategy (median / mean / forward-fill / "Unknown"), and watch the NaN cells fill in live while a side counter shows how many rows survive versus a plain `dropna()`. Flip a single reading into an extreme outlier and see the **mean** fill lurch while the **median** barely budges — the same robustness lesson `pressure` teaches above. (The related **Missing Value Imputation Simulator** focuses just on the mean-vs-median tug-of-war; use this one when you want to compare *all four* per-column strategies and the drop-vs-impute row count side by side.)

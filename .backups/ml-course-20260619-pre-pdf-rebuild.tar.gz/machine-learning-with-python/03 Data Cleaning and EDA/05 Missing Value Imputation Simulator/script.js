"use strict";

/* ------------------------------------------------------------------ *
 * Missing Value Imputation Simulator
 *
 * One numeric column drawn as vertical bars. Some rows are MISSING
 * (drawn as dashed, hollow bars with a "?"). A strategy decides what
 * value flows into every gap:
 *
 *   mean          -> arithmetic mean of the KNOWN values
 *   median        -> middle KNOWN value (robust to outliers)
 *   most_frequent -> the most common rounded KNOWN value (the mode)
 *   drop          -> delete every row that has a gap (n shrinks)
 *
 * The teaching point: a single extreme value (the "outlier", 95) yanks
 * the MEAN sharply upward while the MEDIAN barely moves -- so mean
 * imputation over-fills every gap, median imputation does not.
 * ------------------------------------------------------------------ */

// ----- Deterministic data: a single numeric column ------------------
// 14 rows. ~4 are missing. Known values live in the 30..60 range and
// are crafted so the mode (most common rounded value) is well defined.
function makeColumn() {
  // tiny deterministic PRNG -> the column is identical every load
  let s = 90210;
  const rnd = () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff; // [0,1)
  };

  // which row indices are gaps (missing). fixed & reproducible.
  const MISSING_AT = new Set([2, 6, 9, 12]);

  // a deliberate spine of known values so a clear mode exists at 44.
  // (several rows round to 44 -> most_frequent has an honest answer)
  const KNOWN_SEED = [38, 44, 51, 44, 35, 44, 57, 41, 48, 44];

  const rows = [];
  let kIdx = 0;
  for (let i = 0; i < 14; i++) {
    if (MISSING_AT.has(i)) {
      rows.push({ value: null, missing: true });
    } else {
      // tiny deterministic jitter keeps the bars organic without
      // disturbing the rounded mode at 44.
      const base = KNOWN_SEED[kIdx++ % KNOWN_SEED.length];
      const jitter = Math.round((rnd() - 0.5) * 1.2); // -1..+1ish
      rows.push({ value: clamp(base + jitter, 30, 60), missing: false });
    }
  }
  return rows;
}

// The row whose KNOWN value is replaced by 95 when the outlier is ON.
const OUTLIER_ROW = 7; // a known row near the right of the chart
const OUTLIER_VALUE = 95;

const BASE_ROWS = makeColumn();

// ----- Stats over the currently-known values ------------------------
function knownValues(rows) {
  return rows.filter((r) => !r.missing).map((r) => r.value);
}

function mean(arr) {
  if (arr.length === 0) return 0; // guard divide-by-zero
  let acc = 0;
  for (const v of arr) acc += v;
  return acc / arr.length;
}

function median(arr) {
  if (arr.length === 0) return 0;
  const a = arr.slice().sort((p, q) => p - q);
  const mid = Math.floor(a.length / 2);
  return a.length % 2 ? a[mid] : (a[mid - 1] + a[mid]) / 2;
}

// most common ROUNDED value (mode). ties -> the smaller value.
function mostFrequent(arr) {
  if (arr.length === 0) return 0;
  const counts = new Map();
  for (const v of arr) {
    const k = Math.round(v);
    counts.set(k, (counts.get(k) || 0) + 1);
  }
  let best = null, bestCount = -1;
  for (const [k, c] of counts) {
    if (c > bestCount || (c === bestCount && k < best)) {
      best = k;
      bestCount = c;
    }
  }
  return best;
}

// ----- Build the working column for a given outlier state -----------
// Returns a fresh array of rows; the known outlier row is swapped to 95.
function buildRows(outlierOn) {
  return BASE_ROWS.map((r, i) => {
    if (!r.missing && outlierOn && i === OUTLIER_ROW) {
      return { value: OUTLIER_VALUE, missing: false };
    }
    return { value: r.value, missing: r.missing };
  });
}

// ----- DOM ----------------------------------------------------------
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const strategySel = document.getElementById("strategy");
const stratHint = document.getElementById("stratHint");
const outlierChk = document.getElementById("outlier");
const applyBtn = document.getElementById("apply");
const resetBtn = document.getElementById("reset");
const elFill = document.getElementById("rFill");
const elMean = document.getElementById("rMean");
const elMedian = document.getElementById("rMedian");
const elN = document.getElementById("rN");
const elMissing = document.getElementById("rMissing");

// ----- Plot geometry ------------------------------------------------
const Y_LO = 0;
const Y_HI = 100; // outlier (95) fits comfortably below the top
const PAD = { l: 52, r: 22, t: 30, b: 46 };

function plotW() { return canvas.width - PAD.l - PAD.r; }
function plotH() { return canvas.height - PAD.t - PAD.b; }
function yToPx(y) { return PAD.t + (1 - (y - Y_LO) / (Y_HI - Y_LO)) * plotH(); }
function clamp(v, lo, hi) { return v < lo ? lo : v > hi ? hi : v; }

const HINTS = {
  mean: "Fill each gap with the column mean (average of the known values).",
  median: "Fill each gap with the column median (the middle known value).",
  most_frequent: "Fill each gap with the most common rounded value (the mode).",
  drop: "Delete every row that has a gap. No filling -- the column gets shorter.",
};

// ----- State --------------------------------------------------------
let rows = buildRows(outlierChk.checked); // current column
let stats = { mean: 0, median: 0, mode: 0, n: 0, missing: 0, fill: 0 };
let applied = false;     // has imputation been applied?
let dropped = false;     // is the current strategy a "drop"?
let progress = 0;        // 0..1 fill animation progress
let anim = null;         // requestAnimationFrame id

// Recompute the derived statistics for the current rows + strategy.
function recompute() {
  rows = buildRows(outlierChk.checked);
  const known = knownValues(rows);
  const strat = strategySel.value;

  stats.mean = mean(known);
  stats.median = median(known);
  stats.mode = mostFrequent(known);
  stats.missing = rows.filter((r) => r.missing).length;

  dropped = strat === "drop";
  if (dropped) {
    stats.fill = null;
    stats.n = rows.length - stats.missing; // rows left after dropping gaps
  } else {
    stats.fill =
      strat === "mean" ? stats.mean :
      strat === "median" ? stats.median :
      stats.mode;
    stats.n = rows.length; // every row kept, gaps filled
  }
}

// ----- Animation ----------------------------------------------------
function animateTo(target) {
  if (anim) cancelAnimationFrame(anim);
  const start = progress;
  const dur = 650;
  const t0 = performance.now();
  function frame(t) {
    const k = clamp((t - t0) / dur, 0, 1);
    const e = 1 - Math.pow(1 - k, 3); // ease-out cubic
    progress = start + (target - start) * e;
    render();
    if (k < 1) anim = requestAnimationFrame(frame);
    else { progress = target; anim = null; render(); }
  }
  anim = requestAnimationFrame(frame);
}

// ----- Rendering ----------------------------------------------------
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGrid();
  drawBars();
  if (applied && !dropped) drawFillLine();
  drawAxisLabels();
  updateReadout();
}

function drawGrid() {
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.fillStyle = "#94a3b8";
  ctx.lineWidth = 1;
  ctx.font = "12px ui-monospace, Menlo, monospace";
  ctx.textAlign = "right";

  for (let y = Y_LO; y <= Y_HI + 0.001; y += 20) {
    const py = yToPx(y);
    ctx.beginPath();
    ctx.moveTo(PAD.l, py);
    ctx.lineTo(canvas.width - PAD.r, py);
    ctx.stroke();
    ctx.fillText(String(y), PAD.l - 8, py + 4);
  }

  // solid baseline at y = 0
  ctx.strokeStyle = "rgba(255,255,255,0.22)";
  ctx.lineWidth = 1.5;
  const base = yToPx(Y_LO);
  ctx.beginPath();
  ctx.moveTo(PAD.l, base);
  ctx.lineTo(canvas.width - PAD.r, base);
  ctx.stroke();
  ctx.restore();
}

// Layout: bars are laid out across the plot width. When "drop" is
// applied, missing rows collapse away and only kept bars are shown.
function visibleRows() {
  if (applied && dropped) {
    // at full progress only the kept (non-missing) rows remain
    return rows.filter((r) => !r.missing);
  }
  return rows;
}

function drawBars() {
  const list = visibleRows();
  const n = list.length;
  if (n === 0) return;

  const slotW = plotW() / n;
  const barW = Math.min(46, slotW * 0.62);
  const fillVal = stats.fill;

  ctx.save();
  ctx.font = "13px ui-monospace, Menlo, monospace";
  ctx.textAlign = "center";

  for (let i = 0; i < n; i++) {
    const r = list[i];
    const cx = PAD.l + slotW * (i + 0.5);
    const x = cx - barW / 2;
    const base = yToPx(Y_LO);

    if (!r.missing) {
      // known value -> solid bar (outlier highlighted distinctly)
      const isOutlier = r.value === OUTLIER_VALUE;
      const topY = yToPx(r.value);
      const h = base - topY;
      const grad = ctx.createLinearGradient(0, topY, 0, base);
      if (isOutlier) {
        grad.addColorStop(0, "#fca5a5");
        grad.addColorStop(1, "rgba(248,113,113,0.55)");
      } else {
        grad.addColorStop(0, "#22d3ee");
        grad.addColorStop(1, "rgba(34,211,238,0.35)");
      }
      roundedTopRect(x, topY, barW, h, 5, grad);

      ctx.fillStyle = isOutlier ? "#fca5a5" : "#cbd5e1";
      ctx.fillText(String(Math.round(r.value)), cx, topY - 7);
      if (isOutlier) {
        ctx.fillStyle = "#f87171";
        ctx.font = "11px Inter, sans-serif";
        ctx.fillText("outlier", cx, topY - 22);
        ctx.font = "13px ui-monospace, Menlo, monospace";
      }
    } else {
      // MISSING value. when imputation is applied, fill it up to fillVal.
      const dashTop = yToPx(28); // resting height of the empty placeholder
      const dashH = base - dashTop;

      if (applied && fillVal != null) {
        const targetTop = yToPx(fillVal);
        const targetH = base - targetTop;
        const curH = dashH + (targetH - dashH) * progress;
        const curTop = base - curH;
        // solid filled bar in the accent (violet) colour so it reads as
        // "this was synthesised, not measured"
        const grad = ctx.createLinearGradient(0, curTop, 0, base);
        grad.addColorStop(0, "#c4b5fd");
        grad.addColorStop(1, "rgba(167,139,250,0.40)");
        roundedTopRect(x, curTop, barW, curH, 5, grad);

        if (progress > 0.6) {
          ctx.fillStyle = "#c4b5fd";
          ctx.fillText(stats.fill.toFixed(1), cx, curTop - 7);
        }
      } else {
        // resting state: dashed hollow outline + "?"
        ctx.save();
        ctx.setLineDash([6, 5]);
        ctx.lineWidth = 1.5;
        ctx.strokeStyle = "rgba(167,139,250,0.7)";
        ctx.fillStyle = "rgba(167,139,250,0.05)";
        roundedTopRectStroke(x, dashTop, barW, dashH, 5);
        ctx.restore();

        ctx.fillStyle = "#a78bfa";
        ctx.font = "20px ui-monospace, Menlo, monospace";
        ctx.fillText("?", cx, dashTop + dashH / 2 + 7);
        ctx.font = "13px ui-monospace, Menlo, monospace";
      }
    }

    // row index tick under the baseline
    ctx.fillStyle = "rgba(148,163,184,0.65)";
    ctx.font = "10px ui-monospace, Menlo, monospace";
    ctx.fillText("#" + (i + 1), cx, base + 16);
    ctx.font = "13px ui-monospace, Menlo, monospace";
  }
  ctx.restore();
}

// A dashed horizontal guide showing exactly which level the gaps fill to.
function drawFillLine() {
  if (stats.fill == null) return;
  const py = yToPx(stats.fill);
  ctx.save();
  ctx.setLineDash([7, 6]);
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = "rgba(196,181,253,0.75)";
  ctx.beginPath();
  ctx.moveTo(PAD.l, py);
  ctx.lineTo(canvas.width - PAD.r, py);
  ctx.stroke();

  ctx.setLineDash([]);
  ctx.fillStyle = "#c4b5fd";
  ctx.font = "12px ui-monospace, Menlo, monospace";
  ctx.textAlign = "left";
  ctx.fillText(
    strategySel.value + " = " + stats.fill.toFixed(1),
    PAD.l + 6,
    py - 6
  );
  ctx.restore();
}

function drawAxisLabels() {
  ctx.save();
  ctx.fillStyle = "#e2e8f0";
  ctx.font = "13px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("rows of one numeric column", (PAD.l + canvas.width - PAD.r) / 2, canvas.height - 8);

  ctx.save();
  ctx.translate(15, (PAD.t + canvas.height - PAD.b) / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText("value", 0, 0);
  ctx.restore();
  ctx.restore();
}

// ----- Small canvas helpers -----------------------------------------
function roundedTopRect(x, y, w, h, r, fill) {
  r = Math.min(r, w / 2, Math.max(0, h));
  ctx.beginPath();
  ctx.moveTo(x, y + h);
  ctx.lineTo(x, y + r);
  ctx.arcTo(x, y, x + r, y, r);
  ctx.lineTo(x + w - r, y);
  ctx.arcTo(x + w, y, x + w, y + r, r);
  ctx.lineTo(x + w, y + h);
  ctx.closePath();
  ctx.fillStyle = fill;
  ctx.fill();
}

function roundedTopRectStroke(x, y, w, h, r) {
  r = Math.min(r, w / 2, Math.max(0, h));
  ctx.beginPath();
  ctx.moveTo(x, y + h);
  ctx.lineTo(x, y + r);
  ctx.arcTo(x, y, x + r, y, r);
  ctx.lineTo(x + w - r, y);
  ctx.arcTo(x + w, y, x + w, y + r, r);
  ctx.lineTo(x + w, y + h);
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
}

// ----- Readout ------------------------------------------------------
function updateReadout() {
  elMean.textContent = stats.mean.toFixed(1);
  elMedian.textContent = stats.median.toFixed(1);
  elMissing.textContent = String(stats.missing);
  elN.textContent = String(stats.n);

  if (dropped) {
    elFill.textContent = applied ? "drop" : "—";
    elFill.className = applied ? "v dropped" : "v";
  } else if (applied && stats.fill != null) {
    elFill.textContent = stats.fill.toFixed(1);
    elFill.className = "v filled";
  } else {
    elFill.textContent = "—";
    elFill.className = "v";
  }

  // flag the fragile case: outlier ON + mean strategy pulls the fill high
  elMean.className =
    outlierChk.checked && strategySel.value === "mean" && applied ? "v warn" : "v";
}

// ----- Control wiring -----------------------------------------------
function refreshHint() {
  stratHint.textContent = HINTS[strategySel.value] || "";
}

function resetFill() {
  if (anim) { cancelAnimationFrame(anim); anim = null; }
  applied = false;
  progress = 0;
  applyBtn.disabled = false;
  recompute();
  render();
}

strategySel.addEventListener("change", () => {
  refreshHint();
  resetFill(); // a new strategy means re-imputing from scratch
});

outlierChk.addEventListener("change", () => {
  resetFill(); // toggling the outlier changes the column -> reset gaps
});

applyBtn.addEventListener("click", () => {
  recompute();
  applied = true;
  applyBtn.disabled = true;
  if (dropped) {
    // collapse the missing rows away instantly (no partial bar to grow)
    progress = 1;
    render();
  } else {
    progress = 0;
    animateTo(1); // grow the gap bars up to the imputed value
  }
});

resetBtn.addEventListener("click", resetFill);

// ----- Init ---------------------------------------------------------
refreshHint();
recompute();
render();

# Checkpoint — Data Cleaning and EDA

## What you should now be able to do
- Explain why messy data breaks models and name the five common kinds of messiness.
- Detect and handle missing values, duplicates, and wrong types in Pandas.
- Choose median vs mean imputation, and decide when to drop vs impute.
- Normalize inconsistent category labels and encode text categories as numbers.
- Run an EDA pass with histograms, boxplots, scatter plots, and a correlation heatmap, and turn observations into hypotheses.

## Review questions

1. Explain "garbage in, garbage out" specifically in terms of how a model fits data.
2. Name the five common kinds of messy data and give a one-line example of each.
3. Why should you drop duplicate rows *before* computing values to impute with?
4. When is median imputation a better choice than mean imputation, and why?
5. Give a clear rule for when to **impute** a missing value versus **drop** the row.
6. A numeric column loaded as text because one cell contained "N/A". How do you convert it to numbers while turning bad entries into missing values?
7. Which plot answers "are there outliers in this column?" and how do you read it?
8. What does a correlation of +0.8 between two features tell you — and what does it *not* tell you?
9. Why can a strong non-linear relationship show a near-zero correlation, and what should you also look at?
10. How does grouping a 0/1 `survived` column by `sex` give you a survival *rate*?

## Answers

<details>
<summary>Show answers</summary>

1. A model fits a function to match the data it's given exactly; it has no common sense. If the data contains errors or bias, the fitted function reproduces them, so bad inputs guarantee a bad model.
2. Missing values (a blank `age`); wrong types (price stored as text); duplicates (a form submitted twice); outliers (an age of 200); inconsistent categories ("USA", "U.S.A.", "us").
3. Duplicated rows over-weight their values, skewing the mean/median you compute for imputation. Dedupe first so the fill statistics reflect the true data.
4. When the column is skewed or has outliers. The mean is pulled toward extreme values, so it imputes everyone toward a distorted center; the median sits at the middle and barely moves.
5. Impute when a small fraction is missing, the rest of the row is useful, and you have a sensible fill. Drop the row when most fields are missing, it's an exact duplicate, or the value is impossible and unrecoverable; drop the column when it's missing for most rows.
6. `pd.to_numeric(df["col"], errors="coerce")` converts parseable values to numbers and turns un-parseable ones (like "N/A") into `NaN`, which you can then impute.
7. A **boxplot**. The box is the middle 50% (interquartile range), the inner line is the median, and points past the whiskers are flagged potential outliers.
8. It tells you the two features tend to move together strongly and linearly. It does **not** tell you that one causes the other (correlation ≠ causation).
9. Correlation measures only *linear* association; a U-shape or curve can have offsetting parts that cancel to near zero. Always inspect a **scatter plot** as well.
10. The survival column is 0s and 1s, so its mean equals the fraction of 1s — i.e. the proportion who survived. Grouping by `sex` then gives that proportion within each group, which is the survival rate.

</details>

## Hands-on tasks

1. Recreate the messy `id/country/age/income` dataset from lesson 1 via `io.StringIO`. Clean it fully: drop duplicates, normalize `country`, mark `age > 120` as missing, median-impute `age`, and handle the income outlier. Confirm `df.isna().sum().sum() == 0`.
2. Load `load_diabetes(as_frame=True).frame`. Plot a histogram of `target` and a boxplot of `bmi`; write one sentence interpreting each.
3. From the same diabetes frame, print `corr["target"].sort_values()` and identify the two features most associated with the target. State a one-sentence hypothesis about the strongest one.
4. Redo the passenger lab but impute `age` with the median *per `pclass`* instead of one global median, and note whether the survival-by-class rates change.

## You're ready for the next module when…
- [ ] I can take a raw, messy dataset and produce a clean, fully numeric, no-missing table.
- [ ] I can justify every cleaning decision (impute vs drop, median vs mean) out loud.
- [ ] I can run a four-plot EDA pass and explain what each plot reveals.
- [ ] I can turn what I see in the data into a hypothesis a model could test.

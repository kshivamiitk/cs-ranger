"use strict";

/* ------------------------------------------------------------------ *
 * Missing Values Cleaning Simulator  (whole-TABLE level)
 *
 * Idea taught: a real DataFrame has NaN cells scattered across SEVERAL
 * columns of different types, and you pick a cleaning strategy PER COLUMN.
 *   - numeric columns:     drop rows | fill mean | fill median | fill 0
 *   - categorical columns: drop rows | fill mode (most frequent) | fill "Unknown"
 * "Apply cleaning" animates each gap filling in, column by column; columns
 * set to "drop rows" strike out and remove every row missing that column.
 * A "listwise deletion" toggle drops a row if ANY cell is NaN, to contrast
 * wholesale dropping (big row loss) against targeted imputation.
 *
 * Vanilla JS only. The dirty table is a fixed seed; "Re-seed dirt" advances
 * a deterministic PRNG so the holes move but stay reproducible per click.
 * ------------------------------------------------------------------ */

const NaNc = null; // sentinel for a missing cell in the data model

// ----- Column schema -----
const COLUMNS = [
  { key: "age",    label: "age",    type: "numeric",     fmt: (v) => String(v) },
  { key: "income", label: "income", type: "numeric",     fmt: (v) => "$" + Number(v).toLocaleString("en-US") },
  { key: "city",   label: "city",   type: "categorical", fmt: (v) => String(v) },
  { key: "plan",   label: "plan",   type: "categorical", fmt: (v) => String(v) }
];

const NUMERIC_STRATEGIES = [
  { value: "drop",   text: "drop rows",            hint: "Delete every row missing this column." },
  { value: "mean",   text: "fill mean",            hint: "Fill gaps with the column average." },
  { value: "median", text: "fill median",          hint: "Fill gaps with the middle value (robust to outliers)." },
  { value: "zero",   text: "fill 0",               hint: "Fill gaps with 0 — blunt; only if 0 is meaningful." }
];
const CATEGORICAL_STRATEGIES = [
  { value: "drop",    text: "drop rows",           hint: "Delete every row missing this column." },
  { value: "mode",    text: "fill mode (frequent)", hint: "Fill gaps with the most common category." },
  { value: "unknown", text: 'fill "Unknown"',      hint: 'Fill gaps with the literal label "Unknown".' }
];
const DEFAULT_STRATEGY = { numeric: "median", categorical: "mode" };

// ----- The "clean" universe each column draws its real values from -----
// (deterministic; the dirty table is this base with some cells knocked out)
const BASE = [
  { age: 34, income: 52000,  city: "Pune",      plan: "Pro" },
  { age: 28, income: 41000,  city: "Mumbai",    plan: "Free" },
  { age: 45, income: 88000,  city: "Mumbai",    plan: "Pro" },
  { age: 31, income: 47000,  city: "Delhi",     plan: "Free" },
  { age: 52, income: 120000, city: "Bengaluru", plan: "Team" },
  { age: 26, income: 38000,  city: "Pune",      plan: "Free" },
  { age: 39, income: 61000,  city: "Mumbai",    plan: "Pro" },
  { age: 41, income: 73000,  city: "Delhi",     plan: "Pro" },
  { age: 29, income: 44000,  city: "Bengaluru", plan: "Free" },
  { age: 36, income: 56000,  city: "Mumbai",    plan: "Team" }
];
const NROWS = BASE.length;
const HOLES = 7; // how many cells to knock out per seed

// ----- Deterministic PRNG (so the dirt is reproducible; reseed advances it) -----
let SEED = 20240601;
function makeRng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff; // [0,1)
  };
}

// ----- Build the dirty table from BASE by punching HOLES distinct cells -----
function buildDirty(seed) {
  const rng = makeRng(seed);
  // deep copy
  const rows = BASE.map((r) => ({ ...r }));
  const cells = [];
  for (let i = 0; i < NROWS; i++) {
    for (const c of COLUMNS) cells.push({ r: i, k: c.key });
  }
  // Fisher-Yates shuffle with the seeded rng, then knock out the first HOLES
  for (let i = cells.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    const t = cells[i]; cells[i] = cells[j]; cells[j] = t;
  }
  // guarantee at least one hole in each column so every dropdown matters
  const seenCols = new Set();
  const chosen = [];
  for (const cell of cells) {
    if (chosen.length >= HOLES) break;
    chosen.push(cell);
    seenCols.add(cell.k);
  }
  for (const c of COLUMNS) {
    if (!seenCols.has(c.key)) {
      // swap the last chosen for an untouched cell in this column
      const repl = cells.find((x) => x.k === c.key && !chosen.includes(x));
      if (repl) { chosen[chosen.length - 1] = repl; seenCols.add(c.key); }
    }
  }
  for (const cell of chosen) rows[cell.r][cell.k] = NaNc;
  return rows;
}

// ----- Column statistics on the CURRENT dirty data (ignoring NaN) -----
function presentValues(rows, key) {
  const out = [];
  for (const r of rows) if (r[key] !== NaNc) out.push(r[key]);
  return out;
}
function mean(vals) {
  if (!vals.length) return 0;
  let s = 0; for (const v of vals) s += v;
  return s / vals.length;
}
function median(vals) {
  if (!vals.length) return 0;
  const a = vals.slice().sort((x, y) => x - y);
  const m = Math.floor(a.length / 2);
  return a.length % 2 ? a[m] : (a[m - 1] + a[m]) / 2;
}
function mode(vals) {
  const counts = new Map();
  let best = null, bestN = -1;
  for (const v of vals) {
    const n = (counts.get(v) || 0) + 1;
    counts.set(v, n);
    if (n > bestN) { bestN = n; best = v; } // first-seen wins ties (deterministic)
  }
  return best;
}

// Round numeric fills to integers (these are people's ages / incomes)
function fillValueFor(col, rows, strategy) {
  if (col.type === "numeric") {
    const vals = presentValues(rows, col.key);
    if (strategy === "mean")   return Math.round(mean(vals));
    if (strategy === "median") return Math.round(median(vals));
    if (strategy === "zero")   return 0;
  } else {
    const vals = presentValues(rows, col.key);
    if (strategy === "mode")    return mode(vals);
    if (strategy === "unknown") return "Unknown";
  }
  return null; // "drop"
}

function countMissing(rows) {
  let n = 0;
  for (const r of rows) for (const c of COLUMNS) if (r[c.key] === NaNc) n++;
  return n;
}

// ===================================================================
// State + DOM
// ===================================================================
let dirty = buildDirty(SEED);   // the original dirty table (model)
let view = dirty.map((r) => ({ ...r })); // current displayed table
let strategy = {};              // per-column chosen strategy
for (const c of COLUMNS) strategy[c.key] = DEFAULT_STRATEGY[c.type];
let busy = false;               // true while an apply animation is running

const elControls  = document.getElementById("controls");
const elHead      = document.getElementById("gridHead");
const elBody      = document.getElementById("gridBody");
const elFills     = document.getElementById("fills");
const elApply     = document.getElementById("apply");
const elReset     = document.getElementById("reset");
const elReseed    = document.getElementById("reseed");
const elListwise  = document.getElementById("listwise");

const elRowsBefore = document.getElementById("rRowsBefore");
const elRowsAfter  = document.getElementById("rRowsAfter");
const elMissBefore = document.getElementById("rMissBefore");
const elMissAfter  = document.getElementById("rMissAfter");
const elStatus     = document.getElementById("rStatus");

// ----- Build the per-column strategy dropdowns -----
function strategiesFor(col) {
  return col.type === "numeric" ? NUMERIC_STRATEGIES : CATEGORICAL_STRATEGIES;
}
function hintFor(col, value) {
  const found = strategiesFor(col).find((s) => s.value === value);
  return found ? found.hint : "";
}

function buildControls() {
  elControls.innerHTML = "";
  for (const col of COLUMNS) {
    const ctrl = document.createElement("div");
    ctrl.className = "ctrl";

    const label = document.createElement("label");
    label.setAttribute("for", "sel-" + col.key);
    const name = document.createElement("span");
    name.textContent = col.label;
    const tag = document.createElement("span");
    tag.className = "typetag " + col.type;
    tag.textContent = col.type;
    label.appendChild(name);
    label.appendChild(tag);

    const sel = document.createElement("select");
    sel.id = "sel-" + col.key;
    for (const s of strategiesFor(col)) {
      const opt = document.createElement("option");
      opt.value = s.value;
      opt.textContent = s.text;
      if (s.value === strategy[col.key]) opt.selected = true;
      sel.appendChild(opt);
    }

    const hint = document.createElement("div");
    hint.className = "hint";
    hint.id = "hint-" + col.key;
    hint.textContent = hintFor(col, strategy[col.key]);

    sel.addEventListener("change", () => {
      if (busy) return;
      strategy[col.key] = sel.value;
      hint.textContent = hintFor(col, sel.value);
      // changing a strategy resets the preview back to the dirty table
      restoreDirty();
    });

    ctrl.appendChild(label);
    ctrl.appendChild(sel);
    ctrl.appendChild(hint);
    elControls.appendChild(ctrl);
  }
}

// ----- Render the table head -----
function renderHead() {
  elHead.innerHTML = "";
  const tr = document.createElement("tr");
  const idx = document.createElement("th");
  idx.className = "idxcol";
  idx.textContent = "#";
  tr.appendChild(idx);
  for (const col of COLUMNS) {
    const th = document.createElement("th");
    const nm = document.createElement("span");
    nm.className = "colname";
    nm.textContent = col.label;
    const ty = document.createElement("span");
    ty.className = "coltype";
    ty.textContent = col.type;
    th.appendChild(nm);
    th.appendChild(ty);
    tr.appendChild(th);
  }
  elHead.appendChild(tr);
}

// ----- Render the body from `view`; keeps a stable DOM id per (row,col) -----
function renderBody() {
  elBody.innerHTML = "";
  for (let i = 0; i < view.length; i++) {
    const r = view[i];
    const tr = document.createElement("tr");
    tr.dataset.row = String(i);

    const idx = document.createElement("td");
    idx.className = "idxcol";
    idx.textContent = String(i);
    tr.appendChild(idx);

    for (const col of COLUMNS) {
      const td = document.createElement("td");
      td.dataset.col = col.key;
      const v = r[col.key];
      if (v === NaNc) {
        td.classList.add("nan-cell");
        td.textContent = "NaN";
      } else {
        td.textContent = col.fmt(v);
      }
      tr.appendChild(td);
    }
    elBody.appendChild(tr);
  }
}

function cellEl(rowIdx, colKey) {
  return elBody.querySelector(
    'tr[data-row="' + rowIdx + '"] td[data-col="' + colKey + '"]'
  );
}
function rowEl(rowIdx) {
  return elBody.querySelector('tr[data-row="' + rowIdx + '"]');
}

// ----- Fill chips: what value each column will use -----
function renderFills() {
  elFills.innerHTML = "";
  for (const col of COLUMNS) {
    const chip = document.createElement("span");
    chip.className = "fill";
    const strat = strategy[col.key];
    const label = document.createElement("b");
    label.textContent = col.label + ": ";
    chip.appendChild(label);

    const val = document.createElement("span");
    if (strat === "drop") {
      val.className = "drop";
      val.textContent = "drop rows";
    } else {
      val.className = "used";
      const fv = fillValueFor(col, dirty, strat);
      val.textContent = col.type === "numeric" ? col.fmt(fv) : String(fv);
    }
    chip.appendChild(val);
    elFills.appendChild(chip);
  }
}

// ----- Readout -----
function setStat(el, text, cls) {
  el.textContent = text;
  el.className = "v" + (cls ? " " + cls : "");
}
function renderReadout(after) {
  const rowsBefore = NROWS;
  const missBefore = countMissing(dirty);
  elRowsBefore.textContent = String(rowsBefore);
  elMissBefore.textContent = String(missBefore);

  if (!after) {
    setStat(elRowsAfter, "—", "");
    setStat(elMissAfter, "—", "");
    setStat(elStatus, "press Apply cleaning", "");
    return;
  }

  const rowsAfter = after.rows.length;
  const missAfter = countMissing(after.rows);
  const lost = rowsBefore - rowsAfter;

  setStat(elRowsAfter, String(rowsAfter), lost === 0 ? "good" : (rowsAfter <= rowsBefore / 2 ? "bad" : "warn"));
  setStat(elMissAfter, String(missAfter), missAfter === 0 ? "good" : "warn");

  if (elListwise.checked) {
    setStat(elStatus, "listwise: −" + lost + " rows", lost > 0 ? "bad" : "good");
  } else if (lost > 0) {
    setStat(elStatus, "dropped " + lost + " row" + (lost === 1 ? "" : "s"), "warn");
  } else {
    setStat(elStatus, "imputed — 0 rows lost", "good");
  }
}

// ===================================================================
// Compute the cleaned result (pure; no DOM)
// Returns { rows, fills:{key:value|null}, droppedRows:Set, filledCells:[{r,k,v}] }
// ===================================================================
function computeClean() {
  const fills = {};
  for (const col of COLUMNS) {
    fills[col.key] = strategy[col.key] === "drop"
      ? null
      : fillValueFor(col, dirty, strategy[col.key]);
  }

  // Which original rows get dropped?
  const dropped = new Set();
  for (let i = 0; i < dirty.length; i++) {
    const r = dirty[i];
    if (elListwise.checked) {
      // any NaN anywhere -> drop
      for (const col of COLUMNS) {
        if (r[col.key] === NaNc) { dropped.add(i); break; }
      }
    } else {
      // drop only if a column whose strategy is "drop" is NaN here
      for (const col of COLUMNS) {
        if (strategy[col.key] === "drop" && r[col.key] === NaNc) { dropped.add(i); break; }
      }
    }
  }

  // Build surviving rows, recording which cells were filled
  const rows = [];
  const filledCells = [];
  for (let i = 0; i < dirty.length; i++) {
    if (dropped.has(i)) continue;
    const src = dirty[i];
    const out = { ...src };
    for (const col of COLUMNS) {
      if (out[col.key] === NaNc && fills[col.key] !== null) {
        out[col.key] = fills[col.key];
        filledCells.push({ r: i, k: col.key, v: fills[col.key] });
      }
    }
    rows.push(out);
  }
  return { rows, fills, dropped, filledCells };
}

// ===================================================================
// Restore the dirty table (Reset / strategy change)
// ===================================================================
function restoreDirty() {
  view = dirty.map((r) => ({ ...r }));
  renderBody();
  renderFills();
  renderReadout(null);
  elApply.disabled = false;
}

// ===================================================================
// Apply cleaning, animated column-by-column
// ===================================================================
function applyCleaning() {
  if (busy) return;
  busy = true;
  elApply.disabled = true;
  elReset.disabled = true;
  elReseed.disabled = true;

  const result = computeClean();

  // Phase 1: strike through every row that will be dropped.
  for (const i of result.dropped) {
    const tr = rowEl(i);
    if (tr) tr.classList.add("dropping");
  }

  // Phase 2: fill gaps, grouped by column, one column at a time.
  const byCol = COLUMNS.map((col) =>
    result.filledCells.filter((fc) => fc.k === col.key)
  );

  const STEP = 520; // ms between column waves
  let wave = 0;

  function fillColumn(colIndex) {
    const fills = byCol[colIndex];
    for (const fc of fills) {
      if (result.dropped.has(fc.r)) continue; // dropped rows don't get filled
      const td = cellEl(fc.r, fc.k);
      if (!td) continue;
      const col = COLUMNS[colIndex];
      td.classList.remove("nan-cell");
      td.classList.add("just-filled");
      td.textContent = col.type === "numeric" ? col.fmt(fc.v) : String(fc.v);
    }
  }

  function nextWave() {
    if (wave < COLUMNS.length) {
      fillColumn(wave);
      wave++;
      setTimeout(nextWave, STEP);
    } else {
      finish();
    }
  }

  function finish() {
    // Phase 3: actually remove the dropped rows, then re-render to the result.
    const droppedTrs = [];
    for (const i of result.dropped) {
      const tr = rowEl(i);
      if (tr) { tr.classList.add("dropped"); droppedTrs.push(tr); }
    }
    setTimeout(() => {
      view = result.rows.map((r) => ({ ...r }));
      renderBody();
      renderReadout(result);
      busy = false;
      elReset.disabled = false;
      elReseed.disabled = false;
      elApply.disabled = true; // already clean; Reset to run again
    }, droppedTrs.length ? 420 : 60);
  }

  // give the strikethrough a beat before filling begins
  setTimeout(nextWave, result.dropped.size ? 380 : 40);
}

// ===================================================================
// Wiring
// ===================================================================
elApply.addEventListener("click", applyCleaning);

elReset.addEventListener("click", () => {
  if (busy) return;
  restoreDirty();
  setStat(elStatus, "restored — pick strategies", "");
});

elReseed.addEventListener("click", () => {
  if (busy) return;
  SEED = (SEED * 1664525 + 1013904223) & 0x7fffffff; // advance deterministically
  dirty = buildDirty(SEED);
  restoreDirty();
  setStat(elStatus, "new dirt seeded", "");
});

elListwise.addEventListener("change", () => {
  if (busy) return;
  // toggling the contrast resets the preview
  restoreDirty();
  setStat(
    elStatus,
    elListwise.checked ? "listwise on — Apply to compare" : "per-column mode",
    ""
  );
});

// ----- Init -----
buildControls();
renderHead();
restoreDirty();

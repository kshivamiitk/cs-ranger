# Cleaning — Missing Values, Types, Duplicates

> This is the toolbox you'll reach for on every project: detect what's wrong, decide whether to fix or drop it, and apply the fix in a few lines of Pandas.

## What you'll learn
- Detecting and handling missing values with `isna`, `fillna`, and `dropna`.
- Choosing **median vs mean** imputation and why median is often safer.
- Converting column types with `astype` and fixing inconsistent category labels.
- A clear rule for **when to drop a row vs impute** a value.

## Intuition

Cleaning is a sequence of small, deliberate decisions, each one a fork: *fix it or remove it*. The guiding question is always "what would a careful analyst do, and can I justify it?" You impute (fill in) a missing value when the rest of the row is valuable and you have a reasonable estimate. You drop when the row is mostly empty, clearly wrong, or a true duplicate. There's rarely a single correct answer — but there are clearly *defensible* and *indefensible* ones, and that's what you're learning to tell apart.

A key idea for imputation: **median vs mean.** The mean is the arithmetic average; the median is the middle value. The mean gets dragged toward extreme values (one billionaire pulls the average income way up), while the median barely moves. So when a column has outliers or a skewed shape — incomes, prices, ages with a few errors — fill missing values with the **median**. For a clean, symmetric column, the mean is fine.

## Python in practice

We'll clean the messy dataset from the previous lesson, step by step.

```python
import pandas as pd
import io

csv_text = """id,country,age,income
1,USA,34,55000
2,U.S.A.,29,48000
3,usa,200,61000
4,Canada,,72000
4,Canada,,72000
5,United States,41,9999999"""

df = pd.read_csv(io.StringIO(csv_text))
```

### 1. Remove exact duplicates first

Deduplicate early so duplicates don't skew the statistics you'll use for imputation.

```python
print("Before:", len(df), "rows")
df = df.drop_duplicates()                 # drops the second identical 'id 4' row
df = df.reset_index(drop=True)            # tidy the index after removing rows
print("After: ", len(df), "rows")         # 5 rows now
```

### 2. Fix inconsistent categories

Normalize the spellings so one real country is one category. Lowercase, strip whitespace, then map known variants to a canonical name.

```python
df["country"] = df["country"].str.lower().str.strip()
canonical = {
    "usa": "United States",
    "u.s.a.": "United States",
    "united states": "United States",
    "canada": "Canada",
}
df["country"] = df["country"].map(canonical)
print(df["country"].unique())             # ['United States' 'Canada'] -> 2 clean categories
```

### 3. Handle an impossible value, then missing values

An age of 200 is not a real outlier — it's an error. Replace clearly-impossible values with `NaN` so they're treated as missing, then impute.

```python
import numpy as np

# Mark biologically impossible ages as missing
df.loc[df["age"] > 120, "age"] = np.nan

print("Missing ages now:", df["age"].isna().sum())   # 3 (the two blanks + the former 200)

# Impute with the MEDIAN -- robust to skew/outliers (ages here are otherwise low)
median_age = df["age"].median()
df["age"] = df["age"].fillna(median_age)
print(f"Imputed missing ages with median = {median_age}")
```

### 4. Fix data types

Suppose `income` had been read as text (it wasn't here, but this is the common fix). `astype` converts a column's type. For numbers hiding behind text, `pd.to_numeric(..., errors="coerce")` turns un-parseable entries into `NaN` so you can then impute them.

```python
# Defensive conversion: anything non-numeric becomes NaN instead of crashing
df["income"] = pd.to_numeric(df["income"], errors="coerce")
print(df.dtypes)                          # income is now a clean numeric type
```

### 5. Decide about the income outlier

`9999999` is far above the others. If it's a genuine high earner you might keep it; if it's a likely data-entry error you might cap or drop it. Here we treat it as suspect and replace with the median of the *believable* values.

```python
believable = df.loc[df["income"] < 1_000_000, "income"]
df.loc[df["income"] >= 1_000_000, "income"] = believable.median()
print(df)
print("\nFinal missing values:", df.isna().sum().sum())   # 0 -> fully clean
```

### When to drop vs impute — a rule of thumb

- **Impute** when: the column has a small fraction missing, the rest of the row is useful, and you have a sensible fill (median for skewed numerics, mean for clean ones, most-frequent for categories).
- **Drop the row** when: most of its fields are missing, it's an exact duplicate, or the values are impossible and unrecoverable.
- **Drop the column** when: it's missing for most rows or is irrelevant — imputing 80%-missing data invents more than it fills.

`dropna` does the removing: `df.dropna()` drops rows with any missing value; `df.dropna(subset=["age"])` drops only where `age` is missing; `df.dropna(axis=1)` drops columns with missing values.

## Common mistakes

- **Computing impute statistics before deduplicating.** Duplicated rows skew the mean/median you fill with. Dedupe first.
- **Using the mean on a skewed column.** One huge value drags the mean and you impute everyone toward a wrong center. Prefer the median when in doubt.
- **`fillna` not sticking.** `df["age"].fillna(x)` returns a copy; assign it back: `df["age"] = df["age"].fillna(x)`.
- **Leaving placeholder values as numbers.** A `-1` or `999` standing for "missing" silently joins your real numbers. Convert such placeholders to `NaN` first.
- **Imputing using the whole dataset before splitting.** In a real pipeline, compute the fill value from the *training* set only, to avoid leaking test information. (You'll formalize this with scikit-learn pipelines later.)

## Small exercise

Start from the messy `csv_text` above. Without peeking at the solution, write the cleaning in this order: drop duplicates → normalize `country` → mark `age > 120` as `NaN` → median-impute `age`. Then print `df["age"].mean()` before and after fixing the `200`, and write one sentence on why the mean changed so much. (Hint: the impossible value was inflating it.)

## Before you continue
- [ ] I can detect missing values, duplicates, and bad types and choose a fix for each.
- [ ] I can explain when to use median vs mean imputation.
- [ ] I can normalize inconsistent category labels into one canonical value.
- [ ] I can state a clear rule for when to drop a row/column vs impute.

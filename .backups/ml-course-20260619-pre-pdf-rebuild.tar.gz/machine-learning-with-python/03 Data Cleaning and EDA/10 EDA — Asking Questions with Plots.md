# EDA — Asking Questions with Plots

> Before modeling, you interrogate the data with plots. Each chart type answers a different question — learn which to reach for, and you'll spot patterns (and bugs) the model would otherwise inherit.

## What you'll learn
- The four workhorse plots — histogram, boxplot, scatter, correlation heatmap — and what each reveals.
- How to read distributions, spot outliers, and see relationships between variables.
- How to turn an observation into a testable hypothesis.
- matplotlib code you can paste and adapt for any dataset.

## Intuition

Exploratory Data Analysis (EDA) is a conversation with your data. You ask a question, draw the plot that answers it, and let the answer suggest the next question. A summary table tells you the average; a plot tells you the *shape* — and shape is where the insight (and the bugs) hide. Two columns can share the same mean while one is tidy and the other is full of outliers; only a plot shows the difference.

Match the question to the chart:

- **"What does one variable look like?"** -> **histogram** (distribution of a single numeric column).
- **"Are there outliers, and how spread out is it?"** -> **boxplot** (median, quartiles, and flagged outliers).
- **"Do two variables move together?"** -> **scatter plot** (one numeric vs another).
- **"Which variables relate to each other across the whole dataset?"** -> **correlation heatmap** (all pairwise linear relationships at a glance).

## Python in practice

We'll use scikit-learn's diabetes dataset so it runs offline, loaded into a DataFrame for convenient column names.

```python
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.datasets import load_diabetes

data = load_diabetes(as_frame=True)
df = data.frame                 # features + a 'target' column (disease progression)
print(df.columns.tolist())      # ['age','sex','bmi','bp','s1',...,'target']
```

### Histogram — the shape of one variable

```python
df["target"].hist(bins=20, color="#a78bfa", edgecolor="#0b0b10")
plt.title("Distribution of disease progression (target)")
plt.xlabel("target value"); plt.ylabel("count")
plt.show()
```

**What it reveals:** whether the variable is symmetric, skewed, or has multiple peaks. A long tail to the right means a few very high values — a hint you might need the median over the mean, or a transformation. A second peak can mean two hidden subgroups.

### Boxplot — spread and outliers

```python
df.boxplot(column="bmi")
plt.title("BMI spread and outliers")
plt.show()
```

**What it reveals:** the box spans the middle 50% of the data (the interquartile range), the line inside is the median, and points beyond the "whiskers" are flagged as potential outliers. This is the fastest visual outlier check you have.

### Scatter — relationship between two variables

```python
plt.scatter(df["bmi"], df["target"], alpha=0.5, color="#22d3ee")
plt.title("BMI vs disease progression")
plt.xlabel("bmi (standardized)"); plt.ylabel("target")
plt.show()
```

**What it reveals:** an upward cloud means higher BMI tends to go with higher target — a positive relationship worth modeling. A shapeless blob means little linear relationship. A curve means the relationship exists but isn't a straight line (a linear model would miss it).

### Correlation heatmap — all relationships at once

A correlation runs from -1 (perfect inverse) through 0 (no linear link) to +1 (perfect direct). The heatmap colors every pairwise correlation so strong relationships pop out.

```python
import numpy as np

corr = df.corr(numeric_only=True)      # pairwise linear correlations, a square table
fig, ax = plt.subplots(figsize=(7, 6))
im = ax.imshow(corr, cmap="viridis", vmin=-1, vmax=1)
ax.set_xticks(range(len(corr))); ax.set_xticklabels(corr.columns, rotation=90)
ax.set_yticks(range(len(corr))); ax.set_yticklabels(corr.columns)
fig.colorbar(im, label="correlation")
plt.title("Feature correlation heatmap")
plt.tight_layout(); plt.show()

# Which features correlate most with the target?
print(corr["target"].sort_values(ascending=False))
```

**What it reveals:** which features relate to the target (candidates for strong predictors) and which features relate to *each other* (redundant pairs that carry overlapping information). Both insights shape which features you keep.

### From observation to hypothesis

EDA's payoff is turning a picture into a testable claim. The scatter and heatmap above might prompt: **"Higher BMI is associated with higher disease progression."** That's a hypothesis. You'd then test it by fitting a model and checking BMI's coefficient and the model's error — exactly what the modeling modules do. Good EDA gives you hypotheses worth testing instead of guesses.

## Common mistakes

- **Reaching for the model before plotting.** You'll miss data bugs and pick the wrong model type for the relationship's shape.
- **Reading correlation as causation.** A strong correlation means they move together, not that one causes the other. State relationships carefully.
- **Only trusting correlation for non-linear links.** Correlation measures *linear* association; a strong curve can show near-zero correlation. Always look at the scatter too.
- **Too few or too many histogram bins.** Too few hides structure; too many turns it into noise. Try a couple of `bins` values.
- **Forgetting `plt.show()` in a script.** Notebooks render automatically; scripts need `plt.show()` to display the figure.

## Small exercise

Load the diabetes data as above. (1) Plot a histogram of `bmi` and describe its shape in one sentence. (2) Make a scatter of `bp` (blood pressure) vs `target` and say whether you see a positive, negative, or no clear relationship. (3) From `corr["target"]`, name the two features most correlated with the target, and write a one-sentence hypothesis about the strongest one.

## Before you continue
- [ ] I can choose the right plot (histogram / boxplot / scatter / heatmap) for a given question.
- [ ] I can read a distribution's shape, spot outliers on a boxplot, and judge a scatter relationship.
- [ ] I can interpret a correlation value and the heatmap, and I know correlation ≠ causation.
- [ ] I can turn a visual observation into a testable hypothesis.

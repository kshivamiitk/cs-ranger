# Why Messy Data Breaks Models

> The hardest part of machine learning isn't the algorithm — it's getting the data into a state the algorithm can trust. Skip this and even the best model learns nonsense.

## What you'll learn
- The principle of "garbage in, garbage out" and why it's literal in ML.
- The five common kinds of messiness you'll meet in almost every real dataset.
- Concrete examples of how each kind quietly corrupts a model.
- Why cleaning and exploring data realistically eats most of an ML project's time.

## Intuition

A model has no common sense. It treats your data as the absolute truth about the world and fits a function to match it exactly. If your data says a person is 200 years old, or lists "Male", "male", and "M" as three different genders, or has a price column accidentally stored as text, the model faithfully learns those mistakes. **Garbage in, garbage out** isn't a slogan — it's a guarantee. The model can only be as good as the patterns in your data, and bad data contains bad patterns.

Picture teaching someone to cook from a recipe where half the measurements are missing, some are in the wrong units, and a few steps are duplicated. They'll produce something, but it won't be the dish you wanted. Cleaning is rewriting that recipe so it's complete, consistent, and correct *before* anyone starts cooking.

### The five kinds of messiness

1. **Missing values.** Cells with no data — `NaN`, empty strings, or placeholders like `-1` or `999`. A patient's blood pressure wasn't recorded; a survey question was skipped. Most ML algorithms in scikit-learn will *error out* on missing values, and the ones that don't will be skewed by them.

2. **Wrong data types.** A numeric column read as text because one row contains `"N/A"` or a stray `$`. Now `df["price"]` is a string column and `price.mean()` either fails or concatenates text. Models need numbers; text columns silently break math.

3. **Duplicates.** The same record appearing twice — a double-submitted form, a botched data merge. Duplicates over-weight whatever they contain, so the model "hears" some examples louder than others and biases toward them.

4. **Outliers.** Values far outside the normal range, whether real (a genuine billionaire in an income dataset) or errors (an age of `200`, a typo adding an extra zero). Outliers drag means and slopes toward themselves and can dominate a model's fit, making it worse for the typical case.

5. **Inconsistent categories.** The same thing spelled many ways: `"USA"`, `"U.S.A."`, `"United States"`, `"us"`. To a computer these are four distinct categories, so it splits what should be one group into fragments, diluting any signal and inflating the number of features after encoding.

### Why cleaning takes most of the time

It's a widely repeated rule of thumb among practitioners that data preparation — collecting, cleaning, and shaping — consumes the majority of an ML project, often quoted as roughly 60–80% of the effort, with actual model fitting a small slice at the end. Whether it's exactly that fraction for you, the lesson holds: the model code is short and the data work is long. New learners are surprised because tutorials hand them clean datasets; real datasets never arrive that way. Budget for it, and you'll out-perform people who rush to `model.fit`.

## Python in practice

Here's a tiny dataset showing all five problems at once, so you can *see* what "messy" means before we fix it next lesson.

```python
import pandas as pd
import io

csv_text = """id,country,age,income
1,USA,34,55000
2,U.S.A.,29,48000
3,usa,200,61000
4,Canada,,72000
4,Canada,,72000
5,United States,41,9999999"""

df = pd.read_csv(io.StringIO(csv_text))
print(df)

print("\nUnique countries (should be ~2):", df["country"].unique())
# ['USA' 'U.S.A.' 'usa' 'Canada' 'United States'] -> 4 spellings of 2 countries

print("Missing values per column:")
print(df.isna().sum())                 # age has missing values

print("Duplicate rows:", df.duplicated().sum())   # 1 -> id 4 appears twice

print("Age range:", df["age"].min(), "to", df["age"].max())  # 29 to 200 (200 is an error)
print("Max income:", df["income"].max())          # 9999999 -> likely an outlier/typo
```

Reading the output, you can name every problem: inconsistent `country` spellings, missing `age`, a duplicated row, an impossible age of 200, and a suspicious income. None of these would stop you from calling `model.fit`, but every one of them would poison what the model learns.

## Common mistakes

- **Trusting a dataset because it loaded without errors.** A clean *load* says nothing about clean *data*. Always inspect.
- **Deleting every row with any problem.** You can throw away most of your data that way. Often the fix (impute, standardize a label) keeps the row usable.
- **Ignoring placeholder values.** `-1`, `0`, `999`, or `"N/A"` standing in for "missing" won't show up as `NaN` and will quietly distort statistics. Hunt for them.
- **Cleaning without writing down what you did.** Reproducibility matters; a model trained on data you can't recreate is fragile. Keep cleaning steps in code, not manual edits.

## Small exercise

Run the snippet above. Then, just by reading the printout (no fixing yet), write a one-line note for each of the five messiness types describing exactly where it appears in this dataset and what damage it could cause a model. You'll fix all of them in the next lesson.

## Before you continue
- [ ] I can explain "garbage in, garbage out" in the context of model fitting.
- [ ] I can name the five common kinds of messy data and give an example of each.
- [ ] I can use `isna().sum()`, `duplicated().sum()`, and `unique()` to spot problems.
- [ ] I understand why data work usually dominates an ML project's timeline.

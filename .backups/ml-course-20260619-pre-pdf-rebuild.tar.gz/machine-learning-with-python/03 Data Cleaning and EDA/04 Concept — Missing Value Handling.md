# Missing Value Handling

> Real data has holes, and most ML models can't do arithmetic on a blank — so before you train anything, you have to decide what every NaN should become.

## What is this?

Missing value handling is the step where you find the gaps in your dataset — the empty cells, the `NaN`s, the "not recorded" entries — and decide what to do with each one. A `NaN` ("Not a Number") is pandas' marker for "no value here." Almost every scikit-learn model will refuse to train if even a single feature value is missing, so this isn't optional cleanup; it's a gate every dataset must pass through.

You have two broad choices:

- **Drop** the rows (or columns) that contain missing values. Simple, but you throw away data — sometimes a lot of it.
- **Impute** (fill in) the missing values with a sensible substitute so you can keep the row.

Common imputation strategies:

- **Mean** — fill numeric gaps with the column average. Fast, but sensitive to outliers.
- **Median** — fill with the column's middle value. **Robust**: a few extreme values don't drag it around, so it's usually the safer default for numbers.
- **Mode (most frequent)** — fill *categorical* gaps with the most common category (you can't average "red" and "blue").

Scikit-learn's `SimpleImputer` does all three. The critical rule: you **fit the imputer on the training data only**, then apply those learned fill values to both train and test. Computing the fill value from the whole dataset leaks future information into training. And one more nuance: **missingness can itself be informative** — the *fact* that a value is missing (e.g. "income not provided") may be a useful signal worth recording in its own column.

## Why do we need it?

Two hard reasons. First, **models break on NaNs.** Fit a `LogisticRegression` on a column with a single missing value and scikit-learn throws a `ValueError` and stops. You literally cannot train. Second, **the holes are rarely random.** People skip income questions when they're embarrassed; sensors fail more in extreme weather; a "spouse's age" field is blank precisely because the person is single. How you fill those gaps changes what the model learns.

Done well, imputation lets you **keep precious data** instead of deleting whole rows over one missing field, and it does so without distorting the signal. Done badly — wrong fill value, or computed from the wrong data — it injects bias or leaks information, and the model that looked great in testing fails in production.

## Where it's used in real ML

- **Customer and survey data** — almost always has blank fields (optional questions, partial sign-ups); you impute before any model.
- **Sensor and IoT streams** — devices drop readings; you fill short gaps so time-series models stay usable.
- **Medical records** — not every patient gets every test, so most lab columns are partly empty; imputation strategy is a careful, documented decision.
- **Finance** — missing credit history or income fields, where the *fact* of missingness often predicts risk and gets its own flag.
- **Any Kaggle / real tabular project** — step one of nearly every pipeline is `df.isna().sum()` followed by an imputation choice.

## What breaks if you ignore it

- **Your model won't even train.** scikit-learn raises `ValueError: Input contains NaN`. Hard stop.
- **You silently delete most of your data.** Naively calling `df.dropna()` on a wide dataset can wipe out the majority of rows if missingness is spread across columns — you train on a tiny, biased remainder.
- **You leak the test set.** Computing the mean/median over the *entire* dataset (before splitting) lets test-set information seep into training. Your offline scores look too good and don't hold up live.
- **You wash out a real signal.** Mean-imputing a heavily skewed column (like income, with a few millionaires) drags every filled value upward. Or you impute away "missing = no spouse," destroying information the model could have used.

## Mental model

Think of your dataset as a **paper form filled out by many people**, and some left a few blanks.

- **Dropping rows** = throwing the whole form in the trash because one line is blank. Fast, wasteful, and you lose everything else that person answered.
- **Mean/median imputation** = a clerk who, for each blank, writes in the *typical* answer everyone else gave for that question. Median is the careful clerk who uses the middle answer so one billionaire's salary doesn't skew the fill.
- **Mode imputation** = for a multiple-choice question, the clerk writes the most popular choice.
- **Fit on train only** = the clerk must decide the "typical answer" using *only the forms collected so far* — peeking at next month's forms to fill today's blanks is cheating (leakage).

```
   raw column        median = 30      after imputation
   [ 28 ]            (the middle       [ 28 ]
   [ NaN ]   ---->    value, ignores   [ 30 ]  <- filled
   [ 31 ]             the outlier)     [ 31 ]
   [ 900 ]                             [ 900 ]
   [ 30 ]                              [ 30 ]
```

## Example 1 — Tiny toy example

A 5-row table of ages with two holes. Fill them with the **median** so an outlier doesn't distort the fill.

```
   age
   22
   NaN     <- missing
   25
   31
   NaN     <- missing
```

Step 1: collect the known values: `22, 25, 31`. Step 2: the median (middle value) is `25`. (Note: mean would be `26`, but median ignores any extreme value cleanly.) Step 3: fill both blanks with `25`:

```
   age
   22
   25   <- filled with median
   25
   31
   25   <- filled with median
```

We kept all five rows and made a defensible, outlier-resistant choice. That's the entire idea behind median imputation, done by hand.

## Example 2 — Practical ML example

You're predicting loan **default** from applicant data: `age`, `income`, `loan_amount`, and `employment_type` (a category). The dataset is realistically messy — `income` is missing for self-employed applicants who didn't report it, and `employment_type` is occasionally blank.

You build a **pipeline** so the cleaning travels with the model. Numeric columns (`age`, `income`, `loan_amount`) get a `SimpleImputer(strategy="median")` — median, because `income` is skewed by a few high earners. The categorical `employment_type` gets `SimpleImputer(strategy="most_frequent")`, since you can't average categories. Crucially, the imputers are *fit inside the pipeline on the training fold only*, so the fill values are learned from train and reused on test — no leakage. You might even add an `income_was_missing` flag column, because not reporting income is itself a default-risk signal. The model now trains cleanly on the full dataset and behaves the same way live as it did in testing.

## Python code example

```python
# Missing value handling with SimpleImputer inside a leak-proof pipeline.
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression

# Inline, realistically messy data. Note the NaNs in income and employment_type.
df = pd.DataFrame({
    "age":             [25, 40, 35, 52, 23, 60, 31, 45, 38, 29],
    "income":          [40, 80, np.nan, 120, 30, np.nan, 55, 90, 70, 33],   # skewed, has holes
    "loan_amount":     [10, 20, 15, 30, 8, 25, 12, 22, 18, 9],
    "employment_type": ["salaried", "self", np.nan, "salaried", "salaried",
                        "self", "self", np.nan, "salaried", "self"],
    "defaulted":       [0, 0, 1, 0, 1, 1, 0, 0, 0, 1],   # the label
})

# 1) SEE the holes before doing anything.
print("Missing values per column:")
print(df.isna().sum(), "\n")

X = df.drop(columns="defaulted")
y = df["defaulted"]
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=0)

numeric = ["age", "income", "loan_amount"]
categorical = ["employment_type"]

# 2) Median for numbers (robust to the income outliers); most_frequent for categories.
pre = ColumnTransformer([
    ("num", SimpleImputer(strategy="median"), numeric),
    ("cat", Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("encode", OneHotEncoder(handle_unknown="ignore")),
    ]), categorical),
])

# 3) Wrapping in a Pipeline means imputers are fit on TRAIN ONLY -> no leakage.
model = Pipeline([("prep", pre), ("clf", LogisticRegression())])
model.fit(Xtr, ytr)   # would crash with raw NaNs; the imputers fix them first

print("Test accuracy:", round(model.score(Xte, yte), 3))

# Show the learned median fills (computed from TRAIN, the leak-proof way):
medians = model.named_steps["prep"].named_transformers_["num"].statistics_
print("Median fill values (age, income, loan_amount):", np.round(medians, 1))
```

Expected output (numbers approximate):

```
Missing values per column:
age                0
income             2
loan_amount        0
employment_type    2
defaulted          0
dtype: int64 

Test accuracy: 0.667
Median fill values (age, income, loan_amount): [40.  67.5 20. ]
```

The pipeline detected nothing manually — it learned the fill values from the training rows, applied them everywhere, and trained without ever seeing a raw `NaN`.

## Common mistakes

- **Reflexively calling `df.dropna()`.** On a wide dataset this can delete most of your rows. Check `df.isna().sum()` first and prefer imputing unless a column is mostly empty.
- **Computing fill values on the whole dataset before splitting.** That leaks test information into training. Fit the imputer on train only — easiest via a `Pipeline`.
- **Using mean on skewed columns.** A few outliers drag the mean; use `median` for skewed numeric data (income, prices, counts).
- **Trying to average categories.** You can't take the mean of "salaried" and "self." Use `strategy="most_frequent"` for categorical columns.
- **Treating all missingness as random noise.** Sometimes "missing" is a signal (income not reported, test not ordered). Consider adding a `was_missing` flag column instead of silently erasing the information.

## Before you continue
- [ ] I can detect missing values with `df.isna().sum()` before doing anything else.
- [ ] I can explain the trade-off between dropping rows and imputing them.
- [ ] I know when to use mean vs median (robust) for numbers, and mode for categoricals.
- [ ] I understand why the imputer must be fit on the training data only (leakage).
- [ ] I can recognize that the fact a value is missing may itself be useful information.

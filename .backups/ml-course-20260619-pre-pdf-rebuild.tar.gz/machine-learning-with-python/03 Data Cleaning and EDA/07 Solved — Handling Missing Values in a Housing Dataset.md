# Solved — Handling Missing Values in a Housing Dataset

> You've scraped a small housing dataset to predict sale price, but two columns have holes in them — decide, defensibly, how to fill or drop them before modeling.

## Problem statement

You have a housing table with `price` (target), `sqft`, `lot_size`, `year_built`, and `neighborhood`. Two predictors are incomplete: a handful of `lot_size` and `year_built` values are missing, and `neighborhood` (a category) has a couple of blanks too. The goal: produce a clean feature matrix you can feed to a regression model, while **(a)** not throwing away rows you don't have to, **(b)** not inventing values that bias the model, and **(c)** not leaking information from the test set into your fill values. Success metric for this exercise: zero missing values remaining, with every imputation choice justified.

## Data sample

Shape: 12 rows x 5 columns. `price`, `sqft`, `lot_size`, `year_built` are numeric; `neighborhood` is categorical. Empty fields between commas are missing values.

```python
import pandas as pd
import io

csv_text = """price,sqft,lot_size,year_built,neighborhood
325000,1450,5200,1998,Maple Grove
410000,1980,7100,2005,Riverside
289000,1210,,1976,Maple Grove
515000,2400,9800,2018,Riverside
198000,980,3100,,Old Town
372000,1700,6400,2001,
455000,2150,8200,2012,Riverside
241000,1100,,1969,Old Town
298000,1320,4800,1989,Maple Grove
388000,1850,6900,,Riverside
210000,1020,2950,1972,Old Town
339000,1500,5400,1995,
"""

df = pd.read_csv(io.StringIO(csv_text))
print(df.shape)          # (12, 5)
print(df.isna().sum())   # lot_size 2, year_built 2, neighborhood 2 missing
```

## Why this problem matters

Missing values are the rule, not the exception, in real housing/financial data — sellers omit lot sizes, permit records lose build years, scrapers drop fields. How you fill them silently shapes every downstream prediction: a careless `fillna(0)` would tell the model some houses sit on a zero-size lot or were built in year 0, poisoning the coefficients. And if you compute fill statistics on the *whole* dataset, you leak test-set information into training and your reported accuracy becomes a lie. Getting imputation right is one of the highest-leverage, least-glamorous steps in the pipeline.

## Step-by-step reasoning

1. **Audit first.** Count missingness per column (`df.isna().sum()`) and as a fraction. Here each affected column is missing ~2/12 ≈ 17% — small enough to impute rather than drop the column.
2. **Ask *why* it's missing (MCAR vs not).** *MCAR* (Missing Completely At Random) means the blanks have no relationship to any value — e.g. a flaky scraper dropping random cells. If missingness instead depends on the data (say, expensive homes hide their lot size, or `year_built` is missing only for pre-1900 houses), it is **not** MCAR, and plain mean/median imputation can introduce bias. For this dataset we treat the gaps as roughly MCAR (random scraping failures), which justifies simple imputation; in a real project you'd test this assumption (e.g. compare prices of rows with vs without a missing `lot_size`).
3. **Choose drop vs impute per column.** Dropping every row with any NaN would cost us 6 of 12 rows here — far too expensive for a small dataset. With only ~17% missing per column and the rest of each row useful, **impute**.
4. **Pick the numeric statistic: median, not mean.** `lot_size` and `year_built` can be skewed and outlier-prone (one giant lot, one very old house). The **median** resists those extremes, so it's the safer default fill for skewed numeric columns. (For a clean, symmetric column the mean is fine.)
5. **Handle the category separately.** You can't take a median of `neighborhood`. Two defensible options: fill with the **mode** (most-frequent neighborhood) if you believe the blank is just an unrecorded-but-typical value, or add an explicit **"Missing"** category if "we don't know" is itself informative. Inventing a category avoids pretending a blank is the most common neighborhood.
6. **Do it INSIDE a pipeline to prevent leakage.** The fill values (medians, mode) must be learned from the **training fold only** and then applied to validation/test. Computing them on the full dataset before splitting leaks test information and inflates your scores. `SimpleImputer` inside a `Pipeline`/`ColumnTransformer` learns the statistic in `fit` (training) and reuses it in `transform` (test) automatically.

## Python solution

```python
import pandas as pd
import numpy as np
import io
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LinearRegression

csv_text = """price,sqft,lot_size,year_built,neighborhood
325000,1450,5200,1998,Maple Grove
410000,1980,7100,2005,Riverside
289000,1210,,1976,Maple Grove
515000,2400,9800,2018,Riverside
198000,980,3100,,Old Town
372000,1700,6400,2001,
455000,2150,8200,2012,Riverside
241000,1100,,1969,Old Town
298000,1320,4800,1989,Maple Grove
388000,1850,6900,,Riverside
210000,1020,2950,1972,Old Town
339000,1500,5400,1995,
"""
df = pd.read_csv(io.StringIO(csv_text))

# --- 1. Audit missingness -------------------------------------------------
print("Missing per column:\n", df.isna().sum(), "\n")

X = df.drop(columns="price")
y = df["price"]
numeric_cols = ["sqft", "lot_size", "year_built"]
categorical_cols = ["neighborhood"]

# --- 2. Split BEFORE computing any fill statistic (no leakage) ------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)

# --- 3. Numeric branch: MEDIAN-impute (robust to skew), then scale --------
numeric_pipe = Pipeline(steps=[
    ("impute", SimpleImputer(strategy="median")),
    ("scale", StandardScaler()),
])

# --- 4. Categorical branch: fill with an explicit "Missing" category ------
#     (use strategy="most_frequent" instead to mode-impute)
categorical_pipe = Pipeline(steps=[
    ("impute", SimpleImputer(strategy="constant", fill_value="Missing")),
    ("encode", OneHotEncoder(handle_unknown="ignore")),
])

# --- 5. Combine the branches; fit on TRAIN only ---------------------------
preprocess = ColumnTransformer(transformers=[
    ("num", numeric_pipe, numeric_cols),
    ("cat", categorical_pipe, categorical_cols),
])

model = Pipeline(steps=[
    ("prep", preprocess),
    ("reg", LinearRegression()),
])

model.fit(X_train, y_train)              # medians + mode learned from TRAIN
print("Test R^2:", round(model.score(X_test, y_test), 3))

# Inspect the imputation values the pipeline LEARNED (from training data)
learned = model.named_steps["prep"].named_transformers_["num"].named_steps["impute"]
print("Learned medians (sqft, lot_size, year_built):", learned.statistics_)
```

## Expected output

`df.isna().sum()` reports `lot_size 2`, `year_built 2`, `neighborhood 2`. The pipeline fits without error and prints something like:

```
Missing per column:
 price            0
 sqft             0
 lot_size         2
 year_built       2
 neighborhood     2

Test R^2: 0.74
Learned medians (sqft, lot_size, year_built): [1.450e+03 5.400e+03 1.990e+03]
```

How to read it: `Test R^2 ≈ 0.7` means the model explains roughly 70% of the price variance on held-out homes (your exact number will vary with the tiny split — the point is the pipeline runs clean and leaves no NaNs). The `learned medians` are computed from the **training rows only**; those same numbers are what get plugged into the test rows' blanks at predict time, which is exactly the leakage-free behavior we wanted.

## Common mistakes

- **`df.fillna(0)` on numeric columns.** Zero is a *real, meaningful* value for `lot_size`/`year_built`, so this tells the model some houses have no lot or were built in year 0 — badly biasing coefficients. Use the median.
- **`df.dropna()` reflexively.** On this 12-row table that deletes half the data. Drop the *column* only when it's mostly empty; drop the *row* only when it's mostly empty or impossible.
- **Imputing before the train/test split.** Computing the median over all rows leaks test information into training and inflates your score. Always learn fill values inside the pipeline so they come from the training fold only.
- **Mode-imputing a category when the blank is informative.** If "neighborhood unknown" correlates with, say, new construction, forcing it to the most-common neighborhood erases signal — add a `"Missing"` category instead.
- **Mean-imputing a skewed numeric column.** One mansion's huge `lot_size` drags the mean upward, so every filled value is too big. Median is the safer default when skew/outliers are plausible.

## Extension challenge

1. Replace `SimpleImputer(strategy="median")` with `KNNImputer` (fills using similar rows) and compare the learned values and test R^2 — when does borrowing from neighbors beat a single global median?
2. Add a missingness *indicator*: for each imputed numeric column, append a boolean "was_missing" feature (`SimpleImputer(add_indicator=True)`) and check whether the flag itself carries predictive signal (a clue that the data is NOT MCAR).
3. Make `year_built` missingness depend on age (e.g. blank out only homes built before 1980) and observe how median imputation biases predictions — demonstrating the cost of treating not-MCAR data as MCAR.

## Matching animation

Explore the **Missing Value Imputation Simulator** in this module: toggle the outlier on and watch the mean imputation jump while the median barely moves — the visual proof of why median is the safer default fill for a skewed column.

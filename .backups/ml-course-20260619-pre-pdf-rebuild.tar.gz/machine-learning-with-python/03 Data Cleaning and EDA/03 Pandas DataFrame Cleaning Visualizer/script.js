"use strict";

/* ------------------------------------------------------------------ *
 * Pandas DataFrame Cleaning Visualizer
 * A small messy DataFrame is cleaned in 4 deliberate steps:
 *   1. drop the duplicate row
 *   2. fix a dtype: the string "12" in `age` becomes the int 12
 *   3. normalize a category: "yes"/"Yes"/"YES" -> "yes" in `member`
 *   4. fill a missing cell: NaN in `score` -> the column median
 * Each step re-renders the table and highlights exactly what changed.
 * ------------------------------------------------------------------ */

const COLS = ["name", "age", "member", "score"];

// The raw, messy data. Each cell tracks an optional "missing" flag.
// Note: index 2 ("Bob", row idx 1) is an exact duplicate of index 1.
const RAW = [
  { idx: 0, name: "Ada",  age: "12",  member: "yes", score: 88 },
  { idx: 1, name: "Bob",  age: 41,    member: "Yes", score: 72 },
  { idx: 2, name: "Bob",  age: 41,    member: "Yes", score: 72 }, // duplicate of idx 1
  { idx: 3, name: "Cleo", age: 35,    member: "YES", score: null }, // NaN score
  { idx: 4, name: "Dee",  age: 29,    member: "yes", score: 95 },
];

// ----- DOM -----
const thead = document.getElementById("thead");
const tbody = document.getElementById("tbody");
const shapeEl = document.getElementById("shape");
const codeEl = document.getElementById("codeline");
const noteEl = document.getElementById("stepnote");
const dots = Array.from(document.querySelectorAll(".dot"));
const btnPrev = document.getElementById("prev");
const btnNext = document.getElementById("next");
const btnReset = document.getElementById("reset");

const MAX_STEP = 4;
let step = 0;

// median of the non-missing score values (88, 72, 72, 95) -> sorted 72,72,88,95 -> (72+88)/2 = 80
function medianScore(rows) {
  const vals = rows.map(r => r.score).filter(v => v !== null && v !== undefined).sort((a, b) => a - b);
  if (vals.length === 0) return 0;
  const m = Math.floor(vals.length / 2);
  return vals.length % 2 ? vals[m] : (vals[m - 1] + vals[m]) / 2;
}

// Build the data + per-cell highlight class for a given step.
// Returns { rows: [{idx, cells:[{val, cls}], rowCls}], code, note }.
function buildStep(s) {
  // Deep-ish copy of raw
  let rows = RAW.map(r => ({ ...r }));

  // Compute the median from the de-duplicated, real values for step 4.
  const dedup = [rows[0], rows[1], rows[3], rows[4]];

  if (s === 0) {
    return {
      rows: rows.map(r => ({
        idx: r.idx,
        rowCls: "",
        cells: COLS.map(c => cellRaw(r, c)),
      })),
      code: "# raw data loaded with pd.read_csv(...)",
      note: 'Raw, messy data. Row index <b>2</b> duplicates index 1, <code>age</code> mixes the string <b>"12"</b> with integers, <code>member</code> has three spellings of "yes", and one <code>score</code> is <b>NaN</b>.',
    };
  }

  if (s === 1) {
    // highlight the duplicate row for removal (still shown, struck through)
    return {
      rows: rows.map(r => ({
        idx: r.idx,
        rowCls: r.idx === 2 ? "row-remove" : "",
        cells: COLS.map(c => cellRaw(r, c)),
      })),
      code: "df = df.drop_duplicates().reset_index(drop=True)",
      note: 'Step 1 &mdash; <b>drop duplicates</b>. Index 2 is an exact copy of index 1, so it is removed. Always dedupe <i>first</i>: duplicate rows would skew the median we compute later.',
    };
  }

  // From step 2 on, the duplicate is gone.
  rows = [rows[0], rows[1], rows[3], rows[4]];

  if (s === 2) {
    // fix dtype: Ada's age "12" (string) -> 12 (int)
    return {
      rows: rows.map(r => ({
        idx: r.idx,
        rowCls: "",
        cells: COLS.map(c => {
          if (c === "age" && r.idx === 0) return { val: "12", cls: "cell-change" };
          return cellRaw(r, c);
        }),
      })),
      code: 'df["age"] = pd.to_numeric(df["age"])   # "12" -> 12',
      note: 'Step 2 &mdash; <b>fix the dtype</b>. Ada\'s age was the text <code>"12"</code>, not a number. <code>pd.to_numeric</code> converts the column to <code>int</code> so sums, scaling, and comparisons work correctly.',
    };
  }

  if (s === 3) {
    // normalize category: lowercase member; the previously non-lowercase ones are "cleaned"
    return {
      rows: rows.map(r => ({
        idx: r.idx,
        rowCls: "",
        cells: COLS.map(c => {
          if (c === "age" && r.idx === 0) return { val: 12, cls: "" }; // already fixed
          if (c === "member") {
            const wasMixed = r.member !== "yes";
            return { val: "yes", cls: wasMixed ? "cell-change" : "" };
          }
          return cellRaw(r, c);
        }),
      })),
      code: 'df["member"] = df["member"].str.lower()',
      note: 'Step 3 &mdash; <b>normalize the category</b>. <code>"Yes"</code> and <code>"YES"</code> were distinct categories to pandas. Lowercasing collapses all three spellings into one clean value: <code>"yes"</code>.',
    };
  }

  // s === 4: fill the missing score with the median
  const med = medianScore(dedup);
  return {
    rows: rows.map(r => ({
      idx: r.idx,
      rowCls: "",
      cells: COLS.map(c => {
        if (c === "age" && r.idx === 0) return { val: 12, cls: "" };
        if (c === "member") return { val: "yes", cls: "" };
        if (c === "score" && (r.score === null || r.score === undefined)) {
          return { val: med, cls: "cell-clean" };
        }
        return cellRaw(r, c);
      }),
    })),
    code: 'df["score"] = df["score"].fillna(df["score"].median())  # -> ' + med,
    note: 'Step 4 &mdash; <b>fill the missing value</b>. Cleo\'s <code>score</code> was NaN. We fill it with the column <b>median (' + med + ')</b> &mdash; a defensible, outlier-resistant estimate, not an invented number. The DataFrame is now clean.',
  };
}

// Render a raw cell with NaN styling where appropriate.
function cellRaw(r, c) {
  const v = r[c];
  if (c === "score" && (v === null || v === undefined)) return { val: "NaN", cls: "cell-na" };
  return { val: v, cls: "" };
}

// ----- Rendering -----
function renderHeader() {
  const tr = document.createElement("tr");
  const th0 = document.createElement("th");
  th0.className = "idxcol";
  th0.textContent = "";
  tr.appendChild(th0);
  for (const c of COLS) {
    const th = document.createElement("th");
    th.textContent = c;
    tr.appendChild(th);
  }
  thead.innerHTML = "";
  thead.appendChild(tr);
}

function render() {
  const data = buildStep(step);

  // table body
  tbody.innerHTML = "";
  for (const row of data.rows) {
    const tr = document.createElement("tr");
    if (row.rowCls) tr.className = row.rowCls;

    const tdIdx = document.createElement("td");
    tdIdx.className = "idxcol";
    tdIdx.textContent = row.idx;
    tr.appendChild(tdIdx);

    row.cells.forEach((cell) => {
      const td = document.createElement("td");
      td.textContent = String(cell.val);
      if (cell.cls) td.classList.add(cell.cls);
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
  }

  // shape readout (rows shrink from 5 -> 4 after dedupe)
  const shapeRows = step >= 2 ? "4" : (step === 1 ? "5 → 4" : "5");
  shapeEl.textContent = shapeRows + " rows × " + COLS.length + " cols";

  // code + note
  codeEl.textContent = data.code;
  noteEl.innerHTML = data.note;

  // progress dots
  dots.forEach((d, i) => {
    d.classList.remove("active", "done");
    if (i < step) d.classList.add("done");
    if (i === step) d.classList.add("active");
  });

  btnPrev.disabled = step === 0;
  btnNext.disabled = step === MAX_STEP;
}

// ----- Controls -----
btnNext.addEventListener("click", () => {
  if (step < MAX_STEP) { step += 1; render(); }
});
btnPrev.addEventListener("click", () => {
  if (step > 0) { step -= 1; render(); }
});
btnReset.addEventListener("click", () => {
  step = 0;
  render();
});

// ----- Init -----
renderHeader();
render();

# Lab — Clean and Explore a Passenger Dataset

## Objective

You will take a small, realistic passenger-survival dataset with missing values and text categories, clean it into a model-ready table, then explore it to discover who was most likely to survive. After this lab you'll have done a full clean-then-EDA pass — the exact work that precedes every model — and you'll be able to defend each cleaning choice.

## Dataset

We embed a Titanic-style passenger CSV inline with `io.StringIO`, so the lab runs offline. Each row is one passenger.

| Column | Meaning | Notes |
|---|---|---|
| `pclass` | ticket class | 1 = first, 2 = second, 3 = third |
| `sex` | passenger sex | text: "male" / "female" |
| `age` | age in years | some values missing |
| `fare` | ticket fare paid | float |
| `survived` | outcome | 1 = survived, 0 = did not |

```python
import pandas as pd
import io

csv_text = """pclass,sex,age,fare,survived
1,female,38,71.3,1
1,male,35,53.1,0
3,male,,7.9,0
3,female,26,7.9,1
2,female,14,30.1,1
2,male,,13.0,0
3,male,35,8.0,0
1,female,58,26.5,1
3,female,,7.7,1
1,male,54,51.9,0
2,male,27,13.0,0
3,female,4,16.7,1
3,male,20,7.8,0
1,female,39,110.9,1
2,male,,10.5,0"""

df = pd.read_csv(io.StringIO(csv_text))
```

## Steps

**Step 1 — First look.** Know the shape, types, and where data is missing before touching anything.

```python
print("Shape:", df.shape)              # Shape: (15, 5)
print(df.dtypes)
print("Missing per column:\n", df.isna().sum())   # age has 4 missing
```

**Step 2 — Impute missing `age` with the median.** Age is skewed by a few older passengers, so the median is the robust choice; it also keeps all 15 rows usable instead of dropping a quarter of the data.

```python
median_age = df["age"].median()
df["age"] = df["age"].fillna(median_age)
print(f"Imputed missing ages with median = {median_age}")
print("Missing now:", df["age"].isna().sum())     # 0
```

**Step 3 — Encode `sex` as a number.** Models need numbers, not text. Map female->1, male->0 (a simple, interpretable encoding for a two-category column).

```python
df["sex_female"] = (df["sex"] == "female").astype(int)
print(df[["sex", "sex_female"]].head())
# female -> 1, male -> 0
```

**Step 4 — EDA: survival rate by sex.** A grouped mean of a 0/1 column *is* the survival rate.

```python
print("Survival rate by sex:")
print(df.groupby("sex")["survived"].mean().round(2))
```

**Step 5 — EDA: survival rate by class.** Does ticket class relate to survival?

```python
print("Survival rate by class:")
print(df.groupby("pclass")["survived"].mean().round(2))
```

**Step 6 — Cross-tab: sex and class together.** The clearest single view of the pattern.

```python
print(df.groupby(["sex", "pclass"])["survived"].mean().round(2))
```

**Step 7 — Visualize survival by sex.**

```python
import matplotlib.pyplot as plt

rates = df.groupby("sex")["survived"].mean()
rates.plot(kind="bar", color=["#22d3ee", "#a78bfa"])
plt.title("Survival rate by sex")
plt.ylabel("survival rate"); plt.ylim(0, 1)
plt.tight_layout(); plt.show()
```

## Expected output

- **Shape** is `(15, 5)` and `age` shows **4 missing** values before Step 2 and **0** after.
- **`sex_female`** is 1 for every female row and 0 for every male row — verify a few by eye.
- **Survival by sex:** females show a dramatically higher survival rate than males (close to 1.0 vs near 0.0 in this small sample). This is the famous "women first" pattern.
- **Survival by class:** first class survives at a higher rate than third class — fare and class track survival.
- **Cross-tab:** the highest survival is first-class females; the lowest is third-class males. Reading the bar chart, the female bar towers over the male bar.

**How to interpret it:** you've discovered that `sex` and `pclass` are strong predictors of `survived` *before building any model*. That's the value of clean-then-explore — you now have grounded hypotheses ("being female and in first class strongly predicts survival") that a model will confirm and quantify. With such a tiny sample the exact rates are noisy, but the direction matches the well-known historical pattern, which tells you the pipeline is sound.

## Extension challenge

1. Instead of one global median age, impute age using the **median within each `pclass`** (younger in some classes than others). Does any survival rate shift?
2. Bin `age` into "child" (< 16) and "adult" with `pd.cut` or a comparison, then compute survival rate by that bin. Were children prioritized?
3. Compute the correlation of `fare`, `pclass`, and `sex_female` with `survived` using `df.corr(numeric_only=True)["survived"]`. Which feature has the strongest association, and does its sign make sense?

"use strict";

/* ------------------------------------------------------------------ *
 * Gradient Descent Playground
 * Loss surface:  f(w) = (w - 3)^2     (a simple convex bowl)
 * Gradient:      f'(w) = 2 * (w - 3)
 * Update rule:   w <- w - learningRate * gradient
 * ------------------------------------------------------------------ */

// ----- The math (kept exact and isolated) -----
const W_MIN = 3.0; // location of the minimum of the bowl
function loss(w) { return (w - W_MIN) * (w - W_MIN); }
function grad(w) { return 2.0 * (w - W_MIN); }

// ----- Plot domain (world coordinates) -----
const X_LO = -4, X_HI = 10;        // visible range of w
const Y_LO = 0,  Y_HI = loss(X_LO) > loss(X_HI) ? loss(X_LO) : loss(X_HI); // tallest visible loss
const PAD = { l: 56, r: 24, t: 28, b: 46 };

// ----- DOM -----
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const lrInput = document.getElementById("lr");
const startInput = document.getElementById("startw");
const lrVal = document.getElementById("lrVal");
const startVal = document.getElementById("startwVal");
const elIter = document.getElementById("rIter");
const elW = document.getElementById("rW");
const elLoss = document.getElementById("rLoss");
const elGrad = document.getElementById("rGrad");
const elStatus = document.getElementById("rStatus");

// ----- State -----
let w = parseFloat(startInput.value);
let lr = parseFloat(lrInput.value);
let iter = 0;
let prevLoss = loss(w);
let running = false;
let rafId = null;
let lastTick = 0;
let status = "ready";   // ready | running | converged | diverged
let dragging = false;

const STEP_INTERVAL_MS = 280;  // pace the animation so each step is visible
const CONVERGE_TOL = 1e-6;     // loss change below this => converged
const DIVERGE_LIMIT = 1e9;     // loss above this => clearly diverging

// ----- Coordinate transforms (world <-> pixels). Use canvas's intrinsic size. -----
function plotW() { return canvas.width - PAD.l - PAD.r; }
function plotH() { return canvas.height - PAD.t - PAD.b; }
function xToPx(x) { return PAD.l + ((x - X_LO) / (X_HI - X_LO)) * plotW(); }
function yToPx(y) {
  const yc = clamp(y, Y_LO, Y_HI);
  return PAD.t + (1 - (yc - Y_LO) / (Y_HI - Y_LO)) * plotH();
}
function pxToX(px) { return X_LO + ((px - PAD.l) / plotW()) * (X_HI - X_LO); }

function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

// ----- One gradient-descent step (the real algorithm) -----
function doStep() {
  if (status === "converged" || status === "diverged") return;
  const g = grad(w);
  w = w - lr * g;            // <-- the update rule
  iter += 1;

  const curLoss = loss(w);
  if (!isFinite(curLoss) || curLoss > DIVERGE_LIMIT) {
    status = "diverged";
    stopRun();
  } else if (Math.abs(prevLoss - curLoss) < CONVERGE_TOL && Math.abs(g) < 1e-3) {
    status = "converged";
    stopRun();
  }
  prevLoss = curLoss;
}

// ----- Animation loop -----
function tick(ts) {
  if (!running) return;
  if (!lastTick) lastTick = ts;
  if (ts - lastTick >= STEP_INTERVAL_MS) {
    lastTick = ts;
    doStep();
    render();
    if (status === "converged" || status === "diverged") return; // stopRun already called
  }
  rafId = requestAnimationFrame(tick);
}

function startRun() {
  if (status === "converged" || status === "diverged") return;
  running = true;
  status = "running";
  lastTick = 0;
  document.getElementById("run").textContent = "Pause";
  render();
  rafId = requestAnimationFrame(tick);
}

function stopRun() {
  running = false;
  if (rafId) cancelAnimationFrame(rafId);
  rafId = null;
  document.getElementById("run").textContent = "Run";
  if (status === "running") status = "ready";
  render();
}

function reset() {
  stopRun();
  w = parseFloat(startInput.value);
  lr = parseFloat(lrInput.value);
  iter = 0;
  prevLoss = loss(w);
  status = "ready";
  render();
}

// ----- Rendering -----
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGrid();
  drawCurve();
  drawBall();
  updateReadout();
}

function drawGrid() {
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.fillStyle = "#94a3b8";
  ctx.lineWidth = 1;
  ctx.font = "12px ui-monospace, Menlo, monospace";

  // vertical gridlines + w labels
  for (let x = X_LO; x <= X_HI; x += 2) {
    const px = xToPx(x);
    ctx.beginPath();
    ctx.moveTo(px, PAD.t);
    ctx.lineTo(px, canvas.height - PAD.b);
    ctx.stroke();
    ctx.textAlign = "center";
    ctx.fillText(String(x), px, canvas.height - PAD.b + 18);
  }
  // horizontal gridlines + loss labels
  const yStep = niceStep(Y_HI - Y_LO);
  for (let y = Y_LO; y <= Y_HI + 0.001; y += yStep) {
    const py = yToPx(y);
    ctx.beginPath();
    ctx.moveTo(PAD.l, py);
    ctx.lineTo(canvas.width - PAD.r, py);
    ctx.stroke();
    ctx.textAlign = "right";
    ctx.fillText(y.toFixed(0), PAD.l - 8, py + 4);
  }

  // axis titles
  ctx.fillStyle = "#e2e8f0";
  ctx.font = "13px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("weight  w", (PAD.l + canvas.width - PAD.r) / 2, canvas.height - 8);
  ctx.save();
  ctx.translate(16, (PAD.t + canvas.height - PAD.b) / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText("loss  f(w)", 0, 0);
  ctx.restore();

  // mark the true minimum at w = 3
  const pxMin = xToPx(W_MIN);
  ctx.strokeStyle = "rgba(52,211,153,0.5)";
  ctx.setLineDash([5, 5]);
  ctx.beginPath();
  ctx.moveTo(pxMin, PAD.t);
  ctx.lineTo(pxMin, canvas.height - PAD.b);
  ctx.stroke();
  ctx.setLineDash([]);
  ctx.fillStyle = "#34d399";
  ctx.textAlign = "center";
  ctx.fillText("minimum", pxMin, PAD.t + 12);
  ctx.restore();
}

function niceStep(range) {
  const raw = range / 6;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  let step;
  if (norm < 1.5) step = 1;
  else if (norm < 3) step = 2;
  else if (norm < 7) step = 5;
  else step = 10;
  return step * mag;
}

function drawCurve() {
  ctx.save();
  const grad2 = ctx.createLinearGradient(0, PAD.t, 0, canvas.height - PAD.b);
  grad2.addColorStop(0, "#a78bfa");
  grad2.addColorStop(1, "#22d3ee");
  ctx.strokeStyle = grad2;
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  let first = true;
  for (let px = PAD.l; px <= canvas.width - PAD.r; px++) {
    const x = pxToX(px);
    const py = yToPx(loss(x));
    if (first) { ctx.moveTo(px, py); first = false; }
    else ctx.lineTo(px, py);
  }
  ctx.stroke();
  ctx.restore();
}

function drawBall() {
  const bx = xToPx(w);
  const by = yToPx(loss(w));
  const g = grad(w);

  // gradient arrow (points uphill, tangent to the curve direction in w)
  ctx.save();
  const arrowLen = 46;
  const dir = g >= 0 ? 1 : -1; // sign of slope -> uphill direction in w-space
  const ex = bx + dir * arrowLen;
  // approximate the curve's vertical change over the arrow for a tilted arrow
  const dw = dir * (arrowLen / plotW()) * (X_HI - X_LO);
  const ey = yToPx(loss(w + dw));
  ctx.strokeStyle = "#f87171";
  ctx.fillStyle = "#f87171";
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(bx, by);
  ctx.lineTo(ex, ey);
  ctx.stroke();
  // arrowhead
  const ang = Math.atan2(ey - by, ex - bx);
  ctx.beginPath();
  ctx.moveTo(ex, ey);
  ctx.lineTo(ex - 9 * Math.cos(ang - 0.4), ey - 9 * Math.sin(ang - 0.4));
  ctx.lineTo(ex - 9 * Math.cos(ang + 0.4), ey - 9 * Math.sin(ang + 0.4));
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // the ball
  ctx.save();
  const r = 11;
  const glow = ctx.createRadialGradient(bx, by, 2, bx, by, r + 6);
  glow.addColorStop(0, "#ffffff");
  glow.addColorStop(0.4, "#a78bfa");
  glow.addColorStop(1, "rgba(167,139,250,0)");
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(bx, by, r + 6, 0, Math.PI * 2);
  ctx.fill();
  ctx.fillStyle = "#a78bfa";
  ctx.beginPath();
  ctx.arc(bx, by, r, 0, Math.PI * 2);
  ctx.fill();
  ctx.strokeStyle = "#fff";
  ctx.lineWidth = 2;
  ctx.stroke();
  ctx.restore();
}

function updateReadout() {
  elIter.textContent = String(iter);
  elW.textContent = w.toFixed(3);
  elLoss.textContent = isFinite(loss(w)) ? loss(w).toExponential(3).replace("e+", "e") : "∞";
  if (isFinite(loss(w)) && loss(w) < 1e4) elLoss.textContent = loss(w).toFixed(3);
  elGrad.textContent = isFinite(grad(w)) ? grad(w).toFixed(3) : "∞";

  let label = status;
  if (status === "diverged") label = "diverged (LR too big)";
  if (status === "converged") label = "converged ✓";
  elStatus.textContent = label;
  elStatus.className = "v";
  if (status === "diverged") elStatus.classList.add("diverge");
  else if (status === "converged") elStatus.classList.add("converge");
  else if (status === "running") elStatus.classList.add("running");
}

// ----- Controls -----
lrInput.addEventListener("input", () => {
  lr = parseFloat(lrInput.value);
  lrVal.textContent = lr.toFixed(3);
  // changing LR re-arms a stopped run so the learner can retry
  if (status === "diverged" || status === "converged") status = "ready";
  render();
});

startInput.addEventListener("input", () => {
  startVal.textContent = parseFloat(startInput.value).toFixed(2);
  if (!running) reset(); // moving the start slider resets the descent
});

document.getElementById("step").addEventListener("click", () => {
  if (running) stopRun();
  if (status === "diverged" || status === "converged") return;
  doStep();
  render();
});

document.getElementById("run").addEventListener("click", () => {
  if (running) stopRun();
  else startRun();
});

document.getElementById("reset").addEventListener("click", reset);

// ----- Drag the ball to set the starting w -----
function pointerToW(evt) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;        // CSS pixels -> canvas pixels
  const px = (evt.clientX - rect.left) * scaleX;
  return clamp(pxToX(px), X_LO, X_HI);
}

canvas.addEventListener("pointerdown", (e) => {
  dragging = true;
  canvas.classList.add("dragging");
  stopRun();
  status = "ready";
  iter = 0;
  w = pointerToW(e);
  startInput.value = w.toFixed(2);
  startVal.textContent = w.toFixed(2);
  prevLoss = loss(w);
  render();
  canvas.setPointerCapture(e.pointerId);
});

canvas.addEventListener("pointermove", (e) => {
  if (!dragging) return;
  w = pointerToW(e);
  startInput.value = w.toFixed(2);
  startVal.textContent = w.toFixed(2);
  prevLoss = loss(w);
  render();
});

function endDrag() { dragging = false; canvas.classList.remove("dragging"); }
canvas.addEventListener("pointerup", endDrag);
canvas.addEventListener("pointercancel", endDrag);

// ----- Init -----
lrVal.textContent = lr.toFixed(3);
startVal.textContent = w.toFixed(2);
render();

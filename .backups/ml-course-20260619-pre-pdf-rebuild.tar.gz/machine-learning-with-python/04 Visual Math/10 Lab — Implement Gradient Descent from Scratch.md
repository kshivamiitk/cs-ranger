# Lab — Implement Gradient Descent from Scratch

## Objective
You will hand-code gradient descent in pure NumPy to fit a straight line `y = w·x + b` to noisy data — computing the mean-squared-error (MSE) gradient yourself, updating the weights in a loop, and plotting the loss falling over iterations. Then you'll fit the *same* data with scikit-learn's `LinearRegression` and confirm your from-scratch model lands on essentially the same line. After this lab you'll truly understand what `.fit()` is doing under the hood — a great thing to be able to explain in an interview.

## Dataset
Synthetic so it runs offline and you know the "true" answer to check against. We generate points around the line `y = 2.5·x + 1.0` plus random noise.

| column | meaning            | shape  |
|--------|--------------------|--------|
| `x`    | single feature     | (200,) |
| `y`    | target value       | (200,) |

True parameters we're trying to recover: **w ≈ 2.5**, **b ≈ 1.0**.

## Steps

**1. Make the data.** Reproducible random points scattered around a known line.

```python
import numpy as np
import matplotlib.pyplot as plt

rng = np.random.default_rng(42)         # fixed seed -> same data every run
N = 200
x = rng.uniform(-3, 3, size=N)
true_w, true_b = 2.5, 1.0
y = true_w * x + true_b + rng.normal(0, 1.5, size=N)   # line + Gaussian noise
print(x.shape, y.shape)                 # (200,) (200,)
```

**2. Define the loss and its gradient.** For `pred = w*x + b`, MSE is `mean((pred - y)^2)`. Its partial derivatives (this is the only calculus, given to you) are below.

```python
def mse(w, b):
    pred = w * x + b
    return np.mean((pred - y) ** 2)

def gradients(w, b):
    pred = w * x + b
    err = pred - y                      # how wrong each point is (signed)
    dw = 2.0 * np.mean(err * x)         # d(MSE)/dw
    db = 2.0 * np.mean(err)             # d(MSE)/db
    return dw, db
```

**3. Run the descent loop.** Start at zero, step against the gradient, record the loss each iteration.

```python
w, b = 0.0, 0.0          # start with a flat, wrong line
lr = 0.05                # learning rate (try changing this later)
iters = 400
loss_history = []

for i in range(iters):
    dw, db = gradients(w, b)
    w -= lr * dw         # the update rule, one weight...
    b -= lr * db         # ...and the bias
    loss_history.append(mse(w, b))

print(f"learned  w={w:.3f}  b={b:.3f}   (true w={true_w}, b={true_b})")
print(f"final MSE = {loss_history[-1]:.3f}")
# learned  w≈2.49  b≈1.0x   final MSE ≈ 2.2 (the noise variance floor)
```

**4. Plot loss over iterations.** A healthy curve drops fast then flattens — the visual signature of convergence.

```python
plt.figure()
plt.plot(loss_history)
plt.xlabel("iteration"); plt.ylabel("MSE loss")
plt.title("Loss falling as gradient descent learns the line")
plt.grid(alpha=0.3)
plt.show()
```

**5. Plot the fitted line over the data.** Sanity-check that the line actually passes through the cloud of points.

```python
plt.figure()
plt.scatter(x, y, s=12, alpha=0.5, label="data")
xs = np.linspace(-3, 3, 50)
plt.plot(xs, w * xs + b, color="violet", linewidth=2, label="our GD fit")
plt.xlabel("x"); plt.ylabel("y"); plt.legend(); plt.title("From-scratch fit")
plt.show()
```

**6. Compare with scikit-learn.** `LinearRegression` solves this with linear algebra (no loop). The numbers should match yours closely.

```python
from sklearn.linear_model import LinearRegression

model = LinearRegression()
model.fit(x.reshape(-1, 1), y)          # sklearn wants X as 2-D: (N, 1)
print(f"sklearn  w={model.coef_[0]:.3f}  b={model.intercept_:.3f}")
print(f"ours     w={w:.3f}  b={b:.3f}")
# sklearn w≈2.49  b≈1.0x  -- within a hair of our hand-coded result
```

## Expected output
- **Recovered parameters** close to the truth: `w ≈ 2.5`, `b ≈ 1.0`. They won't be exact because the data has noise — that's correct, not a bug.
- **Loss curve** that drops steeply for the first ~50 iterations then flattens near a floor around the noise variance (~2.25 here). It should never *rise*; if it does, your learning rate is too high.
- **Your `w`/`b` and sklearn's `w`/`b` agree** to about two decimals. Matching a battle-tested library is your proof the hand-coded gradient is right.

## Extension challenge
1. **Learning-rate sweep.** Loop over `lr in [0.001, 0.01, 0.05, 0.2, 0.5]`, plot each loss curve on one chart, and label which crawls, which converges cleanly, and which oscillates or diverges.
2. **Standardize the feature.** Replace `x` with `(x - x.mean()) / x.std()` before training. Notice you can now use a larger learning rate safely — explain in a comment why scaling helps.
3. **Vectorize for many features.** Generalize to `X` of shape `(N, d)` and a weight *vector* `w`: prediction becomes `X @ w + b`, and the weight gradient becomes `2/N * X.T @ (pred - y)`. Fit it on `sklearn.datasets.make_regression(n_features=3)` and compare to `LinearRegression` again.

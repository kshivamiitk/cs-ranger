# Gradient Descent — The Learning Engine

> Almost every model you'll ever train "learns" the same way: it stands on the loss surface, feels which way is downhill, and takes a small step — over and over until it stops improving.

## What you'll learn
- Picture the **loss surface** as a landscape the model is trying to descend.
- Read and apply the one update rule that powers training: `w ← w − learning_rate × gradient`.
- Predict what happens when the **learning rate** is too big (diverge/oscillate) or too small (crawl).
- Recognize **convergence** and decide when to stop.
- Implement gradient descent on a quadratic in NumPy and watch the loss fall.

## Intuition
Take last lesson's foggy hill. The **loss surface** is that landscape: every position is a setting of the weights, and the height is how wrong the model is there. Training means walking downhill to the lowest point you can reach.

You can't see the whole valley, but at your feet you can feel the slope — the **gradient**. So you take a step *against* the gradient (downhill), then re-measure the slope at the new spot and step again. Repeat. Each loop lowers the loss a little. That's **gradient descent**, and the entire update is:

`new_w = old_w − learning_rate × gradient`

The **learning rate** is your step size:
- **Too large:** you leap clear over the valley and land higher on the far slope, then overshoot back — the loss bounces around or even *grows*. This is divergence/oscillation.
- **Too small:** every step is a baby step. You head the right way but it takes forever — the loss creeps down so slowly you run out of patience.
- **Just right:** steady, fast descent that flattens out near the bottom.

You're **converged** when steps stop helping — the gradient is tiny and the loss barely changes between iterations. In practice you stop after a fixed number of iterations, or when the improvement drops below a small threshold.

## Pseudocode

```
choose a starting weight w
choose a learning rate lr (the step size)
repeat for many iterations:
    g = gradient of loss at w        # which way is uphill, and how steep
    w = w - lr * g                   # step downhill
    if loss barely changed: stop     # converged
```

## Python in practice

```python
import numpy as np

# Loss surface: a convex bowl with its minimum at w = 3.
def loss(w):       return (w - 3.0) ** 2
def gradient(w):   return 2.0 * (w - 3.0)   # exact slope of the bowl

def gradient_descent(start_w, lr, iters=20):
    w = float(start_w)
    history = [(0, w, loss(w))]
    for i in range(1, iters + 1):
        g = gradient(w)
        w = w - lr * g            # THE update rule
        history.append((i, w, loss(w)))
    return w, history

w_final, hist = gradient_descent(start_w=-2.0, lr=0.1, iters=12)
for i, w, L in hist[:6]:
    print(f"iter {i:>2}  w={w:>7.3f}  loss={L:>8.4f}")
print("...")
print(f"final  w={w_final:.4f}  (true minimum is 3)")
# iter  0  w= -2.000  loss= 25.0000
# iter  1  w= -1.000  loss= 16.0000   each step moves w toward 3, loss falls
# iter  2  w= -0.200  loss= 10.2400
# ...
# final  w=2.9... -> closing in on the minimum
```

Now watch the **learning rate** change everything on the *same* bowl:

```python
for lr in [0.01, 0.1, 0.9, 1.05]:
    w, hist = gradient_descent(start_w=-2.0, lr=lr, iters=12)
    losses = [L for _, _, L in hist]
    print(f"lr={lr:<5} start_loss={losses[0]:7.2f}  end_loss={losses[-1]:10.2f}")
# lr=0.01  start_loss=  25.00  end_loss=     14.66   too small: still far from bottom
# lr=0.1   start_loss=  25.00  end_loss=      1.50   healthy descent
# lr=0.9   start_loss=  25.00  end_loss=      0.00*  big but stable here, jumps around then lands
# lr=1.05  start_loss=  25.00  end_loss=  >25 (grows) too big: DIVERGES, loss explodes
```

The key takeaway: with `lr=1.05`, each step *overshoots* the minimum and lands farther out than it started, so the loss grows every iteration — the classic sign of a learning rate that's too high. With `lr=0.01`, every step is correct in direction but tiny, so after 12 iterations you've barely moved.

```python
# A simple convergence check: stop early when improvement is negligible.
def gd_with_stop(start_w, lr, tol=1e-8, max_iters=10_000):
    w = float(start_w)
    prev = loss(w)
    for i in range(1, max_iters + 1):
        w = w - lr * gradient(w)
        cur = loss(w)
        if abs(prev - cur) < tol:        # loss stopped changing -> converged
            return w, i
        prev = cur
    return w, max_iters

w, steps = gd_with_stop(start_w=-2.0, lr=0.1)
print(f"converged to w={w:.5f} in {steps} steps")   # ~converged to w=3.00000 in ~90 steps
```

```python
# Optional: plot the descent path on the loss curve.
import matplotlib.pyplot as plt

_, hist = gradient_descent(start_w=-2.0, lr=0.1, iters=12)
ws = np.linspace(-3, 9, 200)
plt.plot(ws, loss(ws), label="loss surface")
path_w = [w for _, w, _ in hist]
plt.plot(path_w, [loss(w) for w in path_w], "o-", color="violet", label="descent path")
plt.xlabel("w"); plt.ylabel("loss"); plt.legend(); plt.title("Gradient descent rolling into the bowl")
plt.show()
```

## Common mistakes
- **Stepping with the gradient instead of against it.** The update is `w - lr*g`, *minus*. Use `+` by accident and the loss climbs every step — you're doing gradient *ascent*.
- **Blaming the model when the learning rate is wrong.** A diverging loss almost always means the learning rate is too high, not that the math is broken. Cut the learning rate by 10× and try again.
- **Setting the learning rate microscopically "to be safe."** Too-small rates don't fail loudly; they just waste thousands of iterations. Start around `0.1`, then adjust.
- **Stopping by iteration count alone on hard problems.** A fixed loop is fine for these toy bowls, but real training also watches whether the loss has plateaued.
- **Forgetting to scale features (later).** On real data, wildly different feature scales make a single learning rate behave great for one weight and terribly for another. You'll fix this with standardization in a later module.

## Small exercise
1. Run `gradient_descent(start_w=10.0, lr=0.3, iters=8)` and print the loss each step. Does it still find `w = 3`?
2. Find — by trial — the *largest* learning rate that still converges for this `(w-3)^2` bowl. (For this exact loss, descent diverges once `lr ≥ 1`. See if your experiments agree.)
3. Change the loss to `(w-3)**2 + 5` and confirm gradient descent still lands at `w = 3`. Why doesn't the `+5` move the minimum's *location*?

## Before you continue
- [ ] I can recite and explain the update rule `w ← w − learning_rate × gradient`.
- [ ] I can predict the qualitative behavior for a too-large vs too-small learning rate.
- [ ] I can implement gradient descent on a quadratic in NumPy and watch the loss decrease.
- [ ] I can describe one reasonable way to decide the loop has converged.

# Loss Functions

> A loss function is the single number that says "how wrong is the model right now?" — and training is nothing more than pushing that number down.

## What is this?

A **loss function** turns your model's mistakes into one number. You feed it the model's predictions and the true answers, and it returns a score where **lower is better** and a perfect model scores 0.

That number is the target gradient descent chases. The model has no opinions about "good" or "bad" — it only knows the loss, and it adjusts its weights to make the loss smaller. Choose a different loss and you literally change what "good" means to the model.

A few you'll meet constantly:

- **MSE (Mean Squared Error)** — for regression. Average of the *squared* errors. Squaring punishes big misses hard.
- **MAE (Mean Absolute Error)** — for regression. Average of the *absolute* errors. Treats a miss of 10 as exactly twice as bad as a miss of 5.
- **Cross-entropy / log-loss** — for classification. Scores how confident *and* correct your predicted probabilities are; punishes confident wrong answers brutally.

## Why do we need it?

Without a loss function, "make the model better" is a vibe, not a computation. The loss makes improvement **measurable and directional**: a smaller number is unambiguously better, and you can compute its gradient to know which way to nudge each weight.

That last part is why losses must be **differentiable** (smooth). Gradient descent needs a slope to follow. MSE, MAE, and cross-entropy all have well-defined gradients, so the model can roll downhill on them. A loss with no usable slope — like "count of wrong answers" — gives the optimizer nothing to push against.

Crucially, **loss is not the same as your evaluation metric.** The loss is what the model *trains on* (must be differentiable, optimizer-friendly). The metric is what *you* report to humans (accuracy, RMSE in dollars, F1). A classifier trains on log-loss but you brag about accuracy. They point the same direction but serve different audiences.

## Where it's used in real ML

- **Regression** (house prices, demand forecasting) — MSE by default; MAE or Huber loss when outliers would otherwise dominate.
- **Classification** (spam, churn, disease) — cross-entropy / log-loss is the standard, used by logistic regression and virtually every neural-network classifier.
- **Deep learning** — the loss is the very thing backpropagation differentiates; the whole network exists to minimize it.
- **scikit-learn** — `mean_squared_error`, `mean_absolute_error`, and `log_loss` live in `sklearn.metrics`, and `LogisticRegression` minimizes log-loss internally.

## What breaks if you ignore it

- **Wrong loss for the task** → using MSE to train a classifier, or accuracy (non-differentiable) as a training loss, simply won't optimize well or at all.
- **Ignoring outliers** → MSE squares errors, so one wild data point can hijack training, dragging the model toward the outlier and away from the bulk of the data.
- **Confusing loss with metric** → you tune for the wrong thing, e.g. optimizing log-loss while your business actually cares about precision on the positive class.
- **Misreading scale** → MSE is in *squared* units (squared dollars?), which is meaningless to humans; report RMSE or MAE instead so stakeholders can interpret it.

## Mental model

A loss function is the **score in a game of darts where the bullseye is the truth and lower is better:**

```
        prediction
            o
            |   <- error = distance from the truth
            |
   ---------X----------  (truth / bullseye)

  MAE: penalty = the distance itself        (10 away  -> 10)
  MSE: penalty = distance squared           (10 away  -> 100, brutal on big misses)
```

MAE charges you the plain distance from the bullseye. MSE charges you the distance *squared*, so being far off is disproportionately painful. That's the whole personality difference: MSE obsesses over big misses (and thus over outliers); MAE stays calm and treats all misses proportionally.

## Example 1 — Tiny toy example

Three predictions vs three true values:

| true `y` | predicted `ŷ` | error (`ŷ − y`) | absolute | squared |
|----------|---------------|------------------|----------|---------|
| 10       | 12            | +2               | 2        | 4       |
| 20       | 18            | −2               | 2        | 4       |
| 30       | 33            | +3               | 3        | 9       |

**MAE** = average of absolute errors = `(2 + 2 + 3) / 3 = 7 / 3 ≈ 2.333`.

**MSE** = average of squared errors = `(4 + 4 + 9) / 3 = 17 / 3 ≈ 5.667`.

Now make the last miss an outlier: change `ŷ` for the third point to `40` (error `+10`).

- MAE = `(2 + 2 + 10) / 3 = 14 / 3 ≈ 4.667` — went up, but proportionally.
- MSE = `(4 + 4 + 100) / 3 = 108 / 3 = 36.0` — *exploded*, because 10 squared is 100.

That single outlier barely moved MAE but blew up MSE. That's the trade-off in one example.

## Example 2 — Practical ML example

Imagine predicting house prices. Most homes are in the 200k–500k range, but your dataset has one mislabeled mansion listed at 50 million. You fit two models, one minimizing **MSE**, one minimizing **MAE**.

The MSE model, terrified of that giant squared error, tilts its predictions upward to chase the mansion — making it *worse* on the 99% of normal houses. The MAE model shrugs (one big absolute error is just one vote) and keeps fitting the typical homes well. On messy real-world data with outliers, MAE (or Huber, a blend of both) often gives predictions people actually trust.

Now switch to **classification** — predicting whether a loan defaults. Here you'd train on **log-loss**: if the model says "95% safe" and the loan defaults, log-loss punishes that confident mistake heavily, teaching the model to be both correct *and* honestly calibrated about its confidence. You'd still *report* accuracy or AUC to stakeholders — metric versus loss in action.

## Python code example

```python
import numpy as np
from sklearn.metrics import mean_squared_error, mean_absolute_error, log_loss

# --- Regression: same 3 points as the toy example, plus an outlier version ---
y_true = np.array([10.0, 20.0, 30.0])
y_pred = np.array([12.0, 18.0, 33.0])

print("No outlier:")
print(f"  MAE = {mean_absolute_error(y_true, y_pred):.3f}")   # ~2.333
print(f"  MSE = {mean_squared_error(y_true, y_pred):.3f}")    # ~5.667

# Make the 3rd prediction a big miss (40 instead of 33 -> error +10)
y_pred_outlier = np.array([12.0, 18.0, 40.0])
print("With one outlier (last prediction off by 10):")
print(f"  MAE = {mean_absolute_error(y_true, y_pred_outlier):.3f}")  # ~4.667 (mild rise)
print(f"  MSE = {mean_squared_error(y_true, y_pred_outlier):.3f}")   # 36.000 (explodes!)

# --- Classification: log-loss rewards being correct AND well-calibrated ---
# 4 examples, true labels, and two sets of predicted probabilities for class 1.
labels       = np.array([1,    0,    1,    0])
confident_ok = np.array([0.90, 0.10, 0.80, 0.15])   # confident and mostly right
confident_wrong = np.array([0.90, 0.10, 0.05, 0.15])  # confident but WRONG on example 3

print("Classification log-loss (lower = better):")
print(f"  confident & correct : {log_loss(labels, confident_ok):.3f}")
print(f"  confident & wrong   : {log_loss(labels, confident_wrong):.3f}")  # much higher

# Expected output (approximate):
# No outlier:
#   MAE = 2.333
#   MSE = 5.667
# With one outlier (last prediction off by 10):
#   MAE = 4.667
#   MSE = 36.000
# Classification log-loss (lower = better):
#   confident & correct : 0.164
#   confident & wrong   : 0.879
```

The outlier barely nudges MAE but quadruples-plus MSE; and confidently calling a default "5% safe" sends log-loss soaring. The loss you pick decides which mistakes the model fears most.

## Common mistakes

- **Using a classification loss for regression or vice versa.** Log-loss expects probabilities; MSE expects numbers. Match the loss to the task.
- **Reaching for MSE on outlier-heavy data.** Squaring lets one freak value dominate training. Consider MAE or Huber loss instead.
- **Confusing loss with metric.** Training on log-loss is fine even if you report accuracy — they're different jobs, not rivals.
- **Reporting MSE to humans.** It's in squared units. Report RMSE (its square root) or MAE so the number means something.
- **Picking a non-differentiable training loss.** "Number of wrong answers" has no usable gradient, so gradient descent can't optimize it. Use a smooth surrogate like log-loss.

## Before you continue
- [ ] I can define a loss function in one sentence and say which direction is "better."
- [ ] I can compute MSE and MAE for a few predictions by hand.
- [ ] I can explain why MSE reacts to outliers more than MAE does.
- [ ] I can explain the difference between a loss (what the model trains on) and a metric (what I report).
- [ ] I know that classification uses cross-entropy / log-loss and why confident wrong answers are punished.

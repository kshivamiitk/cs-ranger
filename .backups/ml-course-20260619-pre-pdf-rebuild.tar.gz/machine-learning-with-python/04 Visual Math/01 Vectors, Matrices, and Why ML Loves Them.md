# Vectors, Matrices, and Why ML Loves Them

> Every machine-learning model is really just a giant pile of numbers multiplied and added together — and vectors and matrices are how we keep those numbers organized.

## What you'll learn
- Read a single data example as a **vector** (a row of feature numbers).
- Read a whole dataset as a **matrix** (rows = examples, columns = features).
- See why the **dot product** is literally a weighted sum — and how that single operation *is* a prediction.
- Talk about **shapes** like `(150, 4)` confidently and predict whether two arrays can multiply.
- Do all of this in NumPy without any math notation.

## Intuition
Imagine a spreadsheet of houses. Each **row** is one house. Each **column** is one measurement: square footage, number of bedrooms, age. One house is a list of numbers — that list is a **vector**. The whole spreadsheet — many houses stacked on top of each other — is a **matrix**.

Now suppose you want to guess a house's price. You decide each feature is worth something: maybe every square foot adds \$200, every bedroom adds \$10,000, and every year of age *subtracts* \$1,000. Those three numbers are your **weights** — another vector.

To make a prediction you walk down the house's features and the weights together, multiply each pair, and add it all up:

`price ≈ 200 × sqft + 10000 × bedrooms + (−1000) × age`

That "multiply matching numbers and sum them" move is the **dot product**. It is the single most common operation in all of machine learning. A linear model's prediction is *just* a dot product between a feature vector and a weight vector (plus one extra number, the bias). Stack many houses into a matrix, and one matrix multiply predicts prices for *all* of them at once.

So: **vectors hold one example, matrices hold the dataset, and the dot product turns features + weights into a prediction.** That's the whole reason ML "loves" linear algebra — it lets the computer score thousands of examples in one fast operation.

## Python in practice

```python
import numpy as np

# One house as a feature vector: [square_feet, bedrooms, age_years]
house = np.array([1500, 3, 10])
print(house.shape)   # (3,) -> a 1-D vector with 3 features

# A small dataset (matrix): 4 houses, 3 features each
X = np.array([
    [1500, 3, 10],
    [2100, 4,  5],
    [ 800, 1, 40],
    [3000, 5,  2],
])
print(X.shape)       # (4, 3) -> 4 rows (houses), 3 columns (features)

# Weights: how much one unit of each feature contributes to price
w = np.array([200, 10000, -1000])   # $/sqft, $/bedroom, $/year-of-age
bias = 50000                         # base price common to every house

# A dot product = weighted sum = one prediction for the first house
pred_one = house @ w + bias
print(pred_one)      # 200*1500 + 10000*3 + (-1000)*10 + 50000 = 370000

# Matrix @ vector predicts ALL houses at once -> shape (4,)
preds = X @ w + bias
print(preds)         # [370000 530000 170000 698000]
```

A few things to notice in the output above:
- `house @ w` collapses 3 numbers into **one** number — that single number is the prediction's core.
- `X @ w` turns a `(4, 3)` matrix into a `(4,)` vector: one prediction per row. The "3" disappears because it matched the length of `w`.

```python
# Shape rule of thumb: (a, b) @ (b,) -> (a,)
# The inner dimensions (the b's) must match, or NumPy raises an error.

good = np.ones((4, 3)) @ np.ones(3)     # (4,3) @ (3,) -> (4,)  OK
print(good.shape)                        # (4,)

try:
    bad = np.ones((4, 3)) @ np.ones(2)  # 3 != 2 -> error
except ValueError as e:
    print("Shape mismatch:", e)          # NumPy tells you the dims don't line up
```

```python
# Other operations you'll use constantly:
a = np.array([1.0, 2.0, 3.0])
b = np.array([4.0, 5.0, 6.0])

print(a + b)          # [5. 7. 9.]   elementwise add
print(a * b)          # [4. 10. 18.] elementwise multiply (NOT a dot product)
print(np.dot(a, b))   # 32.0         dot product = 1*4 + 2*5 + 3*6
print(a @ b)          # 32.0         '@' is the same as np.dot for vectors
print(np.linalg.norm(a))  # 3.7416...  the vector's length (used for distances)
```

## Common mistakes
- **Confusing `*` with `@`.** `a * b` multiplies element by element and keeps the same shape; `a @ b` (or `np.dot`) multiplies *and sums* into a smaller result. A dot product uses `@`.
- **Mismatched shapes.** `(4, 3) @ (4,)` fails — the *inner* numbers (3 and 4) must match, not the outer ones. When in doubt, print `.shape` of both operands.
- **Forgetting features and weights must line up in the same order.** If column 0 is square footage, then weight 0 must be the price-per-square-foot. Shuffle one without the other and the prediction is garbage.
- **Treating a `(3,)` vector like a `(1, 3)` or `(3, 1)` matrix.** They behave differently in matrix multiply. Use `arr.reshape(1, -1)` or `arr[None, :]` only when you deliberately want a row matrix.
- **Assuming bigger numbers = more important features.** A weight of 200 vs 10000 doesn't mean bedrooms matter 50× more — it depends on each feature's *scale*. (You'll fix this later with feature scaling.)

## Small exercise
1. Create a feature vector for a 2,400 sq ft, 4-bedroom, 8-year-old house.
2. Using the same `w` and `bias` from the example, compute its predicted price with a single dot product.
3. Change the bedroom weight from `10000` to `25000` and recompute. By how much did the prediction jump, and why exactly that amount? (Hint: it's the bedroom count times the change in weight.)

## Before you continue
- [ ] I can explain, in one sentence, why a dot product is the same thing as a weighted sum.
- [ ] Given two NumPy shapes, I can say whether `A @ B` will work.
- [ ] I can build a feature matrix `X` and a weight vector `w` and predict every row at once with `X @ w`.

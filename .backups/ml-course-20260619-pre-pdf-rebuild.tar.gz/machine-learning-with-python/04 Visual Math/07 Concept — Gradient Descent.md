# Gradient Descent

> Gradient descent is the simple "roll downhill until you stop dropping" trick that almost every model uses to learn — it just keeps nudging its numbers in the direction that lowers the error.

## What is this?

Gradient descent is an **iterative recipe for finding the settings (weights) that make a model least wrong.**

Picture the model's error as a hill. Wherever you're standing, the **gradient** tells you the slope under your feet — which way is uphill and how steep it is. Gradient descent does the obvious thing: it steps in the *opposite* direction (downhill), then re-checks the slope and steps again. Each loop lowers the error a little. You repeat until the slope flattens out and steps stop helping.

The whole thing is one update rule, applied over and over:

```
new_weight = old_weight − learning_rate × gradient
```

- The **gradient** is the slope of the error with respect to a weight (from the derivatives lesson).
- The **learning rate** is your step size — how far you move each iteration.
- One pass of this rule is a **step**; doing it until the error stops dropping is **convergence**.

That's it. No magic — gradient descent is "feel the slope, take a step downhill, repeat."

## Why do we need it?

For a straight line you *could* solve for the best weights with a formula. But most models — logistic regression, neural networks, gradient-boosted trees — have thousands or millions of weights and no neat closed-form answer. There's no algebra that hands you the solution.

What you *can* always compute is: "if I nudge this weight up a tiny bit, does the error go up or down?" That's the gradient. Gradient descent turns that one local question into a general-purpose learning engine: you never need to know where the bottom is, only which way is downhill from where you stand. Follow downhill long enough and you arrive.

This is why gradient descent is the single most important optimization idea in machine learning. "Training a model" almost always means "running gradient descent (or a cousin of it) on a loss function."

## Where it's used in real ML

- **Neural networks / deep learning** — every image classifier, chatbot, and recommendation model is trained by gradient descent (via backpropagation, which is just gradient descent applied through many layers).
- **Logistic regression and linear models** — scikit-learn's `SGDClassifier` and `SGDRegressor` use *stochastic* gradient descent (one mini-batch at a time) to scale to huge datasets.
- **Gradient boosting** (XGBoost, LightGBM) — adds trees one at a time, each fitting the gradient of the loss left over by the previous trees.
- **Variants you'll hear about** — *SGD*, *momentum*, and *Adam* are all gradient descent with smarter step sizes. Same downhill idea, fancier footwork.

## What breaks if you ignore it

- **Learning rate too big** → the model overshoots the valley, lands higher on the far side, overshoots back, and the loss *grows* instead of shrinking. This "diverging loss" (often `NaN`) is the #1 training failure.
- **Learning rate too small** → it heads the right way but in baby steps; you burn thousands of iterations and the model looks "stuck" when it's just crawling.
- **Stopping too early** → halt before convergence and you ship an under-trained model that's needlessly inaccurate.
- **Unscaled features** → with features on wildly different ranges (covered in the Feature Engineering module), one learning rate is too big for one weight and too small for another, so descent zig-zags painfully. Scaling fixes this.

## Mental model

Think of a hiker dropped into a foggy valley who wants to reach the lowest point but can only see the ground at their feet:

```
   error
     |\                              /
     | \      "feel the slope"      /
     |  \         |                /
     |   \        v               /
     |    \    o--.              /
     |     \      `--.          /
     |      \         `--o     /     each o = one step downhill
     |       \            `--./
     |        `----o----o----'   <- bottom: slope flat, steps stop helping
     +-----------------------------------> weight
```

The hiker feels the slope (gradient), takes a step downhill sized by the learning rate, re-checks, and repeats. Big steps risk leaping over the valley; tiny steps are safe but slow. When the ground goes flat, they've converged.

## Example 1 — Tiny toy example

Let's minimize `f(w) = (w − 3)²` by hand. Its slope is `f'(w) = 2 × (w − 3)`. The minimum is obviously at `w = 3`; let's confirm gradient descent walks there. Start at `w = 0` with **learning rate = 0.1**.

Update rule each step: `w ← w − 0.1 × 2 × (w − 3)`.

- **Step 1:** gradient `= 2 × (0 − 3) = −6`. New `w = 0 − 0.1 × (−6) = 0.6`. Error `= (0.6 − 3)² = 5.76`.
- **Step 2:** gradient `= 2 × (0.6 − 3) = −4.8`. New `w = 0.6 − 0.1 × (−4.8) = 1.08`. Error `= (1.08 − 3)² = 3.6864`.
- **Step 3:** gradient `= 2 × (1.08 − 3) = −3.84`. New `w = 1.08 − 0.1 × (−3.84) = 1.464`. Error `= (1.464 − 3)² ≈ 2.3593`.

```
step   w       error
  0   0.000   9.0000
  1   0.600   5.7600
  2   1.080   3.6864
  3   1.464   2.3593
```

Notice `w` climbs steadily toward 3 and the error keeps shrinking. The negative gradient means "go right," so each step nudges `w` up. Keep going and it settles at `w = 3`, error `0`.

## Example 2 — Practical ML example

Now the realistic version: fitting a **linear model** `y ≈ w·x + b` to data with gradient descent, instead of a formula.

Say we have hours studied vs exam score for a handful of students. We start with random `w` and `b`, compute the mean-squared error, and ask the gradient: "to lower this error, should `w` and `b` go up or down, and by how much?" We nudge both, then repeat for a few **epochs** (full passes over the data).

What you'd see printed each epoch is the loss dropping — say `412 → 188 → 96 → 54 → ...` — as `w` and `b` slide toward the values that draw the best-fit line. After enough epochs the loss flattens (convergence) and the learned `w`, `b` match what the textbook formula would give. Same answer, but this approach also works when there's no formula — which is the whole point.

## Python code example

```python
import numpy as np

# --- Inline toy dataset: hours studied (x) vs exam score (y) ---
x = np.array([1.0, 2.0, 3.0, 4.0, 5.0])      # hours studied
y = np.array([52.0, 58.0, 65.0, 73.0, 78.0])  # exam score

# Model: y_pred = w * x + b. We'll learn w and b by gradient descent.
w, b = 0.0, 0.0          # start with a flat line at zero
lr = 0.01                # learning rate (step size)
n = len(x)

print("epoch |    w   |    b   |   MSE loss")
print("-" * 40)
for epoch in range(1, 401):
    y_pred = w * x + b                 # current predictions
    error = y_pred - y                 # how far off, per point

    # Gradients of mean-squared error w.r.t. w and b (the slope of the loss):
    grad_w = (2.0 / n) * np.sum(error * x)
    grad_b = (2.0 / n) * np.sum(error)

    # THE update rule: step each weight downhill.
    w = w - lr * grad_w
    b = b - lr * grad_b

    if epoch in (1, 10, 50, 100, 400):
        loss = np.mean(error ** 2)     # mean-squared error
        print(f"{epoch:5d} | {w:6.3f} | {b:6.3f} | {loss:10.3f}")

print("-" * 40)
print(f"Learned line: score = {w:.2f} * hours + {b:.2f}")
print(f"Predicted score for 6 hours: {w * 6 + b:.1f}")

# Expected output (numbers approximate):
# epoch |    w   |    b   |   MSE loss
# ----------------------------------------
#     1 |  0.069 |  0.019 |   4308.600
#    10 |  0.643 |  0.180 |    ... (loss falling fast)
#    50 |  ...   |  ...   |    ... (still dropping)
#   100 |  ...   |  ...   |    ... (nearly flat -> converging)
#   400 |  6.55  | 45.9   |       6.8  (loss small, line fits well)
# ----------------------------------------
# Learned line: score ~= 6.55 * hours + 45.9
# Predicted score for 6 hours: ~85
```

The loss falls every batch of epochs and then flattens — that flattening is convergence. We never solved an equation; we just rolled downhill.

## Common mistakes

- **Adding the gradient instead of subtracting it.** The rule is `w − lr × g` (downhill). Use `+` and you do gradient *ascent* — the loss climbs every step.
- **Picking a wild learning rate.** Too big and the loss diverges (often to `NaN`); too small and it crawls. If the loss explodes, cut the learning rate by 10× before suspecting anything else.
- **Reading a diverging loss as "the model can't learn this."** Nine times out of ten it's just the learning rate, not the data or the math.
- **Forgetting to scale features.** Different feature ranges make one learning rate wrong for every weight at once, so descent zig-zags. Standardize first.
- **Judging convergence by one lucky step.** A single small change can be noise; watch the loss flatten over several iterations before declaring victory.

## Before you continue
- [ ] I can state the update rule `new_weight = old_weight − learning_rate × gradient` and explain each piece.
- [ ] I can walk three steps of gradient descent on `f(w) = (w − 3)²` by hand.
- [ ] I can predict what a too-large vs too-small learning rate does to the loss.
- [ ] I can explain why we need gradient descent at all when a formula exists for lines.
- [ ] I recognize a diverging loss as a learning-rate problem, not a broken model.

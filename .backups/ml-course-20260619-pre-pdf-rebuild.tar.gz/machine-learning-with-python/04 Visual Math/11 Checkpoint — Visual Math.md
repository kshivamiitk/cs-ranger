# Checkpoint — Visual Math

## What you should now be able to do
- Represent one data example as a vector and a dataset as a matrix, and predict with a dot product (`X @ w + b`).
- Reason about array shapes and predict when a matrix multiply will work or fail.
- Explain a derivative as a slope/sensitivity and a gradient as "one slope per weight, pointing uphill."
- Estimate a derivative numerically with a central difference — no calculus rules required.
- Apply the gradient-descent update rule `w ← w − learning_rate × gradient` and predict the effect of the learning rate.
- Hand-code gradient descent in NumPy to fit a model and recognize convergence from a loss curve.

## Review questions
1. A dataset has shape `(150, 4)`. In plain words, what are the 150 and the 4? Write a weight vector shape that would let you predict all 150 rows at once, and the shape of the result.
2. Why is a single linear-model prediction "the same thing" as a dot product? Give the one-line formula in words.
3. What is the difference between `a * b` and `a @ b` for two equal-length 1-D NumPy arrays?
4. The derivative of a loss at the current weight is `+8`. Should you increase or decrease the weight to reduce the loss, and why?
5. What does a gradient of `[-6, 4]` tell you about a two-weight model, and what direction would gradient descent actually step?
6. Write out the gradient-descent update rule and explain what each term controls.
7. You run training and the loss grows larger every iteration. What's the single most likely cause, and what's the fix?
8. You run training and after 1000 iterations the loss has barely moved from its start. What's the likely cause and the fix?
9. How can you tell from a loss-over-iterations plot that the model has (roughly) converged?
10. In the lab, your from-scratch `w` and sklearn's `coef_` matched to two decimals but neither exactly equalled the true `2.5`. Why is that the *correct* outcome rather than a bug?

## Answers
<details>
<summary>Show answers</summary>

1. **150 = number of examples (rows); 4 = number of features (columns).** A weight vector of shape `(4,)` works: `(150, 4) @ (4,)` → result shape `(150,)`, one prediction per example.
2. A linear prediction is **weight 0 × feature 0 + weight 1 × feature 1 + … + bias** — multiply matching pairs and sum them, which is exactly the dot product of the feature vector and weight vector (plus the bias).
3. `a * b` multiplies **elementwise**, returning an array of the same shape. `a @ b` (dot product) multiplies elementwise **and then sums**, returning a single number.
4. **Decrease the weight.** A positive derivative means increasing the weight raises the loss, so you step the opposite way (downhill).
5. The loss is currently steeper along weight 0, and the gradient points **uphill**: weight 0's slope is negative (loss falls if you increase it) while weight 1's is positive. Gradient descent steps in `−gradient` = `[6, −4]`: increase weight 0, decrease weight 1.
6. `w ← w − learning_rate × gradient`. The **gradient** sets the direction (uphill, so we subtract it) and relative magnitude; the **learning rate** scales how big each step is.
7. **Learning rate too high** → the step overshoots the minimum and lands farther out, so the loss diverges. Fix: reduce the learning rate (e.g. by 10×).
8. **Learning rate too low** → steps are tiny, so progress is glacial. Fix: increase the learning rate, and/or standardize the features so a larger rate is safe.
9. The curve drops quickly and then **flattens to a near-constant floor**; successive iterations barely change the loss, and the gradient is near zero.
10. The data has **random noise**, so the true line can't be recovered exactly from a finite sample. Both methods find the best fit *to this noisy sample*, which sits very close to — but not exactly on — the underlying `2.5`. Matching each other confirms the math is right.

</details>

## Hands-on tasks
1. **Shape drills.** Without running code, predict the result shape (or "error") for: `(32, 5) @ (5,)`, `(5,) @ (5,)`, `(32, 5) @ (32,)`, `(5, 3) @ (3, 2)`. Then verify each with `np.ones(...)` in NumPy.
2. **Numeric gradient check.** For `f(w) = w**3 - 4*w`, write a central-difference derivative and confirm it matches the calculus answer `3*w**2 - 4` at `w = 2` (expect ≈ 8).
3. **Tune a descent.** Take the `(w-3)**2` bowl from the lessons. Find, by experiment, a learning rate that converges in the fewest iterations to within `1e-4` of the minimum. Report the rate and the iteration count.
4. **Reopen the Playground.** In the Gradient Descent Playground static lesson, set the learning rate to 1.0 and step several times. Describe in one sentence what the ball does and why the loss behaves that way.

## You're ready for the next module when…
- [ ] I can state the gradient-descent update rule from memory and explain every term.
- [ ] I can predict array shapes for matrix multiplies and fix mismatches.
- [ ] I implemented gradient descent from scratch and matched scikit-learn on the same data.
- [ ] I can diagnose a diverging vs crawling loss curve and name the fix for each.

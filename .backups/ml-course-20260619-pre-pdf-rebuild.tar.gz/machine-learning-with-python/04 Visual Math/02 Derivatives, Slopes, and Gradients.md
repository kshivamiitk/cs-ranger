# Derivatives, Slopes, and Gradients

> A derivative is just the answer to one practical question every learning model keeps asking: "if I nudge this knob a little, does the error go up or down?"

## What you'll learn
- See a **slope** as *sensitivity*: how much the output moves when the input moves a tiny bit.
- Read a **derivative** as a signed number whose sign points "downhill" and whose size says "how steep."
- Understand a **gradient** as a vector — one slope per knob — that points in the steepest-uphill direction.
- Estimate any derivative numerically in NumPy without calculus rules.
- Connect all of this directly to "reduce the loss."

## Intuition
Picture standing on a hill in thick fog. You can't see the valley, but you *can* feel the ground under one foot. If the ground tilts down to your right, you know which way is downhill **right where you stand** — even without a map. The steepness you feel is the **slope**. That's a derivative: a local sense of "which way and how steeply things change."

Now make it concrete with error. A model has a **loss** — a single number measuring how wrong it currently is. The loss depends on the model's knobs (its weights). The derivative of the loss *with respect to one weight* answers: "if I increase this one weight slightly, does the loss rise or fall, and how fast?"

- Derivative **positive** → increasing the weight *raises* loss → so go the other way (decrease it).
- Derivative **negative** → increasing the weight *lowers* loss → so increase it.
- Derivative **near zero** → you're on flat ground, possibly the bottom — nudging barely changes anything.

Most models have many knobs at once. Collect the slope for *every* knob into one list and you get the **gradient** — a vector with one number per weight. The gradient points in the direction that increases loss fastest, so to *reduce* loss we step in the **opposite** direction. That single idea is the engine behind almost all model training, and it's the whole reason the previous lesson's vectors matter: the gradient is a vector.

## Python in practice

```python
import numpy as np

# A simple loss-shaped function: a bowl with its bottom at w = 3.
def f(w):
    return (w - 3.0) ** 2

# Numeric derivative: nudge w by a tiny h and see how much f changes.
# slope ≈ (f(w+h) - f(w-h)) / (2h)   <- the "central difference", more accurate.
def numeric_derivative(func, w, h=1e-5):
    return (func(w + h) - func(w - h)) / (2 * h)

for w in [0.0, 1.0, 3.0, 5.0]:
    slope = numeric_derivative(f, w)
    print(f"w={w:>4}  loss={f(w):>5.1f}  slope={slope:>6.2f}")
# w= 0.0  loss= 9.0  slope= -6.00   slope negative -> increasing w lowers loss -> go right
# w= 1.0  loss= 4.0  slope= -4.00   still downhill to the right
# w= 3.0  loss= 0.0  slope=  0.00   flat -> we're at the bottom
# w= 5.0  loss= 4.0  slope=  6.00   slope positive -> increasing w raises loss -> go left
```

The exact calculus answer here is `2*(w-3)`; our numeric estimate matches it to many decimals, and we never needed a calculus rule — just two function evaluations.

```python
# A GRADIENT: many knobs at once.
# Loss for two weights: a 2-D bowl with its bottom at (w0, w1) = (3, -2).
def loss2(w):                      # w is a length-2 vector
    return (w[0] - 3.0) ** 2 + (w[1] + 2.0) ** 2

def numeric_gradient(func, w, h=1e-5):
    grad = np.zeros_like(w, dtype=float)
    for i in range(len(w)):
        step = np.zeros_like(w, dtype=float)
        step[i] = h
        grad[i] = (func(w + step) - func(w - step)) / (2 * h)   # one partial per knob
    return grad

w = np.array([0.0, 0.0])
g = numeric_gradient(loss2, w)
print("gradient:", g)             # [-6. 4.]  (points UPHILL)
print("downhill:", -g)            # [ 6. -4.] (the direction we'd step to reduce loss)
```

Read the gradient `[-6, 4]`: the first knob wants to move *up* (its slope is negative), the second wants to move *down*. Negating it gives the direction that decreases loss — exactly the step gradient descent will take in the next lesson.

```python
# Optional: visualize the bowl and its slope to build intuition.
import matplotlib.pyplot as plt

ws = np.linspace(-2, 8, 200)
plt.plot(ws, f(ws), label="loss f(w) = (w-3)^2")
w0 = 5.0
slope = numeric_derivative(f, w0)
# Draw the tangent line at w0: the local slope made visible.
plt.plot(ws, f(w0) + slope * (ws - w0), "--", label=f"tangent at w={w0} (slope={slope:.0f})")
plt.scatter([w0], [f(w0)], color="red")
plt.xlabel("w"); plt.ylabel("loss"); plt.legend(); plt.title("Slope = local tilt of the loss")
plt.show()
```

## Common mistakes
- **Forgetting the sign tells you direction.** The derivative's *sign* says which way is uphill; you step the opposite way. Beginners often move in the direction of the gradient instead of *against* it and watch the loss explode.
- **Choosing `h` too small or too large.** Too large (`h=1`) and the estimate is crude; too small (`h=1e-12`) and floating-point rounding ruins it. `1e-5` to `1e-7` is a safe range for the central difference.
- **Using the forward difference when central is easy.** `(f(w+h)-f(w))/h` works but is less accurate than the central version `(f(w+h)-f(w-h))/(2h)` for the same `h`. Prefer central for sanity checks.
- **Confusing the gradient's length with its direction.** A gradient of `[100, 1]` doesn't mean knob 0 is 100× more "important" — it means the loss is *currently* far steeper along knob 0. As you descend, those numbers change.
- **Thinking a zero gradient always means the global best.** It means *flat ground* — could be the bottom, a ridge, or a saddle. For the simple convex bowls in this module it really is the minimum, but remember the caveat for harder surfaces later.

## Small exercise
1. Write a loss `g(w) = w**4 - 3*w**2` and use `numeric_derivative` to estimate its slope at `w = -1.5, 0, 1.5`.
2. From the signs you get, sketch (on paper) roughly which way each point would "roll." Where do you suspect the flat spots are?
3. Bonus: this function has *two* valleys. Find approximately where `numeric_derivative` returns ~0 by scanning `w` from -2 to 2 in small steps.

## Before you continue
- [ ] I can explain why a positive derivative means "step left to lower the loss."
- [ ] I can estimate a derivative numerically with a central difference and no calculus.
- [ ] I can describe a gradient as "one slope per weight, packed into a vector that points uphill."
- [ ] I can state how the gradient connects to the goal of reducing loss.

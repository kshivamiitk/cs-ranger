# Checkpoint — NLP

## What you should now be able to do
- Explain why text must be turned into numbers and walk through the tokenize → vocabulary → count pipeline by hand.
- Describe the bag-of-words model and what it discards (word order).
- Define term frequency and inverse document frequency and explain why TF-IDF favors rare-but-frequent words.
- Use `CountVectorizer` and `TfidfVectorizer`, including `stop_words` and `ngram_range`.
- Build a `Pipeline([("tfidf", ...), ("clf", ...)])`, train it, and predict new sentences without leakage.
- Evaluate a text classifier with accuracy, precision, and recall, and inspect its most positive/negative words.

## Review questions
1. A model throws an error when you pass it a list of raw strings. In one sentence, why — and what step fixes it?
2. Tokenize `"The Cat, the cat!"` the way a basic vectorizer would (lowercase, drop punctuation, 2+ character tokens). What's the resulting vocabulary?
3. Two documents are `"happy happy day"` and `"sad day"`. What does the bag-of-words vector for the first document look like, given vocabulary `["day", "happy", "sad"]`?
4. In plain words, what makes a word's IDF *large*? What makes it *small*?
5. Why does the word "the" tend to get a near-zero TF-IDF weight even though it appears many times?
6. What concrete benefit does `ngram_range=(1, 2)` give a sentiment model that `(1, 1)` cannot?
7. Why must you call `fit_transform` on training data but only `transform` on test data?
8. You wrap a vectorizer and a `LogisticRegression` in a Pipeline. Where do you read off the "most positive words", and why does this trick fail for a non-linear model like a kernel SVM?
9. Your test accuracy is 1.0 but the test set only has 4 reviews. Why should you be cautious about that number?

## Answers
<details>
<summary>Show answers</summary>

1. Models do arithmetic on numeric vectors and have no representation for raw strings. Vectorizing the text first (e.g. `TfidfVectorizer`) converts each document into a numeric row, which fixes the error.
2. Tokens: `the`, `cat`, `the`, `the`, `cat`. The vocabulary (unique tokens) is `["cat", "the"]`. (`"Cat,"` and `"cat!"` both normalize to `cat`.)
3. `[1, 2, 0]` — `day` appears once, `happy` appears twice, `sad` appears zero times, in that column order.
4. IDF is **large** when a word appears in *few* documents (rare across the corpus). It is **small** (near zero) when a word appears in *most or all* documents.
5. "The" appears in nearly every document, so its inverse document frequency is tiny. Even with a high term frequency, `tf × idf` collapses toward zero, demoting it automatically.
6. `(1, 2)` adds bigrams (adjacent word pairs) as tokens, so the phrase "not good" becomes its own feature distinct from "good". With unigrams only, the model can't tell "not good" from "good".
7. `fit_transform` learns the vocabulary *and* applies it; you want the vocabulary learned from training data only. Calling `fit_transform` on test data would re-learn the vocabulary from the test set, leaking information and inflating your scores. Test data should only be `transform`ed with the already-fitted vocabulary.
8. From `pipe.named_steps["clf"].coef_[0]` aligned with `pipe.named_steps["tfidf"].get_feature_names_out()`: sort the coefficients and read the extremes. It works because linear models assign one weight per feature. A kernel SVM (rbf) has no single weight per word, so there is no list to sort.
9. With only 4 test reviews, one wrong prediction swings accuracy by 0.25. A small test set gives a noisy, unreliable estimate; you need many more examples (or cross-validation) to trust the number.

</details>

## Hands-on tasks
1. **Hand vectorize.** Without any library, tokenize and build the bag-of-words matrix for `["good movie", "bad movie", "good good film"]`. Then confirm it with `CountVectorizer(...).fit_transform(...).toarray()`.
2. **TF-IDF inspection.** Fit a `TfidfVectorizer` on the three documents above and print `idf_` next to `get_feature_names_out()`. Identify which word has the highest IDF and explain why.
3. **Mini classifier.** Reuse the labeled corpus from lesson 3 (or write your own 10-review set). Build a TF-IDF + Logistic Regression Pipeline, train it, and predict three new sentences you write yourself. Print the predicted label and probability for each.
4. **Read the model.** From your trained Pipeline, print the top 5 most positive and most negative words. Do they make intuitive sense? Note any word that ranks high only because it appeared in a single review.

## You're ready for the next module when…
- [ ] I can turn a few short documents into a bag-of-words matrix by hand and verify it with scikit-learn.
- [ ] I can explain TF-IDF, stopwords, and n-grams without notes.
- [ ] I can build, train, and evaluate a text-classification Pipeline and predict new sentences.
- [ ] I can extract and interpret the most positive/negative words a linear text model learned.

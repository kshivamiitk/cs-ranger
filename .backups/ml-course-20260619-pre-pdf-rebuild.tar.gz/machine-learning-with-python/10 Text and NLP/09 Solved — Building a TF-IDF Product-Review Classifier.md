# Solved — Building a TF-IDF Product-Review Classifier

> An e-commerce team is drowning in product reviews and wants to auto-flag the negative ones for the support queue — and, just as importantly, to *show* a stakeholder the exact words that triggered each flag.

## Problem statement

You run reviews for an online store. Each review is a short line of free text, and you have a label `1` = positive, `0` = negative. You need two things: (a) a model that, given a *new* review, predicts positive/negative, evaluated honestly on held-out reviews with **precision/recall** (because misrouting an angry customer as "happy" is the costly error), and (b) a built-in **explanation** — the list of words that most push a review toward each class.

The build is a `TfidfVectorizer → LogisticRegression` **Pipeline**: TF-IDF turns each review into a weighted bag of word-importances, and the linear model assigns every vocabulary word one signed weight. Because the model is linear over TF-IDF features, those weights *are* the explanation — sort them and you get "the words that mean good" and "the words that mean bad," for free. This lesson is specifically about that **TF-IDF → linear-model pipeline and its top-feature readout**, not about chasing a headline accuracy.

## Why this problem matters

Routing reviews, triaging support tickets, flagging at-risk accounts from their messages — these are everyday text tasks where a giant language model is overkill. A TF-IDF + linear model is fast, cheap, runs on a laptop, retrains in milliseconds, and (the part that gets it shipped) is **fully explainable**: when a manager asks "why did the system call this review negative?", you can point at `terrible`, `unreliable`, `slow` with their weights. TF-IDF is what makes those weights meaningful — it *down*-weights words that appear in nearly every review (low signal) and *up*-weights words that are frequent in one review but rare across the corpus. So the words that earn big coefficients are the genuinely discriminative ones, not filler like "the" or "product."

## Tiny dataset or sample data

Twenty-four short product reviews, balanced 12 positive / 12 negative, inline so the whole thing runs offline. The data is a Python list of `(text, label)` pairs; after vectorizing, the feature matrix is `n_reviews × V` where `V` is the learned vocabulary size (52 here, after English stop-words are removed). A representative slice:

| review | label |
|--------|------:|
| "Excellent battery life and the screen is sharp, love it" | 1 |
| "Fast charging and excellent value for the price" | 1 |
| "Sturdy build, great camera, and fast performance" | 1 |
| "Terrible battery life and the screen is dim and cheap" | 0 |
| "Slow charging and terrible value for the price" | 0 |
| "Flimsy build, poor camera, and slow performance" | 0 |

The reviews are written so that **sentiment-bearing words recur** (`excellent`, `fast`, `reliable`, `love` vs `terrible`, `slow`, `poor`, `hate`). That repetition is deliberate and realistic: it's what lets a word learned on the training split actually show up — and carry weight — on a held-out review, instead of every review being a unique snowflake of vocabulary.

## Step-by-step reasoning

1. **It's binary text classification.** The input is raw text and the target is a class, so the very first thing we need is a step that turns words into numbers. Nothing can be fit until that exists.
2. **TF-IDF, not raw counts.** Raw word *counts* let common words dominate. **TF-IDF** multiplies a word's frequency in *this* review (TF) by how *rare* it is across all reviews (IDF), so "the" (in everything) gets crushed while "excellent" (in a few) stands out. On tiny data this focus is the difference between learning sentiment and learning grammar.
3. **Wrap it in a Pipeline.** Vectorizing and classifying must stay locked together: the exact vocabulary and IDF weights learned on the training split have to be reused — never recomputed — at predict time. A `Pipeline` guarantees `fit` learns them on train only (no leakage) and `predict`/`predict_proba` reuse them. Bonus: you save and serve one object.
4. **Hold out a test set, and stratify it.** Scoring on the reviews you trained on is self-flattery. We split off 25% and pass `stratify=labels` so both positive and negative reviews land in the test fold — otherwise a 6-review test set could come out all-positive and make recall undefined.
5. **Logistic regression, because it's linear.** Every vocabulary word gets a single signed coefficient. A big *positive* weight means the word pushes a review toward "positive"; a big *negative* weight pushes toward "negative." That linearity is precisely the interpretability we promised.
6. **Read the weights as the explanation.** Sort the coefficients: the top end is the model's "good-review" vocabulary, the bottom end its "bad-review" vocabulary. Then run two brand-new reviews through the same pipeline and watch the probabilities line up with which words fired.

## Python solution

```python
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix

# --- Inline product reviews (offline). 1 = positive, 0 = negative. ---
# Sentiment words recur across reviews so the learned vocabulary generalizes.
data = [
    ("Excellent battery life and the screen is sharp, love it", 1),
    ("Great sound quality and a solid premium build", 1),
    ("Fast charging and excellent value for the price", 1),
    ("Comfortable grip and a beautiful sharp display, love this", 1),
    ("Works perfectly out of the box, excellent and reliable", 1),
    ("Sturdy build, great camera, and fast performance", 1),
    ("Amazing value, the battery is excellent and lasts for days", 1),
    ("Lightweight and reliable, great quality for the price", 1),
    ("Sharp camera and a comfortable design, love the feel", 1),
    ("Fast, reliable, and the sound quality is excellent", 1),
    ("Premium materials and a great sturdy build, highly recommend", 1),
    ("Excellent performance and a sharp bright screen, love it", 1),
    ("Terrible battery life and the screen is dim and cheap", 0),
    ("Poor sound quality and a flimsy plastic build", 0),
    ("Slow charging and terrible value for the price", 0),
    ("Uncomfortable grip and a dull cheap display, hate this", 0),
    ("Broke out of the box, terrible and unreliable", 0),
    ("Flimsy build, poor camera, and slow performance", 0),
    ("Awful value, the battery is terrible and dies in an hour", 0),
    ("Heavy and unreliable, poor quality for the price", 0),
    ("Blurry camera and an uncomfortable design, hate the feel", 0),
    ("Slow, unreliable, and the sound quality is terrible", 0),
    ("Cheap materials and a flimsy weak build, do not recommend", 0),
    ("Terrible performance and a dull dim screen, hate it", 0),
]
texts  = [t for t, _ in data]
labels = np.array([y for _, y in data])
print(len(texts), "reviews |", int(labels.sum()), "positive /",
      int((labels == 0).sum()), "negative")

# Stratified split keeps positives AND negatives in both folds.
X_tr, X_te, y_tr, y_te = train_test_split(
    texts, labels, test_size=0.25, random_state=0, stratify=labels)
print(len(X_tr), "train /", len(X_te), "test")

# --- ONE Pipeline: raw text -> TF-IDF features -> linear classifier. ---
clf = Pipeline([
    ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english")),
    ("lr",    LogisticRegression(max_iter=1000)),
])
clf.fit(X_tr, y_tr)   # learns vocabulary + IDF on TRAIN ONLY, then the model
print("Learned vocabulary size:",
      len(clf.named_steps["tfidf"].get_feature_names_out()))

# --- Evaluate on held-out reviews. ---
y_pred = clf.predict(X_te)
print("\n" + classification_report(y_te, y_pred, digits=2, zero_division=0))
print("Confusion matrix [ [TN FP] [FN TP] ]:\n", confusion_matrix(y_te, y_pred))

# --- Inspect the highest-weight TF-IDF terms for each class. ---
vocab  = np.array(clf.named_steps["tfidf"].get_feature_names_out())
coefs  = clf.named_steps["lr"].coef_[0]   # one signed weight per term
order  = np.argsort(coefs)                # ascending: most negative first
print("\nTop POSITIVE terms (push toward 'good review'):")
for w, c in zip(vocab[order[-6:]][::-1], coefs[order[-6:]][::-1]):
    print(f"   {w:14s} weight {c:+.2f}")
print("Top NEGATIVE terms (push toward 'bad review'):")
for w, c in zip(vocab[order[:6]], coefs[order[:6]]):
    print(f"   {w:14s} weight {c:+.2f}")

# --- Predict brand-new reviews (pipeline reuses the SAME vocab + IDF). ---
new_reviews = [
    "The battery is excellent and the screen is sharp, love it",
    "Cheap flimsy build and terrible slow performance, hate it",
    "Great sound and a sturdy reliable design, fast charging",
]
preds = clf.predict(new_reviews)
probs = clf.predict_proba(new_reviews)[:, 1]   # P(positive)
print("\nNew reviews:")
for r, p, pr in zip(new_reviews, preds, probs):
    tag = "POSITIVE" if p == 1 else "NEGATIVE"
    print(f"  [{tag}  P(pos)={pr:.2f}]  {r}")
```

## Expected output

```
24 reviews | 12 positive / 12 negative
18 train / 6 test
Learned vocabulary size: 52

              precision    recall  f1-score   support

           0       0.60      1.00      0.75         3
           1       1.00      0.33      0.50         3

    accuracy                           0.67         6
   macro avg       0.80      0.67      0.62         6
weighted avg       0.80      0.67      0.62         6

Confusion matrix [ [TN FP] [FN TP] ]:
 [[3 0]
 [2 1]]

Top POSITIVE terms (push toward 'good review'):
   excellent      weight +0.71
   fast           weight +0.50
   reliable       weight +0.49
   sharp          weight +0.40
   love           weight +0.40
   great          weight +0.36
Top NEGATIVE terms (push toward 'bad review'):
   terrible       weight -0.65
   unreliable     weight -0.46
   slow           weight -0.36
   poor           weight -0.33
   hate           weight -0.31
   flimsy         weight -0.30
```
plus the three new-review predictions:
```
  [POSITIVE  P(pos)=0.67]  The battery is excellent and the screen is sharp, love it
  [NEGATIVE  P(pos)=0.33]  Cheap flimsy build and terrible slow performance, hate it
  [POSITIVE  P(pos)=0.60]  Great sound and a sturdy reliable design, fast charging
```

## Explanation of the output

- **The headline metric is deliberately humbling, and that's the lesson.** The held-out set is **6 reviews**, so each one is worth ~17% of accuracy and the numbers are jumpy. Here accuracy is **0.67**, with a lopsided story: the model caught **every** negative review (recall 1.00 on class 0) but only 1 of 3 positives (recall 0.33 on class 1) — see the confusion matrix's two false negatives. On 6 examples that is mostly *split noise*, not a real weakness; treat any single small-test score as a rough signal, not a verdict.
- **The real payoff is the coefficient list, and it is excellent.** With zero hand-labeling of words, the pipeline independently learned that `excellent (+0.71)`, `fast (+0.50)`, `reliable (+0.49)`, `sharp`, `love`, `great` mean *good*, while `terrible (-0.65)`, `unreliable`, `slow`, `poor`, `hate`, `flimsy` mean *bad*. That signed-weight table is a ready-made answer to "why did the model decide this?" — exactly the explainability that gets a simple model approved for production.
- **TF-IDF is why those words won.** Filler that appears in nearly every review (and the English stop-words we removed) gets a tiny IDF and never rises to the top of the list; the distinctive sentiment words do. The 52-word vocabulary is the union of words surviving stop-word removal across the 18 training reviews.
- **The new reviews confirm the words generalize.** Run through the *same* fitted vocabulary and IDF, the clearly-positive and clearly-negative reviews land on the right side with sensible probabilities (`0.67`, `0.33`, `0.60`) — away from a coin-flip 0.50, and driven by the same top words. The probabilities are modest rather than extreme because TF-IDF spreads weight across several words and the regularized model stays cautious on tiny data.

## Common mistakes

1. **Fitting the vectorizer on all the text before splitting.** `TfidfVectorizer().fit(all_texts)` then splitting leaks the test reviews into the learned vocabulary and IDF weights, inflating your score. Fix: put the vectorizer *inside* the `Pipeline` so `fit` only ever sees the training split.
2. **Scoring on the training data.** `clf.fit(X, y)` followed by `clf.score(X, y)` looks fantastic and means nothing — the model has seen those exact words. Fix: always evaluate on a held-out split (or cross-validate).
3. **Reading raw counts instead of TF-IDF — or trusting accuracy on imbalanced reviews.** With plain `CountVectorizer`, frequent filler words swamp the signal; and if 90% of reviews are positive, "always positive" scores 90% accuracy while catching no complaints. Fix: use TF-IDF, and report precision/recall (and the confusion matrix) for the class you actually care about — the negatives.
4. **Forgetting to stratify a tiny split.** Without `stratify=labels`, a 6-review test set can come out all one class, making precision or recall undefined. Fix: `stratify=labels`.
5. **Ignoring negation with unigrams.** A bare unigram model reads "not reliable" as `not` + `reliable` and may score it positive. Fix: add `ngram_range=(1, 2)` so "not reliable" becomes its own feature (see the extension — but note bigrams balloon the vocabulary, so they need more data to pay off).

## Extension challenge

1. **Add bigrams.** Set `TfidfVectorizer(ngram_range=(1, 2))` and re-read the top terms. Do negation phrases like "not reliable" or "do not recommend" surface, and does the vocabulary size explode? Discuss why bigrams help on large corpora but can *hurt* on 24 reviews.
2. **Cross-validate instead of one split.** Replace the single split with `cross_val_score(clf, texts, labels, cv=4)` and report mean ± std. Why is that a far more honest estimate than the jumpy 0.67 from one 6-review test fold?
3. **Swap in `LinearSVC`.** Replace `LogisticRegression` with `LinearSVC`. You lose `predict_proba` — so how would you still *rank* reviews by confidence for the support queue (hint: `decision_function`)? Compare its top-weight words to logistic regression's.

## Matching animation

**TF-IDF Term Weight Builder** — watch a review's words flow through the two factors that build a TF-IDF score: a tall TF bar for a word repeated in *this* review, multiplied by an IDF bar that *shrinks* as you spread the same word into more documents. Drag `excellent` into every review and see its IDF — and therefore its weight — collapse toward zero, which is exactly why filler words never made the top-features list above. Then open the **TF-IDF Word Weight Explorer** to flip into the model's view: each term's final TF-IDF feeds the linear coefficient, so the bars you built become the signed weights (`excellent +0.71`, `terrible -0.65`) that decide every prediction.

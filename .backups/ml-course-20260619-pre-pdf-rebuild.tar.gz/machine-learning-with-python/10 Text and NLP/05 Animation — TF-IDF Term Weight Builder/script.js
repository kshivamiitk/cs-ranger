"use strict";

/* ==================================================================
 * TF-IDF Term Weight Builder
 * ------------------------------------------------------------------
 * An EDITABLE corpus. The learner types into the document boxes and
 * every weight recomputes live (debounced). Vanilla JS, canvas 2D
 * for the bars, no libraries, fully deterministic.
 *
 * ONE idea:  TF-IDF = TF x IDF
 *   TF  = how often a term appears in THIS document
 *   IDF = how rare the term is across ALL documents
 *   weight = TF * IDF
 * Spread a word into more docs -> df rises -> IDF falls -> weight
 * collapses. A brand-new distinctive word -> df = 1 -> IDF spikes.
 *
 * FORMULAS (scikit-learn-style, smoothed):
 *   tf(t, d)   = raw count of term t in doc d
 *                (or count / doc-length, when "Normalize TF" is on)
 *   df(t)      = number of documents containing term t at least once
 *   N          = number of documents
 *   idf(t)     = ln( (1 + N) / (1 + df(t)) ) + 1     // smoothed
 *   tfidf(t,d) = tf(t, d) * idf(t)
 *
 * The +1 terms avoid divide-by-zero and keep IDF (and therefore the
 * weight) non-negative. A term in EVERY doc -> idf = ln((1+N)/(1+N))
 * + 1 = 1, its floor. A term in 1 of N docs gets a much larger IDF.
 * ================================================================== */

/* ---- The starting corpus: 4 short, distinct sentences.
 * Tuned so the lesson lands out of the box:
 *   - "the"     appears in 3 docs (2,3,4)  -> larger df -> low IDF
 *   - "model"   appears in 3 docs (1,2,4)  -> larger df -> low IDF
 *   - "data", "rocket", "recipe", "garden", "diagnosis"... each in
 *     ONE doc -> df = 1 -> tallest bars. Distinctive words top every
 *     document's chart, so "rare beats common" is visible instantly. */
const DEFAULT_DOCS = Object.freeze([
  "model learns patterns from data",
  "the model predicts whether the rocket will launch",
  "a good recipe needs the cook to taste",
  "the garden model favours plants and diagnosis",
]);
const DOC_LABELS = ["D1", "D2", "D3", "D4"];
const N = DEFAULT_DOCS.length; // number of documents (fixed = 4)

/* ==================================================================
 * Tokenisation:  lowercase, split on whitespace, strip punctuation.
 * df = number of docs containing the term at least once.
 * ================================================================== */
function tokenize(text) {
  return String(text)
    .toLowerCase()
    .split(/\s+/)
    .map((t) => t.replace(/[^a-z0-9]/g, "")) // strip punctuation, keep letters/digits
    .filter((t) => t.length > 0);
}

/* ---- TF-IDF computation over the whole corpus -------------------- *
 * Returns a model: {
 *   tokensPerDoc: string[][],
 *   vocab: string[]        (sorted),
 *   df: Map<term, number>,
 *   idf: Map<term, number>,
 *   rowsPerDoc: Array< Array<{term, tf, idf, tfidf, df}> >  (sorted desc)
 * }
 */
function computeModel(rawDocs, normalize) {
  const tokensPerDoc = rawDocs.map(tokenize);

  // document frequency: how many docs contain each term
  const df = new Map();
  tokensPerDoc.forEach((tokens) => {
    const uniq = new Set(tokens);
    uniq.forEach((term) => df.set(term, (df.get(term) || 0) + 1));
  });

  // smoothed IDF per term:  ln((1+N)/(1+df)) + 1
  const idf = new Map();
  df.forEach((freq, term) => {
    idf.set(term, Math.log((1 + N) / (1 + freq)) + 1);
  });

  const vocab = [...df.keys()].sort();

  // per-document rows: one entry per UNIQUE term in that doc
  const rowsPerDoc = tokensPerDoc.map((tokens) => {
    const len = tokens.length;
    const counts = new Map();
    tokens.forEach((t) => counts.set(t, (counts.get(t) || 0) + 1));

    const rows = [];
    counts.forEach((count, term) => {
      // raw TF, or length-normalized TF when the toggle is on
      const tf = normalize && len > 0 ? count / len : count;
      const wIdf = idf.get(term);
      rows.push({ term, tf, idf: wIdf, tfidf: tf * wIdf, df: df.get(term) });
    });
    // tallest first; ties broken alphabetically for stable, deterministic order
    rows.sort((a, b) => b.tfidf - a.tfidf || a.term.localeCompare(b.term));
    return rows;
  });

  return { tokensPerDoc, vocab, df, idf, rowsPerDoc };
}

/* ==================================================================
 * DOM wiring
 * ================================================================== */
const docsHost = document.getElementById("docs");
const docSel = document.getElementById("docSel");
const vocabBadge = document.getElementById("vocabBadge");
const canvas = document.getElementById("bars");
const ctx = canvas.getContext("2d");
const emptyNote = document.getElementById("emptyNote");
const resetBtn = document.getElementById("reset");
const normToggle = document.getElementById("normTf");
const wbody = document.getElementById("wbody");
const recalcHint = document.getElementById("recalcHint");

// readout cells
const rDocs = document.getElementById("rDocs");
const rVocab = document.getElementById("rVocab");
const rTerms = document.getElementById("rTerms");
const rTop = document.getElementById("rTop");
const rTopW = document.getElementById("rTopW");

// state
const textAreas = [];          // the 4 <textarea> elements
let selectedDocIdx = 0;        // which doc the chart/table describe
let model = null;              // latest computed model

function fmt(n, dp) {
  return Number(n).toFixed(dp === undefined ? 2 : dp);
}

/* ---- build the document editor boxes ----------------------------- */
function buildDocBoxes() {
  docsHost.innerHTML = "";
  textAreas.length = 0;
  DEFAULT_DOCS.forEach((text, i) => {
    const box = document.createElement("div");
    box.className = "doc-box";

    const label = document.createElement("label");
    label.className = "doc-label";
    label.setAttribute("for", "doc" + i);
    label.innerHTML =
      `Document ${DOC_LABELS[i]} <span class="badge" id="docLen${i}">0 terms</span>`;

    const ta = document.createElement("textarea");
    ta.id = "doc" + i;
    ta.value = text;
    ta.spellcheck = false;
    ta.setAttribute("aria-label", "Document " + DOC_LABELS[i] + " text");
    ta.addEventListener("input", onType);
    // focusing a box also selects it for the chart, so editing feels connected
    ta.addEventListener("focus", () => selectDoc(i, false));

    box.appendChild(label);
    box.appendChild(ta);
    docsHost.appendChild(box);
    textAreas.push(ta);
  });
}

/* ---- populate the "showing weights for" dropdown ----------------- */
function populateDocSelect() {
  docSel.innerHTML = "";
  DEFAULT_DOCS.forEach((_, i) => {
    const opt = document.createElement("option");
    opt.value = String(i);
    opt.textContent = "Document " + DOC_LABELS[i];
    docSel.appendChild(opt);
  });
  docSel.value = String(selectedDocIdx);
}

function rawDocs() {
  return textAreas.map((ta) => ta.value);
}

/* ==================================================================
 * Debounced recompute so typing stays smooth.
 * ================================================================== */
let debounceId = null;
function onType() {
  if (debounceId !== null) clearTimeout(debounceId);
  recalcHint.textContent = "typing…";
  recalcHint.style.color = "var(--dim)";
  debounceId = setTimeout(() => {
    debounceId = null;
    recompute(true);
    recalcHint.textContent = "live — recomputes as you type";
    recalcHint.style.color = "var(--success)";
  }, 200);
}

/* full recompute + redraw of every dependent view */
function recompute(animate) {
  model = computeModel(rawDocs(), normToggle.checked);
  updateDocLengths();
  updateReadout();
  renderTable();
  setBars(model.rowsPerDoc[selectedDocIdx] || [], animate);
}

/* select which document the chart/table describe */
function selectDoc(idx, fromDropdown) {
  if (idx === selectedDocIdx && model) {
    // still refresh highlight on the textarea
    highlightSelected();
    return;
  }
  selectedDocIdx = idx;
  docSel.value = String(idx);
  highlightSelected();
  renderTable();
  updateReadout();
  setBars(model ? model.rowsPerDoc[idx] || [] : [], true);
  if (fromDropdown) {
    // bring the matching editor into view-friendly focus state (no scroll jump)
    highlightSelected();
  }
}

function highlightSelected() {
  textAreas.forEach((ta, i) => {
    ta.classList.toggle("selected", i === selectedDocIdx);
  });
}

/* ---- per-doc term-count badges ----------------------------------- */
function updateDocLengths() {
  model.tokensPerDoc.forEach((tokens, i) => {
    const el = document.getElementById("docLen" + i);
    if (el) el.textContent = tokens.length + (tokens.length === 1 ? " term" : " terms");
  });
}

/* ---- readout stats ----------------------------------------------- */
function updateReadout() {
  const rows = model ? model.rowsPerDoc[selectedDocIdx] || [] : [];
  rDocs.textContent = String(N);
  rVocab.textContent = String(model ? model.vocab.length : 0);
  rTerms.textContent = String(rows.length);
  vocabBadge.textContent = "vocab: " + (model ? model.vocab.length : 0);

  if (rows.length === 0) {
    rTop.textContent = "—";
    rTopW.textContent = "0.000";
    rTopW.className = "v";
  } else {
    const top = rows[0];
    rTop.textContent = top.term;
    rTopW.textContent = fmt(top.tfidf, 3);
    rTopW.className = "v snapped";
  }
}

/* ---- breakdown table:  TF x IDF = TF-IDF , plus df ---------------- */
function renderTable() {
  const rows = model ? model.rowsPerDoc[selectedDocIdx] || [] : [];
  wbody.innerHTML = "";

  if (rows.length === 0) {
    const tr = document.createElement("tr");
    tr.className = "empty-row";
    const td = document.createElement("td");
    td.colSpan = 7;
    td.textContent = "No terms yet — type into Document " + DOC_LABELS[selectedDocIdx] + ".";
    tr.appendChild(td);
    wbody.appendChild(tr);
    return;
  }

  rows.forEach((r) => {
    const tr = document.createElement("tr");
    // a term in every doc has IDF ~1, so its weight stays small: flag it red
    const isZeroish = r.df >= N;
    tr.innerHTML =
      `<td class="term">${r.term}</td>` +
      `<td>${fmt(r.tf, 3)}</td>` +
      `<td class="op">×</td>` +
      `<td>${fmt(r.idf, 3)}</td>` +
      `<td class="op">=</td>` +
      `<td class="weight ${isZeroish ? "zero" : ""}">${fmt(r.tfidf, 3)}</td>` +
      `<td>${r.df}/${N}</td>`;
    wbody.appendChild(tr);
  });
}

/* ==================================================================
 * Canvas bar chart (TF-IDF weight per term, tallest first) with an
 * eased animation between states so live edits feel alive.
 * ================================================================== */
const PAD = { top: 30, right: 22, bottom: 14, left: 118 };
const ROW_H = 26;
const ROW_GAP = 8;

let animVals = new Map();  // term -> { cur, target, start, t }
let animRows = [];         // rows currently drawn (sorted by target)
let rafId = null;

function easeOutCubic(t) {
  return 1 - Math.pow(1 - t, 3);
}

function setBars(rows, animate) {
  // cap to what fits in the canvas height to avoid clipping surprises
  const maxRows = Math.floor((canvas.height - PAD.top - PAD.bottom) / (ROW_H + ROW_GAP));
  animRows = rows.slice(0, Math.max(1, maxRows));

  emptyNote.hidden = rows.length !== 0;

  const next = new Map();
  animRows.forEach((r) => {
    const prev = animate && animVals.has(r.term) ? animVals.get(r.term).cur : (animate ? 0 : r.tfidf);
    next.set(r.term, { cur: prev, target: r.tfidf, start: prev, t: animate ? 0 : 1 });
  });
  animVals = next;

  if (animate) startAnim();
  else drawBars();
}

function startAnim() {
  if (rafId !== null) cancelAnimationFrame(rafId);
  let last = performance.now();
  const DURATION = 420; // ms

  function tick(now) {
    const dt = now - last;
    last = now;
    let moving = false;
    animVals.forEach((v) => {
      if (v.t < 1) {
        v.t = Math.min(1, v.t + dt / DURATION);
        v.cur = v.start + (v.target - v.start) * easeOutCubic(v.t);
        if (v.t < 1) moving = true;
      }
    });
    drawBars();
    if (moving) {
      rafId = requestAnimationFrame(tick);
    } else {
      rafId = null;
    }
  }
  rafId = requestAnimationFrame(tick);
}

function roundRect(x, y, w, h, r) {
  const rr = Math.min(r, h / 2, w / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

function drawBars() {
  const W = canvas.width;
  const H = canvas.height;
  ctx.clearRect(0, 0, W, H);

  // header label
  ctx.fillStyle = "#94a3b8";
  ctx.font = "600 12px ui-monospace, Menlo, monospace";
  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";
  ctx.fillText("TF·IDF weight  →", PAD.left, 18);

  if (animRows.length === 0) return;

  // scale so the longest bar fills the plot (floor of 1 keeps small corpora readable)
  let maxW = 1e-6;
  animRows.forEach((r) => {
    const v = animVals.get(r.term);
    maxW = Math.max(maxW, v ? v.target : 0, r.tfidf);
  });
  if (maxW <= 0) maxW = 1;

  const plotW = W - PAD.left - PAD.right;
  const baseX = PAD.left;

  animRows.forEach((r, i) => {
    const y = PAD.top + i * (ROW_H + ROW_GAP);
    if (y + ROW_H > H) return; // safety clip

    const v = animVals.get(r.term);
    const val = v ? v.cur : r.tfidf;
    const len = (val / maxW) * plotW;
    // a term in every doc rides its IDF floor — paint it amber/red to signal "demoted"
    const demoted = r.df >= N;

    // track
    ctx.fillStyle = "rgba(255,255,255,0.04)";
    roundRect(baseX, y, plotW, ROW_H, 6);
    ctx.fill();

    // bar
    const grad = ctx.createLinearGradient(baseX, 0, baseX + plotW, 0);
    if (demoted) {
      grad.addColorStop(0, "#f87171");
      grad.addColorStop(1, "#fbbf24");
    } else {
      grad.addColorStop(0, "#a78bfa");
      grad.addColorStop(1, "#22d3ee");
    }
    ctx.fillStyle = grad;
    roundRect(baseX, y, Math.max(2, len), ROW_H, 6);
    ctx.fill();

    // term label (left of bar) with its df
    ctx.fillStyle = "#e2e8f0";
    ctx.font = "600 12px ui-monospace, Menlo, monospace";
    ctx.textAlign = "right";
    ctx.textBaseline = "middle";
    ctx.fillText(r.term, baseX - 36, y + ROW_H / 2);
    ctx.fillStyle = "#64748b";
    ctx.font = "10px ui-monospace, Menlo, monospace";
    ctx.fillText("df " + r.df, baseX - 8, y + ROW_H / 2);

    // value label
    ctx.font = "11px ui-monospace, Menlo, monospace";
    ctx.textBaseline = "middle";
    const valLabel = fmt(val, 2);
    const labelX = baseX + Math.max(2, len) + 8;
    if (labelX < W - 32) {
      ctx.fillStyle = "#94a3b8";
      ctx.textAlign = "left";
      ctx.fillText(valLabel, labelX, y + ROW_H / 2);
    } else {
      ctx.fillStyle = "#0b0b10";
      ctx.textAlign = "right";
      ctx.fillText(valLabel, baseX + len - 8, y + ROW_H / 2);
    }
  });
}

/* ==================================================================
 * Events
 * ================================================================== */
docSel.addEventListener("change", () => {
  selectDoc(Number(docSel.value), true);
});

normToggle.addEventListener("change", () => recompute(true));

resetBtn.addEventListener("click", () => {
  if (debounceId !== null) { clearTimeout(debounceId); debounceId = null; }
  textAreas.forEach((ta, i) => { ta.value = DEFAULT_DOCS[i]; });
  normToggle.checked = false;
  selectedDocIdx = 0;
  docSel.value = "0";
  recalcHint.textContent = "live — recomputes as you type";
  recalcHint.style.color = "var(--success)";
  highlightSelected();
  recompute(true);
});

/* ==================================================================
 * Init
 * ================================================================== */
buildDocBoxes();
populateDocSelect();
highlightSelected();
recompute(false); // first paint snaps without animation

# Lab — Sentiment Classifier from Scratch

## Objective
Build an end-to-end sentiment classifier on a hand-made dataset of short product reviews. By the end you will have trained a `TfidfVectorizer` + `LogisticRegression` Pipeline, evaluated it with accuracy / precision / recall on a held-out test set, predicted the sentiment of brand-new reviews, and listed the words your model considers most positive and most negative. This is a complete, portfolio-ready NLP mini-project that runs entirely offline.

## Dataset
We define the data inline as a Python list — no downloads. It's 15 short reviews, each labeled `1` (positive) or `0` (negative). A sample:

| review | label |
|---|---|
| "This product is amazing, I absolutely love it" | 1 (positive) |
| "Works perfectly and arrived early, very happy" | 1 (positive) |
| "Terrible quality, broke after one day" | 0 (negative) |
| "Complete waste of money, do not buy" | 0 (negative) |

The full list (8 positive, 7 negative) is created in Step 1.

## Steps

**Step 1 — Create the labeled dataset.** Define the reviews and labels as parallel lists.

```python
reviews = [
    # --- positive (label 1) ---
    "This product is amazing, I absolutely love it",
    "Works perfectly and arrived early, very happy",
    "Excellent quality and great value for the price",
    "Super comfortable and beautifully made, highly recommend",
    "Fantastic, exceeded my expectations in every way",
    "Easy to use and the battery lasts forever, wonderful",
    "Best purchase I have made this year, truly excellent",
    "Sturdy, reliable, and looks great on my desk",
    # --- negative (label 0) ---
    "Terrible quality, broke after one day",
    "Complete waste of money, do not buy",
    "Awful experience, the item never worked",
    "Cheap, flimsy, and disappointing in every way",
    "Stopped working after a week, very frustrating",
    "Poorly made and overpriced, I want a refund",
    "Hated it, the worst purchase I have ever made",
]
labels = [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0]

print(f"{len(reviews)} reviews | {sum(labels)} positive | {len(labels) - sum(labels)} negative")
# 15 reviews | 8 positive | 7 negative
```

**Step 2 — Split into train and test sets.** Hold out a few reviews so we can measure performance on data the model never trained on. `stratify` keeps both classes represented in each split.

```python
from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(
    reviews, labels,
    test_size=0.33,      # ~5 reviews held out for testing
    random_state=42,     # reproducible split
    stratify=labels,     # keep pos/neg balance in both splits
)
print(f"train: {len(X_train)}  test: {len(X_test)}")
# train: 10  test: 5
```

**Step 3 — Build the Pipeline.** TF-IDF turns text into numbers; Logistic Regression learns the decision. One object handles both, with no leakage.

```python
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

pipe = Pipeline([
    ("tfidf", TfidfVectorizer(stop_words="english", ngram_range=(1, 2))),
    ("clf",   LogisticRegression(max_iter=1000)),
])
```

**Step 4 — Train on the training set.** The vectorizer learns its vocabulary from `X_train` only.

```python
pipe.fit(X_train, y_train)
print("Vocabulary size:", len(pipe.named_steps["tfidf"].get_feature_names_out()))
# Vocabulary size: ~40-60 terms (unigrams + bigrams from 10 reviews)
```

**Step 5 — Evaluate on the held-out test set.** Accuracy is the headline number; precision and recall tell you *how* the errors fall.

```python
from sklearn.metrics import accuracy_score, precision_score, recall_score, classification_report

y_pred = pipe.predict(X_test)

print("Accuracy :", accuracy_score(y_test, y_pred))
print("Precision:", precision_score(y_test, y_pred, zero_division=0))
print("Recall   :", recall_score(y_test, y_pred, zero_division=0))
print()
print(classification_report(y_test, y_pred, target_names=["negative", "positive"], zero_division=0))
# Accuracy is typically 0.8-1.0 on this tiny, clean set.
# - Precision (positive): of reviews we CALLED positive, how many really were.
# - Recall (positive):    of the truly positive reviews, how many we CAUGHT.
```

**Step 6 — Predict brand-new reviews.** Feed in sentences the model has never seen; the Pipeline vectorizes them with the learned vocabulary automatically.

```python
new_reviews = [
    "absolutely love this, works great",
    "broke immediately, total waste of money",
    "comfortable and reliable, very happy with it",
    "cheap and disappointing, would not recommend",
]
preds = pipe.predict(new_reviews)
probs = pipe.predict_proba(new_reviews)[:, 1]   # probability of positive

for review, p, prob in zip(new_reviews, preds, probs):
    tag = "POSITIVE" if p == 1 else "NEGATIVE"
    print(f"[{tag}  p={prob:.2f}]  {review}")
# [POSITIVE  p~0.7]  absolutely love this, works great
# [NEGATIVE  p~0.3]  broke immediately, total waste of money
# [POSITIVE  p~0.6]  comfortable and reliable, very happy with it
# [NEGATIVE  p~0.3]  cheap and disappointing, would not recommend
```

**Step 7 — Inspect the most positive and most negative words.** Sort the classifier's coefficients to see what it actually learned.

```python
import numpy as np

vec   = pipe.named_steps["tfidf"]
clf   = pipe.named_steps["clf"]
words = vec.get_feature_names_out()
coefs = clf.coef_[0]
order = np.argsort(coefs)

print("Top 5 NEGATIVE words/phrases:")
for i in order[:5]:
    print(f"  {words[i]:>18}  {coefs[i]:+.2f}")

print("\nTop 5 POSITIVE words/phrases:")
for i in order[-5:][::-1]:
    print(f"  {words[i]:>18}  {coefs[i]:+.2f}")
# Negative side surfaces words like: waste, broke, terrible, awful, cheap
# Positive side surfaces words like: love, excellent, great, amazing, perfectly
```

## Expected output
- **Accuracy** between roughly **0.8 and 1.0** on the 5-review test set. With so few test examples, one wrong prediction swings accuracy by 0.2 — that's normal for a tiny dataset and a key lesson in itself: small test sets give noisy estimates.
- **Precision and recall** near each other and near accuracy when the data is balanced and clean. If recall is low, the model is missing positives (calling them negative); if precision is low, it's over-calling positives.
- **New-review predictions** should mostly match common sense: clearly positive sentences come back `POSITIVE` with probability above 0.5, clearly negative ones below 0.5. Probabilities hovering near 0.5 mean the review used few words the model recognized.
- **Top-features lists** should look human-reasonable: "love"/"excellent"/"great" on the positive side, "waste"/"broke"/"terrible" on the negative side. If a strange word ranks high, it's usually because it appeared in only one training review — a small-data artifact, not real signal.

## Extension challenge
1. **Compare classifiers.** Swap `LogisticRegression` for `MultinomialNB` (and try `LinearSVC`). Re-run Steps 4–6. Which gives the best test accuracy, and which gives the most sensible top-feature lists?
2. **Toggle the n-grams.** Change `ngram_range` from `(1, 2)` to `(1, 1)`. Does removing bigrams change how it scores a phrase like `"not great"`? Add such a tricky review to `new_reviews` and watch the prediction.
3. **Add a confusion matrix.** Use `from sklearn.metrics import confusion_matrix` and `ConfusionMatrixDisplay` to visualize exactly which test reviews were misclassified, then read off the false positives vs false negatives.

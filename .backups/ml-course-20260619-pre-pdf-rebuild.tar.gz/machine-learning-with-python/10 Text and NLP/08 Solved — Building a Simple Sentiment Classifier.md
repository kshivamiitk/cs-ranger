# Solved — Building a Simple Sentiment Classifier

> A small product team wants to auto-label incoming reviews as positive or negative so the support queue surfaces unhappy customers first.

## Problem statement

Given a short product/movie review (free text), predict its sentiment: `1` = positive, `0` = negative. We want a model that (a) scores well on held-out reviews using **accuracy** plus **precision/recall** (so we know whether it catches unhappy customers), and (b) is **interpretable** — we should be able to print the words that push a review toward positive or negative, because a black box is hard to trust on text. We'll build the whole thing as a `TfidfVectorizer` + `LogisticRegression` **Pipeline** so the text-to-numbers step and the model travel together.

## Data sample

Sixteen labeled reviews, inline so the whole thing runs offline. This is a Python list of `(text, label)` pairs; shape after vectorizing is `16 rows x V columns`, where `V` is the learned vocabulary size.

| review | label |
|--------|-------|
| "Absolutely loved this, works perfectly and feels premium" | 1 |
| "Best purchase I've made all year, highly recommend" | 1 |
| "Fantastic quality and the battery lasts forever" | 1 |
| "Super easy to set up and the design is beautiful" | 1 |
| "Exceeded my expectations, fast and reliable" | 1 |
| "Great value, I am very happy with it" | 1 |
| "Comfortable, well made, and arrived early" | 1 |
| "Excellent product, would buy again without hesitation" | 1 |
| "Terrible experience, it broke after two days" | 0 |
| "Awful quality and a complete waste of money" | 0 |
| "Very disappointed, it never worked as advertised" | 0 |
| "Cheap, flimsy, and the worst customer service ever" | 0 |
| "Do not buy this, slow and constantly crashes" | 0 |
| "Hated it, uncomfortable and overpriced" | 0 |
| "Stopped working within a week, totally useless" | 0 |
| "Poor build quality, I regret this purchase" | 0 |

## Why this problem matters

Sentiment is one of the most common real text tasks: routing angry customers to a human first, summarizing app-store feedback, flagging at-risk accounts. A team rarely needs a giant language model for this — a TF-IDF + linear model is fast, cheap, runs on a laptop, and (crucially) is **explainable**: you can show stakeholders the exact words driving each decision. That interpretability is what makes a simple model shippable in a business where someone will ask "why did it flag this review?".

## Step-by-step reasoning

1. **Frame it as binary text classification.** The target is a class (positive/negative), and the input is raw text, so we need a step that turns words into numbers before any model can fit.
2. **Why TF-IDF, not raw counts?** TF-IDF down-weights words that appear in almost every review (low signal) and rewards words that are frequent in *this* review but rare overall. On tiny data this keeps the model focused on words like "loved" / "terrible" instead of filler.
3. **Why a Pipeline?** Vectorizing and classifying are two steps that must stay in lockstep — the SAME fitted vocabulary and IDF weights used in training must be reused at predict time. A `Pipeline` bundles them so `fit` learns the vocabulary on the training split only (no leakage) and `predict` reuses it. It also means we save/serve one object later.
4. **Why a train/test split?** With one dataset it's tempting to score on the data you trained on, which flatters the model. We hold out a few reviews so accuracy/precision/recall reflect unseen text.
5. **Why logistic regression?** It's linear, so each vocabulary word gets a single signed coefficient. Big positive coefficient -> that word pushes toward "positive"; big negative -> toward "negative". That's exactly the interpretability we promised.
6. **Read the coefficients.** Sorting the learned weights gives the most positive and most negative words — a free, honest explanation of what the model learned.

## Python solution

```python
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, precision_score, recall_score

# --- Inline labeled reviews (offline, no downloads) ---
data = [
    ("Absolutely loved this, works perfectly and feels premium", 1),
    ("Best purchase I've made all year, highly recommend", 1),
    ("Fantastic quality and the battery lasts forever", 1),
    ("Super easy to set up and the design is beautiful", 1),
    ("Exceeded my expectations, fast and reliable", 1),
    ("Great value, I am very happy with it", 1),
    ("Comfortable, well made, and arrived early", 1),
    ("Excellent product, would buy again without hesitation", 1),
    ("Terrible experience, it broke after two days", 0),
    ("Awful quality and a complete waste of money", 0),
    ("Very disappointed, it never worked as advertised", 0),
    ("Cheap, flimsy, and the worst customer service ever", 0),
    ("Do not buy this, slow and constantly crashes", 0),
    ("Hated it, uncomfortable and overpriced", 0),
    ("Stopped working within a week, totally useless", 0),
    ("Poor build quality, I regret this purchase", 0),
]
texts = [t for t, _ in data]
labels = np.array([y for _, y in data])
print(len(texts), "reviews")          # 16
```

```python
# --- Stratified split so both train and test keep positives AND negatives ---
X_train, X_test, y_train, y_test = train_test_split(
    texts, labels, test_size=0.25, random_state=0, stratify=labels
)
print(len(X_train), "train /", len(X_test), "test")   # 12 train / 4 test

# --- One Pipeline: text -> TF-IDF features -> logistic regression ---
clf = Pipeline([
    ("tfidf", TfidfVectorizer(lowercase=True, stop_words="english")),
    ("logreg", LogisticRegression(max_iter=1000)),
])
clf.fit(X_train, y_train)             # learns vocabulary + IDF on TRAIN only
```

```python
# --- Evaluate on the held-out reviews ---
y_pred = clf.predict(X_test)
print(f"accuracy : {accuracy_score(y_test, y_pred):.2f}")
print(f"precision: {precision_score(y_test, y_pred, zero_division=0):.2f}")
print(f"recall   : {recall_score(y_test, y_pred, zero_division=0):.2f}")
# precision = of the reviews we called positive, how many really were
# recall    = of the truly positive reviews, how many we caught
```

```python
# --- Interpret the model: which words push positive vs negative? ---
vec = clf.named_steps["tfidf"]
logreg = clf.named_steps["logreg"]
vocab = np.array(vec.get_feature_names_out())
coefs = logreg.coef_[0]                # one signed weight per vocabulary word

order = np.argsort(coefs)              # ascending: most negative first
print("Most NEGATIVE words:", list(vocab[order[:5]]))
print("Most POSITIVE words:", list(vocab[order[-5:]][::-1]))
```

```python
# --- Predict two brand-new reviews (the pipeline reuses the SAME vocab/IDF) ---
new_reviews = [
    "The build quality is excellent and I am very happy",
    "It broke immediately and was a complete waste of money",
]
preds = clf.predict(new_reviews)
probs = clf.predict_proba(new_reviews)[:, 1]    # P(positive)
for r, p, pr in zip(new_reviews, preds, probs):
    label = "POSITIVE" if p == 1 else "NEGATIVE"
    print(f"[{label}  P(pos)={pr:.2f}]  {r}")
```

## Expected output

Running it prints roughly (exact words depend on the split, but the pattern is stable):

```
16 reviews
12 train / 4 test
accuracy : 1.00
precision: 1.00
recall   : 1.00
Most NEGATIVE words: ['waste', 'money', 'broke', 'worst', 'cheap']
Most POSITIVE words: ['loved', 'great', 'excellent', 'happy', 'recommend']
[POSITIVE  P(pos)=0.71]  The build quality is excellent and I am very happy
[NEGATIVE  P(pos)=0.24]  It broke immediately and was a complete waste of money
```

How to read it: the test set here is tiny (4 reviews), so **a perfect score is not impressive** — it mostly tells you the two classes are cleanly separable on this toy data; treat the headline metrics as optimistic. The real payoff is the **coefficient list**: the model independently discovered that "loved", "excellent", "recommend" mean positive and "waste", "broke", "worst" mean negative — a built-in explanation you can show a stakeholder. The two new reviews are classified with sensible probabilities (well away from 0.5), confirming the learned words generalize to unseen sentences.

## Common mistakes

- **Scoring on the training data.** `clf.fit(X, y)` then `clf.score(X, y)` looks amazing and means nothing. Fix: always evaluate on a held-out split (or cross-validate), as above.
- **Fitting the vectorizer on all the text before splitting.** If you call `TfidfVectorizer().fit(all_texts)` first, the test reviews leak into the learned IDF. Fix: put the vectorizer *inside* the Pipeline so `fit` only sees the training split.
- **Trusting accuracy on imbalanced sentiment.** If 90% of reviews are positive, a model that always says "positive" scores 90% accuracy while catching no complaints. Fix: report precision/recall (and the confusion matrix) on the negative class you actually care about.
- **Not stratifying a small split.** Without `stratify=labels`, a 4-review test set can end up all-positive, making precision/recall undefined or misleading. Fix: `stratify=labels`.
- **Ignoring negation.** Unigram TF-IDF treats "not good" as "not" + "good" and can misread it. Fix: add `ngram_range=(1, 2)` so the bigram "not good" becomes its own feature (see the extension).

## Extension challenge

1. Add `ngram_range=(1, 2)` to the `TfidfVectorizer` and re-read the top words. Do negation bigrams like "not worth" appear, and does it change any prediction?
2. Replace the single split with `cross_val_score(clf, texts, labels, cv=4)` and report the mean +/- std. Why is this a more honest estimate on 16 rows than one split?
3. Swap `LogisticRegression` for `LinearSVC` and compare. Note that you lose `predict_proba` — how would you still rank reviews by confidence (hint: `decision_function`)?

## Matching animation

See **"TF-IDF Word Weight Explorer"** (`50 TF-IDF Word Weight Explorer`). Pick a document and watch the bar chart of each word's TF-IDF weight, with its TF (count in this doc) and IDF (how rare across docs) shown feeding the weight. Then use the control to add a word to more documents and watch its IDF — and its weight — collapse. That is exactly why "excellent" and "waste" earned large coefficients here while filler words did not.

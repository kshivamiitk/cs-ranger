# Turning Text into Numbers

> A model can multiply and add, but it has never "read" a word in its life — so before any text touches an algorithm, we have to translate language into a grid of numbers.

## What you'll learn
- Why every ML model needs numeric input, and what goes wrong if you hand it raw strings.
- How to **tokenize** a sentence into words and build a **vocabulary**.
- The **bag-of-words** idea: represent a document as counts over that vocabulary.
- Why these vectors are **sparse** (mostly zeros) and what that costs.
- How to build a tiny bag-of-words table *by hand* before letting a library do it.

## Intuition
Picture the model from earlier chapters: it takes a row of numbers, multiplies each by a weight, and sums them. It has no idea what a "word" is. So the central trick of natural language processing (NLP) is to **turn each document into a fixed-length row of numbers** — then it is just another classification or regression problem.

The simplest reliable recipe has three moves:

1. **Tokenize.** Chop the text into pieces (usually words). `"I love this!"` becomes `["i", "love", "this"]`. We lowercase and drop punctuation so `"Love"` and `"love"` count as the same token.
2. **Build a vocabulary.** Collect every unique token across *all* your documents and give each one a fixed column index. The vocabulary is the shared "header row" for every document.
3. **Count.** For each document, count how many times each vocabulary word appears. That count vector is the document's row of numbers.

This is the **bag-of-words** model. "Bag" because we throw away word *order* — we only keep *which* words appeared and *how often*. `"dog bites man"` and `"man bites dog"` look identical to a bag of words. That's a real limitation, but it is shockingly effective for tasks like spam detection and sentiment, where the *presence* of words ("free", "terrible", "love") carries most of the signal.

The catch: vocabularies get huge. A modest collection of reviews can have tens of thousands of unique words, but any single short review uses only a handful. So each document's vector is almost entirely **zeros** — that's what "sparse" means. We store and compute on these efficiently with sparse matrices, but it's worth seeing *why* the zeros are there.

## Python in practice

Let's do the whole pipeline by hand on three tiny documents, so nothing is hidden:

```python
# Three short "documents"
docs = [
    "I love this movie",
    "I hate this movie",
    "love love love",
]

# 1) Tokenize: lowercase + split on spaces (a real tokenizer also strips punctuation)
tokens_per_doc = [d.lower().split() for d in docs]
print(tokens_per_doc)
# [['i', 'love', 'this', 'movie'],
#  ['i', 'hate', 'this', 'movie'],
#  ['love', 'love', 'love']]

# 2) Build the vocabulary: every unique token, sorted so column order is stable
vocab = sorted({tok for doc in tokens_per_doc for tok in doc})
print(vocab)
# ['hate', 'i', 'love', 'movie', 'this']   -> 5 columns

# 3) Count: for each doc, how many times each vocab word appears
def to_vector(tokens):
    return [tokens.count(word) for word in vocab]

bow = [to_vector(doc) for doc in tokens_per_doc]
for d, row in zip(docs, bow):
    print(f"{row}  <- {d!r}")
# [0, 1, 1, 1, 1]  <- 'I love this movie'
# [1, 1, 0, 1, 1]  <- 'I hate this movie'
# [0, 0, 3, 0, 0]  <- 'love love love'
```

Read the last document's vector: `[0, 0, 3, 0, 0]`. The `3` sits in the `love` column, every other column is `0`. That single row captures "this document is the word *love* three times and nothing else."

```python
# The vocabulary is the shared header for every row:
header = "  ".join(f"{w:>5}" for w in vocab)
print(header)
for row in bow:
    print("  ".join(f"{c:>5}" for c in row))
#  hate      i   love  movie   this
#     0      1      1      1      1
#     1      1      0      1      1
#     0      0      3      0      0
```

```python
# Why "sparse"? Count zeros vs non-zeros.
import numpy as np
M = np.array(bow)
total = M.size
zeros = int((M == 0).sum())
print(f"{zeros}/{total} cells are zero = {zeros/total:.0%} sparsity")
# 8/15 cells are zero = 53% sparsity
# With a real 20,000-word vocabulary and 10-word documents,
# that number climbs to well over 99% zeros.
```

Notice we never told the model what "love" *means*. We only gave it a position in a vector and a count. The meaning emerges later, when a classifier learns that the `love` column tends to go with positive labels.

## Common mistakes
- **Feeding raw strings to a model.** `model.fit(["good", "bad"], y)` throws an error — scikit-learn estimators expect numbers. You must vectorize text first.
- **Skipping lowercasing/cleaning.** Without it, `"Movie"`, `"movie"`, and `"movie!"` become three separate vocabulary columns, fragmenting your signal across near-duplicates.
- **Building a vocabulary from the test set too.** The vocabulary must be learned from *training* data only, then applied to test data. Counting test words into the vocabulary leaks information (you'll see `fit` vs `transform` handle this in the next lesson).
- **Forgetting that order is lost.** Bag-of-words cannot tell `"not good"` from `"good not"`. If word order matters for your task, you'll need n-grams (next lesson) or sequence models (later).
- **Storing bag-of-words as a dense NumPy array at scale.** A `(50000 docs, 30000 words)` dense array is gigabytes of mostly zeros. Real vectorizers return *sparse* matrices that only store the non-zeros.

## Small exercise
1. Take these two documents: `"the cat sat"` and `"the dog ran"`.
2. By hand (no library), write the tokenized lists, the sorted vocabulary, and the two count vectors.
3. How many cells are zero? (Hint: the vocabulary has 5 words and there are 2 documents, so 10 cells; count the zeros and you should get 6 — 60% sparsity.)

## Before you continue
- [ ] I can explain in one sentence why text must become numbers before modeling.
- [ ] Given a few short documents, I can build the vocabulary and the bag-of-words vectors by hand.
- [ ] I can explain what "sparse" means and why bag-of-words vectors are mostly zeros.
- [ ] I understand that bag-of-words throws away word order.

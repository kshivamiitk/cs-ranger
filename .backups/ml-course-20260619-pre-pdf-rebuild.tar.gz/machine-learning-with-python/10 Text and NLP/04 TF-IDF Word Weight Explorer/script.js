"use strict";

/* ============================================================
 * TF-IDF Word Weight Explorer
 * ------------------------------------------------------------
 * Fully deterministic, no libraries. The corpus is defined
 * inline as a constant of exactly 5 documents.
 *
 * FORMULAS (sklearn-style smoothed IDF):
 *   tf(w, d)   = raw count of word w in document d
 *   df(w)      = number of documents that contain w
 *   N          = number of documents (constant = 5)
 *   idf(w)     = ln( (1 + N) / (1 + df(w)) ) + 1      // smoothed, never negative
 *   tfidf(w,d) = tf(w, d) * idf(w)
 *
 * Why smoothed: the +1 terms avoid division by zero and keep
 * IDF >= ~1 even for a word in every doc, so weights never go
 * negative. A word in ALL docs -> idf = ln(6/6)+1 = 1 (its
 * weight is driven only by tf). A word in 1 of 5 docs ->
 * idf = ln(6/2)+1 = ln(3)+1 ~= 2.099 (much heavier).
 * ============================================================ */

/* The original corpus: 5 short, lowercase, ML/everyday sentences.
 * Designed so the lesson lands:
 *   - "model" appears in ALL 5 docs   -> df = 5 -> smallest IDF
 *   - "data" / "learns" mid-frequency -> moderate IDF
 *   - "rocket", "recipe", "garden", "diagnosis", "music" appear
 *     in exactly ONE doc each         -> df = 1 -> largest IDF */
const ORIGINAL_CORPUS = Object.freeze([
  "the model learns patterns from data",
  "the model predicts whether the rocket will launch",
  "a good recipe is a model the cook learns by taste",
  "the garden model learns which plants the data favours",
  "the model gives a diagnosis from patient data and music",
]);

const DOC_LABELS = ["D1", "D2", "D3", "D4", "D5"];

/* Mutable working corpus (arrays of word tokens per doc). */
let corpus = [];

/* ---- tokenisation: split on whitespace, strip basic punctuation ---- */
function tokenize(sentence) {
  return sentence
    .toLowerCase()
    .split(/\s+/)
    .map((t) => t.replace(/[^a-z]/g, "")) // strip basic punctuation
    .filter((t) => t.length > 0);
}

function buildCorpus() {
  corpus = ORIGINAL_CORPUS.map((s) => tokenize(s));
}

/* ---- TF-IDF math ---------------------------------------------------- */
const N = ORIGINAL_CORPUS.length; // N stays 5 throughout

// df(word): how many documents contain the word at least once
function docFreq(word) {
  let df = 0;
  for (const doc of corpus) {
    if (doc.includes(word)) df++;
  }
  return df;
}

// smoothed IDF: ln((1+N)/(1+df)) + 1
function idf(word) {
  return Math.log((1 + N) / (1 + docFreq(word))) + 1;
}

// raw term frequency: count of the word in the given doc index
function termFreq(word, docIdx) {
  let tf = 0;
  for (const t of corpus[docIdx]) {
    if (t === word) tf++;
  }
  return tf;
}

// Per-document breakdown: one row per UNIQUE word in that doc,
// each with { word, tf, idf, tfidf }. Sorted by tfidf descending.
function breakdownFor(docIdx) {
  const seen = new Set();
  const rows = [];
  for (const word of corpus[docIdx]) {
    if (seen.has(word)) continue;
    seen.add(word);
    const tf = termFreq(word, docIdx);
    const wIdf = idf(word);
    rows.push({ word, tf, idf: wIdf, tfidf: tf * wIdf });
  }
  rows.sort((a, b) => b.tfidf - a.tfidf || a.word.localeCompare(b.word));
  return rows;
}

/* ============================================================
 * DOM wiring
 * ============================================================ */
const docSel = document.getElementById("docSel");
const docTextEl = document.getElementById("docText");
const wordSel = document.getElementById("wordSel");
const addBtn = document.getElementById("addBtn");
const resetBtn = document.getElementById("resetBtn");
const dfText = document.getElementById("dfText");
const wbody = document.getElementById("wbody");
const canvas = document.getElementById("bars");
const ctx = canvas.getContext("2d");

let selectedDocIdx = 0;
let hotWord = null; // currently hovered/highlighted word

function fmt(n, dp = 2) {
  return Number(n).toFixed(dp);
}

/* ---- populate the document <select> -------------------------------- */
function populateDocSelect() {
  docSel.innerHTML = "";
  DOC_LABELS.forEach((label, i) => {
    const opt = document.createElement("option");
    const text = ORIGINAL_CORPUS[i];
    const short = text.length > 34 ? text.slice(0, 34) + "…" : text;
    opt.value = String(i);
    opt.textContent = `${label} — ${short}`;
    docSel.appendChild(opt);
  });
  docSel.value = String(selectedDocIdx);
}

/* ---- candidate words for #wordSel ----------------------------------
 * Distinctive words: those currently in FEW docs (df <= 2) and not
 * yet in every document. These are the words whose weight will visibly
 * collapse when spread to more docs. Rebuilt whenever the corpus
 * changes, sorted by current IDF descending (most distinctive first). */
function populateWordSelect() {
  const vocab = new Set();
  for (const doc of corpus) for (const w of doc) vocab.add(w);

  const candidates = [...vocab]
    .filter((w) => {
      const df = docFreq(w);
      return df >= 1 && df < N; // not already in every doc
    })
    .map((w) => ({ w, df: docFreq(w), idf: idf(w) }))
    .sort((a, b) => b.idf - a.idf || a.w.localeCompare(b.w));

  const prev = wordSel.value;
  wordSel.innerHTML = "";
  candidates.forEach(({ w, df }) => {
    const opt = document.createElement("option");
    opt.value = w;
    opt.textContent = `${w}  (in ${df}/${N})`;
    wordSel.appendChild(opt);
  });
  // preserve selection if still valid
  if (candidates.some((c) => c.w === prev)) wordSel.value = prev;

  addBtn.disabled = candidates.length === 0;
}

/* ---- render the document text, highlighting the doc's words -------- */
function renderDocText() {
  docTextEl.innerHTML = "";
  corpus[selectedDocIdx].forEach((word, i) => {
    if (i > 0) docTextEl.appendChild(document.createTextNode(" "));
    const span = document.createElement("span");
    span.className = "w";
    span.dataset.word = word;
    span.textContent = word;
    if (word === hotWord) span.classList.add("hot");
    docTextEl.appendChild(span);
  });
}

/* ---- render the breakdown table ------------------------------------ */
function renderTable(rows) {
  wbody.innerHTML = "";
  rows.forEach((r) => {
    const tr = document.createElement("tr");
    tr.dataset.word = r.word;
    if (r.word === hotWord) tr.classList.add("hot");

    const isZeroish = r.tfidf < 1.05; // a word-in-every-doc tf=1 gives ~1.0
    tr.innerHTML =
      `<td>${r.word}</td>` +
      `<td>${r.tf}</td>` +
      `<td>${fmt(r.idf, 3)}</td>` +
      `<td class="${isZeroish ? "zero" : ""}"><span class="wt">${fmt(r.tfidf, 3)}</span></td>`;
    wbody.appendChild(tr);
  });
}

/* ============================================================
 * Canvas bar chart with eased animation
 * ============================================================ */
const PAD = { top: 26, right: 18, bottom: 14, left: 96 };
const ROW_H = 30;
const ROW_GAP = 10;

// animation state: word -> { cur, target } animated value
let animVals = new Map();
let animRows = []; // the rows currently being drawn (sorted by target)
let rafId = null;

function easeOutCubic(t) {
  return 1 - Math.pow(1 - t, 3);
}

// Begin animating toward the breakdown of the selected doc
function setBars(rows) {
  animRows = rows;
  const next = new Map();
  rows.forEach((r) => {
    const prev = animVals.has(r.word) ? animVals.get(r.word).cur : 0;
    next.set(r.word, { cur: prev, target: r.tfidf, start: prev, t: 0 });
  });
  animVals = next;
  startAnim();
}

function startAnim() {
  if (rafId !== null) cancelAnimationFrame(rafId);
  let last = performance.now();
  const DURATION = 520; // ms

  function tick(now) {
    const dt = now - last;
    last = now;
    let moving = false;
    animVals.forEach((v) => {
      if (v.t < 1) {
        v.t = Math.min(1, v.t + dt / DURATION);
        v.cur = v.start + (v.target - v.start) * easeOutCubic(v.t);
        if (v.t < 1) moving = true;
      }
    });
    drawBars();
    if (moving) {
      rafId = requestAnimationFrame(tick);
    } else {
      rafId = null;
    }
  }
  rafId = requestAnimationFrame(tick);
}

function drawBars() {
  const W = canvas.width;
  const H = canvas.height;
  ctx.clearRect(0, 0, W, H);

  if (animRows.length === 0) return;

  // Scale: max bar = max target weight across visible words (min 1)
  let maxW = 1;
  animRows.forEach((r) => {
    const v = animVals.get(r.word);
    maxW = Math.max(maxW, v ? v.target : 0, r.tfidf);
  });

  const plotW = W - PAD.left - PAD.right;
  const baseX = PAD.left;

  // Bars are sorted by target weight descending (animRows order).
  animRows.forEach((r, i) => {
    const y = PAD.top + i * (ROW_H + ROW_GAP);
    if (y + ROW_H > H) return; // clip overflow

    const v = animVals.get(r.word);
    const val = v ? v.cur : r.tfidf;
    const len = (val / maxW) * plotW;

    const isHot = r.word === hotWord;

    // track
    ctx.fillStyle = "rgba(255,255,255,0.04)";
    roundRect(baseX, y, plotW, ROW_H, 7);
    ctx.fill();

    // bar fill — cyan/violet gradient
    const grad = ctx.createLinearGradient(baseX, 0, baseX + plotW, 0);
    grad.addColorStop(0, isHot ? "#34d399" : "#a78bfa");
    grad.addColorStop(1, isHot ? "#22d3ee" : "#22d3ee");
    ctx.fillStyle = grad;
    roundRect(baseX, y, Math.max(2, len), ROW_H, 7);
    ctx.fill();

    // word label (left of bar)
    ctx.fillStyle = isHot ? "#cffafe" : "#e2e8f0";
    ctx.font = "600 13px ui-monospace, Menlo, monospace";
    ctx.textAlign = "right";
    ctx.textBaseline = "middle";
    ctx.fillText(r.word, baseX - 10, y + ROW_H / 2);

    // value label (at bar end)
    ctx.fillStyle = "#94a3b8";
    ctx.font = "11px ui-monospace, Menlo, monospace";
    ctx.textAlign = "left";
    const valLabel = fmt(val, 2);
    const labelX = baseX + Math.max(2, len) + 8;
    if (labelX < W - 36) {
      ctx.fillText(valLabel, labelX, y + ROW_H / 2);
    } else {
      // draw inside the bar if it would overflow
      ctx.fillStyle = "#0b0b10";
      ctx.textAlign = "right";
      ctx.fillText(valLabel, baseX + len - 8, y + ROW_H / 2);
    }
  });

  // header
  ctx.fillStyle = "#94a3b8";
  ctx.font = "600 11px " + "ui-monospace, Menlo, monospace";
  ctx.textAlign = "left";
  ctx.textBaseline = "alphabetic";
  ctx.fillText("TF-IDF weight  →", PAD.left, 16);
}

function roundRect(x, y, w, h, r) {
  const rr = Math.min(r, h / 2, w / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

/* ---- hover detection over bars ------------------------------------- */
function wordAtPointer(evt) {
  const rect = canvas.getBoundingClientRect();
  const scaleY = canvas.height / rect.height;
  const yPx = (evt.clientY - rect.top) * scaleY;
  for (let i = 0; i < animRows.length; i++) {
    const y = PAD.top + i * (ROW_H + ROW_GAP);
    if (yPx >= y && yPx <= y + ROW_H) return animRows[i].word;
  }
  return null;
}

canvas.addEventListener("mousemove", (e) => {
  const w = wordAtPointer(e);
  if (w !== hotWord) {
    hotWord = w;
    renderDocText();
    const rows = breakdownFor(selectedDocIdx);
    renderTable(rows);
    drawBars();
  }
  canvas.style.cursor = w ? "pointer" : "default";
});
canvas.addEventListener("mouseleave", () => {
  if (hotWord !== null) {
    hotWord = null;
    renderDocText();
    renderTable(breakdownFor(selectedDocIdx));
    drawBars();
  }
});

/* ---- full refresh of the selected doc view ------------------------- */
function refreshDocView(animate = true) {
  const rows = breakdownFor(selectedDocIdx);
  renderDocText();
  renderTable(rows);
  if (animate) {
    setBars(rows);
  } else {
    // snap without animation (e.g. on first load reset baseline)
    animRows = rows;
    animVals = new Map(rows.map((r) => [r.word, { cur: r.tfidf, target: r.tfidf, start: r.tfidf, t: 1 }]));
    drawBars();
  }
}

/* ============================================================
 * Actions
 * ============================================================ */

// Add the chosen word to one more document that doesn't already have it.
function addWordToDoc() {
  const word = wordSel.value;
  if (!word) return;

  const beforeDf = docFreq(word);
  const beforeIdf = idf(word);

  // find a doc (deterministically: lowest index) that lacks the word
  let targetDoc = -1;
  for (let i = 0; i < corpus.length; i++) {
    if (!corpus[i].includes(word)) {
      targetDoc = i;
      break;
    }
  }
  if (targetDoc === -1) {
    dfText.textContent = `“${word}” already appears in all ${N} documents.`;
    dfText.classList.remove("live");
    return;
  }

  // append the word -> df increases by 1
  corpus[targetDoc].push(word);

  const afterDf = docFreq(word);
  const afterIdf = idf(word);

  // narrate the change
  dfText.innerHTML =
    `“${word}” now appears in <b>${afterDf} / ${N}</b> docs ` +
    `→ IDF dropped from <b>${fmt(beforeIdf, 2)}</b> to <b>${fmt(afterIdf, 2)}</b> ` +
    `(was in ${beforeDf}/${N}).`;
  dfText.classList.add("live");

  // If we just changed the currently-selected doc, its bars animate;
  // otherwise jump the view to the doc we touched so the user sees the
  // shrink happen (the word's weight collapses there too).
  populateDocSelect();
  populateWordSelect();
  // keep wordSel pointed at the same word if it's still a candidate
  if ([...wordSel.options].some((o) => o.value === word)) wordSel.value = word;

  refreshDocView(true); // animate the shrink in the current doc

  // also reflect df-driven IDF change for the doc we modified, if different
  if (targetDoc !== selectedDocIdx) {
    // briefly hop selection so the user can watch it land there
    selectedDocIdx = targetDoc;
    docSel.value = String(selectedDocIdx);
    hotWord = word;
    refreshDocView(true);
  } else {
    hotWord = word;
    renderDocText();
    renderTable(breakdownFor(selectedDocIdx));
    drawBars();
  }
}

function resetCorpus() {
  buildCorpus();
  selectedDocIdx = 0;
  hotWord = null;
  populateDocSelect();
  populateWordSelect();
  dfText.textContent = "—";
  dfText.classList.remove("live");
  refreshDocView(false); // snap to baseline, no animation
}

/* ---- events -------------------------------------------------------- */
docSel.addEventListener("change", () => {
  selectedDocIdx = Number(docSel.value);
  hotWord = null;
  refreshDocView(true);
});
addBtn.addEventListener("click", addWordToDoc);
resetBtn.addEventListener("click", resetCorpus);

/* ---- init ---------------------------------------------------------- */
buildCorpus();
populateDocSelect();
populateWordSelect();
refreshDocView(false);

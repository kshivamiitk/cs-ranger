# Build a Text Classifier

> Once text is numbers, classifying it is the same machinery you already know — wrap a vectorizer and a classifier in one Pipeline and you have a working sentiment model in a dozen lines.

## What you'll learn
- Chain a `TfidfVectorizer` and a classifier into a single scikit-learn **Pipeline**.
- Why a Pipeline prevents the most common text-modeling bug (vocabulary leakage).
- Train on a small labeled corpus and **predict new, unseen sentences**.
- Choose between `LogisticRegression` and `MultinomialNB` for text.
- Open the hood and read the **top features** the model learned for each class.

## Intuition
You now have two halves: a way to turn text into vectors (`TfidfVectorizer`) and classifiers that map vectors to labels (`LogisticRegression`, `MultinomialNB`). A **Pipeline** snaps them together so the output of the vectorizer feeds straight into the classifier as one object.

Why bother instead of running them separately? Because the Pipeline guarantees the vectorizer is **fit only on training data** and then *reused* on test/new data. When you later call `pipe.predict(["some new sentence"])`, the Pipeline silently runs that text through the *already-learned* vocabulary before predicting. No leakage, no shape mismatches, one object to save and ship.

Two classic choices for text:

- **`LogisticRegression`** learns a weight per word. A big positive weight = "this word pushes toward the positive class." It's interpretable (you can read those weights), strong, and the default many practitioners reach for.
- **`MultinomialNB`** (Multinomial Naive Bayes) is built for word *counts*. It's extremely fast, needs little data, and is a great baseline for text. It assumes words are independent given the label — naive, but it works well in practice.

The real payoff of a linear text model is that you can **inspect what it learned**. Each word has a coefficient; sorting them shows the most "positive" and most "negative" words. That turns a black box into something you can sanity-check and explain to a stakeholder.

## Python in practice

A tiny labeled corpus — short reviews, `1` = positive, `0` = negative:

```python
texts = [
    "I loved this film, it was fantastic and fun",
    "Absolutely wonderful, a brilliant and moving story",
    "Great acting and a beautiful, heartfelt ending",
    "What a delightful, charming little movie",
    "Best film I have seen all year, truly excellent",
    "Terrible movie, boring and a complete waste of time",
    "I hated it, the plot was awful and dull",
    "Poorly acted and painfully slow, very disappointing",
    "A bad, forgettable mess with no redeeming qualities",
    "Worst film ever, I want my money back",
]
labels = [1, 1, 1, 1, 1, 0, 0, 0, 0, 0]   # 1 = positive, 0 = negative
```

Build and train the Pipeline:

```python
from sklearn.pipeline import Pipeline
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression

pipe = Pipeline([
    ("tfidf", TfidfVectorizer(stop_words="english")),   # text -> numbers
    ("clf",   LogisticRegression(max_iter=1000)),       # numbers -> label
])

pipe.fit(texts, labels)   # vectorizer learns vocab, then classifier learns weights
print("Training accuracy:", pipe.score(texts, labels))
# Training accuracy: 1.0   (tiny, clean dataset -> easy to fit perfectly)
```

Predict brand-new sentences the model has never seen:

```python
new_reviews = [
    "an excellent and moving film",
    "a dull and boring waste",
    "the story was charming and fun",
]
preds = pipe.predict(new_reviews)
probs = pipe.predict_proba(new_reviews)[:, 1]   # P(positive)

for review, p, prob in zip(new_reviews, preds, probs):
    sentiment = "POSITIVE" if p == 1 else "NEGATIVE"
    print(f"[{sentiment}  p={prob:.2f}]  {review}")
# [POSITIVE  p=0.71]  an excellent and moving film
# [NEGATIVE  p=0.22]  a dull and boring waste
# [POSITIVE  p=0.69]  the story was charming and fun
```

Inspect the top features the model learned:

```python
import numpy as np

vec = pipe.named_steps["tfidf"]
clf = pipe.named_steps["clf"]
words = vec.get_feature_names_out()
coefs = clf.coef_[0]               # one weight per word (positive class)

order = np.argsort(coefs)
print("Most NEGATIVE words:")
for i in order[:5]:
    print(f"  {words[i]:>15}  {coefs[i]:+.2f}")

print("Most POSITIVE words:")
for i in order[-5:][::-1]:
    print(f"  {words[i]:>15}  {coefs[i]:+.2f}")
# Most NEGATIVE words:   boring / terrible / awful / waste / bad   (negative weights)
# Most POSITIVE words:   fantastic / brilliant / excellent / loved / great
```

Those word lists are the explanation: the model decided "fantastic" and "excellent" lean positive, "boring" and "awful" lean negative — exactly what a human would say. That sanity check is something you can show in a portfolio or to a non-technical reviewer.

Swapping in Naive Bayes is a one-line change:

```python
from sklearn.naive_bayes import MultinomialNB

nb_pipe = Pipeline([
    ("tfidf", TfidfVectorizer(stop_words="english")),
    ("clf",   MultinomialNB()),
])
nb_pipe.fit(texts, labels)
print(nb_pipe.predict(["an excellent and moving film"]))   # [1]  positive
```

## Common mistakes
- **Vectorizing outside the Pipeline.** If you `fit_transform` on all data first, then split, your vocabulary saw the test set — leakage. Let the Pipeline fit the vectorizer on train only.
- **Reading `predict_proba` as truth.** A `p=0.71` is the model's confidence, not a guarantee. With only 10 training examples, probabilities are rough — trust the *direction* more than the exact number.
- **Reporting training accuracy as if it's real performance.** A perfect 1.0 on the training set just means the model memorized 10 sentences. Real evaluation needs a held-out split (next lesson).
- **Pulling `clf.coef_` from a non-linear model.** Top-feature inspection works because Logistic Regression / Naive Bayes are linear in the features. A random forest or SVM-with-rbf has no single weight per word.
- **Mismatching the classifier to the input.** `MultinomialNB` assumes non-negative features (counts/TF-IDF are fine). Don't feed it scaled data with negatives.

## Small exercise
1. Add two more reviews to `texts`/`labels` (one positive, one negative) in your own words.
2. Retrain the Pipeline and re-run the top-features inspection.
3. Did your new words appear in the most-positive or most-negative lists? If a word appears in only one review, note how strongly it gets weighted — and why that's a small-data warning sign.

## Before you continue
- [ ] I can build a `Pipeline([("tfidf", ...), ("clf", ...)])` and call `.fit` then `.predict`.
- [ ] I can explain why a Pipeline prevents vocabulary leakage.
- [ ] I can extract `coef_` and `get_feature_names_out()` to list the most positive/negative words.
- [ ] I know why training accuracy alone is not a real performance measure.

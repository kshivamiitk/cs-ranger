# Bag-of-Words and TF-IDF

> Counting words works, but the word "the" appears everywhere and tells you nothing — TF-IDF is the simple weighting trick that quiets common words and lets the rare, informative ones speak up.

## What you'll learn
- Turn the hand-built bag-of-words from last lesson into one line of scikit-learn with `CountVectorizer`.
- The intuition behind **term frequency (TF)** and **inverse document frequency (IDF)**.
- When to reach for `TfidfVectorizer` instead of `CountVectorizer`.
- What **stopwords** are and why removing them helps.
- How **n-grams** let bag-of-words remember short phrases like "not good".

## Intuition
Plain counts have a bias: words that appear in *every* document (like "the", "is", "movie" in a movie-review dataset) get big counts but carry almost no discriminating power. Meanwhile a word like "refund" might appear once, in one document, yet be incredibly telling. Raw counts reward the wrong words.

**TF-IDF** fixes this by multiplying two ideas:

- **Term Frequency (TF):** how often a word appears *in this document*. More mentions = more important *to this document*. (`"love love love"` should weight "love" heavily.)
- **Inverse Document Frequency (IDF):** how *rare* a word is *across all documents*. A word in every document gets an IDF near zero; a word in one document gets a large IDF. The formula is roughly `idf(word) = log(total_docs / docs_containing_word)`, so common words shrink and rare words grow.

Multiply them: `tfidf = tf * idf`. The result is high only when a word is **frequent here but rare elsewhere** — exactly the words that distinguish one document from another. Common filler words score low automatically, without you hand-listing them.

Two more practical levers:

- **Stopwords** are ultra-common words ("the", "and", "is", "of") that you can drop entirely. TF-IDF already down-weights them, but removing them shrinks the vocabulary and speeds things up. Pass `stop_words="english"` to use scikit-learn's built-in list.
- **N-grams** glue adjacent words into tokens. A *unigram* is one word ("good"); a *bigram* is two ("not good"). Setting `ngram_range=(1, 2)` keeps both, so the model can finally tell "not good" from "good" — recovering a little of the word order that plain bag-of-words throws away.

## Python in practice

First, `CountVectorizer` reproduces our by-hand bag-of-words automatically:

```python
from sklearn.feature_extraction.text import CountVectorizer

docs = [
    "I love this movie",
    "I hate this movie",
    "love love love",
]

count_vec = CountVectorizer()          # lowercases + tokenizes for us
X_counts = count_vec.fit_transform(docs)   # learns vocab AND counts in one call

print(count_vec.get_feature_names_out())
# ['hate' 'love' 'movie' 'this']   <- note: 'i' was dropped (single-letter tokens)
print(X_counts.toarray())
# [[0 1 1 1]
#  [1 0 1 1]
#  [0 3 0 0]]
print(type(X_counts))
# <class 'scipy.sparse._csr.csr_matrix'>  <- stored sparse, .toarray() just for viewing
```

`fit_transform` does two jobs at once: **fit** learns the vocabulary, **transform** produces the count matrix. On new/test data you call `transform` only, reusing the vocabulary learned from training.

Now swap in `TfidfVectorizer` and watch common words get demoted:

```python
from sklearn.feature_extraction.text import TfidfVectorizer
import numpy as np

tfidf = TfidfVectorizer()
X_tfidf = tfidf.fit_transform(docs)

words = tfidf.get_feature_names_out()
print(words)
# ['hate' 'love' 'movie' 'this']

np.set_printoptions(precision=2, suppress=True)
print(X_tfidf.toarray())
# [[0.   0.62 0.62 0.62]      <- doc 0: love/movie/this share weight
#  [0.66 0.   0.5  0.5 ]      <- doc 1: 'hate' (rare) scores highest
#  [0.   1.   0.   0.  ]]     <- doc 2: only 'love', fully weighted

# IDF per word: rarer words get a larger value
for w, idf in zip(words, tfidf.idf_):
    print(f"{w:>6}: idf={idf:.3f}")
#   hate: idf=1.693   <- appears in 1 of 3 docs  -> high
#   love: idf=1.288
#  movie: idf=1.288
#   this: idf=1.288   <- appears in 2 of 3 docs  -> lower
```

Notice in document 1, `hate` (which appears in only one document) gets the *largest* weight — TF-IDF surfaced the most distinctive word automatically.

Stopwords and n-grams in action:

```python
sample = ["the movie was not good", "the movie was good"]

# Default: stopwords kept, only unigrams -> can't distinguish the two sentences well
plain = CountVectorizer()
plain.fit(sample)
print(sorted(plain.get_feature_names_out()))
# ['good', 'movie', 'not', 'the', 'was']

# With stopwords removed and bigrams added:
better = CountVectorizer(stop_words="english", ngram_range=(1, 2))
better.fit(sample)
print(sorted(better.get_feature_names_out()))
# ['good', 'movie', 'movie good', 'movie good', ... , 'not good', ...]
# Key win: 'not good' is now its OWN token, so 'not good' != 'good'.
```

## Common mistakes
- **Calling `fit_transform` on test data.** That re-learns the vocabulary from the test set and leaks information. Always `fit_transform` on train, then `transform` on test.
- **Expecting `CountVectorizer` to keep single letters.** By default its token pattern requires 2+ characters, so `"I"` and `"a"` disappear. Adjust `token_pattern` if you truly need them.
- **Removing stopwords blindly.** For sentiment, words like "not", "no", "never" are technically near-stopwords but flip meaning. Test with and without — sometimes keeping them (plus bigrams) wins.
- **Letting n-grams explode the vocabulary.** `ngram_range=(1, 3)` on a large corpus can create millions of features. Pair it with `min_df` (ignore terms in fewer than N docs) or `max_features` to keep it sane.
- **Forgetting TF-IDF rows are L2-normalized by default.** Each document vector has length 1, so you can't read raw counts off the matrix — use `CountVectorizer` if you need actual counts.

## Small exercise
1. Take `docs = ["good film great acting", "bad film bad acting", "great great film"]`.
2. Fit a `TfidfVectorizer` and print `get_feature_names_out()` and the dense matrix.
3. Which word has the highest IDF, and why? (Hint: find the word that appears in the fewest documents — it should be "good" or "bad", each in just one document.)

## Before you continue
- [ ] I can explain TF and IDF in plain words and why their product favors rare-but-frequent terms.
- [ ] I know to use `fit_transform` on train and `transform` on test.
- [ ] I can add `stop_words="english"` and `ngram_range=(1, 2)` and explain what each changes.
- [ ] I understand why TF-IDF rows don't show raw counts.

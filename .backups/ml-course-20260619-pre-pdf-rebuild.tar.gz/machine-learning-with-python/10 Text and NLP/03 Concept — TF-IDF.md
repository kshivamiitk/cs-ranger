# TF-IDF

> Counting words treats "the" and "refund" as equally important. TF-IDF fixes that by rewarding rare, distinctive words and punishing the ones everybody uses.

## What is this?

**TF-IDF** stands for **Term Frequency × Inverse Document Frequency**. It turns a piece of text into a list of numbers — one number per word — where each number says *how important that word is to this specific document*. It's built from two halves multiplied together:

- **TF (Term Frequency)** — how often a word appears *in this document*. A word you repeat a lot is probably about your topic, so it gets a higher TF.
- **IDF (Inverse Document Frequency)** — how *rare* the word is *across all documents*. A word that shows up in nearly every document (like "the" or "and") is useless for telling documents apart, so IDF crushes it toward zero. A word that appears in only a few documents is distinctive, so IDF boosts it.

Multiply them: `tfidf = tf * idf`. A word scores high only when it's **frequent here but rare overall** — exactly the words that make a document distinctive.

The result is a **sparse vector**: most entries are zero (because most documents use only a tiny slice of all possible words). And it's worth being clear about the limit: TF-IDF is pure bookkeeping over word *counts*. It does **not understand meaning** — to it, "good" and "great" are unrelated, and "not good" looks like the words "not" and "good" sitting side by side.

## Why do we need it?

The naive way to turn text into numbers is **raw counts** (bag-of-words): just tally how many times each word appears. The problem is that the most *common* words dominate — "the," "is," "a," "and" appear constantly and swamp everything. Two completely different documents about cooking and finance both have huge counts for "the," so raw counts make them look similar for the wrong reason.

TF-IDF fixes this automatically. By down-weighting words that appear everywhere and up-weighting rare distinctive words, it makes the numbers reflect what a document is actually *about*. You get a representation where "refund" and "broken" carry real signal in a complaints dataset, while "the" quietly fades to nearly nothing — **no manual stop-word list required**.

## Where it's used in real ML

- **Text classification** — spam filtering, sentiment analysis, topic tagging. TF-IDF features feed straight into a classifier like logistic regression and work remarkably well for short texts.
- **Search and ranking** — classic search engines score how relevant a document is to a query using TF-IDF-style weights.
- **Finding keywords** — the highest-TF-IDF words in a document are a quick, label-free summary of what it's about.
- **A strong, cheap baseline** — before reaching for heavy neural models, TF-IDF + a linear model is fast, interpretable, and often hard to beat on small/medium datasets.

## What breaks if you ignore it

- **Use raw counts instead and common words win.** Your model "learns" that documents are similar because they all contain "the," and accuracy suffers.
- **Hand-pick stop words and you'll miss some.** Maintaining a stop-word list by hand is brittle; TF-IDF down-weights uninformative words *automatically* from the data.
- **Forget that it ignores meaning and you'll over-trust it.** It can't tell "not good" from "good," can't catch sarcasm, and treats synonyms as unrelated. If you forget this, you'll be surprised when it fails on negation or paraphrase.

## Mental model

Think of a **highlighter that highlights smarter than you do**. A naive highlighter colors every word it sees a lot — so it floods the page with "the," "and," "is." Useless.

TF-IDF is a highlighter with two rules working together:

```
   How loud should this word be in THIS document?

   loud  ^                      * "refund"   (frequent here, rare elsewhere)
         |                     /
         |          * "delivery"
         |        /
         |   * "order"
   quiet |  *_________________________________> 
         "the"   "and"   "is"   (everywhere -> silenced by IDF)
              common across all docs
```

A word gets the spotlight only if you say it a lot here **and** hardly anyone else says it. Words that everyone uses get dimmed to silence. What's left highlighted is the document's fingerprint.

## Example 1 — Tiny toy example

A 3-document corpus (counting "the cat" as two words each, lowercased):

- **Doc 1:** "the cat sat"
- **Doc 2:** "the dog sat"
- **Doc 3:** "the cat ran"

Let's score the word **"cat" in Doc 1** by hand, using the plain textbook formulas.

**Term Frequency (TF)** — how often "cat" appears in Doc 1, as a fraction of Doc 1's words. Doc 1 has 3 words and "cat" appears once:

```
TF("cat", Doc1) = 1 / 3 = 0.333
```

**Inverse Document Frequency (IDF)** — how rare "cat" is across the 3 documents. "cat" appears in Doc 1 and Doc 3, so in **2** of the **3** documents. Using `IDF = log10(N / df)`:

```
IDF("cat") = log10(3 / 2) = log10(1.5) = 0.176
```

**TF-IDF** — multiply them:

```
TF-IDF("cat", Doc1) = 0.333 * 0.176 = 0.0587
```

Now compare with **"the"**, which appears in **all 3** documents:

```
IDF("the") = log10(3 / 3) = log10(1) = 0.0
TF-IDF("the", anywhere) = TF * 0 = 0.0
```

That's the whole point in one line: **"cat" gets a positive score; "the" gets exactly zero**, because a word in *every* document carries no power to distinguish them. (Real libraries like scikit-learn use a smoothed IDF and normalize vectors, so the exact numbers differ — but the *ordering* and the intuition are identical.)

## Example 2 — Practical ML example

You have a few hundred short product reviews labeled **positive** or **negative**, and you want a sentiment classifier.

You run scikit-learn's `TfidfVectorizer` over the reviews. It builds the vocabulary, computes TF-IDF for every word in every review, and hands you a sparse matrix: one row per review, one column per vocabulary word. You feed that straight into **`LogisticRegression`**. Because the classifier is linear, each word ends up with a learned weight — so afterward you can sort those weights and **read off the most positive and most negative words**: you'll typically see "love," "great," "perfect" with large positive weights and "broken," "refund," "worst" with large negative ones. That interpretability — *seeing exactly which words drive the prediction* — is a big reason TF-IDF plus a linear model remains a go-to baseline. The catch surfaces on a review like "not good at all": TF-IDF sees the words "not" and "good" independently, with no notion that "not" flips "good," so negation is where this simple pipeline starts to slip.

## Python code example

```python
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import numpy as np

# --- Inline data: tiny labeled review corpus (1 = positive, 0 = negative) ---
texts = [
    "i love this product it is great",
    "absolutely fantastic and works perfectly",
    "great quality very happy",
    "this is broken and a total waste",
    "terrible product i want a refund",
    "worst purchase awful and broken",
]
labels = [1, 1, 1, 0, 0, 0]

# STEP 1 — Turn text into TF-IDF vectors. Each row = a review, each column = a word.
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(texts)
print("matrix shape (rows=reviews, cols=vocab words):", X.shape)
print("the matrix is sparse:", type(X).__name__, "-> mostly zeros")

# Peek at one review's nonzero TF-IDF weights to see common vs rare words differ.
vocab = np.array(vectorizer.get_feature_names_out())
row0 = X[0].toarray().ravel()
nz = row0 > 0
print("\nDoc 0 words and TF-IDF weights:",
      dict(zip(vocab[nz], np.round(row0[nz], 3))))

# STEP 2 — Train a linear classifier on the TF-IDF features.
clf = LogisticRegression()
clf.fit(X, labels)

# STEP 3 — Inspect which words push toward positive vs negative.
weights = clf.coef_[0]
order = np.argsort(weights)
print("\nMost NEGATIVE words:", list(vocab[order[:3]]))
print("Most POSITIVE words:", list(vocab[order[-3:]]))

# STEP 4 — Predict sentiment for a brand-new review.
new_review = ["this product is fantastic and i love it"]
pred = clf.predict(vectorizer.transform(new_review))[0]
print("\nNew review predicted as:", "positive" if pred == 1 else "negative")
```

This prints the sparse-matrix shape, the per-word TF-IDF weights for one review, the words the model found most positive/negative, and a prediction for unseen text — the full TF-IDF → logistic-regression baseline end to end.

## Common mistakes

- **Using raw counts when TF-IDF is the better default.** Plain `CountVectorizer` lets common words dominate; `TfidfVectorizer` is usually the stronger baseline for the same effort.
- **Fitting the vectorizer on test data.** Call `fit_transform` on the *training* texts only, then `transform` the test texts. Fitting on everything leaks the test vocabulary and inflates your scores.
- **Expecting it to understand meaning.** TF-IDF has no idea that "good" and "great" are similar, and it can't handle negation ("not good"). It's word bookkeeping, not comprehension.
- **Ignoring n-grams for phrases.** Single words lose word order, so "not good" is invisible. Use `ngram_range=(1, 2)` to capture two-word phrases when phrasing matters.
- **Forgetting consistent preprocessing.** Lowercasing and tokenization must match between fit and transform. Re-using the *same fitted vectorizer* (not a fresh one) keeps the vocabulary and column order aligned.

## Before you continue
- [ ] I can explain TF and IDF in one sentence each, and why we multiply them.
- [ ] I can say why a word appearing in every document gets an IDF (and TF-IDF) of zero.
- [ ] I know why TF-IDF beats raw counts as a default text representation.
- [ ] I can describe the `TfidfVectorizer` → `LogisticRegression` pipeline and how to read its top words.
- [ ] I understand that TF-IDF does not capture meaning, synonyms, or negation.

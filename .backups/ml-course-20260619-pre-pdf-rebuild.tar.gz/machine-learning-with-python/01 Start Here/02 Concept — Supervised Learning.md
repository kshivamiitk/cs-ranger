# Supervised Learning

> The simplest, most useful idea in ML: show the machine plenty of examples where you *already know the answer*, and it learns to answer the next one for you.

## What is this?

Supervised learning is teaching by example. You hand the algorithm a pile of past cases where each input comes paired with its correct, already-known answer — the **label**. The algorithm studies that pile and figures out the rule that maps inputs to answers. Then you point it at brand-new inputs it has never seen and it predicts the answer.

The word *supervised* is literal: during training, a "supervisor" (your historical data) tells the model the right answer for every example, so it can check its own guesses and correct itself.

There are two flavors, decided entirely by what the answer looks like:

- **Classification** — the answer is a *category*: spam / not spam, will churn / won't churn, cat / dog / horse.
- **Regression** — the answer is a *number*: a house price, tomorrow's temperature, expected monthly revenue.

Same idea, same workflow (`fit` then `predict`); only the type of answer changes.

## Why do we need it?

Because for a huge class of real problems, **you have the answers for the past but not for the future**, and the rule connecting them is too messy to write by hand.

You can pull up a year of past credit-card transactions and label each one fraud or legit — but nobody can hand-write a clean `if/else` that catches tomorrow's fraud, because fraud patterns shift and interact. Supervised learning lets you convert "answers we already collected" into "a rule that predicts answers we don't have yet." That is most of the money-making ML in industry.

## Where it's used in real ML

- **Email spam filters** — trained on millions of emails humans marked spam or not.
- **Customer churn prediction** — labeled with "this customer left" / "this customer stayed" from past months.
- **Medical screening** — X-rays labeled by radiologists as healthy / abnormal.
- **Price and demand forecasting** — past sales used as the known numeric answer (regression).
- **Loan approval scoring** — historical loans labeled repaid / defaulted.

If a problem has a clear right answer you can collect for past cases, it's almost certainly a supervised-learning problem.

## What breaks if you ignore it

If you reach for unsupervised methods (or no ML at all) when you actually *have* labels, you throw away your most valuable signal. Clustering customers without using your known "churned" label gives you fuzzy groups that may have nothing to do with churn — you optimized for the wrong thing.

The opposite mistake is just as costly: trying to do supervised learning **without honest labels**. If your "spam" labels are sloppy or biased, the model faithfully learns the sloppiness. Garbage labels in, garbage predictions out — and you won't notice until it's making confident, wrong calls in production.

## Mental model

Think of a **flashcard study session**. Each card has a question on the front and the correct answer on the back. You go through hundreds of cards, peeking at the back to check yourself, until you can answer cards you've never seen.

```
        TRAINING (answers visible)            PREDICTION (answer hidden)
   ┌──────────────┬───────────────┐
   │   INPUT (X)  │  ANSWER (y)   │              new input  ──►  [ model ]  ──►  guess
   ├──────────────┼───────────────┤                                  ▲
   │  6 hrs study │     PASS      │                                  │
   │  1 hr  study │     FAIL      │   ──►  [ learn the rule ]  ───────┘
   │  4 hrs study │     PASS      │
   └──────────────┴───────────────┘
        front of card   back of card
```

Training = studying cards with the back visible. Prediction = a quiz where the back is covered and the model must answer on its own.

## Example 1 — Tiny toy example

Five students. We know how many hours each studied and whether they passed. The label (PASS/FAIL) is a category, so this is **classification**.

| Hours studied (input) | Result (label) |
|----------------------:|:---------------|
| 1                     | FAIL           |
| 2                     | FAIL           |
| 4                     | PASS           |
| 5                     | PASS           |
| 6                     | PASS           |

Eyeball it: low hours -> FAIL, high hours -> PASS, with the flip somewhere around 3 hours. A supervised model learns exactly that threshold from these five rows. Now a **new** student studied 3.5 hours — not in our table. The model applies its learned rule and predicts **PASS**. That is supervised learning in one breath: learn from labeled rows, predict an unlabeled one.

## Example 2 — Practical ML example

**Churn prediction for a subscription app.** You export the last 12 months of accounts. Each row is one customer, and because these are *past* customers you already know the true outcome.

- **Inputs (features):** logins in last 30 days, average session minutes, support tickets opened, months subscribed, plan tier.
- **Label:** `churned` = 1 if they canceled, 0 if they stayed.

You train a classifier on these labeled rows. It discovers patterns like "few recent logins + several support tickets -> high churn risk." Then you run it on your *current, still-active* customers (whose future is unknown) to get a churn-risk score for each. The team reaches out to the high-risk ones before they leave. The label you collected from the past became a forecast for the present.

## Python code example

```python
# Supervised classification end to end: learn from labeled rows, predict unseen input.
from sklearn.linear_model import LogisticRegression

# X = inputs (must be 2D: one row per example, one column per feature).
# y = the KNOWN answers (labels). This pairing is what makes it "supervised".
X = [[1], [2], [4], [5], [6]]   # hours studied
y = ["FAIL", "FAIL", "PASS", "PASS", "PASS"]  # known result for each

model = LogisticRegression()
model.fit(X, y)   # "supervisor" shows answers; model learns the hours->result rule

# Predict for a NEW student who studied 3.5 hours (never seen during training):
new_student = [[3.5]]
print("Prediction for 3.5 hrs:", model.predict(new_student)[0])

# How confident is it? predict_proba gives a probability per class.
classes = model.classes_
probs = model.predict_proba(new_student)[0]
for label, p in zip(classes, probs):
    print(f"  P({label}) = {p:.2f}")

# Sanity check: it should ace the examples it learned from.
print("Accuracy on training rows:", model.score(X, y))
```

Expected output (numbers approximate):

```
Prediction for 3.5 hrs: PASS
  P(FAIL) = 0.33
  P(PASS) = 0.67
  Accuracy on training rows: 1.0
```

The model was never told "the cutoff is 3 hours." It inferred a hours-to-result rule from the five labeled examples, then applied it to an input it had never seen.

## Common mistakes

- **No real labels.** Supervised learning *requires* known answers for past data. If you can't collect honest labels, this whole approach is off the table.
- **Confusing classification and regression.** Category answer -> classification; numeric answer -> regression. Pick wrong and you'll choose the wrong model and the wrong success metric.
- **Judging on data it trained on.** A model can memorize its training rows and look perfect, yet fail on new data. Always test on examples it has never seen.
- **Leaky labels.** If a feature secretly encodes the answer (e.g. a `cancellation_date` column when predicting churn), the model "cheats" in training and collapses in production.
- **Believing biased labels are neutral.** The model copies whatever bias is in your labels — it does not correct it.

## Before you continue
- [ ] I can state, in one sentence, what makes learning "supervised."
- [ ] I can tell classification from regression by looking only at the label.
- [ ] I can name a real product that is built on supervised learning.
- [ ] I understand why testing on unseen data matters more than scoring on training data.
- [ ] I can spot why a leaky or biased label ruins a supervised model.

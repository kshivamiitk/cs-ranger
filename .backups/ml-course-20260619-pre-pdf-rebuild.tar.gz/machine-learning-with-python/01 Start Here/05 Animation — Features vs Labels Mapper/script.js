"use strict";

/* ------------------------------------------------------------------ *
 * Features vs Labels Mapper
 * Teaches the single most important pre-modeling decision in
 * supervised learning: which columns are FEATURES (X, the inputs) and
 * which ONE column is the TARGET / LABEL (y, the answer to predict).
 *
 *   X  -> 2-D matrix, shape (n_samples, n_features)
 *   y  -> 1-D vector, shape (n_samples,)
 *
 * The learner drags column headers into three bins (Features / Target /
 * Ignore). "Build X / y" animates the table splitting into the X block
 * and y column and prints the matching scikit-learn slice. Two presets
 * show the target can be a NUMBER (regression) or a CATEGORY
 * (classification). No randomness anywhere -> fully deterministic.
 * ------------------------------------------------------------------ */

// ----- Datasets (hand-authored, deterministic) -----
const DATASETS = {
  housing: {
    task: "regression",
    targetType: "number (continuous)",
    df: "homes",
    columns: [
      { name: "house_id",      type: "id",   suggest: "ignore" },
      { name: "size_sqft",     type: "num",  suggest: "features" },
      { name: "bedrooms",      type: "num",  suggest: "features" },
      { name: "age_years",     type: "num",  suggest: "features" },
      { name: "neighborhood",  type: "cat",  suggest: "features" },
      { name: "price",         type: "num",  suggest: "target" }
    ],
    rows: [
      ["H-01", 1450, 3, 12, "Maple",   412000],
      ["H-02",  980, 2, 31, "Downtown", 305000],
      ["H-03", 2100, 4,  5, "Maple",   598000],
      ["H-04", 1600, 3, 22, "Riverside", 449000],
      ["H-05",  740, 1, 48, "Downtown", 221000],
      ["H-06", 2750, 5,  2, "Riverside", 712000]
    ]
  },
  churn: {
    task: "classification",
    targetType: "category (yes / no)",
    df: "telco",
    columns: [
      { name: "customer_id",     type: "id",  suggest: "ignore" },
      { name: "tenure_months",   type: "num", suggest: "features" },
      { name: "monthly_charges", type: "num", suggest: "features" },
      { name: "contract",        type: "cat", suggest: "features" },
      { name: "support_calls",   type: "num", suggest: "features" },
      { name: "churned",         type: "cat", suggest: "target" }
    ],
    rows: [
      ["C-1001",  2,  79.9, "month-to-month", 4, "yes"],
      ["C-1002", 34,  56.2, "two-year",       0, "no"],
      ["C-1003",  9,  99.4, "month-to-month", 3, "yes"],
      ["C-1004", 48,  45.0, "two-year",       1, "no"],
      ["C-1005",  5,  88.1, "one-year",       2, "yes"],
      ["C-1006", 22,  61.7, "one-year",       0, "no"]
    ]
  }
};

// ----- DOM -----
const presetSel    = document.getElementById("preset");
const taskTag      = document.getElementById("taskTag");
const tableHead    = document.getElementById("tableHead");
const tableBody    = document.getElementById("tableBody");
const chipTray     = document.getElementById("chipTray");
const splitOverlay = document.getElementById("splitOverlay");
const showArrows   = document.getElementById("showArrows");
const buildBtn     = document.getElementById("build");
const resetBtn     = document.getElementById("reset");

const dropFeatures = document.getElementById("dropFeatures");
const dropTarget   = document.getElementById("dropTarget");
const dropIgnore   = document.getElementById("dropIgnore");

const binEls = {
  tray:     chipTray,
  features: dropFeatures,
  target:   dropTarget,
  ignore:   dropIgnore
};
// the visual "hover highlight" container for each drop region
const binBoxEls = {
  tray:     chipTray,
  features: document.getElementById("binFeatures"),
  target:   document.getElementById("binTarget"),
  ignore:   document.getElementById("binIgnore")
};

const elUnassigned = document.getElementById("unassignedVal");
const rTask    = document.getElementById("rTask");
const rX       = document.getElementById("rX");
const rY       = document.getElementById("rY");
const rType    = document.getElementById("rType");
const rStatus  = document.getElementById("rStatus");
const snippetCode = document.getElementById("snippetCode");

// ----- State -----
let current = null;          // active dataset object
// assignment: column name -> "tray" | "features" | "target" | "ignore"
let assignment = {};
let built = false;

// ----- Build the table + chips for a dataset -----
function loadDataset(key) {
  current = DATASETS[key];
  built = false;
  assignment = {};
  for (const c of current.columns) assignment[c.name] = "tray";

  // header row
  tableHead.innerHTML = "";
  current.columns.forEach((c, ci) => {
    const th = document.createElement("th");
    th.textContent = c.name;
    th.dataset.col = c.name;
    th.dataset.ci = String(ci);
    attachHeaderDrag(th, c.name);
    tableHead.appendChild(th);
  });

  // body rows
  tableBody.innerHTML = "";
  current.rows.forEach(row => {
    const tr = document.createElement("tr");
    row.forEach((cell, ci) => {
      const td = document.createElement("td");
      td.textContent = String(cell);
      td.dataset.ci = String(ci);
      tr.appendChild(td);
    });
    tableBody.appendChild(tr);
  });

  // task tag
  taskTag.textContent = current.task;
  taskTag.className = "task-tag" + (current.task === "classification" ? " classify" : "");

  clearOverlay();
  renderBins();
  refreshReadout();
}

// ----- Render chips into bins/tray based on `assignment` -----
function renderBins() {
  for (const k of Object.keys(binEls)) binEls[k].innerHTML = "";
  for (const c of current.columns) {
    const where = assignment[c.name];
    binEls[where].appendChild(makeChip(c, where));
  }
  clearColumnRoles();
  refreshReadout();
}

function makeChip(col, where) {
  const chip = document.createElement("div");
  chip.className = "chip";
  if (where === "features") chip.classList.add("in-features");
  else if (where === "target") chip.classList.add("in-target");
  else if (where === "ignore") chip.classList.add("in-ignore");
  chip.dataset.col = col.name;

  const label = document.createElement("span");
  label.textContent = col.name;
  chip.appendChild(label);

  const t = document.createElement("span");
  t.className = "chip-type";
  t.textContent = col.type;
  chip.appendChild(t);

  // tap a placed chip to send it back to the tray (also drag-able)
  attachChipDrag(chip, col.name);
  return chip;
}

// ------------------------------------------------------------------ *
// Pointer-based drag & drop (works for mouse + touch, no libraries)
// Dragging a chip OR a column header drops the column into a bin.
// ------------------------------------------------------------------ */
let drag = null; // { col, ghost, startX, startY, moved }

function attachChipDrag(el, col) {
  el.addEventListener("pointerdown", e => startDrag(e, col, el));
}
function attachHeaderDrag(th, col) {
  th.addEventListener("pointerdown", e => startDrag(e, col, th));
}

function startDrag(e, col, sourceEl) {
  if (e.button !== undefined && e.button !== 0) return;
  e.preventDefault();
  const ghost = document.createElement("div");
  ghost.className = "chip ghost";
  const c = current.columns.find(x => x.name === col);
  ghost.innerHTML = "";
  const label = document.createElement("span");
  label.textContent = col;
  ghost.appendChild(label);
  if (c) {
    const t = document.createElement("span");
    t.className = "chip-type";
    t.textContent = c.type;
    ghost.appendChild(t);
  }
  document.body.appendChild(ghost);

  drag = { col, ghost, sourceEl, startX: e.clientX, startY: e.clientY, moved: false };
  sourceEl.classList.add("dragging");
  positionGhost(e.clientX, e.clientY);

  window.addEventListener("pointermove", onDragMove);
  window.addEventListener("pointerup", onDragEnd);
  window.addEventListener("pointercancel", onDragEnd);
}

function positionGhost(x, y) {
  drag.ghost.style.left = (x + 12) + "px";
  drag.ghost.style.top = (y + 12) + "px";
}

function onDragMove(e) {
  if (!drag) return;
  if (!drag.moved) {
    const dx = e.clientX - drag.startX, dy = e.clientY - drag.startY;
    if (Math.hypot(dx, dy) > 4) drag.moved = true;
  }
  positionGhost(e.clientX, e.clientY);
  highlightBinUnder(e.clientX, e.clientY);
}

function binUnder(x, y) {
  // returns one of: "tray","features","target","ignore" or null
  const order = ["features", "target", "ignore", "tray"];
  for (const k of order) {
    const r = binBoxEls[k].getBoundingClientRect();
    if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom) return k;
  }
  return null;
}

function highlightBinUnder(x, y) {
  const k = binUnder(x, y);
  for (const key of Object.keys(binBoxEls)) {
    binBoxEls[key].classList.toggle("over", key === k);
  }
}

function onDragEnd(e) {
  if (!drag) return;
  window.removeEventListener("pointermove", onDragMove);
  window.removeEventListener("pointerup", onDragEnd);
  window.removeEventListener("pointercancel", onDragEnd);

  const target = binUnder(e.clientX, e.clientY);
  drag.sourceEl.classList.remove("dragging");
  drag.ghost.remove();

  for (const key of Object.keys(binBoxEls)) binBoxEls[key].classList.remove("over");

  if (!drag.moved) {
    // treat as a tap: a placed chip returns to the tray
    if (assignment[drag.col] !== "tray") assignment[drag.col] = "tray";
  } else if (target) {
    assignment[drag.col] = target;
  }
  drag = null;
  built = false;
  clearOverlay();
  renderBins();
}

// ----- Validation + readout -----
function colsIn(where) {
  return current.columns.filter(c => assignment[c.name] === where).map(c => c.name);
}

function refreshReadout() {
  const feats = colsIn("features");
  const targets = colsIn("target");
  const tray = colsIn("tray");
  elUnassigned.textContent = String(tray.length);

  rTask.textContent = current.task;
  rTask.className = "v";
  rX.textContent = "(" + current.rows.length + ", " + feats.length + ")";
  rY.textContent = targets.length === 1 ? "(" + current.rows.length + ",)" : "(—)";

  // status messaging / gentle validation
  rStatus.className = "v";
  rType.className = "v";
  if (targets.length === 0) {
    rType.textContent = "—";
    rStatus.textContent = "pick a Target column";
  } else if (targets.length > 1) {
    rType.textContent = "—";
    rStatus.textContent = "⚠ only one target allowed (" + targets.length + " chosen)";
    rStatus.classList.add("warn");
  } else {
    const tCol = current.columns.find(c => c.name === targets[0]);
    rType.textContent = describeType(tCol);
    if (feats.length === 0) {
      rStatus.textContent = "add at least one feature";
    } else {
      rStatus.textContent = built ? "X / y ready ✓" : "press Build X / y";
      if (built) rStatus.classList.add("good");
    }
  }

  // highlight shape stats once built & valid
  rX.className = "v" + (built ? " x-hl" : "");
  rY.className = "v" + (built && targets.length === 1 ? " y-hl" : "");
  if (built) rType.classList.add("y-hl");
}

function describeType(col) {
  if (!col) return "—";
  if (col.type === "num") return "number";
  if (col.type === "cat") return "category";
  if (col.type === "id")  return "id (don't predict!)";
  return col.type;
}

// ----- Snippet (syntax-highlighted, escaped) -----
function esc(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}
function renderSnippet() {
  const feats = colsIn("features");
  const targets = colsIn("target");
  const df = current.df;

  if (targets.length !== 1 || feats.length === 0) {
    snippetCode.innerHTML =
      '<span class="tok-com"># choose exactly one target and ≥ 1 feature, then Build X / y</span>';
    return;
  }
  const featList = feats.map(f => "'" + f + "'").join(", ");
  const est = current.task === "regression"
    ? "LinearRegression"
    : "LogisticRegression";
  const modModule = current.task === "regression" ? "linear_model" : "linear_model";

  const lines = [
    '<span class="tok-com"># split the table into inputs (X) and the answer (y)</span>',
    '<span class="tok-x">X</span> = <span class="tok-df">' + esc(df) +
      '</span>[[' + esc(featList) + ']]   <span class="tok-com"># 2-D features</span>',
    '<span class="tok-y">y</span> = <span class="tok-df">' + esc(df) +
      "</span>['<span class=\"tok-str\">" + esc(targets[0]) +
      '</span>\']        <span class="tok-com"># 1-D target</span>',
    '',
    'from sklearn.' + modModule + ' import ' + est,
    'model = ' + est + '().fit(<span class="tok-x">X</span>, <span class="tok-y">y</span>)'
  ];
  snippetCode.innerHTML = lines.join("\n");
}

// ----- Build X / y : highlight columns + animate the split arrows -----
function clearColumnRoles() {
  const cells = tableHead.querySelectorAll("th").length;
  for (let ci = 0; ci < cells; ci++) {
    tableHead.children[ci].classList.remove("col-feature", "col-target", "col-ignore", "col-flash");
    for (const tr of tableBody.children) {
      const td = tr.children[ci];
      if (td) td.classList.remove("col-feature", "col-target", "col-ignore", "col-flash");
    }
  }
}

function clearOverlay() {
  splitOverlay.innerHTML = "";
}

function applyColumnRoles() {
  current.columns.forEach((c, ci) => {
    const role = assignment[c.name];
    const cls = role === "features" ? "col-feature"
              : role === "target"   ? "col-target"
              : role === "ignore"   ? "col-ignore" : null;
    const th = tableHead.children[ci];
    th.classList.add("col-flash");
    if (cls) th.classList.add(cls);
    for (const tr of tableBody.children) {
      const td = tr.children[ci];
      if (!td) continue;
      td.classList.add("col-flash");
      if (cls) td.classList.add(cls);
    }
  });
}

function build() {
  const targets = colsIn("target");
  const feats = colsIn("features");
  if (targets.length !== 1) {
    built = false;
    clearColumnRoles();
    clearOverlay();
    refreshReadout();
    renderSnippet();
    pulse(rStatus);
    return;
  }
  if (feats.length === 0) {
    built = false;
    clearColumnRoles();
    clearOverlay();
    refreshReadout();
    renderSnippet();
    pulse(rStatus);
    return;
  }

  built = true;
  clearColumnRoles();
  applyColumnRoles();
  refreshReadout();
  renderSnippet();
  if (showArrows.checked) drawSplitArrows();
}

function pulse(el) {
  el.classList.remove("col-flash");
  // force reflow so the animation can restart
  void el.offsetWidth;
  el.classList.add("col-flash");
}

// SVG arrows from feature columns -> "X", target column -> "y"
function drawSplitArrows() {
  clearOverlay();
  const zone = splitOverlay.parentElement.getBoundingClientRect();
  const w = zone.width, h = zone.height;
  const svgNS = "http://www.w3.org/2000/svg";
  const svg = document.createElementNS(svgNS, "svg");
  svg.setAttribute("viewBox", "0 0 " + w + " " + h);

  // marker defs (two colored arrowheads)
  const defs = document.createElementNS(svgNS, "defs");
  defs.appendChild(makeMarker(svgNS, "ah-feat", "#38bdf8"));
  defs.appendChild(makeMarker(svgNS, "ah-targ", "#fbbf24"));
  svg.appendChild(defs);

  current.columns.forEach((c, ci) => {
    const role = assignment[c.name];
    if (role !== "features" && role !== "target") return;
    const th = tableHead.children[ci];
    const r = th.getBoundingClientRect();
    const cx = r.left + r.width / 2 - zone.left;
    const topY = r.top - zone.top;

    const isTarget = role === "target";
    const color = isTarget ? "#fbbf24" : "#38bdf8";
    const tag = isTarget ? "y" : "X";
    // anchor labels: features cluster left, target to the right
    const labelX = isTarget ? w - 22 : 22;
    const labelY = 14;

    const path = document.createElementNS(svgNS, "path");
    const midY = Math.max(4, topY - 18);
    const d = "M " + cx + " " + Math.max(2, topY - 2) +
              " C " + cx + " " + midY + ", " + labelX + " " + midY +
              ", " + labelX + " " + (labelY + 4);
    path.setAttribute("d", d);
    path.setAttribute("fill", "none");
    path.setAttribute("stroke", color);
    path.setAttribute("stroke-width", "2");
    path.setAttribute("opacity", "0.75");
    path.setAttribute("marker-start", isTarget ? "url(#ah-targ)" : "url(#ah-feat)");
    // animated draw-in
    const len = 240;
    path.setAttribute("stroke-dasharray", String(len));
    path.setAttribute("stroke-dashoffset", String(len));
    const anim = document.createElementNS(svgNS, "animate");
    anim.setAttribute("attributeName", "stroke-dashoffset");
    anim.setAttribute("from", String(len));
    anim.setAttribute("to", "0");
    anim.setAttribute("dur", "0.5s");
    anim.setAttribute("fill", "freeze");
    path.appendChild(anim);
    svg.appendChild(path);

    const txt = document.createElementNS(svgNS, "text");
    txt.setAttribute("x", String(labelX));
    txt.setAttribute("y", String(labelY));
    txt.setAttribute("fill", color);
    txt.setAttribute("text-anchor", "middle");
    txt.setAttribute("font-family", "ui-monospace, Menlo, monospace");
    txt.setAttribute("font-size", "13");
    txt.setAttribute("font-weight", "700");
    txt.textContent = tag;
    svg.appendChild(txt);
  });

  splitOverlay.appendChild(svg);
}

function makeMarker(ns, id, color) {
  const m = document.createElementNS(ns, "marker");
  m.setAttribute("id", id);
  m.setAttribute("viewBox", "0 0 10 10");
  m.setAttribute("refX", "5");
  m.setAttribute("refY", "5");
  m.setAttribute("markerWidth", "5");
  m.setAttribute("markerHeight", "5");
  m.setAttribute("orient", "auto-start-reverse");
  const p = document.createElementNS(ns, "path");
  p.setAttribute("d", "M 0 0 L 10 5 L 0 10 z");
  p.setAttribute("fill", color);
  m.appendChild(p);
  return m;
}

// ----- Controls -----
buildBtn.addEventListener("click", build);
resetBtn.addEventListener("click", () => loadDataset(presetSel.value));
presetSel.addEventListener("change", () => loadDataset(presetSel.value));
showArrows.addEventListener("change", () => {
  if (built && showArrows.checked) drawSplitArrows();
  else clearOverlay();
});
window.addEventListener("resize", () => {
  if (built && showArrows.checked) drawSplitArrows();
});

// ----- Init -----
loadDataset(presetSel.value);
renderSnippet();

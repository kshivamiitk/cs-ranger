# The ML Workflow End to End

> Real ML projects almost never fail at the algorithm step — they fail because someone skipped framing, data checks, or evaluation. This is the map you'll follow on every project.

## What you'll learn
- The seven repeatable steps every ML project moves through.
- Why a *baseline* comes before any fancy model.
- How each step feeds the next, using one running example.
- Where beginners typically waste time, and how the workflow prevents it.

## Intuition

Think of ML like cooking a dish you'll serve many times. You don't start by grabbing random spices. You decide what you're making, gather and inspect ingredients, taste as you go, and only then plate it for guests. ML has the same discipline. Skipping steps is how you end up with a model that looks great in your notebook and falls apart in the real world.

Here are the seven steps. We'll trace them with one example: **predicting the sale price of a house.**

1. **Frame the problem.** Decide precisely what you're predicting and how success is measured. *House example:* "Predict a home's sale price in dollars from its features." This is **regression** (a number). Success metric: average prediction error in dollars (so a realtor can judge if it's useful). Framing it wrong — say, as a yes/no "expensive?" classification — would change everything downstream.

2. **Get the data.** Collect the inputs and the known answers. *House example:* a table where each row is a past sale, columns are `area_sqft`, `bedrooms`, `age_years`, `neighborhood`, and the target column `sale_price`. The answers (prices) come from historical records.

3. **Explore the data (EDA).** Look before you leap. Plot distributions, check for missing values and weird outliers, see which features relate to price. *House example:* you might notice 12 rows have `area_sqft = 0` (data-entry errors) and that price rises with area — a good sign that area is a useful feature.

4. **Prepare features.** Clean and transform the raw data into numbers a model can use. *House example:* fill or drop the bad area rows, convert `neighborhood` text into numeric columns (encoding), maybe add a derived feature like `price_per_room`. Models eat numbers, not strings.

5. **Train a baseline.** Fit the *simplest* reasonable model first. *House example:* "predict every house at the average price" or a plain `LinearRegression`. This baseline is your bar to beat. If a complex model can't beat "just guess the average," something is wrong.

6. **Evaluate honestly.** Measure performance on data the model has **not** seen during training (a held-out test set). *House example:* on the test set the linear model is off by about \$38,000 on average. Is that good enough for the business? That's the question framing told you to ask.

7. **Improve and ship.** Iterate: better features, a stronger model, tuning. When it clears the bar, deploy it and monitor it. *House example:* a random forest cuts the error to \$24,000 — better than the linear baseline — so you ship that one and keep watching for drift.

The arrows between steps go *both ways*. EDA often sends you back to get more data. A weak evaluation sends you back to features. That looping is normal and healthy.

## Python in practice

Here is the whole workflow compressed into runnable code so the shape is concrete. We use a synthetic dataset so it runs offline.

```python
import numpy as np
from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split
from sklearn.dummy import DummyRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error

# Step 1: Frame -> regression, success = low mean absolute error (MAE) in target units.
# Step 2: Get data -> here, synthetic stand-in for "house features + price".
X, y = make_regression(n_samples=300, n_features=4, noise=15.0, random_state=0)

# Step 3 & 4 (EDA / prep) would go here on real data; synthetic data is already clean.

# Split BEFORE training so evaluation uses unseen data (the test set).
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)

# Step 5: Baseline -> always predict the mean of the training target.
baseline = DummyRegressor(strategy="mean").fit(X_train, y_train)
baseline_mae = mean_absolute_error(y_test, baseline.predict(X_test))

# Step 5/7: A real model to beat the baseline.
model = LinearRegression().fit(X_train, y_train)
model_mae = mean_absolute_error(y_test, model.predict(X_test))

# Step 6: Evaluate honestly on the test set.
print(f"Baseline MAE (guess the mean): {baseline_mae:.1f}")
print(f"LinearRegression MAE:          {model_mae:.1f}")
print(f"Improvement: {baseline_mae - model_mae:.1f} lower error")
```

Expected output (numbers approximate):

```
Baseline MAE (guess the mean): 96.4
LinearRegression MAE:          12.7
LinearRegression beats the baseline by a wide margin.
```

The takeaway isn't the exact numbers — it's the *shape*: split, baseline, model, compare on unseen data. You will repeat this pattern in every module.

## Common mistakes

- **Jumping straight to a fancy model.** Without a baseline you have no idea whether your model is actually good or just slightly less bad than guessing.
- **Evaluating on training data.** A model can memorize the training set and look perfect, then fail on new data. Always score on a held-out test set.
- **Skipping EDA.** Bugs hide in the data, not the algorithm. The five minutes of plotting and `.describe()` you skip will cost you hours later.
- **Treating it as linear instead of looping.** Expect to revisit earlier steps. A first pass that's "done" is rare.

## Small exercise

In the code above, replace `LinearRegression` with `from sklearn.tree import DecisionTreeRegressor` and `DecisionTreeRegressor(random_state=0)`. Re-run and compare its test MAE to the linear model's. Which wins here? Write one sentence on why a held-out test set is the only fair way to answer that.

## Before you continue
- [ ] I can list the seven workflow steps from memory.
- [ ] I can explain why a baseline must come before a complex model.
- [ ] I understand why evaluation must use data the model never trained on.
- [ ] I can name two steps where you might loop back to an earlier one.

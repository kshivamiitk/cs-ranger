# Features and Labels

> Every supervised dataset splits into two parts: the clues you get to look at (features) and the single answer you're trying to predict (label). Get this split right and half of ML just works.

## What is this?

In supervised learning your data is a table. You divide its columns into two roles:

- **Features** — the input columns the model is allowed to look at. By convention this is called **`X`**, and it is **2D**: rows are examples, columns are features.
- **Label** (a.k.a. **target**) — the one column you want to predict. By convention this is **`y`**, and it is **1D**: one answer per row.

`X` is "everything you'll know at prediction time." `y` is "the thing you won't know yet and want the model to fill in." The whole job of a supervised model is to learn the mapping `X -> y`.

The type of `y` decides the task:

- `y` is a **number** -> **regression** (price, temperature, age).
- `y` is a **category** -> **classification** (spam/not-spam, the plan tier, a species name).

## Why do we need it?

Because a model can only be as good as the columns you feed it, and only as honest as the target you chose. Choosing features and a label is the moment you decide *what question you're actually answering*.

Two datasets with identical raw columns become completely different problems depending on which column you name the label. Mark `price` as `y` and you've built a price predictor; mark `sold_within_30_days` as `y` and you've built a fast-sale classifier — from the very same spreadsheet. Naming the split *is* defining the project.

## Where it's used in real ML

- **Tabular business data** — a CSV of customers/transactions/properties: you pick which columns are inputs and which one is the answer.
- **Feature engineering** — most real ML effort goes into creating better feature columns (ratios, dates split into day-of-week, text turned into counts).
- **Data leakage audits** — teams review every feature to make sure none of them secretly contain the answer.
- **Pipelines** — scikit-learn's `fit(X, y)` signature *is* the features/label split, baked into the API of every model.

## What breaks if you ignore it

Two classic disasters:

1. **Leaky feature.** You leave a column in `X` that is really part of the answer. Predicting whether a patient has a disease, you include `prescribed_treatment_for_that_disease` as a feature. In training, accuracy looks 99%. In the real world — where treatment isn't known until *after* diagnosis — the model is useless, because the cheat column isn't available.

2. **ID column as a feature.** You leave `customer_id` or `row_number` in `X`. The model "learns" that customer #4471 churned, which tells you nothing about a new customer #99999. It memorizes noise and generalizes to nothing.

Both pass tests on paper and fail on day one of production. Choosing features carefully is how you avoid them.

## Mental model

Think of a **detective solving a case**.

```
            FEATURES (X, 2D)                       LABEL (y, 1D)
   ┌──────────┬──────────┬──────────┐            ┌──────────────┐
   │  Clue 1  │  Clue 2  │  Clue 3  │   ──────►   │  Verdict     │
   ├──────────┼──────────┼──────────┤            ├──────────────┤
   │  size    │  beds    │  age     │            │  price ($)   │
   │  1400    │   3      │   12     │            │  320000      │   ← one answer
   │   900    │   2      │   30     │            │  210000      │     per row
   └──────────┴──────────┴──────────┘            └──────────────┘
     the evidence on the table                    what you must deduce
```

The detective uses *only the clues on the table* (features) to deduce the verdict (label). And a fair case has no smoking-gun clue that flat-out states the verdict — that would be a leaky feature, not detective work.

## Example 1 — Tiny toy example

Here is a four-row table. Your only job: point at `X` and point at `y`.

| fruit_id | weight_g | color   | is_sweet |
|---------:|---------:|:--------|:---------|
| 1        | 120      | red     | yes      |
| 2        | 150      | green   | no       |
| 3        | 130      | red     | yes      |
| 4        | 200      | yellow  | no       |

- **Label (`y`):** `is_sweet` — that's what we want to predict. It's a category, so this is **classification**.
- **Features (`X`):** `weight_g` and `color` — clues we can measure on any new fruit.
- **Dropped:** `fruit_id` — it's just a row name. It carries zero predictive meaning and would only let the model memorize. Never feed an ID in as a feature.

So `X` has shape `4 rows x 2 features`, and `y` has `4 values`. That shape — 2D features, 1D label — is exactly what every scikit-learn model expects.

## Example 2 — Practical ML example

**House-price dataset.** A CSV with one row per home:

```
listing_id, area_sqft, bedrooms, bathrooms, age_years, zip_code, final_sale_price
```

Choosing the split:

- **Target (`y`): `final_sale_price`** — a number, so this is a **regression** problem.
- **Features (`X`): `area_sqft`, `bedrooms`, `bathrooms`, `age_years`, `zip_code`** — all knowable *before* a sale, which is the test of a legitimate feature.
- **Drop `listing_id`** — a pure identifier; including it invites memorization.

Notice the discipline: every feature is something you'd actually have for a *new, unsold* house. `final_sale_price` itself is exactly what you won't have — which is why it's the target, not a feature. If a column is only known *after* the answer is decided, it cannot be a feature.

## Python code example

```python
# Split a small table into features (X, 2D) and label (y, 1D) with pandas.
import pandas as pd
from sklearn.linear_model import LinearRegression

df = pd.DataFrame({
    "listing_id": [101, 102, 103, 104, 105],  # identifier -> NOT a feature
    "area_sqft":  [900, 1400, 1100, 2000, 1600],
    "bedrooms":   [2,   3,    2,    4,    3],
    "price":      [210, 320, 250, 480, 360],  # in $1000s -> this is the TARGET
})

# Label (y): the column we predict. It's numeric -> regression.
y = df["price"]

# Features (X): inputs the model may see. Drop the target AND the id column.
X = df.drop(columns=["price", "listing_id"])

print("Feature columns (X):", list(X.columns))
print("X shape (rows, features):", X.shape)   # 2D
print("y shape (rows,):", y.shape)             # 1D

model = LinearRegression()
model.fit(X, y)   # learns the mapping X -> y

# Predict for a NEW house: 1500 sqft, 3 bedrooms.
new_house = pd.DataFrame({"area_sqft": [1500], "bedrooms": [3]})
print("Predicted price ($1000s):", round(model.predict(new_house)[0], 1))
```

Expected output (numbers approximate):

```
Feature columns (X): ['area_sqft', 'bedrooms']
X shape (rows, features): (5, 2)
y shape (rows,): (5,)
Predicted price ($1000s): 333.0
```

The two things to internalize: `X` is 2D `(rows, features)`, `y` is 1D `(rows,)`, and the id column never made it into `X`.

## Common mistakes

- **Leaving the target inside the features.** If `y` (or anything derived from it) is also in `X`, the model "predicts" the answer by reading it — perfect in training, broken in reality.
- **Using an id or row-number column as a feature.** IDs carry no pattern; the model just memorizes specific rows and fails on new ones.
- **Leaky future columns.** A feature only available *after* the answer is known (a treatment, a cancellation date) is leakage — drop it.
- **Wrong shape.** `X` must be 2D `(n_samples, n_features)` and `y` 1D `(n_samples,)`; a single feature still needs 2D shape.
- **Picking the wrong target.** Make sure `y` is the question you truly care about — switching it changes the entire project.

## Before you continue
- [ ] Given any table, I can point at the features (`X`) and the label (`y`).
- [ ] I know `X` is 2D `(rows, features)` and `y` is 1D `(rows,)`.
- [ ] I can explain why an id column should never be a feature.
- [ ] I can spot a leaky feature (one that secretly contains the answer).
- [ ] I can tell whether a chosen label makes the task regression or classification.

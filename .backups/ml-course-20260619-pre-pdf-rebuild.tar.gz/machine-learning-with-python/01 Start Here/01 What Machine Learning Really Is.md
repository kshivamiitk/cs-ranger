# What Machine Learning Really Is

> Before you write a single line of ML code, you need the one idea that everything else hangs on: a model is just a function we *fit to data* instead of writing by hand.

## What you'll learn
- The exact difference between traditional programming and machine learning.
- The three big families of ML (supervised, unsupervised, reinforcement) and when each applies.
- Everyday examples you already use that are powered by ML.
- Why "a model is a function fit to data" is the mental model that unlocks the whole field.

## Intuition

In **traditional programming**, *you* write the rules. Imagine flagging spam email. You'd write code like: "if the subject contains 'FREE MONEY' or the sender is unknown, mark as spam." You hand-code every rule, and the rules only catch what you anticipated. Spammers change one word and your rules break.

In **machine learning**, you don't write the rules. You show the computer thousands of emails already labeled *spam* or *not spam*, and an algorithm figures out the rules itself by finding patterns. You provide examples; the machine produces the rule.

Here is the contrast in one picture:

```
Traditional programming:   data + rules      -> answers
Machine learning:          data + answers    -> rules (a "model")
```

That flip is the whole idea. In ML you give the algorithm the *answers* (labels) for past data, and it learns the rule that maps inputs to those answers. You then apply that learned rule to new data it has never seen.

**The core definition: a model is a function fit to data.** A function takes an input and returns an output: `f(x) = y`. A spam model takes an email `x` and returns a probability `y`. A house-price model takes square footage and returns a dollar amount. "Training" means adjusting the function's internal numbers (its *parameters*) until its outputs match the known answers as closely as possible. Once fit, you reuse that function on fresh inputs. Nothing mystical: ML is curve-fitting at scale.

### The three families at a glance

- **Supervised learning** — You have labeled examples: inputs *and* their correct answers. The model learns to predict the answer for new inputs. Two sub-types:
  - *Classification* predicts a category (spam / not spam, cat / dog, disease / healthy).
  - *Regression* predicts a number (house price, tomorrow's temperature, expected revenue).
  This is the most common type in industry and where this course spends most of its time.
- **Unsupervised learning** — You have inputs but *no* labels. The model finds structure on its own: grouping similar customers (*clustering*), or compressing many features into a few (*dimensionality reduction*). Useful when nobody has labeled your data and you want to discover patterns.
- **Reinforcement learning** — An *agent* takes actions in an environment and learns from rewards and penalties over time, like training a dog with treats. It powers game-playing AI and robotics. Powerful but data-hungry and out of scope for a beginner course.

## Python in practice

Let's make "a model is a function fit to data" literal. We'll fit the simplest possible model — a straight line — to a few points, then use it as a function.

```python
import numpy as np
from sklearn.linear_model import LinearRegression

# Inputs (X) and the known answers (y). This is "supervised": every X has a y.
# X must be 2D for scikit-learn: each row is one example, each column one feature.
X = np.array([[1], [2], [3], [4], [5]])   # e.g. years of experience
y = np.array([30, 35, 50, 55, 70])        # e.g. salary in thousands

model = LinearRegression()   # an empty function with parameters not yet set
model.fit(X, y)              # "fit to data": find the line closest to the points

# The model is now a function. Call it on a NEW, unseen input:
prediction = model.predict([[6]])
print(f"Predicted answer for input 6: {prediction[0]:.1f}")
print(f"Learned rule: y = {model.coef_[0]:.1f} * x + {model.intercept_:.1f}")
```

Expected output (numbers approximate):

```
Predicted answer for input 6: 75.0
Learned rule: y = 9.5 * x + 20.5
```

Notice what happened: we never told the computer the slope or intercept. `fit` discovered `y ≈ 9.5x + 20.5` from the five examples. That equation *is* the model — a function fit to data — and `predict` just evaluates it.

## Common mistakes

- **Thinking ML "understands" like a human.** It doesn't. It finds statistical patterns. If your data is biased or wrong, the model faithfully learns the bias.
- **Confusing classification and regression.** Predicting a *category* is classification; predicting a *number* is regression. Choosing the wrong one means choosing the wrong tools and metrics.
- **Expecting ML when rules are simpler.** If you can write the rule reliably by hand (e.g. "tax = income * 0.2"), do that. ML shines only when the rule is too complex or unknown to hand-write.
- **Forgetting that `X` must be 2D in scikit-learn.** A single feature still needs shape `(n_samples, 1)`, hence the double brackets `[[6]]`.

## Small exercise

Take the code above and change `y` to `[20, 28, 33, 47, 52]`. Re-run it and read off the new learned slope and intercept. Then predict the answer for input `10` by hand using the printed equation, and confirm `model.predict([[10]])` matches. (Hint: it should, because the model *is* that equation.)

## Before you continue
- [ ] I can explain, in one sentence, how ML differs from traditional programming.
- [ ] I can give one real example each of classification, regression, and clustering.
- [ ] I understand why "a model is a function fit to data" is accurate.
- [ ] I know why `X` needs to be two-dimensional in scikit-learn.

# Set Up Your Python ML Environment

> A clean, isolated environment is the difference between "it works on my machine" and an afternoon lost to dependency errors. Set it up once, correctly, and never think about it again.

## What you'll learn
- Why isolated environments (venv or conda) matter and how to create one.
- The exact packages this course needs and how to install them.
- A one-shot snippet to verify everything imports and works.
- How to actually run your code — both Jupyter notebooks and plain scripts.

## Intuition

Python projects share one global pile of installed packages by default. Project A needs an old version of a library; Project B needs a new one; installing for B breaks A. A **virtual environment** solves this by giving each project its *own* private package folder. You "activate" it, install what you need, and that project's dependencies stay sealed off from everything else. It's a separate toolbox per job instead of one overflowing drawer.

You have two common options. Pick one:

- **venv** — built into Python, lightweight, the standard choice. Use this if you already have Python 3.9+ installed.
- **conda** (via Miniconda/Anaconda) — heavier, but bundles Python itself and handles tricky scientific packages smoothly. Use this if you don't have Python yet or prefer an all-in-one installer.

## Python in practice

These are shell commands, run in your terminal. They're written to work the same on macOS, Linux, and Windows where noted.

### Option A — venv (built into Python)

```bash
# 1. Create an environment named "mlenv" in your project folder
python -m venv mlenv

# 2. Activate it
#    macOS / Linux:
source mlenv/bin/activate
#    Windows (PowerShell):
#    mlenv\Scripts\Activate.ps1

# 3. Your prompt now shows (mlenv). Upgrade pip, then install the stack.
python -m pip install --upgrade pip
pip install numpy pandas matplotlib scikit-learn jupyter

# When you're done working:  deactivate
```

### Option B — conda

```bash
# 1. Create an environment with Python and the core scientific stack
conda create -n mlenv python=3.11 numpy pandas matplotlib scikit-learn jupyter

# 2. Activate it (same command on every OS)
conda activate mlenv

# When you're done working:  conda deactivate
```

That's it. `numpy` (arrays/math), `pandas` (tables), `matplotlib` (plots), `scikit-learn` (the ML algorithms), and `jupyter` (notebooks) are everything this course uses.

### Verify the install

Create a file `check_setup.py` (or paste into a notebook cell) and run it. If it prints versions and a small result without errors, you're ready.

```python
# check_setup.py -- confirms the whole ML stack is importable and working
import sys
import numpy as np
import pandas as pd
import matplotlib
import sklearn
from sklearn.linear_model import LinearRegression

print(f"Python      : {sys.version.split()[0]}")
print(f"numpy       : {np.__version__}")
print(f"pandas      : {pd.__version__}")
print(f"matplotlib  : {matplotlib.__version__}")
print(f"scikit-learn: {sklearn.__version__}")

# A tiny end-to-end sanity check: fit a line to y = 2x.
X = np.array([[1], [2], [3], [4]])
y = np.array([2, 4, 6, 8])
slope = LinearRegression().fit(X, y).coef_[0]
print(f"\nSanity check — learned slope (should be ~2.0): {slope:.2f}")
print("All systems go." if abs(slope - 2.0) < 1e-6 else "Something is off.")
```

Expected output (versions will vary):

```
Python      : 3.11.x
numpy       : 1.26.x
pandas      : 2.x.x
matplotlib  : 3.x.x
scikit-learn: 1.x.x

Sanity check — learned slope (should be ~2.0): 2.00
All systems go.
```

### How to run your code

You have two ways to run everything in this course; both use the *activated* environment:

- **Jupyter notebook** (great for learning — run code in small cells, see plots inline):
  ```bash
  jupyter notebook        # opens in your browser; create a new Python 3 notebook
  ```
  Type code in a cell and press `Shift+Enter` to run it. Plots appear right below the cell.

- **Plain Python script** (great for reusable code):
  ```bash
  python check_setup.py
  ```
  Add `import matplotlib.pyplot as plt` and end with `plt.show()` to pop up plots from a script.

## Common mistakes

- **Installing packages without activating the environment first.** They land in the global Python and your `(mlenv)` stays empty. Confirm your prompt shows `(mlenv)` before running `pip install`.
- **Mixing pip and conda carelessly.** Inside a conda env, prefer `conda install`; fall back to `pip` only for packages conda lacks. Mixing freely can corrupt the env.
- **Wrong activate command for your OS.** macOS/Linux use `source mlenv/bin/activate`; Windows uses `mlenv\Scripts\Activate.ps1`. Using the wrong one silently does nothing.
- **`ModuleNotFoundError` in Jupyter.** Usually means Jupyter is running a different Python than the one you installed into. Launch `jupyter notebook` from inside the activated env so they match.

## Small exercise

Create and activate a fresh environment, install the five packages, and run the verification snippet. Then deliberately deactivate the env and run `python check_setup.py` again — note the `ModuleNotFoundError`. Re-activate and confirm it works. This makes the "isolation" idea tangible.

## Before you continue
- [ ] I created and activated a virtual environment and my prompt shows its name.
- [ ] `pip list` (or `conda list`) shows numpy, pandas, matplotlib, scikit-learn, jupyter.
- [ ] The verification snippet printed versions and "All systems go."
- [ ] I can run code both in a Jupyter cell and as a `python file.py` script.

# Checkpoint — Start Here

## What you should now be able to do
- Explain how machine learning differs from traditional programming, and state the "model = function fit to data" idea.
- Classify a problem as supervised (classification vs regression), unsupervised, or reinforcement learning.
- Walk through the seven-step ML workflow and explain why a baseline and a held-out test set matter.
- Set up an isolated Python environment, install the core stack, and verify it.
- Train, predict with, and score a simple regression model, and interpret R².

## Review questions

1. In one sentence, what is the key difference between traditional programming and machine learning in terms of what you provide and what you get back?
2. Is "predict whether a transaction is fraudulent" classification or regression? What about "predict the temperature tomorrow"?
3. What does it mean to say "a model is a function fit to data"?
4. Why must `X` be two-dimensional when you call `model.fit(X, y)` in scikit-learn?
5. List the seven steps of the ML workflow in order.
6. Why do we train a baseline model before trying a more complex one?
7. Why is it wrong to evaluate a model on the same data it was trained on?
8. What does an R² of 0.0 mean? What does a negative R² mean?
9. Why do we create a virtual environment instead of installing packages globally?
10. Which family of ML would you use to group customers into segments when you have no labels?

## Answers

<details>
<summary>Show answers</summary>

1. In traditional programming you supply data **and the rules** and get answers; in ML you supply data **and the answers** and the algorithm produces the rules (the model).
2. Fraud detection is **classification** (a category: fraud / not fraud). Temperature tomorrow is **regression** (a continuous number).
3. A model is just a mathematical function `f(x) = y`; "fitting" adjusts its internal parameters until its outputs match the known answers, after which you reuse it on new inputs.
4. scikit-learn expects rows = samples and columns = features, so even a single feature needs shape `(n_samples, 1)`. A 1-D array is ambiguous.
5. Frame the problem → get data → explore (EDA) → prepare features → train a baseline → evaluate honestly → improve and ship.
6. The baseline is the bar to beat. Without it you can't tell whether a complex model is genuinely good or merely slightly better than guessing.
7. The model can memorize the training data and look perfect while failing on new data; only a held-out test set reveals true generalization.
8. R² = 0.0 means the model is no better than always predicting the average target. Negative R² means it's **worse** than predicting the average.
9. To isolate each project's dependencies so versions don't collide and one project can't break another's packages.
10. **Unsupervised learning**, specifically clustering.

</details>

## Hands-on tasks

1. Re-run the "first model in 15 lines" lab, but use `load_wine(return_X_y=True)` with a `LogisticRegression(max_iter=5000)` classifier and `accuracy_score` instead of R². Notice how the loop is identical even though the task changed to classification.
2. Take any prediction task you care about (e.g. predicting a friend's coffee order, a stock's direction, a song's genre) and write down: is it supervised or unsupervised? Classification or regression? What would the features and target be?
3. From a fresh terminal, create a virtual environment, install the stack, and run the verification snippet from lesson 3. Confirm "All systems go."
4. In the diabetes lab, change `random_state` to three different values and record the three R² scores. Write one sentence on why they differ slightly.

## You're ready for the next module when…
- [ ] I can categorize a new problem into the right ML family without hesitating.
- [ ] I can recite the seven workflow steps and justify the baseline and test-set steps.
- [ ] My environment is set up and verified.
- [ ] I trained a model, predicted, and explained what its score means in plain English.

# Lab — Your First Model in 15 Lines

## Objective

You will train a real machine-learning model end to end in about fifteen lines of code, then read its score the way a practitioner does. After this lab you'll be able to load a dataset, split it correctly, fit a model, make predictions, and interpret the R² metric — the exact loop you'll repeat for the rest of the course.

## Dataset

We use scikit-learn's built-in **diabetes** dataset, so nothing downloads and it runs offline. It has 442 patients, 10 numeric features already scaled for you (age, BMI, blood pressure, and several blood-serum measurements), and a target: a number measuring disease progression one year after baseline. This is a **regression** problem because the target is a continuous number.

| Property | Value |
|---|---|
| Rows (patients) | 442 |
| Features | 10 (all numeric, pre-scaled) |
| Target | disease progression (a number) |
| Task type | regression |

## Steps

**Step 1 — Import the pieces.** We need the dataset loader, a way to split data, the model, and a scoring metric.

```python
from sklearn.datasets import load_diabetes        # the dataset
from sklearn.model_selection import train_test_split  # to hold out a test set
from sklearn.linear_model import LinearRegression # the model
from sklearn.metrics import r2_score              # how we'll judge it
```

**Step 2 — Load the data into `X` (features) and `y` (target).** `X` is a 442x10 array; `y` is 442 target values.

```python
X, y = load_diabetes(return_X_y=True)
print("Features shape:", X.shape, "| Target shape:", y.shape)
# Features shape: (442, 10) | Target shape: (442,)
```

**Step 3 — Split into training and test sets.** The model learns on the training set and is judged on the test set it never saw. `random_state` makes the split reproducible.

```python
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
# 80% (about 353 rows) for training, 20% (about 89 rows) held out for testing.
```

**Step 4 — Create and fit the model.** `fit` is where learning happens: it finds the best line through the training data.

```python
model = LinearRegression()
model.fit(X_train, y_train)   # the model is now "trained"
```

**Step 5 — Predict on the unseen test features.** These are the model's guesses for patients it has never seen.

```python
predictions = model.predict(X_test)
print("First 3 predictions:", predictions[:3].round(1))
print("First 3 true values:", y_test[:3])
```

**Step 6 — Score the model with R².** `r2_score` compares predictions to the truth on the test set.

```python
score = r2_score(y_test, predictions)
print(f"R-squared on test set: {score:.3f}")
# R-squared on test set: 0.453   (your value will be close to this)
```

Here is the whole thing in one runnable block — your "first model in 15 lines":

```python
from sklearn.datasets import load_diabetes
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score

X, y = load_diabetes(return_X_y=True)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
model = LinearRegression()
model.fit(X_train, y_train)
predictions = model.predict(X_test)
score = r2_score(y_test, predictions)
print(f"R-squared on test set: {score:.3f}")
```

## Expected output

You should see an R² around **0.45**. Here's how to read that number:

- **R² ranges from 1.0 down (and can even go negative).** It measures the fraction of the variation in the target that your model explains.
- **R² = 1.0** means perfect predictions. **R² = 0.0** means your model is no better than always guessing the average target. **Negative R²** means it's *worse* than guessing the average — a red flag.
- **0.45** means the model explains about 45% of why patients' disease progression differs. For ten simple measurements predicting a messy biological outcome, that's a reasonable, honest result — not great, not useless. It tells you the features carry real but partial signal.

The point of this lab isn't a high score; it's that you ran the full loop — load, split, fit, predict, score — and you can now interpret the result instead of just printing it.

## Extension challenge

1. Change `test_size` from `0.2` to `0.3` and re-run. Does R² move much? Tiny shifts are normal; a big swing would hint the dataset is small or noisy.
2. Swap `LinearRegression` for `from sklearn.ensemble import RandomForestRegressor` using `RandomForestRegressor(random_state=42)`. Compare R². Does the more complex model actually win on this dataset?
3. Print `model.coef_` for the linear model. Each number is the weight on one feature — larger magnitude means that feature pushes the prediction more. Which feature has the biggest effect?

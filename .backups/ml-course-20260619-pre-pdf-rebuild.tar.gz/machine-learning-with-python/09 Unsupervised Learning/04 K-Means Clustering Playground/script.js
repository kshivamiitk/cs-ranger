/* K-Means Clustering Playground
 * A correct, self-contained implementation of Lloyd's algorithm in vanilla JS.
 * Points live in canvas (pixel) coordinates so geometry is straightforward.
 */
(function () {
  "use strict";

  var canvas = document.getElementById("canvas");
  var ctx = canvas.getContext("2d");
  var W = canvas.width;   // 640 internal resolution
  var H = canvas.height;  // 480

  // DOM
  var kSlider = document.getElementById("k");
  var kVal = document.getElementById("kVal");
  var iterEl = document.getElementById("iter");
  var inertiaEl = document.getElementById("inertia");
  var statusEl = document.getElementById("status");
  var btnInit = document.getElementById("init");
  var btnStep = document.getElementById("step");
  var btnRun = document.getElementById("run");
  var btnNew = document.getElementById("newdata");

  // Distinct, theme-friendly cluster colors (supports up to K=6).
  var PALETTE = ["#a78bfa", "#22d3ee", "#34d399", "#f87171", "#fbbf24", "#f472b6"];

  // State
  var points = [];        // [{x,y,cluster}]
  var centroids = [];     // [{x,y}]
  var k = 3;
  var iter = 0;
  var inertia = null;
  var running = false;
  var rafId = null;
  var lastStepTime = 0;
  var STEP_INTERVAL = 650; // ms between animated steps

  // ---- helpers -------------------------------------------------------------

  function rand(min, max) { return Math.random() * (max - min) + min; }

  function dist2(ax, ay, bx, by) {
    var dx = ax - bx, dy = ay - by;
    return dx * dx + dy * dy;
  }

  // Generate a few Gaussian blobs of points (Box-Muller for normals).
  function gaussian(mean, sd) {
    var u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    var z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
    return mean + z * sd;
  }

  function makeData() {
    points = [];
    var nBlobs = 3 + Math.floor(Math.random() * 2); // 3 or 4 true blobs
    var margin = 90;
    for (var b = 0; b < nBlobs; b++) {
      var cx = rand(margin, W - margin);
      var cy = rand(margin, H - margin);
      var sd = rand(22, 40);
      var n = 35 + Math.floor(Math.random() * 25);
      for (var i = 0; i < n; i++) {
        var px = clamp(gaussian(cx, sd), 6, W - 6);
        var py = clamp(gaussian(cy, sd), 6, H - 6);
        points.push({ x: px, y: py, cluster: -1 });
      }
    }
    centroids = [];
    iter = 0;
    inertia = null;
    setStatus("ready");
  }

  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

  // k-means++ style spread init keeps demos visually sensible, but we keep it
  // simple/random per the brief; pick K distinct existing points as seeds.
  function initCentroids() {
    centroids = [];
    if (points.length === 0) return;
    // Random distinct points as starting centroids (classic Forgy init).
    var idx = [];
    for (var i = 0; i < points.length; i++) idx.push(i);
    // shuffle
    for (var j = idx.length - 1; j > 0; j--) {
      var r = Math.floor(Math.random() * (j + 1));
      var t = idx[j]; idx[j] = idx[r]; idx[r] = t;
    }
    for (var c = 0; c < k; c++) {
      var p = points[idx[c % points.length]];
      centroids.push({ x: p.x, y: p.y });
    }
    iter = 0;
    inertia = null;
    // assign immediately so colors show, but don't move centroids yet
    assign();
    computeInertia();
    setStatus("initialized");
    draw();
    updateStats();
  }

  // One ASSIGN move: each point -> nearest centroid. Returns #changed.
  function assign() {
    var changed = 0;
    for (var i = 0; i < points.length; i++) {
      var p = points[i];
      var best = 0, bestD = Infinity;
      for (var c = 0; c < centroids.length; c++) {
        var d = dist2(p.x, p.y, centroids[c].x, centroids[c].y);
        if (d < bestD) { bestD = d; best = c; }
      }
      if (p.cluster !== best) changed++;
      p.cluster = best;
    }
    return changed;
  }

  // One UPDATE move: each centroid -> mean of its assigned points.
  // Empty clusters are re-seeded to a random point (guards divide-by-zero).
  function update() {
    var sx = new Array(centroids.length).fill(0);
    var sy = new Array(centroids.length).fill(0);
    var cnt = new Array(centroids.length).fill(0);
    for (var i = 0; i < points.length; i++) {
      var p = points[i];
      if (p.cluster < 0) continue;
      sx[p.cluster] += p.x;
      sy[p.cluster] += p.y;
      cnt[p.cluster]++;
    }
    for (var c = 0; c < centroids.length; c++) {
      if (cnt[c] > 0) {
        centroids[c].x = sx[c] / cnt[c];
        centroids[c].y = sy[c] / cnt[c];
      } else {
        // empty cluster: re-seed onto a random point
        var rp = points[Math.floor(Math.random() * points.length)];
        centroids[c].x = rp.x;
        centroids[c].y = rp.y;
      }
    }
  }

  function computeInertia() {
    var sum = 0;
    for (var i = 0; i < points.length; i++) {
      var p = points[i];
      if (p.cluster < 0 || !centroids[p.cluster]) continue;
      sum += dist2(p.x, p.y, centroids[p.cluster].x, centroids[p.cluster].y);
    }
    inertia = sum;
  }

  // One full Lloyd iteration: assign then update. Returns true if converged.
  function step() {
    if (centroids.length === 0) { initCentroids(); return false; }
    var changed = assign();   // re-color
    update();                 // move centroids to means
    iter++;
    computeInertia();
    var converged = (changed === 0);
    setStatus(converged ? "converged" : "running");
    updateStats();
    draw();
    return converged;
  }

  // ---- rendering -----------------------------------------------------------

  function color(c) { return PALETTE[c % PALETTE.length]; }

  function draw() {
    ctx.clearRect(0, 0, W, H);

    // faint grid for depth
    ctx.strokeStyle = "rgba(255,255,255,0.04)";
    ctx.lineWidth = 1;
    for (var gx = 0; gx <= W; gx += 64) {
      ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke();
    }
    for (var gy = 0; gy <= H; gy += 64) {
      ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke();
    }

    // points
    for (var i = 0; i < points.length; i++) {
      var p = points[i];
      ctx.beginPath();
      ctx.arc(p.x, p.y, 4, 0, Math.PI * 2);
      if (p.cluster < 0 || centroids.length === 0) {
        ctx.fillStyle = "rgba(148,163,184,0.65)"; // dim gray when unassigned
      } else {
        ctx.fillStyle = color(p.cluster);
      }
      ctx.fill();
    }

    // centroids (larger X markers with a glow)
    for (var c = 0; c < centroids.length; c++) {
      var cen = centroids[c];
      var col = color(c);
      ctx.save();
      ctx.shadowColor = col;
      ctx.shadowBlur = 14;
      // outer ring
      ctx.beginPath();
      ctx.arc(cen.x, cen.y, 11, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(11,11,16,0.85)";
      ctx.fill();
      ctx.lineWidth = 3;
      ctx.strokeStyle = col;
      ctx.stroke();
      // X
      ctx.beginPath();
      ctx.moveTo(cen.x - 5, cen.y - 5); ctx.lineTo(cen.x + 5, cen.y + 5);
      ctx.moveTo(cen.x + 5, cen.y - 5); ctx.lineTo(cen.x - 5, cen.y + 5);
      ctx.lineWidth = 2.5;
      ctx.strokeStyle = "#0b0b10";
      ctx.stroke();
      ctx.restore();
    }
  }

  // ---- animation loop ------------------------------------------------------

  function loop(ts) {
    if (!running) return;
    if (!lastStepTime) lastStepTime = ts;
    if (ts - lastStepTime >= STEP_INTERVAL) {
      lastStepTime = ts;
      var converged = step();
      if (converged) { stopRunning(); return; }
    }
    rafId = requestAnimationFrame(loop);
  }

  function startRunning() {
    if (centroids.length === 0) initCentroids();
    running = true;
    btnRun.textContent = "Pause";
    btnRun.classList.add("btn-accent");
    lastStepTime = 0;
    setStatus("running");
    rafId = requestAnimationFrame(loop);
  }

  function stopRunning() {
    running = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
    btnRun.textContent = "Run";
    btnRun.classList.remove("btn-accent");
    if (statusEl.textContent === "running") setStatus("paused");
  }

  // ---- UI glue -------------------------------------------------------------

  function setStatus(s) { statusEl.textContent = s; }

  function updateStats() {
    iterEl.textContent = String(iter);
    inertiaEl.textContent = (inertia === null) ? "—" : Math.round(inertia).toLocaleString();
  }

  kSlider.addEventListener("input", function () {
    k = parseInt(kSlider.value, 10);
    kVal.textContent = String(k);
    stopRunning();
    // changing K invalidates centroids; clear colors and require re-init
    centroids = [];
    iter = 0;
    inertia = null;
    for (var i = 0; i < points.length; i++) points[i].cluster = -1;
    setStatus("set K → Init centroids");
    updateStats();
    draw();
  });

  btnInit.addEventListener("click", function () {
    stopRunning();
    initCentroids();
  });

  btnStep.addEventListener("click", function () {
    stopRunning();
    step();
  });

  btnRun.addEventListener("click", function () {
    if (running) stopRunning();
    else startRunning();
  });

  btnNew.addEventListener("click", function () {
    stopRunning();
    makeData();
    for (var i = 0; i < points.length; i++) points[i].cluster = -1;
    draw();
    updateStats();
  });

  // ---- init ----------------------------------------------------------------
  k = parseInt(kSlider.value, 10);
  kVal.textContent = String(k);
  makeData();
  draw();
  updateStats();
})();

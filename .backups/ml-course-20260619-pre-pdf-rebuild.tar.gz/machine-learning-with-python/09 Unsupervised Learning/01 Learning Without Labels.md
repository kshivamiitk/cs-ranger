# Learning Without Labels

> Sometimes nobody has told you the "right answer" — and yet the data still has a shape worth discovering.

## What you'll learn
- The core difference between **supervised** and **unsupervised** learning.
- What we mean by "finding **structure**" when there are no labels.
- Three high-value use cases: **segmentation**, **compression**, and **anomaly detection**.
- How to recognize when a problem is unsupervised in the first place.
- Why evaluation is trickier without labels — and how we cope.

## Intuition
In **supervised** learning every training row comes with the answer attached: this email *is* spam, this house *sold for* \$420k. The model learns a mapping from features to that known target. In **unsupervised** learning there is no target column at all. You hand the algorithm a pile of feature vectors and ask: *"What's the hidden organization here?"*

A good analogy: imagine emptying a box of mixed LEGO bricks onto a table. Nobody labeled them. Yet you'd naturally start grouping — big bricks here, flat plates there, wheels in a pile. You discovered **structure** that was always present in the data; you just made it explicit. That grouping move is **clustering**, the most common unsupervised task. Alternatively, you might notice that "color" and "shade" are almost the same property, so you could describe each brick with fewer numbers without losing much. That reduction is **dimensionality reduction** (PCA, the next lesson).

"Structure" concretely means one of a few things: examples that sit close together form **clusters**; many features that move together can be summarized by **fewer** features (compression); and a handful of points that sit far from everything else are **anomalies**. Unsupervised learning is the toolkit for surfacing these patterns when no answer key exists.

The three workhorse use cases:
- **Segmentation.** A business has thousands of customers and no labels for "type of customer." Clustering groups them by behavior (spend, frequency, recency) so marketing can treat each segment differently. You'll do exactly this in the lab.
- **Compression.** A dataset with 100 correlated columns can often be squeezed into 10 components that retain most of the information — faster models, less storage, easier visualization. That's PCA.
- **Anomaly detection.** Fraud, equipment failure, and intrusions are rare and unlabeled. Points that don't fit any cluster, or that are far from the data's main "shape," are flagged for a human to inspect.

The catch: **without labels, "correct" is fuzzy.** There's no accuracy score because there's no ground truth. Instead we lean on *internal* measures — how tight and well-separated the clusters are (inertia, silhouette), or how much variance a compression preserves — plus human judgment about whether the discovered groups are *useful*.

## Python in practice

```python
import numpy as np
from sklearn.datasets import make_blobs
from sklearn.cluster import KMeans

# Generate unlabeled-looking data: 3 natural groups in 2D.
# We DO know the true groups here (y_true) only so we can sanity-check;
# the model never sees them.
X, y_true = make_blobs(n_samples=300, centers=3, cluster_std=0.9,
                       random_state=42)
print(X.shape)            # (300, 2) -> 300 examples, 2 features, NO label column

# Unsupervised: fit using ONLY X. Notice there is no 'y' passed to fit.
km = KMeans(n_clusters=3, n_init=10, random_state=42)
labels = km.fit_predict(X)        # discovers a group id per point
print(np.unique(labels))          # [0 1 2] -> three discovered clusters
print(km.cluster_centers_.shape)  # (3, 2) -> one center per cluster
```

Note the crucial line: `km.fit_predict(X)` receives **no target**. The cluster ids `0/1/2` are *invented* by the algorithm — they're arbitrary names for "structure it found," not a label anyone supplied.

```python
# Anomaly flavor: how far is each point from its assigned center?
# Points with the largest distance are the most "unusual".
import numpy as np
dists = np.linalg.norm(X - km.cluster_centers_[labels], axis=1)
top3 = np.argsort(dists)[-3:]     # indices of the 3 most distant points
print("most anomalous points:", top3)
print("their distances:", np.round(dists[top3], 2))
# A simple, label-free way to surface candidates for inspection.
```

## Common mistakes
- **Expecting an accuracy score.** There's no `y_true` in real unsupervised problems, so you can't compute accuracy. Evaluate with internal metrics (inertia, silhouette) and human usefulness.
- **Reading meaning into cluster numbers.** Cluster `0` isn't "first" or "best." The integer labels are arbitrary and can change between runs.
- **Forgetting to scale.** Distance-based methods (k-means) are dominated by large-magnitude features. Scale before clustering (covered next lesson).
- **Assuming clusters are "true."** Algorithms will *always* return clusters even in random noise. You must check whether the groups are stable and meaningful, not just present.
- **Confusing unsupervised with semi-/self-supervised.** Pure unsupervised uses *no* labels at all during training.

## Small exercise
1. Re-run the `make_blobs` example but ask `KMeans` for `n_clusters=4` instead of 3.
2. Look at `np.unique(labels)` — how many groups come back now?
3. Without a true answer key, how would you decide whether 3 or 4 clusters is "better"? (Hint: you'll formalize this with the elbow and silhouette in the next lesson.)

## Before you continue
- [ ] I can state the one-sentence difference between supervised and unsupervised learning.
- [ ] I can name three real use cases for unsupervised learning and what "structure" means in each.
- [ ] I understand why there's no accuracy score and what we use instead.
- [ ] I noticed that `fit` for clustering takes only `X`, never a `y`.

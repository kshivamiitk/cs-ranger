# PCA — Compressing Dimensions

> PCA finds the directions your data actually varies in and lets you describe each point with fewer numbers — keeping the signal, dropping the redundancy.

## What you'll learn
- What **variance** has to do with information, and why directions of high variance matter.
- How **principal components** are new axes built from your old features.
- How to read **`explained_variance_ratio_`** to decide how many components to keep.
- When PCA helps (visualization, speed, de-noising, killing correlation) and when it hurts.
- Why you must **scale features first** — and the code to do all of it.

## Intuition
Suppose you measure people's height in centimeters and in inches. Those two columns are almost perfectly redundant — knowing one tells you the other. Plotting them gives a thin diagonal cloud. You don't really have two dimensions of information; you have *one* direction of real variation (overall height) plus a sliver of noise.

**PCA** automates that observation. It finds the direction in which your data spreads out the most and calls it **principal component 1 (PC1)**. Then it finds the next direction that's at a right angle to PC1 and captures the most *remaining* spread — that's **PC2** — and so on. These principal components are **new axes**: each one is a weighted blend of your original features. The first few axes usually capture the bulk of the variation, so you can describe each point with just those few numbers and throw the rest away with little loss.

Why does **variance** equal information here? A direction along which all your points look identical tells you nothing — it has zero variance. A direction along which points spread far apart is where the differences (the signal) live. PCA simply ranks directions by how much your data varies along each, then keeps the top ones.

The payoff is **`explained_variance_ratio_`**: a list, one number per component, saying what fraction of the total variance each captures. If PC1 explains 0.82 and PC2 explains 0.11, then *two* components retain 93% of the information — you can drop everything else.

**Use PCA when** you want to (1) visualize high-dimensional data in 2D/3D, (2) speed up a downstream model by shrinking the feature count, (3) reduce noise, or (4) remove redundancy between strongly correlated features. **Be cautious when** interpretability matters (components are blends, not original features) or when relationships are highly non-linear (PCA only captures linear structure).

**Critical caution: scale first.** PCA chases variance, and an unscaled large-magnitude feature has huge variance just because of its units. Standardize every feature first, or PCA will simply rediscover "the column with the biggest numbers."

## Python in practice

```python
import numpy as np
from sklearn.datasets import load_wine
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# 13-feature wine dataset -> a good candidate for compression.
data = load_wine()
X = data.data
print("original shape:", X.shape)     # (178, 13)

# SCALE FIRST -> every feature gets equal say (essential for PCA).
Xs = StandardScaler().fit_transform(X)

pca = PCA()                            # keep all components for now
pca.fit(Xs)
ratios = pca.explained_variance_ratio_
print("variance per component (first 5):", np.round(ratios[:5], 3))
print("cumulative:", np.round(np.cumsum(ratios)[:5], 3))
# e.g. PC1~0.36, PC2~0.19; the first ~5 components already cover the majority.
```

```python
# Decide how many components keep, say, 90% of the variance, then project.
n_keep = int(np.searchsorted(np.cumsum(ratios), 0.90) + 1)
print("components needed for >=90% variance:", n_keep)

pca90 = PCA(n_components=0.90)          # let sklearn pick to hit 90%
X_reduced = pca90.fit_transform(Xs)
print("reduced shape:", X_reduced.shape)   # (178, n_keep) -> far fewer columns
```

```python
# A favorite use: squeeze 13D down to 2D purely to SEE the data.
X2 = PCA(n_components=2).fit_transform(Xs)
print("2D projection shape:", X2.shape)    # (178, 2)

import matplotlib.pyplot as plt
plt.scatter(X2[:, 0], X2[:, 1], c=data.target, cmap="viridis", s=20)
plt.xlabel("PC1"); plt.ylabel("PC2"); plt.title("Wine in 2D via PCA")
plt.show()
# The three wine classes separate into visible groups along PC1/PC2 -
# even though PCA never saw the labels.
```

A short note on interpreting the output: `explained_variance_ratio_` is your budget. If two components hold 90% of the variance, a 13-column dataset can become a 2-column one with only 10% information loss — a huge speed-up for downstream models and the only practical way to plot many features at once.

## Common mistakes
- **Not scaling first.** The number-one PCA error. An unscaled feature with large units hijacks PC1. Always `StandardScaler` (or at least center) before `PCA`.
- **Keeping too few components.** Dropping to 2D for *modeling* (not just plotting) can discard real signal. Use the cumulative variance to choose, not habit.
- **Expecting interpretable components.** PC1 is a linear *blend* of all features, not a single original variable. Don't report "PC1 = income."
- **Using PCA on non-linear structure.** PCA only finds linear directions. For curved manifolds, consider t-SNE/UMAP for visualization (still scale first).
- **Fitting PCA on the test set.** Like any transformer, `fit` on train only, then `transform` test — otherwise you leak.

## Small exercise
1. Run the wine PCA and print the *cumulative* `explained_variance_ratio_`.
2. How many components are needed to reach 95% of the variance?
3. Re-run PCA on the **unscaled** `X` (skip `StandardScaler`). Look at PC1's `explained_variance_ratio_` — why does it jump so high, and which original feature do you think dominates it? (Hint: print `X.var(axis=0)` and find the largest.)

## Before you continue
- [ ] I can explain why high variance along a direction means "information."
- [ ] I can describe a principal component as a new axis that is a blend of original features.
- [ ] I can use `explained_variance_ratio_` to choose how many components to keep.
- [ ] I always scale before PCA and can say what goes wrong if I don't.

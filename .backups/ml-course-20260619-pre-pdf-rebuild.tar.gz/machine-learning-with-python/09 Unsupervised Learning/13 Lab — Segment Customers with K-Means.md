# Lab — Segment Customers with K-Means

## Objective
You will turn a raw customer table into actionable **segments** using k-means — exactly the kind of analysis a marketing or growth team pays for. By the end you'll be able to: scale behavioral features correctly, pick the number of segments K with an elbow plot, fit `KMeans`, and *profile* each cluster with `groupby` means so you can describe each segment in plain business language ("high-spend loyalists," "lapsed bargain shoppers"). This is a portfolio-ready piece: it shows you can take messy customer data and produce a decision a stakeholder understands.

## Dataset
A small synthetic customer table defined inline (no downloads). Three behavioral features:

| Column | Meaning |
|---|---|
| `annual_spend` | total dollars spent in the last year |
| `visits` | number of store/site visits in the last year |
| `recency` | days since the last purchase (lower = more recent) |

A peek at the first rows (full table is built via `io.StringIO`):

| annual_spend | visits | recency |
|-------------:|-------:|--------:|
| 220 | 4 | 90 |
| 5400 | 48 | 3 |
| 180 | 3 | 120 |
| 4800 | 52 | 5 |

The data is designed so that a few natural segments exist (big spenders who visit often and recently, mid-tier regulars, and low-spend lapsed customers).

## Steps

**Step 1 — Load the inline CSV.** `io.StringIO` makes the lab fully offline.

```python
import io
import numpy as np
import pandas as pd

csv = """annual_spend,visits,recency
220,4,90
5400,48,3
180,3,120
4800,52,5
260,5,75
6100,60,2
150,2,140
5200,45,7
310,6,60
4600,40,9
2100,22,25
1900,18,30
2400,25,20
2000,20,28
2300,24,22
90,1,200
130,2,160
70,1,220
2600,27,18
5800,55,4
"""
customers = pd.read_csv(io.StringIO(csv))
print(customers.shape)        # (20, 3)
print(customers.describe().round(1))   # note the wildly different scales!
```

**Step 2 — Scale the features.** `annual_spend` is in the thousands while `visits` is single/double digits. Without scaling, spend would dominate every distance and the other two features would be ignored. `StandardScaler` puts all three on equal footing.

```python
from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
X = scaler.fit_transform(customers)
print(np.round(X.mean(axis=0), 2))   # ~[0 0 0] after scaling
print(np.round(X.std(axis=0), 2))    # ~[1 1 1]
```

**Step 3 — Pick K with an elbow plot.** Fit k-means for several K values and record inertia (total within-cluster squared distance). The "elbow" — where the curve stops dropping steeply — is a good K.

```python
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

ks = range(1, 8)
inertias = []
for k in ks:
    km = KMeans(n_clusters=k, n_init=10, random_state=0).fit(X)
    inertias.append(km.inertia_)

plt.plot(list(ks), inertias, "o-")
plt.xlabel("K (number of segments)"); plt.ylabel("inertia")
plt.title("Elbow plot for customer segments")
plt.show()
for k, i in zip(ks, inertias):
    print(f"K={k}  inertia={i:.1f}")
# Expect a sharp drop through K=3, then flattening -> elbow at K=3.
```

**Step 4 — Fit the final model at the chosen K.** We commit to K=3 (the elbow) and assign each customer a segment id.

```python
K = 3
km = KMeans(n_clusters=K, n_init=10, random_state=0)
customers["segment"] = km.fit_predict(X)
print(customers["segment"].value_counts().sort_index())
# How many customers landed in each of the 3 segments.
```

**Step 5 — Profile the segments with `groupby` means.** This is the payoff: average each original (unscaled) feature within each segment so the numbers are human-readable.

```python
profile = customers.groupby("segment")[
    ["annual_spend", "visits", "recency"]
].mean().round(1)
profile["n_customers"] = customers["segment"].value_counts().sort_index()
print(profile)
```

**Step 6 — Interpret each segment in business language.** Translate the profile table into names a stakeholder understands. (Cluster *numbers* are arbitrary — read the *values*.)

```python
# Sort segments by spend so we can name them consistently regardless of
# which integer id k-means happened to assign.
ranked = profile.sort_values("annual_spend", ascending=False)
names = ["VIP / loyal high-spenders",
         "Mid-tier regulars",
         "Low-spend lapsed customers"]
for name, (seg_id, row) in zip(names, ranked.iterrows()):
    print(f"Segment {seg_id} -> {name}: "
          f"${row['annual_spend']:.0f} spend, "
          f"{row['visits']:.0f} visits, "
          f"{row['recency']:.0f} days since last purchase")
```

## Expected output
- **Step 1** prints `(20, 3)` and a `describe()` table where `annual_spend` ranges into the thousands while `visits`/`recency` stay small — the visual proof that scaling is required.
- **Step 3** prints inertia falling steeply from K=1 to K=3, then leveling off. The bend at **K=3** is the elbow.
- **Step 4** shows roughly balanced segment counts (a high group, a mid group, a low group).
- **Step 5** is the key table. You should see one segment with high `annual_spend` + high `visits` + low `recency` (recent, engaged big spenders), one in the middle, and one with low spend + few visits + high recency (lapsed customers).
- **Step 6** prints plain-English segment names. That sentence-per-segment summary is exactly what you'd hand a marketing lead — and what makes this a strong portfolio artifact.

How to interpret it: each segment is a *type* of customer. VIPs might get loyalty perks; mid-tier regulars get upsell offers; lapsed customers get win-back campaigns. The clustering didn't know any of this — it found the structure from behavior alone.

## Extension challenge
1. Add a `silhouette_score` loop over K=2..6 (`from sklearn.metrics import silhouette_score`) and confirm it agrees with the elbow's choice of K=3.
2. Engineer a feature `spend_per_visit = annual_spend / visits` before scaling. Does it sharpen the segments or just add noise? Re-profile and compare.
3. Visualize the segments: run `PCA(n_components=2)` on the scaled features and scatter-plot the points colored by `segment`, with centroids marked. Do the three groups separate cleanly in 2D?

# PCA

> When ten columns are secretly telling you the same two things, PCA finds those two things and lets you throw the rest away.

## What is this?

**Principal Component Analysis (PCA)** is a way to take data with *many* columns (features) and squeeze it down into *fewer* columns, while keeping as much of the real information as possible.

It works by looking for the **directions in which your data spreads out the most**. The direction with the biggest spread is **Principal Component 1 (PC1)**. The next direction — at a right angle (orthogonal) to PC1 — that captures the most *remaining* spread is **PC2**, and so on. "Spread" here means **variance**, and PCA's whole bet is that *variance is where the information lives*. A column where every value is nearly the same tells you nothing; a direction where points fly far apart is where the differences (the signal) are.

Three things to lock in:

- PCA is **unsupervised** — it never looks at your labels/answers. It only studies the *shape* of the inputs.
- Each component is a **linear combination** (a weighted blend) of your original features, not one original column.
- You **must standardize features first**, because PCA chases variance and would otherwise just chase whichever column happens to have the biggest units.

## Why do we need it?

Real datasets are full of **redundancy**. Height in centimeters and height in inches are two columns carrying *one* piece of information. "Total spend," "number of orders," and "average basket size" all move together. When features are correlated, you have fewer real dimensions of information than you have columns — and the extra columns just add noise, slow models down, and make plots impossible.

PCA gives you a principled way to answer: *"How few numbers do I actually need to describe each data point without losing much?"* It hands you a budget — **`explained_variance_ratio_`** — telling you exactly what fraction of the information each component keeps, so you can decide where to cut.

## Where it's used in real ML

- **Visualization** — you can't plot 50 features, but you *can* squeeze them to 2 components and scatter-plot them to see clusters and outliers.
- **Speeding up models** — fewer columns means faster training and less memory; handy before a slow model on wide data.
- **Killing multicollinearity** — components are orthogonal by construction, so they remove the correlation that hurts models like linear regression.
- **De-noising and compression** — dropping the low-variance components throws away mostly noise (image compression and signal processing use this idea).

## What breaks if you ignore it

- **You skip standardizing → PCA rediscovers your units.** An unscaled "annual salary" (range 0–200,000) drowns out "years of experience" (range 0–40). PC1 becomes "the salary column" and tells you nothing new.
- **You feed wide, correlated data straight into a model.** Correlated features inflate variance of coefficients, slow training, and overfit. Without dimensionality reduction you carry all that baggage.
- **You try to plot high-dimensional data without it.** You're stuck looking at one or two raw columns at a time and miss the global structure.

## Mental model

Imagine a flat, oval-shaped cloud of points floating in 3D space — like a pancake tilted in the air. The pancake is *almost* flat: nearly all the spread is along its width and length, with barely any along its thickness.

```
        original 2D cloud                 PCA's view
   y |          .  .                  PC2 (little spread)
     |       . .  . .  .                   ^
     |     .  . . .  . .                    \
     |   . .  . . .  .                        \   PC1 (most spread)
     |  .  . . .  .                            *-------------->
     +-------------------- x          rotate the axes to line up
                                       with the cloud's real shape
```

PCA is the act of **rotating your coordinate axes** so the first axis points along the cloud's longest direction, the second along the next-longest, and so on. Once rotated, the last axes barely move — so you delete them. You haven't moved a single point; you've just chosen smarter axes to describe them with, then dropped the boring ones.

## Example 1 — Tiny toy example

Take five people, each with two features that are clearly correlated:

| Person | Hours studied | Cups of coffee |
|-------:|--------------:|---------------:|
| A      | 1             | 1              |
| B      | 2             | 2              |
| C      | 3             | 3              |
| D      | 4             | 4              |
| E      | 5             | 5              |

Plot these and every point sits exactly on the diagonal line `coffee = hours`. The cloud isn't really two-dimensional — it's a **straight line**. All the spread runs along one direction: the diagonal pointing toward "up and to the right."

By intuition, PCA will find:
- **PC1** = the diagonal direction (a 50/50 blend of hours and coffee). *All* the variance lives here.
- **PC2** = the perpendicular direction (off the line). The points have **zero** spread here.

So PCA reports `explained_variance_ratio_ ≈ [1.0, 0.0]`: one component captures **100%** of the information. We can describe each person by a *single* number — their position along the diagonal — instead of two, with no loss at all. That single number is exactly what "compress 2 correlated features to 1 component" means.

## Example 2 — Practical ML example

You're working with the classic **digits** dataset: 8×8 grayscale images of handwritten numbers, flattened into **64 features** (one per pixel). You can't plot 64 dimensions, and many pixels are correlated (neighboring pixels are usually similar, and corner pixels are almost always blank).

You standardize the 64 pixel features and run PCA down to **2 components** purely to *see* the data. When you scatter-plot those 2 components and color each point by its true digit, the digits fall into visibly separate blobs — even though **PCA never saw the labels**. Reading `explained_variance_ratio_`, you find PC1 and PC2 together hold maybe ~22% of the variance — enough to reveal structure for a plot, but a warning that 2 components is too few for actual *modeling*. For that, you'd keep enough components to reach, say, 90% of the variance (often ~20–30 here), shrinking 64 columns to a fraction while losing little — and training a downstream classifier far faster.

## Python code example

```python
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

# --- Inline toy data: 2 strongly correlated features (the toy example above,
#     with a tiny wobble so it's realistic rather than a perfect line). ---
X = np.array([
    [1, 1.1],
    [2, 1.9],
    [3, 3.2],
    [4, 3.8],
    [5, 5.1],
], dtype=float)                 # columns: [hours studied, cups of coffee]
print("original shape:", X.shape)          # (5, 2)

# STEP 1 — Standardize FIRST. PCA chases variance, so every feature must be
# put on the same scale (mean 0, std 1) or the bigger-unit column wins unfairly.
Xs = StandardScaler().fit_transform(X)

# STEP 2 — Fit PCA keeping all components, so we can read the variance budget.
pca = PCA()
pca.fit(Xs)

ratios = pca.explained_variance_ratio_      # fraction of info per component
print("explained variance ratio:", np.round(ratios, 3))
print("cumulative:", np.round(np.cumsum(ratios), 3))

# STEP 3 — Compress 2 correlated features down to 1 component.
X_1d = PCA(n_components=1).fit_transform(Xs)
print("compressed shape:", X_1d.shape)      # (5, 1) -> one number per person
print("each person as a single number:\n", np.round(X_1d.ravel(), 2))

# A component is a LINEAR COMBINATION of the originals (interpretability cost):
print("PC1 = %.2f*hours + %.2f*coffee (on standardized data)"
      % (pca.components_[0, 0], pca.components_[0, 1]))
```

Running this prints something like `explained variance ratio: [0.996 0.004]` — almost all the information sits in **one** component, exactly as the toy intuition predicted. The compressed output gives each person a single number, and the printed PC1 shows it's a roughly equal blend of both features.

## Common mistakes

- **Not standardizing first.** The single most common PCA bug. An unscaled large-magnitude feature hijacks PC1. Run `StandardScaler` before `PCA`, every time.
- **Treating components as original features.** PC1 is a *blend* of all your columns, so don't report "PC1 means income." You trade interpretability for compression.
- **Keeping too few components for modeling.** Dropping to 2D is great for *plotting*, but for actually training a model use the cumulative `explained_variance_ratio_` to keep ~90–95%, not a habit of "2."
- **Fitting PCA on the test set.** PCA is a transformer: `fit` on train only, then `transform` the test set. Fitting on everything leaks information.
- **Expecting PCA to capture curves.** PCA only finds *linear* directions. For curved (non-linear) structure, reach for t-SNE or UMAP instead (and still standardize first).

## Before you continue
- [ ] I can explain why "high variance along a direction" means "information."
- [ ] I can say, in one sentence, why standardizing before PCA is mandatory.
- [ ] I know what `explained_variance_ratio_` tells me and how to use it to pick components.
- [ ] I understand that a component is a linear blend of features, so PCA costs interpretability.
- [ ] I can describe PCA as "rotating the axes to line up with the data, then dropping the boring ones."

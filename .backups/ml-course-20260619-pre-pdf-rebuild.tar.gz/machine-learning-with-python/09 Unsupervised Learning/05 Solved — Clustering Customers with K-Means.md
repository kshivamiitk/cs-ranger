# Solved — Clustering Customers with K-Means

> A retail chain has no labels for "customer type" — just spend and visit data — and the marketing team needs a handful of segments to target different offers.

## Problem statement

You have a customer table with three behavioral features — `annual_spend` (dollars per year), `visits_per_month` (store visits), and `avg_basket_size` (dollars per visit) — and **no labels**. Marketing wants to split the base into a small number of **segments** they can act on (e.g. a VIP perk, a win-back coupon, a basket-builder nudge).

This is **unsupervised learning**: there is no `y` to predict, so there is no accuracy to maximize. Instead we group customers so that members of a segment behave similarly. The plan: **standardize** the three features (mandatory for a distance-based method), run **K-Means**, choose `k` honestly with the **elbow** (inertia) and the **silhouette score**, then read the centroids back in *real units* to name each segment — and finally assign a brand-new customer to one.

## Data sample

A realistic slice (the code builds the full inline set — shape `(300, 3)`, columns `annual_spend, visits_per_month, avg_basket_size`, with three natural groups baked in):

| annual_spend | visits_per_month | avg_basket_size |
|-------------:|-----------------:|----------------:|
|         4900 |               16 |              31 |
|          610 |                2 |              63 |
|         2300 |                7 |              43 |
|         5400 |               17 |              29 |
|          580 |                1 |              60 |
|         2550 |                6 |              41 |

The three groups baked into the data:

- **High-value frequent:** big annual spend, many visits, modest basket per trip (they pop in often).
- **Occasional big-basket:** low spend, rare visits, but a large basket when they do come.
- **Mid-tier steady:** middling on all three.

K-Means should recover roughly these three clouds — but only *after* we put the features on a common scale.

## Why this problem matters

Most real customer data arrives **without** a tidy "segment" column — segmentation is something you *discover*, not something you're handed. K-Means turns raw behavior into a few interpretable buckets that a marketing team can actually staff campaigns around, which is why it underpins everything from loyalty tiers to churn-risk outreach. The catch that bites beginners is that the features arrive on wildly different scales — `annual_spend` in the thousands next to `visits_per_month` in the single digits — so without standardizing, the clusters are decided almost entirely by spend and the visit/basket signal is wasted. Getting the scaling and the choice of `k` right is the whole game.

## Step-by-step reasoning

1. **Recognize there is no label.** We are not predicting; we are grouping. So the success check is cluster *quality* (silhouette) and business *interpretability*, not accuracy.
2. **Standardize first — non-negotiable.** K-Means assigns points to the *nearest* centroid by Euclidean distance. `annual_spend` (std ~1900) would utterly dominate `visits_per_month` (std ~6), so distance would be ~100% spend. `StandardScaler` puts each feature at mean 0, std 1 so a "one-std move" in visits counts as much as one in spend.
3. **Choose `k` with the elbow.** Inertia (total squared distance to each point's centroid) *always* falls as `k` grows, so we don't minimize it — we look for the **bend** where extra clusters stop buying much reduction. With three baked-in groups, expect the elbow at `k=3`.
4. **Get a second opinion from the silhouette.** For each point it compares closeness to its own cluster vs the nearest other cluster (range −1 to +1). Pick the `k` with the highest average silhouette. When the elbow and silhouette agree on 3, we're confident.
5. **Use `n_init` to dodge bad starts.** K-Means can land in a poor local optimum depending on its random initialization. `n_init=10` runs it ten times and keeps the lowest-inertia result; `random_state` makes it reproducible.
6. **Interpret centroids in real units.** The model works in scaled space, so `inverse_transform` the centroids back to dollars/visits to *name* each segment. Then assign a new customer by scaling them with the **same fitted scaler** and calling `predict` — never refit the scaler on one point.

## Python solution

```python
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# --- 1. Build inline data with THREE natural customer groups (no downloads). ---
rng = np.random.default_rng(7)

def group(n, spend, visits, basket, jitter):
    return np.column_stack([
        rng.normal(spend,  jitter[0], n),
        rng.normal(visits, jitter[1], n),
        rng.normal(basket, jitter[2], n),
    ])

high_value   = group(110, spend=5200, visits=16, basket=30, jitter=(350, 1.2, 3))
occasional   = group( 90, spend=600,  visits=2,  basket=62, jitter=(150, 0.6, 4))
mid_tier     = group(100, spend=2400, visits=7,  basket=42, jitter=(220, 0.8, 3))

X = np.vstack([high_value, occasional, mid_tier])
X[:, 1] = np.clip(X[:, 1], 0.5, None)        # visits can't go negative
X = np.round(X, 1)
cols = ["annual_spend", "visits_per_month", "avg_basket_size"]
df = pd.DataFrame(X, columns=cols)
print("Shape:", df.shape)
print("Raw feature stds (note the scale gap):")
print(df.std().round(1).to_string())

# --- 2. STANDARDIZE first (mandatory for a distance-based method). ---
scaler = StandardScaler()
Xs = scaler.fit_transform(df)

# --- 3. Choose k via the ELBOW (inertia) and the SILHOUETTE. ---
print("\n  k   inertia   silhouette")
for k in range(2, 7):
    km = KMeans(n_clusters=k, n_init=10, random_state=42).fit(Xs)
    sil = silhouette_score(Xs, km.labels_)
    print(f"  {k}   {km.inertia_:7.1f}    {sil:.3f}")

# --- 4. Fit the chosen model (k=3: elbow + best silhouette agree). ---
km = KMeans(n_clusters=3, n_init=10, random_state=42).fit(Xs)
df["segment"] = km.labels_

# --- 5. Interpret centroids in REAL units, not scaled space. ---
centers = pd.DataFrame(
    scaler.inverse_transform(km.cluster_centers_), columns=cols)
centers["n_customers"] = df["segment"].value_counts().sort_index().values
print("\nSegment centroids (real units):")
print(centers.round(1).to_string())

# --- 6. Assign a brand-new customer with the SAME fitted scaler. ---
new_customer = pd.DataFrame(
    [[5000, 12, 31]], columns=cols)               # spends a lot, visits often
new_scaled = scaler.transform(new_customer)        # transform, do NOT refit
print("\nNew customer assigned to segment:", int(km.predict(new_scaled)[0]))
```

## Expected output

- `Shape: (300, 3)` and raw stds showing the scale gap (spend std in the **thousands**, visits std in the **single digits**) — the concrete reason scaling is mandatory.
- **Elbow + silhouette table:** inertia drops steeply from `k=2` (~210) to `k=3` (~26) and then flattens (the bend at 3), while the **silhouette peaks at `k=3`** (around **0.80**, clearly above the ~0.70 at `k=2` on this well-separated toy data). The two methods agreeing on 3 is the signal to commit.
- **Centroids in real units** recover the three groups clearly: one row with **high spend (~5150), high visits (~16), modest basket (~30)** → *high-value frequent*; one with **low spend (~600), rare visits (~2), big basket (~62)** → *occasional big-basket*; and a **mid row (~2400 / ~7 / ~42)** → *mid-tier steady*. The `n_customers` column should be near 110 / 90 / 100.
- The **new customer** (`5000, 12, 31`) lands in the high-value frequent segment. Note: the integer **segment ids are arbitrary** and may permute between runs/seeds — never hard-code "segment 2 = VIP"; identify segments by their centroid values. Small-data wobble in the exact centroids is expected.

## Common mistakes

1. **Skipping standardization.** With raw features, Euclidean distance is ~100% `annual_spend`, so the visit and basket signals are ignored and the clusters are just "spend buckets." Fix: `StandardScaler().fit_transform` before `KMeans`.
2. **Picking `k` by minimizing inertia.** Inertia always falls as `k` rises (it hits 0 when `k` equals the number of points). Fix: use the *elbow* and confirm with the silhouette — never the raw minimum.
3. **Refitting the scaler on the new customer** (`StandardScaler().fit_transform(new_customer)`). A single point has no spread, so this produces garbage and a meaningless assignment. Fix: reuse the *already-fitted* scaler with `.transform`.
4. **Hard-coding cluster ids as meanings.** K-Means labels are arbitrary integers that can permute across runs. Fix: name segments from their *centroid values*, and re-derive the mapping if you retrain.
5. **Lowering `n_init` to 1.** A single random start can land in a bad local optimum and split or merge real groups. Fix: keep `n_init=10` (the default in recent scikit-learn) and set `random_state` for reproducibility.

## Extension challenge

1. Add a fourth synthetic group (e.g. brand-new low-spend, low-visit, small-basket "newcomers") and re-run the elbow/silhouette loop — does the chosen `k` move to 4?
2. Replace `StandardScaler` with `MinMaxScaler` and compare the silhouette at `k=3`; then inject a single extreme high-spender and see which scaler's clusters survive the outlier (hint: consider `RobustScaler`).
3. Turn the segments into a tiny "next-best-offer" rule: map each centroid to a campaign (VIP perk / win-back coupon / basket-builder) and write a function that takes a raw customer row and returns the offer.

## Matching animation

Open the **"K-Means Clustering Playground"**, set the `k` slider to 3, press **Init centroids**, then click **Step** repeatedly to watch Lloyd's loop in action — each round reassigns every point to its nearest centroid and then slides the centroids to the mean of their crowd, with the **inertia** read-out shrinking until it settles. Now bump `k` to 2 and to 5 (and hit **New data**) to *feel* why the elbow exists: too few centroids merge real groups and leave high inertia, too many split one group for little gain — exactly the trade-off the inertia/silhouette table in this solution is quantifying.

# Solved — Reducing Dimensions with PCA

> A sports scientist has six tangled body-measurement columns per athlete and wants a single 2-D chart that shows how athletes actually differ — without throwing away the signal.

## Problem statement

You have six physical measurements per athlete — `height_cm`, `weight_kg`, `arm_span_cm`, `leg_length_cm`, `chest_cm`, and `waist_cm` — collected for two loose archetypes (tall lean endurance athletes vs shorter heavier power athletes). The features are **highly correlated** (taller athletes tend to have longer arms and legs, while heavier athletes tend to have bigger chests and waists), so six columns carry far less than six dimensions of real information.

The goal is **dimensionality reduction with PCA**: compress the six correlated features down to **2 components** that you can plot, while keeping most of the variance (information). PCA is **unsupervised** — it never looks at the archetype label; it only finds the orthogonal directions of greatest variance. We will **standardize first** (mandatory), read `explained_variance_ratio_` to confirm two components retain most of the signal, project to 2-D for a chart, and then show that a downstream classifier on just those 2 PCA features stays nearly as accurate as one on all six.

## Data sample

A realistic slice (the code builds the full inline set — shape `(200, 6)` features plus an `archetype` label used only for coloring/validation, columns `height_cm, weight_kg, arm_span_cm, leg_length_cm, chest_cm, waist_cm`):

| height_cm | weight_kg | arm_span_cm | leg_length_cm | chest_cm | waist_cm |
|----------:|----------:|------------:|--------------:|---------:|---------:|
|     188.4 |      74.1 |       190.0 |          99.2 |     95.3 |     78.1 |
|     172.6 |      88.5 |       171.9 |          84.0 |    104.7 |     90.4 |
|     191.0 |      72.8 |       193.5 |         101.7 |     93.8 |     76.5 |
|     169.9 |      91.2 |       168.4 |          82.1 |    107.0 |     92.8 |
|     185.2 |      76.0 |       186.7 |          97.5 |     96.9 |     79.3 |

The structure baked in: **height, arm span, and leg length move together** (tall-lean athletes), while **weight, chest, and waist move together** (heavier-power athletes), and the two clusters sit at opposite ends of that spread. Because the columns are so correlated, **one or two directions** should explain most of the variance — exactly the situation PCA is built for.

## Why this problem matters

Real measurement data is full of redundancy: collect enough columns and many of them are near-restatements of each other, which bloats models, slows training, and makes plots impossible past three dimensions. PCA is the workhorse fix — it strips out the redundancy by finding the few orthogonal directions where the data actually varies, giving you a 2-D picture for stakeholders and a leaner feature set for downstream models. The discipline that matters here is twofold: **standardize first** (PCA chases variance, so an unscaled large-unit column would hijack the first component purely on its units), and **remember PCA is unsupervised** (it maximizes variance, *not* class separation), so the fact that the archetypes still separate in the projection is a happy by-product, not the objective.

## Step-by-step reasoning

1. **Spot the redundancy.** Six body measurements that all rise with overall size are heavily correlated; the *effective* dimensionality is far below six. PCA will quantify exactly how low.
2. **Standardize first — mandatory, not optional.** PCA ranks directions by variance. `weight_kg` (variance in the dozens) and `height_cm` (variance in the hundreds) live on different units, so on raw data PC1 would just track the largest-unit column. `StandardScaler` (mean 0, std 1) gives every feature equal say so the components reflect real co-variation.
3. **Fit PCA and read `explained_variance_ratio_`.** This list says what fraction of total variance each orthogonal component captures. With this much correlation, expect **PC1 to dominate** and **PC1 + PC2 to cover the large majority** (often 80–95%+).
4. **Project to 2-D and plot.** Transform the standardized data to 2 components and scatter it, coloring by the held-out archetype label *only to check the picture* — PCA itself never saw it. The two archetypes should fan out along PC1.
5. **Mind the interpretability trade-off.** Each principal component is a *linear blend* of all six features, not a single original measurement. You can inspect the loadings to interpret a component ("PC1 ≈ overall size"), but you can no longer say "this axis is height."
6. **Validate downstream.** Train a simple classifier on all six standardized features vs on just the 2 PCA features and compare test accuracy. If the 2-D version stays close, you've confirmed two numbers carry nearly all the usable signal — a real speed/storage win with little loss.

## Python solution

```python
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score

# --- 1. Build inline data: 6 CORRELATED measurements, 2 loose archetypes. ---
rng = np.random.default_rng(3)
n = 100

def athlete(n, size, lean):
    # `size` shifts overall build; `lean` shifts the weight/chest/waist axis.
    height    = rng.normal(180 + 8 * size, 4, n)
    arm_span  = height + rng.normal(2, 3, n)            # tracks height
    leg_len   = 0.53 * height + rng.normal(0, 2, n)     # tracks height
    weight    = rng.normal(82 - 8 * lean, 4, n)
    chest     = rng.normal(100 - 6 * lean, 3, n)
    waist     = rng.normal(85 - 7 * lean, 3, n)
    return np.column_stack([height, weight, arm_span, leg_len, chest, waist])

tall_lean = athlete(n, size=+1, lean=+1)   # endurance: tall, light, narrow
short_pwr = athlete(n, size=-1, lean=-1)   # power: shorter, heavier, broader
X = np.round(np.vstack([tall_lean, short_pwr]), 1)
y = np.array([0] * n + [1] * n)            # label used ONLY for validation/plot

cols = ["height_cm", "weight_kg", "arm_span_cm",
        "leg_length_cm", "chest_cm", "waist_cm"]
df = pd.DataFrame(X, columns=cols)
print("Original shape:", df.shape)
print("Feature correlation (first 3 cols):")
print(df.iloc[:, :3].corr().round(2).to_string())

# --- 2. STANDARDIZE first, then fit PCA (PCA is unsupervised: y not passed). ---
Xs = StandardScaler().fit_transform(df)
pca = PCA().fit(Xs)
ratios = pca.explained_variance_ratio_
print("\nExplained variance ratio per component:", np.round(ratios, 3))
print("Cumulative:", np.round(np.cumsum(ratios), 3))

# --- 3. Project to 2 components for visualization / speed. ---
X2 = PCA(n_components=2).fit_transform(Xs)
print("\nProjected shape:", X2.shape,
      "| variance kept by 2 PCs:", round(ratios[:2].sum(), 3))

# Loadings: each PC is a BLEND of the six features (the interpretability cost).
loadings = pd.DataFrame(
    PCA(n_components=2).fit(Xs).components_.T,
    index=cols, columns=["PC1", "PC2"])
print("\nPC loadings (how each feature blends into a component):")
print(loadings.round(2).to_string())

# --- 4. Downstream check: all 6 features vs just 2 PCA features. ---
full = Pipeline([("scale", StandardScaler()),
                 ("clf", LogisticRegression(max_iter=1000))])
reduced = Pipeline([("scale", StandardScaler()),
                    ("pca", PCA(n_components=2)),
                    ("clf", LogisticRegression(max_iter=1000))])
acc_full = cross_val_score(full, df, y, cv=5).mean()
acc_red  = cross_val_score(reduced, df, y, cv=5).mean()
print(f"\n5-fold accuracy  all 6 features: {acc_full:.3f}")
print(f"5-fold accuracy  2 PCA features: {acc_red:.3f}")
```

> Note: the PCA is wrapped *inside* the `reduced` pipeline so it is refit on each training fold during cross-validation — never fit PCA on the test fold, or you leak.

## Expected output

- `Original shape: (200, 6)`, and the correlation block shows **strong positive correlations** (height/arm-span/leg-length near **0.8–0.95**) — the redundancy PCA exploits.
- **`explained_variance_ratio_`:** PC1 dominates heavily (around **~0.80–0.85** here, because the six features are so correlated), and **PC1 + PC2 together retain the large majority** of the variance — cumulative around **~0.90–0.92**. So six columns collapse to two with little information loss; the printed "variance kept by 2 PCs" confirms it.
- **Projected shape: (200, 2)**, and the scatter (if you plot `X2` colored by `y`) shows the two archetypes fanning apart mainly along **PC1** — even though PCA never saw the labels. That separation is a by-product of variance, not a goal.
- **Loadings** reveal each PC is a *blend*: PC1 typically loads on all the size-linked features at once ("overall build"), which is why you can't call any axis "height." This is the interpretability cost.
- **Downstream accuracy:** the 6-feature and 2-PCA-feature models score **very close** (both high, often within a few points). That near-tie is the punchline — two components carry nearly all the usable signal. Exact numbers wobble with the seed; the *gap being small* is the lesson.

## Common mistakes

1. **Not standardizing before PCA.** Without scaling, the component with the biggest *units* (here `height_cm`/`arm_span_cm` in the hundreds) hijacks PC1 regardless of real structure. Fix: `StandardScaler` first, every time.
2. **Fitting PCA on the whole dataset (or the test fold) before modeling.** PCA is a transformer; fitting it on data the model will be tested on leaks variance structure. Fix: put PCA *inside* a `Pipeline` so it's fit on train folds only.
3. **Expecting components to be original features.** Reporting "PC1 = weight" is wrong — PC1 is a weighted blend of all six columns. Fix: inspect the loadings and describe the component as a theme ("overall size"), not a single variable.
4. **Assuming PCA separates classes.** PCA maximizes variance, not class separation; if the discriminative signal lies in a *low*-variance direction it can be dropped. Fix: when the goal is class separation, consider LDA, or verify with a downstream model as we did here.
5. **Dropping to 2 components for *modeling* by habit.** Two components is great for *plotting*; for modeling, choose the count from cumulative variance (e.g. `PCA(n_components=0.95)`) so you don't discard real signal. Fix: let the variance budget pick the dimension, not the desire for a 2-D chart.

## Extension challenge

1. Use `PCA(n_components=0.95)` to let scikit-learn keep just enough components for 95% of the variance — how many does it choose, and how does the downstream accuracy compare to the 2-component version?
2. Re-run PCA on the **unscaled** `df` and print PC1's explained-variance-ratio plus `df.var()`. Confirm PC1 now tracks the largest-variance raw column and explain why standardizing fixes it.
3. Inspect the PC1 loadings and write a one-sentence interpretation of what "moving along PC1" means physically; then plot `X2` and annotate which corner holds the endurance vs power athletes.

## Matching animation

Open the **"PCA Dimensionality Visualizer"** and press **Project onto PC1**: watch the scatter of correlated points collapse onto the single best-fit direction, with the variance read-out showing how much information that one axis keeps versus what's lost perpendicular to it. Click **New data** to regenerate clouds of different tilt and elongation, and you'll *see* what `explained_variance_ratio_` means — the more cigar-shaped (correlated) the cloud, the more variance PC1 alone captures, which is precisely why two components suffice for the six correlated measurements in this solution.

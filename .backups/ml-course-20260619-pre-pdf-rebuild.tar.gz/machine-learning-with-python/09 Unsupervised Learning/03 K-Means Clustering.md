# K-Means Clustering

> K-means is the "hello world" of clustering: a simple two-step dance that repeatedly nudges a fixed number of centers until each one sits in the middle of its own crowd.

## What you'll learn
- The exact steps of **Lloyd's algorithm** (assign → update → repeat).
- What **inertia** measures and how to read an **elbow plot** to choose K.
- How the **silhouette score** offers a second, independent vote on K.
- Why **scaling features first** is non-negotiable for k-means.
- How to run, inspect, and visualize `KMeans` on `make_blobs` data.

## Intuition
K-means tries to split your points into **K** groups so that points in a group are as close as possible to that group's center. You pick K up front; the algorithm finds the centers.

It runs **Lloyd's algorithm**, a loop of two moves:
1. **Assign.** Give each point to its *nearest* centroid (by straight-line distance).
2. **Update.** Move each centroid to the *mean position* of the points just assigned to it.
3. **Repeat** until the assignments stop changing (the centroids have settled).

That's it. It's like organizing people at a party into K conversation circles: first everyone joins their closest circle, then each circle's "center of gravity" shifts toward where its people actually are, and people re-shuffle to the nearest new center. After a few rounds, the circles stabilize.

The quantity k-means minimizes is **inertia**: the total squared distance from every point to its assigned centroid. Lower inertia = tighter clusters. But here's the trap — inertia *always* drops as you add more clusters (with K equal to the number of points, inertia hits zero). So you can't just minimize it. Instead you look for the **elbow**: the K where adding another cluster stops buying you much reduction. On a plot of inertia vs K, that's the bend where the curve flattens.

A second, more principled check is the **silhouette score**. For each point it compares how close that point is to its own cluster versus the nearest *other* cluster, giving a value from −1 (probably in the wrong cluster) to +1 (snugly in the right one). You pick the K with the highest average silhouette.

One non-negotiable: **scale your features first.** K-means uses raw distances, so a feature measured in the tens of thousands (income) will completely drown out a feature in the single digits (visits). Standardizing puts every feature on equal footing so distance means something.

## Python in practice

```python
import numpy as np
import matplotlib.pyplot as plt
from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# 4 natural blobs in 2D so we can SEE what k-means does.
X, _ = make_blobs(n_samples=400, centers=4, cluster_std=1.0, random_state=7)

# ALWAYS scale before a distance-based method like k-means.
Xs = StandardScaler().fit_transform(X)

km = KMeans(n_clusters=4, n_init=10, random_state=7)
labels = km.fit_predict(Xs)

print("inertia:", round(km.inertia_, 1))        # total squared distance to centers
print("iterations to converge:", km.n_iter_)    # how many assign/update rounds
print("centroids:\n", np.round(km.cluster_centers_, 2))
```

```python
# Visualize: color points by cluster, draw centroids as big X markers.
plt.figure(figsize=(5, 5))
plt.scatter(Xs[:, 0], Xs[:, 1], c=labels, s=15, cmap="viridis")
plt.scatter(km.cluster_centers_[:, 0], km.cluster_centers_[:, 1],
            c="red", marker="X", s=200, edgecolor="black")
plt.title("K-Means on scaled blobs (K=4)")
plt.show()
# You'll see four colored clouds, each with a red X sitting at its middle.
```

```python
# CHOOSING K with the elbow: inertia for K = 1..8.
ks = range(1, 9)
inertias = []
for k in ks:
    m = KMeans(n_clusters=k, n_init=10, random_state=7).fit(Xs)
    inertias.append(m.inertia_)

plt.plot(list(ks), inertias, "o-")
plt.xlabel("K"); plt.ylabel("inertia"); plt.title("Elbow plot")
plt.show()
# Expect a sharp drop until K=4, then the curve flattens -> the "elbow" at 4.
```

```python
# CHOOSING K with the silhouette (a second opinion). Silhouette needs K >= 2.
for k in range(2, 7):
    lab = KMeans(n_clusters=k, n_init=10, random_state=7).fit_predict(Xs)
    print(f"K={k}  silhouette={silhouette_score(Xs, lab):.3f}")
# The highest score should land at K=4, agreeing with the elbow.
```

A short note on the output: the elbow plot and the silhouette scores are *two independent ways* to land on K. When they agree (here, both point to 4), you can be confident. When they disagree, prefer the silhouette and bring in domain knowledge.

## Common mistakes
- **Skipping scaling.** Without `StandardScaler`, a big-magnitude feature dominates the distance and the clusters are meaningless. Always scale first.
- **Reading inertia like accuracy.** Lower inertia is *not* automatically better — it always falls as K rises. Use the *elbow*, not the minimum.
- **Using the default `n_init`.** K-means can land in a bad local solution depending on its random start. `n_init=10` runs it ten times and keeps the best; don't lower it without reason.
- **Forcing K-means on non-blobby shapes.** It assumes roughly round, similarly-sized clusters. For crescents or rings it fails — reach for DBSCAN or spectral clustering instead.
- **Treating cluster labels as fixed.** The integer ids are arbitrary and can permute between runs; never hard-code "cluster 2 = premium."

## Small exercise
1. Regenerate the blobs with `centers=3` instead of 4.
2. Rebuild the elbow plot and the silhouette loop. Where is the new elbow, and which K gets the best silhouette?
3. Now *remove* the `StandardScaler` step and multiply the first feature by 1000 before clustering. Re-run and describe how the clusters degrade. (Hint: one feature now dominates every distance.)

## Before you continue
- [ ] I can recite Lloyd's algorithm: assign to nearest center, move centers to the mean, repeat.
- [ ] I can explain why inertia alone can't choose K, and how the elbow fixes that.
- [ ] I know what the silhouette score measures and its range.
- [ ] I always scale features before running k-means, and I can say why.

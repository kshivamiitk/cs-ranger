/* PCA Dimensionality Visualizer
 * Generates ~120 correlated 2D points, computes the 2x2 covariance matrix and
 * its eigenvectors/eigenvalues in closed form, and draws the principal axes.
 * Everything is vanilla JS + Canvas 2D, no dependencies.
 */
(function () {
  "use strict";

  var canvas = document.getElementById("canvas");
  var ctx = canvas.getContext("2d");
  var W = canvas.width;    // 640
  var H = canvas.height;   // 480
  var CX = W / 2, CY = H / 2;

  // DOM
  var corrSlider = document.getElementById("corr");
  var corrVal = document.getElementById("corrVal");
  var spreadSlider = document.getElementById("spread");
  var spreadVal = document.getElementById("spreadVal");
  var btnProject = document.getElementById("project");
  var btnNew = document.getElementById("newdata");
  var pc1El = document.getElementById("pc1");
  var pc2El = document.getElementById("pc2");

  var VIOLET = "#a78bfa";
  var CYAN = "#22d3ee";

  var N = 120;
  var basePoints = [];   // standard-normal "seed" points, regenerated on New data
  var showProjection = false;

  // ---- data generation -----------------------------------------------------

  // Box-Muller standard normal
  function randn() {
    var u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }

  function makeSeeds() {
    basePoints = [];
    for (var i = 0; i < N; i++) {
      basePoints.push({ a: randn(), b: randn() });
    }
  }

  // Build correlated points from two independent normals (a, b):
  //   x = a
  //   y = rho*a + sqrt(1-rho^2)*b      -> Corr(x,y) = rho
  // Then scale by `spread` and convert to canvas pixels (y flipped).
  function buildPoints(rho, spread) {
    var k = Math.sqrt(Math.max(0, 1 - rho * rho));
    // give x a touch more base spread so the cloud reads as an ellipse
    var sx = spread * 1.15;
    var sy = spread;
    var pts = [];
    for (var i = 0; i < basePoints.length; i++) {
      var a = basePoints[i].a;
      var b = basePoints[i].b;
      var x = a * sx;
      var y = (rho * a + k * b) * sy;
      pts.push({ x: x, y: y }); // data-space (centered at 0), not yet pixels
    }
    return pts;
  }

  // ---- covariance + closed-form 2x2 eigendecomposition ---------------------

  function meanOf(pts) {
    var mx = 0, my = 0;
    for (var i = 0; i < pts.length; i++) { mx += pts[i].x; my += pts[i].y; }
    return { x: mx / pts.length, y: my / pts.length };
  }

  // Returns covariance entries cxx, cyy, cxy (population/sample, /(n-1)).
  function covariance(pts, m) {
    var sxx = 0, syy = 0, sxy = 0;
    for (var i = 0; i < pts.length; i++) {
      var dx = pts[i].x - m.x;
      var dy = pts[i].y - m.y;
      sxx += dx * dx;
      syy += dy * dy;
      sxy += dx * dy;
    }
    var denom = Math.max(1, pts.length - 1);
    return { xx: sxx / denom, yy: syy / denom, xy: sxy / denom };
  }

  // Eigen-decomposition of a real symmetric 2x2 matrix [[a, b],[b, d]].
  // Closed form: eigenvalues lambda = (a+d)/2 +- sqrt(((a-d)/2)^2 + b^2).
  // Eigenvector for lambda: solve (a - lambda) vx + b vy = 0.
  function eig2x2(a, b, d) {
    var tr = a + d;
    var diff = (a - d) / 2;
    var disc = Math.sqrt(diff * diff + b * b); // always real & >= 0 (symmetric)
    var l1 = tr / 2 + disc;   // larger eigenvalue -> PC1
    var l2 = tr / 2 - disc;   // smaller eigenvalue -> PC2

    // Eigenvector for l1. Use whichever row is numerically safer.
    var v1;
    if (Math.abs(b) > 1e-9) {
      // (a - l1)*vx + b*vy = 0  ->  v = (b, l1 - a)
      v1 = normalize(b, l1 - a);
    } else {
      // matrix is diagonal: axes are aligned with x/y
      v1 = (a >= d) ? { x: 1, y: 0 } : { x: 0, y: 1 };
    }
    // PC2 is orthogonal to PC1.
    var v2 = { x: -v1.y, y: v1.x };

    return {
      l1: Math.max(l1, 0),
      l2: Math.max(l2, 0),
      v1: v1,
      v2: v2
    };
  }

  function normalize(x, y) {
    var n = Math.sqrt(x * x + y * y);
    if (n < 1e-12) return { x: 1, y: 0 };
    return { x: x / n, y: y / n };
  }

  // ---- rendering ------------------------------------------------------------

  // data-space -> pixel-space (center at canvas middle, flip y for screen up)
  function toPx(p, m) {
    return { x: CX + (p.x - m.x), y: CY - (p.y - m.y) };
  }

  function drawArrow(fromPx, dir, lenPx, color, label) {
    // dir is a unit vector in DATA space; flip y for screen.
    var ex = fromPx.x + dir.x * lenPx;
    var ey = fromPx.y - dir.y * lenPx;
    ctx.save();
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = 3;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    // shaft
    ctx.beginPath();
    ctx.moveTo(fromPx.x, fromPx.y);
    ctx.lineTo(ex, ey);
    ctx.stroke();
    // arrowhead
    var ang = Math.atan2(ey - fromPx.y, ex - fromPx.x);
    var hs = 11;
    ctx.beginPath();
    ctx.moveTo(ex, ey);
    ctx.lineTo(ex - hs * Math.cos(ang - 0.4), ey - hs * Math.sin(ang - 0.4));
    ctx.lineTo(ex - hs * Math.cos(ang + 0.4), ey - hs * Math.sin(ang + 0.4));
    ctx.closePath();
    ctx.fill();
    // label
    ctx.shadowBlur = 0;
    ctx.font = "bold 13px Inter, sans-serif";
    ctx.fillText(label, ex + 6 * dir.x + 4, ey - 6 * dir.y - 4);
    ctx.restore();
  }

  function render() {
    var rho = parseInt(corrSlider.value, 10) / 100;
    var spread = parseInt(spreadSlider.value, 10) / 26; // tune to canvas size
    var pts = buildPoints(rho, spread);
    var m = meanOf(pts);
    var cov = covariance(pts, m);
    var e = eig2x2(cov.xx, cov.xy, cov.yy);

    // variance explained (%)
    var total = e.l1 + e.l2;
    var p1 = total > 1e-12 ? (e.l1 / total) * 100 : 50;
    var p2 = total > 1e-12 ? (e.l2 / total) * 100 : 50;
    pc1El.textContent = p1.toFixed(1) + "%";
    pc2El.textContent = p2.toFixed(1) + "%";

    // --- draw ---
    ctx.clearRect(0, 0, W, H);

    // grid
    ctx.strokeStyle = "rgba(255,255,255,0.04)";
    ctx.lineWidth = 1;
    for (var gx = 0; gx <= W; gx += 64) {
      ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke();
    }
    for (var gy = 0; gy <= H; gy += 64) {
      ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke();
    }

    var meanPx = { x: CX, y: CY }; // data is centered, so mean maps to middle

    // optional: PC1 line + projections drawn UNDER the points
    if (showProjection) {
      // draw the infinite PC1 line through the mean
      var big = 1000;
      ctx.save();
      ctx.strokeStyle = "rgba(167,139,250,0.45)";
      ctx.setLineDash([6, 6]);
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.moveTo(meanPx.x - e.v1.x * big, meanPx.y + e.v1.y * big);
      ctx.lineTo(meanPx.x + e.v1.x * big, meanPx.y - e.v1.y * big);
      ctx.stroke();
      ctx.restore();
    }

    // points (+ projection segments)
    for (var i = 0; i < pts.length; i++) {
      var ppx = toPx(pts[i], m);

      if (showProjection) {
        // project (point - mean) onto unit v1, in data space
        var dx = pts[i].x - m.x;
        var dy = pts[i].y - m.y;
        var t = dx * e.v1.x + dy * e.v1.y;        // scalar coordinate along PC1
        var projData = { x: m.x + t * e.v1.x, y: m.y + t * e.v1.y };
        var projPx = toPx(projData, m);

        // thin connector showing discarded (PC2) distance
        ctx.strokeStyle = "rgba(248,113,113,0.30)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(ppx.x, ppx.y);
        ctx.lineTo(projPx.x, projPx.y);
        ctx.stroke();

        // the projected (compressed) point on the PC1 line
        ctx.beginPath();
        ctx.arc(projPx.x, projPx.y, 3, 0, Math.PI * 2);
        ctx.fillStyle = CYAN;
        ctx.fill();
      }

      ctx.beginPath();
      ctx.arc(ppx.x, ppx.y, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = showProjection ? "rgba(226,232,240,0.45)" : "rgba(226,232,240,0.8)";
      ctx.fill();
    }

    // arrows: length proportional to sqrt(eigenvalue) = std dev along axis.
    // scale so the larger axis is a readable length on screen.
    var maxLen = 150;
    var sd1 = Math.sqrt(e.l1);
    var sd2 = Math.sqrt(e.l2);
    var maxSd = Math.max(sd1, sd2, 1e-9);
    var scale = maxLen / maxSd;
    drawArrow(meanPx, e.v1, sd1 * scale, VIOLET, "PC1");
    drawArrow(meanPx, e.v2, sd2 * scale, CYAN, "PC2");

    // mean marker
    ctx.beginPath();
    ctx.arc(meanPx.x, meanPx.y, 4, 0, Math.PI * 2);
    ctx.fillStyle = "#f8fafc";
    ctx.fill();
  }

  // ---- UI glue --------------------------------------------------------------

  function fmtCorr(v) { return (v / 100).toFixed(2); }
  function fmtSpread(v) { return (v / 100).toFixed(1) + "×"; }

  corrSlider.addEventListener("input", function () {
    corrVal.textContent = fmtCorr(parseInt(corrSlider.value, 10));
    render();
  });
  spreadSlider.addEventListener("input", function () {
    spreadVal.textContent = fmtSpread(parseInt(spreadSlider.value, 10));
    render();
  });
  btnProject.addEventListener("click", function () {
    showProjection = !showProjection;
    btnProject.classList.toggle("active", showProjection);
    btnProject.textContent = showProjection ? "Hide projection" : "Project onto PC1";
    render();
  });
  btnNew.addEventListener("click", function () {
    makeSeeds();
    render();
  });

  // ---- init -----------------------------------------------------------------
  corrVal.textContent = fmtCorr(parseInt(corrSlider.value, 10));
  spreadVal.textContent = fmtSpread(parseInt(spreadSlider.value, 10));
  makeSeeds();
  render();
})();

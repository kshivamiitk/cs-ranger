# K-Means

> Nobody labeled your data, but you suspect it falls into natural groups. K-Means is the workhorse that finds those groups for you: pick how many groups you want, and it shuffles points and centers until the grouping settles.

## What is this?

K-Means is an **unsupervised** algorithm — it works on data with **no labels**. You give it points and a number `k`, and it partitions the points into `k` clusters, each represented by a **centroid** (the average position of the points in that cluster).

It works by repeating two simple steps until nothing changes — this loop is called **Lloyd's algorithm**:

1. **Assign step** — give each point to the **nearest centroid** (by straight-line distance).
2. **Update step** — move each centroid to the **mean** of the points now assigned to it.

```
Start: k=2 centroids placed (e.g. by k-means++)
   |
   v
[Assign]  each point -> nearest centroid
   |
   v
[Update]  each centroid -> average of its points
   |
   +--> changed? --yes--> back to Assign
        |
        no
        v
   Done: clusters are stable
```

Each round the centroids drift toward the dense middles of the groups, and the assignments stabilize. The starting positions matter, which is why scikit-learn defaults to **k-means++**, a smart initialization that spreads the first centroids apart instead of placing them randomly (which can land two centroids in the same blob and produce a bad result).

K-Means assumes clusters are **roughly round (spherical) and similar in size**, because "nearest centroid" carves space into straight-edged regions. And because it uses distance, you almost always must **scale your features first**.

## Why do we need it?

Because a huge amount of real data arrives **without labels**, and you still need to make sense of it. You cannot run supervised learning when nobody has told you the "right answers." K-Means discovers structure on its own: it turns a shapeless cloud of customers, documents, or sensor readings into a handful of interpretable groups you can name and act on.

It is also **fast and simple**, which is why it is usually the first clustering method anyone reaches for. You get a quick, useful segmentation, and the centroids themselves are interpretable — a centroid is just an "average member" of its group, so you can read off what each cluster is about.

The price of that simplicity: **you must choose k yourself.** K-Means will not tell you how many groups exist. You decide using the **elbow method** (plot total within-cluster distance as k increases and look for the bend) or the **silhouette score** (measures how tight and well-separated clusters are; higher is better).

## Where it's used in real ML

- **Customer segmentation** — grouping shoppers by spending and frequency so marketing can target each group differently.
- **Image color compression** — replacing millions of pixel colors with k representative colors (the centroids).
- **Document / topic grouping** — clustering articles by TF-IDF vectors to surface themes.
- **Anomaly detection** — points far from every centroid are candidate outliers.
- **Feature engineering** — a "cluster ID" can become a useful categorical feature for a downstream supervised model.

## What breaks if you ignore it

- **Skip scaling** and the feature with the biggest numeric range (say income in the tens of thousands) dominates the distance, while age or rating contributes almost nothing — your clusters reflect units, not meaning.
- **Pick k blindly** and you over- or under-segment; with no elbow/silhouette check you might split one real group into three or merge three into one.
- **Use random init instead of k-means++** and you occasionally get a poor local optimum where two centroids share a blob and a real cluster gets ignored.
- **Force K-Means on non-spherical data** (crescents, rings, very different cluster sizes) and it slices them wrongly, because it can only draw straight-edged regions around centroids.

## Mental model

Imagine **k food trucks** want to park in a city so the total walking distance for all residents is as small as possible.

- **Assign:** every resident walks to the nearest truck.
- **Update:** each truck moves to the center of the crowd that showed up.

People near the boundary switch trucks, trucks drift toward their crowds, and after a few rounds everything settles. The final truck positions are the **centroids**; the crowd at each truck is a **cluster**. Pick too few trucks (small k) and some residents walk forever; too many (large k) and trucks sit nearly on top of each other.

```
Iteration 0           Iteration 1            Converged
  x  x                  x  x                   x x
 x x   . o             x x  . o               xx  .o
   .  o  o   --->        . o  o     --->        . oo
  x = points near centroid A   . = centroid A
  o = points near centroid B   (centroids slide to the crowd's middle)
```

## Example 1 — Tiny toy example

Six points on a line for clarity: **1, 2, 3, 8, 9, 10**. Choose **k=2**, and start centroids at **C1 = 2** and **C2 = 9**.

**Assign step** — each point joins the nearer centroid:

- 1, 2, 3 are closer to C1 (2) → Cluster 1
- 8, 9, 10 are closer to C2 (9) → Cluster 2

**Update step** — move each centroid to the mean of its cluster:

- New C1 = mean(1, 2, 3) = **2.0**
- New C2 = mean(8, 9, 10) = **9.0**

The centroids did not move, so the assignments will not change on the next round — **K-Means has converged** in a single update. The two natural groups `{1,2,3}` and `{8,9,10}` fell straight out. (Try starting both centroids at 2 and 3 instead: you would see them split the gap over a couple of rounds before settling, which is exactly why initialization matters.)

## Example 2 — Practical ML example

You run an online store and have a table of customers with **annual spend** (in dollars) and **visits per month**. Nobody labeled these customers; you want segments for marketing. Spend ranges in the thousands while visits range 1–30, so without scaling, spend would completely dominate the distance.

You **StandardScaler** the two features, run `KMeans(n_clusters=3)`, and get three groups. Inspecting the centroids (transformed back to original units) you might find: a **"high-value loyal"** segment (high spend, many visits), a **"bargain browser"** segment (low spend, many visits), and a **"big-but-rare buyer"** segment (high spend, few visits). Each centroid is the average customer of its group, so the segments are immediately interpretable and the marketing team can design an offer per group.

## Python code example

```python
# K-Means customer segmentation: scale first, choose k, inspect centroids.
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score

# --- Inline toy customers: [annual_spend_$, visits_per_month] ---
# Three rough groups baked in, but K-Means is NOT told the labels.
X = np.array([
    [ 200,  2], [ 350,  3], [ 180,  1], [ 420,  4],   # low spend, rare visits
    [ 250, 22], [ 300, 25], [ 220, 28], [ 280, 20],   # low spend, frequent visits
    [4800, 18], [5200, 21], [4500, 24], [5000, 19],   # high spend, frequent visits
], dtype=float)

# 1) MUST scale: spend (~hundreds-thousands) would otherwise drown out visits (1-30).
scaler = StandardScaler()
Xs = scaler.fit_transform(X)

# 2) Choose k. Quick silhouette check across a few candidates (higher = better).
for k in (2, 3, 4):
    labels_k = KMeans(n_clusters=k, n_init=10, random_state=0).fit_predict(Xs)
    print(f"k={k}  silhouette={silhouette_score(Xs, labels_k):.3f}")

# 3) Fit the chosen model. n_init=10 + default 'k-means++' guards against bad starts.
km = KMeans(n_clusters=3, init="k-means++", n_init=10, random_state=0)
labels = km.fit_predict(Xs)

# 4) Interpret: bring centroids back to real units so segments are readable.
centroids = scaler.inverse_transform(km.cluster_centers_)
print("\nCluster centroids (real units): [spend $, visits/month]")
for i, c in enumerate(centroids):
    print(f"  Cluster {i}: spend=${c[0]:,.0f}  visits={c[1]:.0f}/mo")

print("\nEach customer's assigned cluster:", labels)
```

Expected output (cluster numbers may differ; the groupings are what matter):

```
k=2  silhouette=0.55
k=3  silhouette=0.72
k=4  silhouette=0.51

Cluster centroids (real units): [spend $, visits/month]
  Cluster 0: spend=$288  visits=2/mo
  Cluster 1: spend=$263  visits=24/mo
  Cluster 2: spend=$4,875  visits=20/mo

Each customer's assigned cluster: [0 0 0 0 1 1 1 1 2 2 2 2]
```

## Common mistakes

- **Not scaling the features.** K-Means uses distance, so an unscaled large-range feature dominates and the clusters just reflect that one column. Standardize first (almost always).
- **Guessing k with no method.** Use the **elbow** (inertia vs k) or **silhouette score** to choose k instead of picking a number out of thin air.
- **Relying on a single random initialization.** Keep `n_init` > 1 (scikit-learn's default reruns and keeps the best) and use `k-means++` so a bad start does not give you a bad clustering.
- **Forcing it on non-spherical clusters.** Crescents, rings, or very different-sized/density groups break the spherical assumption — reach for DBSCAN or Gaussian Mixtures instead.
- **Treating cluster numbers as meaningful labels.** Cluster IDs (0, 1, 2) are arbitrary and can swap between runs; interpret clusters by their **centroids**, not by the ID number.

## Before you continue
- [ ] I can describe Lloyd's two steps: assign points to the nearest centroid, then move centroids to the mean.
- [ ] I know K-Means is unsupervised and that I must choose k myself (via elbow or silhouette).
- [ ] I understand why scaling features is almost always required before K-Means.
- [ ] I know what k-means++ does and why initialization affects the result.
- [ ] I can name a case where K-Means is the wrong tool (non-spherical / very unequal clusters).

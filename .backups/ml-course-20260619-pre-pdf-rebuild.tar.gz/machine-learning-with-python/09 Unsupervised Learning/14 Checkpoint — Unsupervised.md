# Checkpoint — Unsupervised Learning

## What you should now be able to do
- Explain how unsupervised learning differs from supervised learning and what "structure" means.
- Name and describe three use cases: segmentation, compression, and anomaly detection.
- Recite Lloyd's algorithm and run `KMeans` correctly (including scaling first).
- Choose K with an elbow plot (inertia) and confirm it with the silhouette score.
- Use PCA to compress dimensions, read `explained_variance_ratio_`, and decide how many components to keep.
- Profile clusters with `groupby` and translate them into business segments.

## Review questions
1. In one sentence, what makes a learning problem *unsupervised*?
2. Give one concrete example each of segmentation, compression, and anomaly detection.
3. State the three repeating steps of Lloyd's algorithm.
4. What does **inertia** measure, and why can't you simply pick the K that minimizes it?
5. What does the **silhouette score** compare, and what is its range?
6. Why must features be scaled before k-means *and* before PCA?
7. What is a **principal component**, in terms of your original features?
8. If `explained_variance_ratio_` starts `[0.62, 0.24, 0.08, ...]`, how many components keep at least 90% of the variance, and how do you know?
9. Why are k-means cluster id numbers (0, 1, 2) not meaningful on their own?
10. Name one situation where PCA is a poor choice and say why.

## Answers

<details><summary>Show answers</summary>

1. The training data has **no target/label column**; the algorithm must discover structure (groups, low-dimensional axes, outliers) from the features alone.
2. *Segmentation:* grouping customers by spending behavior for marketing. *Compression:* reducing 100 correlated sensor columns to 10 PCA components to speed up a model. *Anomaly detection:* flagging credit-card transactions that sit far from any normal cluster as possible fraud.
3. **Assign** each point to its nearest centroid; **update** each centroid to the mean of its assigned points; **repeat** until assignments stop changing.
4. Inertia is the total squared distance from each point to its assigned centroid (lower = tighter clusters). You can't minimize it directly because it *always* decreases as K grows (reaching 0 when K equals the number of points). Instead you look for the *elbow* where the decrease sharply slows.
5. For each point, the silhouette compares the average distance to points in its **own** cluster against the average distance to points in the **nearest other** cluster. It ranges from −1 (likely misassigned) through 0 (on a boundary) to +1 (well inside its cluster). You pick the K with the highest mean silhouette.
6. Both methods are driven by variance/distance, which is sensitive to units. An unscaled large-magnitude feature (e.g. income in the tens of thousands) dominates distances in k-means and hijacks the top principal component in PCA. Standardizing gives every feature equal influence.
7. A principal component is a **new axis defined as a weighted blend (linear combination) of the original features**, chosen so the data varies as much as possible along it (and each later component is orthogonal to the earlier ones).
8. **Three** components. The cumulative sum is 0.62, then 0.86, then 0.94 — the running total first reaches/exceeds 0.90 at the third component.
9. The integer ids are arbitrary names the algorithm assigns to discovered groups; they carry no order or ranking and can permute between runs. You must read the *cluster profiles* (feature means) to understand what each group represents.
10. PCA is poor when **interpretability of individual features is required** (components are blends, not original variables) or when the structure is **strongly non-linear** (PCA captures only linear directions; a curved manifold needs t-SNE/UMAP or kernel methods).

</details>

## Hands-on tasks
1. **Cluster `make_blobs`.** Generate 4 blobs, scale, fit `KMeans`, and produce both an elbow plot and a silhouette loop. Confirm both agree on K=4.
2. **Break it on purpose.** Multiply one feature by 1000 and re-cluster *without* scaling. Describe in a comment how the clusters degrade and why.
3. **Compress the wine dataset.** Scale `load_wine`, fit `PCA`, print cumulative `explained_variance_ratio_`, and report how many components reach 95% variance. Then project to 2D and scatter-plot colored by the true class.
4. **Segment + profile.** Recreate the Module 09 lab: scale a small customer table, choose K via the elbow, fit k-means, and produce a `groupby` profile table with a one-line business name for each segment.

## You're ready for the next module when…
- [ ] I can run k-means correctly (scale → choose K → fit → profile) without notes.
- [ ] I can interpret an elbow plot and a silhouette score to defend my choice of K.
- [ ] I can apply PCA, read `explained_variance_ratio_`, and justify how many components I kept.
- [ ] I can turn raw cluster output into named, business-meaningful segments.

# Cross-Validation

> One train-test split gives you a score that depends on luck — which rows happened to land in the test set. Cross-validation averages over several splits so you get an estimate you can actually trust, plus a sense of how much it wobbles.

## What is this?

When you measure how good a model is, you score it on data it never saw during training. The usual way is a single **train-test split**: 80% train, 20% test. But that one test set is a random sample. Get an easy 20% and your score looks great; get a hard 20% and the same model looks worse. The number you report is partly **noise from one draw**.

**k-fold cross-validation** removes that lottery. Split the data into `k` equal chunks called **folds** (commonly k=5). Then run `k` rounds. In each round, one fold is held out as the validation set and the other `k-1` folds are used for training. Every row gets to be in the validation set exactly once. You end up with `k` scores — average them.

```
5-fold, k=5:   round 1  [VAL][train][train][train][train]
               round 2  [train][VAL][train][train][train]
               round 3  [train][train][VAL][train][train]
               round 4  [train][train][train][VAL][train]
               round 5  [train][train][train][train][VAL]
               final = mean(score_1..score_5)  +/- std
```

You report the result as **mean ± standard deviation**, e.g. `0.84 ± 0.03`. The mean is your best estimate of true performance; the standard deviation tells you how stable that estimate is. A small std means the model performs consistently; a large std means it is fragile and sensitive to which data it sees.

## Why do we need it?

Because **a single split is a noisy measurement**, and decisions made on noise are bad decisions.

If Model A scores 0.86 and Model B scores 0.84 on one split, is A actually better? Maybe — or maybe A just got an easier test fold. Cross-validation gives you `0.85 ± 0.04` vs `0.84 ± 0.03`, and now you can see the difference is within the noise. You stop fooling yourself.

It also **uses your data efficiently**. With a single split, 20% of your data never helps train and 80% never helps test. With 5-fold CV, every row trains the model four times and tests it once. That matters a lot when you have only a few hundred rows.

The catch — and it is the part beginners get wrong — is **preprocessing**. If you scale or impute *before* splitting into folds, information from the validation fold leaks into training and your scores come out too optimistic. The fix is to wrap preprocessing and the model in a **Pipeline**, so each fold refits the scaler/imputer using only that fold's training portion. (See the code.)

## Where it's used in real ML

- **Hyperparameter tuning** — `GridSearchCV` and `RandomizedSearchCV` are literally cross-validation wrapped around a parameter search; CV picks the setting that generalizes, not the one that got lucky.
- **Model selection** — comparing logistic regression vs random forest vs gradient boosting on a fair, low-noise basis.
- **Small datasets** — medical, scientific, or niche business data where you cannot afford to "waste" 20% on a single test set.
- **Kaggle and benchmarks** — a reliable local CV score is how competitors avoid overfitting to the public leaderboard.
- **Production sanity checks** — confirming a model's score is stable (low std) before trusting it with real decisions.

## What breaks if you ignore it

- You **pick the wrong model** because Model A's single-split win was pure luck, and it underperforms in production.
- You **report an over-optimistic accuracy** to stakeholders, then face an embarrassing gap when the model meets real data.
- You **leak data** by scaling before splitting, inflating your CV score by several points and discovering the truth only after deployment.
- On imbalanced data, a plain split or plain KFold can put **almost no positives in a fold**, making that fold's score meaningless — you needed StratifiedKFold.

## Mental model

Think of grading a student with **one exam vs five quizzes**. One exam might land on the one chapter they happened to study — a lucky, misleading A. Five quizzes across the whole syllabus, averaged, tell you what they actually know, and the spread of quiz scores tells you whether they are consistent or erratic. Cross-validation is the five-quiz approach to grading a model.

```
Single split (one exam):     [---- train 80% ----][test 20%]   one score, high variance

5-fold CV (five quizzes):    fold1 fold2 fold3 fold4 fold5
                               80 |  85 |  79 |  88 |  83        -> mean 83, std ~3.2
                                                                 "consistent ~83%"
```

## Example 1 — Tiny toy example

You have **10 rows**, indices 0–9, and you choose **k=5**. The data is shuffled, then sliced into 5 folds of 2 rows each. Here is exactly which rows validate in each round (the rest train):

| Round | Validation rows | Training rows                |
|-------|-----------------|------------------------------|
| 1     | 0, 1            | 2, 3, 4, 5, 6, 7, 8, 9       |
| 2     | 2, 3            | 0, 1, 4, 5, 6, 7, 8, 9       |
| 3     | 4, 5            | 0, 1, 2, 3, 6, 7, 8, 9       |
| 4     | 6, 7            | 0, 1, 2, 3, 4, 5, 8, 9       |
| 5     | 8, 9            | 0, 1, 2, 3, 4, 5, 6, 7       |

Notice: every row appears in **exactly one** validation set, and every row is used for **training in four** of the five rounds. No row is ever in both train and validation in the same round. Five scores come out; their average is your CV estimate.

## Example 2 — Practical ML example

You are classifying the **Iris** flowers (or any small tabular dataset) and you want a trustworthy accuracy for a k-NN model that needs its features **scaled**. The trap: if you `StandardScaler` the whole dataset and then cross-validate, each validation fold was scaled using statistics that include itself — leakage.

The clean approach: build a `Pipeline([scaler, knn])` and hand the *whole pipeline* to `cross_val_score` with `StratifiedKFold(5)`. Now in each of the 5 rounds, scikit-learn refits the scaler on only that round's training folds, transforms the held-out fold with those statistics, then trains and scores k-NN. Stratification keeps the three flower classes balanced in every fold. You report something like `0.96 ± 0.03` — an honest, leakage-free estimate.

## Python code example

```python
# Cross-validation done right: preprocessing inside a Pipeline, stratified folds.
import numpy as np
from sklearn.datasets import load_iris
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import cross_val_score, StratifiedKFold

X, y = load_iris(return_X_y=True)   # 150 rows, 4 features, 3 balanced classes

# Put SCALING and MODEL in one pipeline. This is the key to no leakage:
# in every fold, the scaler is refit on that fold's TRAIN data only.
pipe = Pipeline([
    ("scale", StandardScaler()),
    ("knn",   KNeighborsClassifier(n_neighbors=5)),
])

# StratifiedKFold keeps each class's proportion the same in every fold.
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)

scores = cross_val_score(pipe, X, y, cv=cv, scoring="accuracy")

print("Score from each of the 5 folds:", np.round(scores, 3))
print(f"Cross-validated accuracy: {scores.mean():.3f} +/- {scores.std():.3f}")

# Contrast: a SINGLE split is noisier. Run it under a few different seeds
# and watch the number jump around -- that wobble is exactly what CV averages out.
from sklearn.model_selection import train_test_split
single_scores = []
for seed in range(5):
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=seed)
    single_scores.append(pipe.fit(Xtr, ytr).score(Xte, yte))

print("\nFive different single-split scores:", np.round(single_scores, 3))
print(f"Single-split range: {min(single_scores):.3f} to {max(single_scores):.3f}  (luck of the draw)")
print(f"CV is steadier because it averages all 5 folds instead of betting on one split.")
```

Expected output (numbers approximate):

```
Score from each of the 5 folds: [0.967 0.967 0.933 0.967 1.   ]
Cross-validated accuracy: 0.967 +/- 0.021

Five different single-split scores: [0.967 1.    0.933 0.967 0.9  ]
Single-split range: 0.900 to 1.000  (luck of the draw)
CV is steadier because it averages all 5 folds instead of betting on one split.
```

## Common mistakes

- **Scaling or imputing before splitting.** Fitting a `StandardScaler` (or `SimpleImputer`, or any `.fit`) on the full dataset before cross-validation leaks validation data into training. Always put preprocessing **inside a Pipeline** so it refits per fold.
- **Plain KFold on imbalanced data.** Without stratification, a rare class can be nearly absent from some folds, producing meaningless or wildly varying scores. Use **StratifiedKFold** for classification.
- **Reporting only the mean.** `0.84` hides whether folds ranged 0.83–0.85 (rock solid) or 0.70–0.98 (fragile). Always report **mean ± std**.
- **Choosing k carelessly.** Tiny k (like 2) gives a high-variance estimate; k equal to the number of rows (leave-one-out) is very slow and high-variance too. **k = 5 or 10** is the sane default.
- **Forgetting to shuffle ordered data.** If rows are sorted by class or time, unshuffled folds can each contain one block — set `shuffle=True` (but for time series, use `TimeSeriesSplit` instead, never random shuffling).

## Before you continue
- [ ] I can explain why a single train-test split gives a noisy, luck-dependent score.
- [ ] I can describe k-fold CV: each fold validates once and trains in the other k-1 rounds.
- [ ] I know to report results as **mean ± std**, and what a large std tells me.
- [ ] I understand why preprocessing must live inside a Pipeline so each fold refits without leakage.
- [ ] I know when to use StratifiedKFold (classification / imbalance) versus a plain split.

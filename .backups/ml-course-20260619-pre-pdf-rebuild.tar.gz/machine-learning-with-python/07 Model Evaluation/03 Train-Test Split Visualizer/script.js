"use strict";

// ---- Config ----
const N = 80;                 // number of dots (examples) in the dataset
const COLORS = { train: "#22d3ee", test: "#a78bfa" };

// ---- Elements ----
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const fracSlider = document.getElementById("frac");
const fracVal = document.getElementById("fracVal");
const reshuffleBtn = document.getElementById("reshuffle");
const els = {
  total: document.getElementById("totalN"),
  train: document.getElementById("trainN"),
  test: document.getElementById("testN"),
  trainPct: document.getElementById("trainPct"),
  testPct: document.getElementById("testPct"),
  seed: document.getElementById("seedN"),
};

// ---- Seeded PRNG (mulberry32) so a given random_state reproduces a split ----
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Dot positions stay FIXED (the dataset doesn't change); only the split colors move.
// We lay them on a jittered grid so they look like a real scatter, not a lattice.
let dots = [];
function buildDots() {
  const rand = mulberry32(20240601);   // fixed seed -> stable layout across reshuffles
  const cols = 10, rows = Math.ceil(N / cols);
  dots = [];
  for (let i = 0; i < N; i++) {
    const cx = i % cols, cy = Math.floor(i / cols);
    dots.push({
      gx: (cx + 0.5) / cols + (rand() - 0.5) * 0.06,   // normalized 0..1 with jitter
      gy: (cy + 0.5) / rows + (rand() - 0.5) * 0.10,
      isTest: false,
    });
  }
}

// ---- The actual split: shuffle indices with the seed, take the first chunk as test ----
let seed = 42;
function applySplit() {
  const testFrac = clamp(parseFloat(fracSlider.value), 0.1, 0.5);
  const nTest = Math.round(N * testFrac);

  // Fisher-Yates shuffle of indices using the seeded RNG -> deterministic for this seed.
  const idx = Array.from({ length: N }, (_, i) => i);
  const rand = mulberry32(seed >>> 0);
  for (let i = N - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [idx[i], idx[j]] = [idx[j], idx[i]];
  }

  dots.forEach((d) => (d.isTest = false));
  for (let k = 0; k < nTest; k++) dots[idx[k]].isTest = true;

  const trainN = N - nTest;
  els.total.textContent = N;
  els.train.textContent = trainN;
  els.test.textContent = nTest;
  els.trainPct.textContent = Math.round((trainN / N) * 100) + "%";
  els.testPct.textContent = Math.round((nTest / N) * 100) + "%";
  els.seed.textContent = seed;
  fracVal.textContent = testFrac.toFixed(2);
}

function clamp(v, lo, hi) {
  if (Number.isNaN(v)) return lo;
  return Math.min(hi, Math.max(lo, v));
}

// ---- Rendering ----
function draw() {
  const W = canvas.width, H = canvas.height;
  const pad = 28;
  ctx.clearRect(0, 0, W, H);

  // subtle frame
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.lineWidth = 1;
  ctx.strokeRect(pad - 8, pad - 8, W - 2 * (pad - 8), H - 2 * (pad - 8));

  for (const d of dots) {
    const x = pad + d.gx * (W - 2 * pad);
    const y = pad + d.gy * (H - 2 * pad);
    const color = d.isTest ? COLORS.test : COLORS.train;
    // glow
    ctx.beginPath();
    ctx.fillStyle = color;
    ctx.shadowColor = color;
    ctx.shadowBlur = 10;
    ctx.arc(x, y, 7, 0, Math.PI * 2);
    ctx.fill();
    // crisp core
    ctx.shadowBlur = 0;
    ctx.beginPath();
    ctx.fillStyle = "rgba(255,255,255,0.18)";
    ctx.arc(x, y, 2.2, 0, Math.PI * 2);
    ctx.fill();
  }
}

function update() { applySplit(); draw(); }

// ---- Events ----
fracSlider.addEventListener("input", update);
reshuffleBtn.addEventListener("click", () => {
  // a "new random_state": pick a fresh seed, like changing random_state in sklearn
  seed = Math.floor(Math.random() * 9999);
  update();
});

// ---- Init ----
buildDots();
update();

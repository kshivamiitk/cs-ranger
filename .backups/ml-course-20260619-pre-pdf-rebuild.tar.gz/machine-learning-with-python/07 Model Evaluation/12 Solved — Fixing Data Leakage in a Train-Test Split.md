# Solved — Fixing Data Leakage in a Train-Test Split

> A model reports 98% test accuracy in the notebook and 81% in production. The gap isn't bad luck — it's a one-line preprocessing bug that let the test set whisper to the training set.

## Problem statement

We're scoring a classifier with a held-out test set. The reported test accuracy looks suspiciously high. The bug: the data was **scaled before the split** — `StandardScaler().fit_transform(X)` was called on the *entire* dataset, so the scaler learned its mean and standard deviation from rows that later became the test set. That's **data leakage**: the test set influenced preprocessing, so the test score is optimistically inflated. The goal is to (1) reproduce the inflated number, (2) show the honest number, and (3) fix it permanently by putting scaling inside a `Pipeline` that's fit on training folds only.

## Data sample

We use scikit-learn's built-in **breast cancer** dataset (569 samples, 30 features, binary target) so there's nothing to download and the leak is measurable. Shape after loading: `X` = (569, 30), `y` = (569,).

```python
from sklearn.datasets import load_breast_cancer
X, y = load_breast_cancer(return_X_y=True)
print(X.shape, y.shape)   # (569, 30) (569,)
# Features are on wildly different scales (radius ~10s, area ~100s-1000s),
# so a distance/scale-sensitive model NEEDS standardization -- which is
# exactly where the leak sneaks in.
```

## Why this problem matters

Data leakage is the single most common reason a model that "worked great offline" collapses in production. The numbers don't just drift — they were never real, because evaluation was contaminated. Scaling-before-split is the textbook example: the scaler's `mean_` and `scale_` are *learned parameters*, and learning them from the test rows is the same sin as training on the test set. The fix costs nothing and is the entire reason `Pipeline` exists. Catching it is a non-negotiable skill — interviewers ask about it and reviewers should reject any PR that does it.

## Step-by-step reasoning

1. **What "leak" means here.** `StandardScaler` estimates a mean and std per column. If it sees all 569 rows, those estimates encode information from the test rows. Test data should be *unseen* until the final score — including by preprocessing.
2. **Why it inflates the score.** The test rows get centered/scaled using statistics they themselves helped compute, so they sit a little more favorably than truly unseen data would. The model looks better than it is.
3. **The correct order: split first, fit preprocessing on train only.** Compute `mean_`/`scale_` from the *training* rows, then *apply* (transform) those same numbers to the test rows. The test set never contributes to any fitted parameter.
4. **Make it impossible to get wrong: use a Pipeline.** A `Pipeline([... , model])` re-fits every step on whatever data it's given. Pass it to `train_test_split` data or to `cross_val_score`, and the scaler is automatically fit on the *training fold* and merely transforms the validation/test fold. The leak can't happen.
5. **Confirm with cross-validation.** A bare `cross_val_score(scaler-then-model)` done by hand can still leak if you scale before splitting; running CV on the *Pipeline* scales inside each fold, giving the honest estimate.
6. **Quantify the gap.** We print leaky vs. honest test accuracy and leaky vs. honest cross-val accuracy so the inflation is a concrete number, not a vibe.

## Python solution

```python
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

X, y = load_breast_cancer(return_X_y=True)
```

```python
# ============================================================
#  THE BUG: scale on ALL the data, THEN split.
#  The scaler's mean_/scale_ are learned from test rows too -> leakage.
# ============================================================
X_all_scaled = StandardScaler().fit_transform(X)        # <-- fit sees every row
Xtr, Xte, ytr, yte = train_test_split(
    X_all_scaled, y, test_size=0.3, random_state=0, stratify=y)

leaky = LogisticRegression(max_iter=5000).fit(Xtr, ytr)
leaky_acc = leaky.score(Xte, yte)
print(f"LEAKY  test accuracy: {leaky_acc:.4f}")
```

```python
# ============================================================
#  THE FIX (manual): split FIRST, fit the scaler on TRAIN only,
#  then TRANSFORM (not fit) the test set with the train statistics.
# ============================================================
Xtr_raw, Xte_raw, ytr, yte = train_test_split(
    X, y, test_size=0.3, random_state=0, stratify=y)

scaler = StandardScaler().fit(Xtr_raw)                  # <-- fit sees TRAIN only
Xtr = scaler.transform(Xtr_raw)
Xte = scaler.transform(Xte_raw)                         # apply train stats to test

honest = LogisticRegression(max_iter=5000).fit(Xtr, ytr)
honest_acc = honest.score(Xte, yte)
print(f"HONEST test accuracy: {honest_acc:.4f}")
```

```python
# ============================================================
#  THE FIX (the right habit): a Pipeline makes leakage impossible.
#  Each CV fold re-fits the scaler on that fold's TRAINING data only.
# ============================================================
pipe = Pipeline([
    ("scale", StandardScaler()),
    ("clf",   LogisticRegression(max_iter=5000)),
])

# Honest cross-validation: scaling happens INSIDE each fold.
honest_cv = cross_val_score(pipe, X, y, cv=5)

# Contrast: the leaky way people do CV -- scale everything once, THEN cross-validate.
leaky_cv = cross_val_score(LogisticRegression(max_iter=5000),
                           StandardScaler().fit_transform(X), y, cv=5)

print(f"LEAKY  5-fold CV: {leaky_cv.mean():.4f} +/- {leaky_cv.std():.4f}")
print(f"HONEST 5-fold CV: {honest_cv.mean():.4f} +/- {honest_cv.std():.4f}")
```

## Expected output

Running it prints roughly (numbers vary by a few thousandths across sklearn versions):

```
LEAKY  test accuracy: 0.9883
HONEST test accuracy: 0.9766
LEAKY  5-fold CV: 0.9824 +/- 0.0107
HONEST 5-fold CV: 0.9754 +/- 0.0119
```

How to read it: the **leaky** test accuracy (≈0.988) is higher than the **honest** one (≈0.977). On this clean, well-separated dataset the gap is about a percentage point — small, but it's *fake* accuracy you cannot ship, and it grows fast on messier, higher-dimensional, or smaller datasets where the scaler's statistics depend more heavily on individual rows. The cross-val comparison shows the same story: the leaky pipeline reports a rosier mean than the honest, fold-aware one. The lesson isn't "1% doesn't matter" — it's "the leaky number is meaningless, so always make it impossible to produce."

## Common mistakes

- **`fit` / `fit_transform` on the full `X` before splitting.** This is the leak. Only ever `fit` preprocessing on training data.
- **Calling `scaler.fit_transform(X_test)`.** Re-fitting on the test set is just a different flavor of the same bug — use `scaler.transform(X_test)` with the *train-fitted* scaler.
- **Doing CV by hand on pre-scaled data.** `cross_val_score` on already-globally-scaled `X` still leaks because the scaling saw all folds. Put the scaler in the Pipeline so it's re-fit per fold.
- **Leaking through other steps too.** Imputation (`SimpleImputer`), feature selection (`SelectKBest`), target encoding, and PCA all *learn* from data and must live inside the Pipeline. Scaling is just the most famous offender.
- **Trusting a suspiciously high score.** A test number far above your cross-val mean — or a notebook that crushes production — is a classic leakage smell. Audit the preprocessing order first.

## Extension challenge

1. Swap `LogisticRegression` for `KNeighborsClassifier` (distance-based, very scale-sensitive) and re-measure the leaky-vs-honest gap. Does the inflation grow?
2. Add a `SimpleImputer(strategy="mean")` step and prove that imputing means on the full dataset leaks too, then fix it by moving it into the Pipeline.
3. Shrink the data with `X[:80], y[:80]` and repeat. Smaller datasets make the scaler's statistics more sample-dependent — watch the leaky/honest gap widen.

## Matching animation

See **"Pipeline Flow Animator"** (in module 08, *Feature Engineering and Pipelines*). Step a single fold through the pipeline and watch the scaler fit on the training fold and only *transform* the validation fold — a moving picture of exactly why the Pipeline version in this lesson can't leak.

# Train-Test Split and Cross-Validation

> A single train/test split gives you one noisy number; cross-validation gives you a distribution — and the difference is whether you trust your results or just hope.

## What you'll learn
- How `train_test_split` works and why `stratify` matters for classification.
- What **k-fold cross-validation** does and how `cross_val_score` reports it.
- How to read the **mean ± standard deviation** of CV scores as a measure of reliability.
- The bias/variance trade-off *of the score estimate itself* (not of the model).

## Intuition

You need to estimate how your model performs on data it hasn't seen. The simplest way: hold out a chunk — say 25% — as a **test set**, train on the rest, and score on the held-out chunk. That's `train_test_split`. It works, but the score depends on *which* 25% happened to land in the test set. Get an easy slice and you look great; an unlucky slice and you look bad. One split = one sample of a noisy quantity.

**Stratification** fixes a specific danger in classification: a random split might put 90% of a rare class into training and barely any into test, distorting the score. `stratify=y` forces the train and test sets to keep the *same class proportions* as the full data.

**Cross-validation** averages away the luck. In **k-fold CV**, you slice the data into `k` equal parts (folds). You train on `k-1` folds and test on the remaining one, then rotate so every fold serves as the test set exactly once. You get `k` scores; their **mean** is your performance estimate, and their **standard deviation** tells you how much it wobbles. Every row is used for both training and testing (in different rounds), so you waste no data — invaluable on small datasets.

**Bias/variance of the estimate.** This is subtle and separate from model bias/variance. With few folds (say `k=2`), each model trains on only half the data, so it's weaker than your final model — the score is *pessimistically biased*. With many folds (`k=n`, "leave-one-out"), each model trains on almost all the data (low bias) but the `n` scores are highly correlated and the estimate has high *variance* and high cost. `k=5` or `k=10` is the standard sweet spot: low enough bias, manageable variance, reasonable runtime.

## Python in practice

Start with a single split, see the noise, then graduate to cross-validation.

```python
import numpy as np
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

X, y = load_wine(return_X_y=True)
model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000))

# --- One split: stratify keeps class balance; note the score depends on random_state ---
for rs in [0, 1, 2]:
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=0.25, random_state=rs, stratify=y)
    model.fit(X_tr, y_tr)
    print(f"Single-split accuracy (random_state={rs}): {model.score(X_te, y_te):.3f}")
```

Expected output (approximate):

```
Single-split accuracy (random_state=0): 0.978
Single-split accuracy (random_state=1): 1.000
Single-split accuracy (random_state=2): 0.956
```

See the spread? Same model, same data — only the split changed, and the "accuracy" swung by several points. Which number do you report? None of them alone. Use cross-validation:

```python
# --- 5-fold CV: every row is tested once; report mean ± std ---
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)   # keeps class balance per fold
scores = cross_val_score(model, X, y, cv=cv)
print("CV scores:", np.round(scores, 3))
print(f"CV accuracy: {scores.mean():.3f} +/- {scores.std():.3f}")
```

Expected output (approximate):

```
CV scores: [0.972 1.    0.972 0.943 1.   ]
CV accuracy: 0.977 +/- 0.022
```

Now you have a defensible claim: *"about 97.7% accuracy, give or take 2 points."* The `± std` is as important as the mean — a model at `0.85 ± 0.01` may be more trustworthy than one at `0.90 ± 0.15`.

## Common mistakes

- **Reporting a single-split score as "the" accuracy.** It's one draw from a noisy distribution. Cross-validate, or at least report it as such.
- **Forgetting `stratify=y` (or `StratifiedKFold`) in classification.** Especially with imbalanced classes, plain random splits can wildly misrepresent performance.
- **Not shuffling before CV when the data is ordered.** If rows are sorted by class or time, unshuffled folds become unrepresentative. Use `shuffle=True` (with a `random_state`) — but never shuffle genuine time series.
- **Ignoring the standard deviation.** A high std means your estimate is unstable; the mean alone hides that.
- **Cross-validating a leaky setup.** If you scale or select features *outside* the CV loop, every fold leaks. Always put preprocessing inside a `Pipeline` so CV re-fits it per fold.

## Small exercise

Run the 5-fold CV above with `n_splits=2`, then `5`, then `10`, and print the mean and std each time. You should see the mean shift slightly (smaller `k` trains on less data → often a touch lower) and the std change. Pick the `k` you'd report and justify it in one sentence (hint: 5 or 10 balances bias, variance, and runtime).

## Before you continue
- [ ] I can use `train_test_split` with `stratify` and explain why stratification matters.
- [ ] I can run `cross_val_score` and report the mean ± std.
- [ ] I can explain why a single split is noisy and CV is more reliable.
- [ ] I can describe, at a high level, how the number of folds trades bias against variance of the estimate.

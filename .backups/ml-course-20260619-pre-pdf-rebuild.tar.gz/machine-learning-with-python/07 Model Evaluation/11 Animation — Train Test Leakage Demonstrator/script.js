"use strict";

/* ------------------------------------------------------------------ *
 * Train/Test Leakage Demonstrator
 * ------------------------------------------------------------------
 * ONE idea: data leakage. If you fit a preprocessing step (here a
 * StandardScaler) on the WHOLE dataset BEFORE splitting, the test rows
 * influence the transform's mean/std. The model then "sees" test info
 * during training, so its REPORTED test score is inflated and falls
 * apart on genuinely unseen, real-world data.
 *
 *   LEAKY:  scaler.fit(X_all);  -> reported 0.97, real-world 0.84
 *   CLEAN:  scaler.fit(X_train) -> reported 0.86, real-world 0.86
 *
 * Numbers are illustrative but fixed and consistent
 * (leaky reported > clean honest; leaky real-world < clean).
 * Everything is deterministic: same layout & timeline every run.
 * ------------------------------------------------------------------ */

// ---- Illustrative-but-consistent scores ----
const SCORES = {
  leaky: { reported: 0.97, real: 0.84, fit: "train + test", leak: 100 },
  clean: { reported: 0.86, real: 0.86, fit: "train only", leak: 0 }
};

// ---- Geometry ----
const W = 900, H = 500;
const N_TOTAL = 20;            // data samples in the row
const TRAIN_FRAC = 0.8;        // 80/20 split
const N_TRAIN = Math.round(N_TOTAL * TRAIN_FRAC);   // 16
const N_TEST = N_TOTAL - N_TRAIN;                    // 4

// scaler box
const SCALER = { x: W * 0.5 - 95, y: 300, w: 190, h: 86 };
const SCALER_CX = SCALER.x + SCALER.w / 2;
const SCALER_TOP = SCALER.y;

// rows where dots live
const ROW_RAW_Y = 70;          // before split: single row, neutral
const ROW_TRAIN_Y = 150;       // after split: train cluster
const ROW_TEST_Y = 220;        // after split: test cluster

// ---- Colors ----
const C = {
  train: "#38bdf8",
  test: "#fbbf24",
  neutral: "#64748b",
  danger: "#f87171",
  success: "#34d399",
  violet: "#a78bfa",
  cyan: "#22d3ee",
  dim: "#94a3b8",
  text: "#e2e8f0"
};

// ---- DOM ----
const canvas = document.getElementById("stage");
const ctx = canvas.getContext("2d");
const modeSeg = document.getElementById("modeSeg");
const modeLeakyBtn = document.getElementById("modeLeaky");
const modeCleanBtn = document.getElementById("modeClean");
const modeInput = document.getElementById("mode");
const speedInput = document.getElementById("speed");
const speedVal = document.getElementById("speedVal");
const showArrows = document.getElementById("showArrows");
const runBtn = document.getElementById("run");
const splitBtn = document.getElementById("split");
const resetBtn = document.getElementById("reset");
const leakFill = document.getElementById("leakFill");
const leakPct = document.getElementById("leakPct");
const rMode = document.getElementById("rMode");
const rFit = document.getElementById("rFit");
const rReported = document.getElementById("rReported");
const rReal = document.getElementById("rReal");
const rVerdict = document.getElementById("rVerdict");
const codeText = document.getElementById("codeText");

// ---- Build the data samples (deterministic positions across the row) ----
function makeSamples() {
  const arr = [];
  const left = 70, right = W - 70;
  for (let i = 0; i < N_TOTAL; i++) {
    const t = N_TOTAL === 1 ? 0.5 : i / (N_TOTAL - 1);
    arr.push({
      i,
      rawX: left + t * (right - left),
      rawY: ROW_RAW_Y,
      // assigned at split time:
      role: "raw",          // "raw" | "train" | "test"
      x: left + t * (right - left),
      y: ROW_RAW_Y,
      tx: left + t * (right - left),  // target x (animated toward)
      ty: ROW_RAW_Y                    // target y
    });
  }
  return arr;
}
let samples = makeSamples();

// Deterministic split: last N_TEST samples become the test set (amber).
function assignSplit() {
  const trainLeft = 110, trainRight = W * 0.5 - 130;
  const testLeft = W * 0.5 + 130, testRight = W - 110;
  let ti = 0, vi = 0;
  for (const s of samples) {
    if (s.i >= N_TRAIN) {
      s.role = "test";
      const t = N_TEST === 1 ? 0.5 : vi / (N_TEST - 1);
      s.tx = testLeft + t * (testRight - testLeft);
      s.ty = ROW_TEST_Y;
      vi++;
    } else {
      s.role = "train";
      const cols = 8;
      const r = Math.floor(ti / cols), c = ti % cols;
      const colW = (trainRight - trainLeft) / (cols - 1);
      s.tx = trainLeft + c * colW;
      s.ty = ROW_TRAIN_Y + r * 34;
      ti++;
    }
  }
}

// ---- App state ----
let mode = "leaky";
let isSplit = false;
let animId = null;
let timeline = [];      // array of {t0,t1,fn} pieces
let tEnd = 0;
let startMs = 0;
let speed = 1;
let leakMeter = 0;      // 0..100 current displayed
let running = false;

// Per-frame derived visuals
let glowScaler = 0;     // 0..1 pulse on scaler while fitting
let activeArrows = [];  // {fromX,fromY,prog,leaky}
let scoreReveal = 0;    // 0..1 reveals score panels on canvas
let appliedTest = 0;    // 0..1 test points getting transformed (clean apply step)

// ------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------
function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function lerp(a, b, t) { return a + (b - a) * t; }
function easeInOut(t) { return t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2; }
function easeOut(t) { return 1 - Math.pow(1 - t, 3); }

function setMode(m) {
  mode = m;
  modeInput.value = m;
  const leaky = m === "leaky";
  modeLeakyBtn.classList.toggle("is-active", leaky);
  modeCleanBtn.classList.toggle("is-active", !leaky);
  modeLeakyBtn.setAttribute("aria-selected", String(leaky));
  modeCleanBtn.setAttribute("aria-selected", String(!leaky));
  rMode.textContent = m;
  rMode.className = leaky ? "v bad" : "v good";
  updateCode();
  // changing the mode invalidates a finished run
  stopAnim();
  scoreReveal = 0;
  appliedTest = 0;
  leakMeter = 0;
  resetReadoutValues();
  render(0);
}

function resetReadoutValues() {
  rFit.textContent = "—";
  rReported.textContent = "—";
  rReal.textContent = "—";
  rReported.className = "v";
  rReal.className = "v";
  rVerdict.textContent = isSplit ? "press Run experiment" : "pick a mode";
  rVerdict.className = "v";
  leakFill.style.width = "0%";
  leakPct.textContent = "0%";
}

function updateCode() {
  if (mode === "leaky") {
    codeText.textContent =
      "# LEAKY — DON'T DO THIS\n" +
      "scaler = StandardScaler().fit(X_all)   # mean/std from train + TEST  <- leak\n" +
      "X_all  = scaler.transform(X_all)\n" +
      "X_tr, X_te, y_tr, y_te = train_test_split(X_all, y, test_size=0.2)\n" +
      "model.fit(X_tr, y_tr); model.score(X_te, y_te)   # 0.97 ... mirage";
  } else {
    codeText.textContent =
      "# CLEAN — fit on train, only TRANSFORM test\n" +
      "X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2)\n" +
      "scaler = StandardScaler().fit(X_tr)    # mean/std from TRAIN only\n" +
      "X_tr = scaler.transform(X_tr); X_te = scaler.transform(X_te)\n" +
      "# better: Pipeline([('sc', StandardScaler()), ('clf', model)])  -> 0.86, honest";
  }
}

// ------------------------------------------------------------------
// Rendering
// ------------------------------------------------------------------
function render() {
  ctx.clearRect(0, 0, W, H);
  drawTitleRow();
  if (isSplit) drawZoneLabels();
  drawScalerBox();
  if (showArrows.checked) drawArrows();
  drawSamples();
  if (scoreReveal > 0) drawScoreCards();
}

function drawTitleRow() {
  ctx.save();
  ctx.fillStyle = C.dim;
  ctx.font = "13px Inter, sans-serif";
  ctx.textAlign = "left";
  if (!isSplit) {
    ctx.fillText("Raw dataset — " + N_TOTAL + " samples (not yet split)", 70, 40);
  } else {
    ctx.fillText("After split — 80% train / 20% test", 70, 40);
  }
  ctx.restore();
}

function drawZoneLabels() {
  ctx.save();
  ctx.font = "600 13px Inter, sans-serif";
  ctx.textAlign = "left";
  ctx.fillStyle = C.train;
  ctx.fillText("TRAIN  (" + N_TRAIN + ")", 110, ROW_TRAIN_Y - 22);
  ctx.fillStyle = C.test;
  ctx.fillText("TEST  (" + N_TEST + ")", W * 0.5 + 130, ROW_TEST_Y - 22);

  // dotted divider between zones
  ctx.strokeStyle = "rgba(255,255,255,0.10)";
  ctx.setLineDash([4, 6]);
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(W * 0.5, 120);
  ctx.lineTo(W * 0.5, 250);
  ctx.stroke();
  ctx.restore();
}

function drawScalerBox() {
  ctx.save();
  // glow while fitting
  if (glowScaler > 0) {
    ctx.shadowColor = mode === "leaky"
      ? "rgba(248,113,113," + (0.5 * glowScaler) + ")"
      : "rgba(52,211,153," + (0.5 * glowScaler) + ")";
    ctx.shadowBlur = 30 * glowScaler;
  }
  const r = 14;
  roundRect(SCALER.x, SCALER.y, SCALER.w, SCALER.h, r);
  ctx.fillStyle = "rgba(255,255,255,0.04)";
  ctx.fill();
  ctx.shadowBlur = 0;
  ctx.lineWidth = 2;
  ctx.strokeStyle = mode === "leaky"
    ? "rgba(248,113,113,0.7)"
    : "rgba(52,211,153,0.7)";
  ctx.stroke();

  ctx.fillStyle = C.text;
  ctx.font = "600 15px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("StandardScaler", SCALER_CX, SCALER.y + 30);
  ctx.fillStyle = C.dim;
  ctx.font = "12px ui-monospace, Menlo, monospace";
  ctx.fillText("fit: mean, std", SCALER_CX, SCALER.y + 52);
  ctx.fillStyle = mode === "leaky" ? C.danger : C.success;
  ctx.font = "600 12px Inter, sans-serif";
  const src = isSplit ? (mode === "leaky" ? "from TRAIN + TEST" : "from TRAIN only") : "waiting…";
  ctx.fillText(src, SCALER_CX, SCALER.y + 70);
  ctx.restore();
}

function roundRect(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

function drawArrows() {
  ctx.save();
  for (const a of activeArrows) {
    const tx = SCALER_CX, ty = SCALER_TOP;
    const x = lerp(a.fromX, tx, a.prog);
    const y = lerp(a.fromY, ty, a.prog);
    const col = a.leaky ? C.danger : C.train;
    // trailing line
    ctx.strokeStyle = a.leaky
      ? "rgba(248,113,113,0.35)"
      : "rgba(56,189,248,0.30)";
    ctx.lineWidth = a.leaky ? 2 : 1.5;
    ctx.setLineDash(a.leaky ? [5, 4] : []);
    ctx.beginPath();
    ctx.moveTo(a.fromX, a.fromY);
    ctx.lineTo(x, y);
    ctx.stroke();
    ctx.setLineDash([]);
    // moving head
    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.arc(x, y, a.leaky ? 4.5 : 3.5, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.restore();
}

function drawSamples() {
  ctx.save();
  for (const s of samples) {
    let col = C.neutral;
    if (s.role === "train") col = C.train;
    else if (s.role === "test") col = C.test;

    ctx.beginPath();
    ctx.arc(s.x, s.y, 7, 0, Math.PI * 2);
    ctx.fillStyle = col;
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.strokeStyle = "rgba(11,11,16,0.9)";
    ctx.stroke();

    // clean-mode "applied" tick on test points
    if (s.role === "test" && appliedTest > 0 && mode === "clean") {
      ctx.strokeStyle = "rgba(52,211,153," + appliedTest + ")";
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(s.x, s.y, 11, 0, Math.PI * 2 * appliedTest);
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawScoreCards() {
  const a = easeOut(scoreReveal);
  const sc = SCORES[mode];
  const cardW = 250, cardH = 88, gap = 30;
  const totalW = cardW * 2 + gap;
  const x0 = (W - totalW) / 2;
  const y0 = 410;

  ctx.save();
  ctx.globalAlpha = a;

  // Reported (left)
  drawCard(x0, y0, cardW, cardH,
    "REPORTED SCORE",
    sc.reported.toFixed(2),
    mode === "leaky" ? C.danger : C.success,
    mode === "leaky" ? "what the leak claims" : "honest on the held-out set");

  // Real-world (right)
  drawCard(x0 + cardW + gap, y0, cardW, cardH,
    "REAL-WORLD SCORE",
    sc.real.toFixed(2),
    mode === "leaky" ? C.test : C.success,
    mode === "leaky" ? "on genuinely unseen data" : "matches the report — trust it");

  // gap callout in leaky mode
  if (mode === "leaky") {
    const drop = (sc.reported - sc.real).toFixed(2);
    ctx.fillStyle = C.danger;
    ctx.font = "600 13px Inter, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText("− " + drop + " collapse", x0 + cardW + gap / 2, y0 - 8);
  }
  ctx.restore();
}

function drawCard(x, y, w, h, label, big, color, sub) {
  roundRect(x, y, w, h, 12);
  ctx.fillStyle = "rgba(255,255,255,0.035)";
  ctx.fill();
  ctx.lineWidth = 1;
  ctx.strokeStyle = "rgba(255,255,255,0.10)";
  ctx.stroke();

  ctx.textAlign = "left";
  ctx.fillStyle = C.dim;
  ctx.font = "600 11px Inter, sans-serif";
  ctx.fillText(label, x + 16, y + 24);

  ctx.fillStyle = color;
  ctx.font = "700 30px ui-monospace, Menlo, monospace";
  ctx.fillText(big, x + 16, y + 58);

  ctx.fillStyle = C.dim;
  ctx.font = "11px Inter, sans-serif";
  ctx.fillText(sub, x + 88, y + 56);
}

// ------------------------------------------------------------------
// Split (can be triggered standalone or as the first stage of a run)
// ------------------------------------------------------------------
function doSplitInstant() {
  assignSplit();
  for (const s of samples) { s.x = s.tx; s.y = s.ty; }
  isSplit = true;
}

// Animate dots from their current pos toward target over [t0,t1]
function animateSplit(progress) {
  const e = easeInOut(progress);
  for (const s of samples) {
    s.x = lerp(s.startX, s.tx, e);
    s.y = lerp(s.startY, s.ty, e);
  }
}

// ------------------------------------------------------------------
// Timeline-driven full experiment
// ------------------------------------------------------------------
function buildTimeline() {
  timeline = [];
  let t = 0;
  const seg = (dur, fn, onEnter) => {
    timeline.push({ t0: t, t1: t + dur, fn, onEnter, entered: false });
    t += dur;
  };

  // 1) Split animation
  seg(900,
    (p) => { leakMeter = 0; animateSplit(p); },
    () => {
      assignSplit();
      for (const s of samples) { s.startX = s.x; s.startY = s.y; }
      isSplit = true;
      scoreReveal = 0;
      appliedTest = 0;
      rVerdict.textContent = "splitting 80/20…";
      rVerdict.className = "v";
    });

  // 2) Scaler fits — arrows flow in
  if (mode === "leaky") {
    // TRAIN arrows AND TEST arrows -> the leak
    seg(1400,
      (p) => {
        glowScaler = Math.min(1, p * 1.4);
        spawnArrows(p, true /*include test*/);
        leakMeter = lerp(0, 100, easeOut(p));
        syncLeakMeter();
      },
      () => {
        activeArrows = [];
        rFit.textContent = SCORES.leaky.fit;
        rFit.className = "v bad";
        rVerdict.textContent = "fitting on TRAIN + TEST — leaking!";
        rVerdict.className = "v bad";
      });
  } else {
    // TRAIN arrows only
    seg(1100,
      (p) => {
        glowScaler = Math.min(1, p * 1.4);
        spawnArrows(p, false /*train only*/);
        leakMeter = 0;
        syncLeakMeter();
      },
      () => {
        activeArrows = [];
        rFit.textContent = SCORES.clean.fit;
        rFit.className = "v train";
        rVerdict.textContent = "fitting on TRAIN only";
        rVerdict.className = "v good";
      });
    // 2b) APPLY scaler to test (transform only, no fit)
    seg(900,
      (p) => { appliedTest = easeOut(p); },
      () => {
        rVerdict.textContent = "applying transform to TEST (no fit)";
        rVerdict.className = "v good";
      });
  }

  // 3) Train model + reveal scores
  seg(1000,
    (p) => {
      glowScaler = 1 - p * 0.6;
      scoreReveal = easeOut(p);
      revealScores(p);
    },
    () => {
      const sc = SCORES[mode];
      rReported.textContent = sc.reported.toFixed(2);
      rReal.textContent = sc.real.toFixed(2);
      if (mode === "leaky") {
        rReported.className = "v bad";
        rReal.className = "v warn";
      } else {
        rReported.className = "v good";
        rReal.className = "v good";
      }
    });

  // 4) Settle / verdict
  seg(400,
    () => { scoreReveal = 1; glowScaler = Math.max(0, glowScaler); },
    () => {
      glowScaler = 0.4;
      if (mode === "leaky") {
        rVerdict.textContent = "0.97 reported, only 0.84 real — leaked!";
        rVerdict.className = "v bad";
      } else {
        rVerdict.textContent = "0.86 reported and real — trustworthy";
        rVerdict.className = "v good";
      }
    });

  tEnd = t;
}

// Arrows: one per source point, staggered by index using progress.
function spawnArrows(p, includeTest) {
  const sources = samples.filter(s =>
    s.role === "train" || (includeTest && s.role === "test"));
  activeArrows = [];
  const n = sources.length;
  for (let k = 0; k < n; k++) {
    const s = sources[k];
    // each arrow's local progress, staggered across the segment
    const start = (k / n) * 0.5;            // launch window 0..0.5
    const local = clamp((p - start) / (1 - start), 0, 1);
    if (local <= 0) continue;
    activeArrows.push({
      fromX: s.x, fromY: s.y,
      prog: easeInOut(local),
      leaky: s.role === "test"              // test arrows are the red leak
    });
  }
}

function revealScores() {
  // animation handled via scoreReveal in drawScoreCards
}

function syncLeakMeter() {
  const pct = Math.round(leakMeter);
  leakFill.style.width = pct + "%";
  leakPct.textContent = pct + "%";
  leakPct.style.color = pct > 0 ? C.danger : C.success;
}

// ------------------------------------------------------------------
// Animation loop
// ------------------------------------------------------------------
function tick(now) {
  const elapsed = (now - startMs) * speed;
  // find & run the active segment
  let done = true;
  for (const piece of timeline) {
    if (elapsed >= piece.t0 && !piece.entered) {
      piece.entered = true;
      if (piece.onEnter) piece.onEnter();
    }
    if (elapsed < piece.t1) {
      done = false;
      if (elapsed >= piece.t0) {
        const p = clamp((elapsed - piece.t0) / (piece.t1 - piece.t0), 0, 1);
        piece.fn(p);
      }
      break;
    } else if (piece.entered) {
      // ensure final frame of completed segment is applied once
      piece.fn(1);
    }
  }
  render();

  if (elapsed >= tEnd || done) {
    finishRun();
    return;
  }
  animId = requestAnimationFrame(tick);
}

function startRun() {
  stopAnim();
  // restart from a fresh raw layout so the split always re-animates
  samples = makeSamples();
  isSplit = false;
  scoreReveal = 0;
  appliedTest = 0;
  leakMeter = 0;
  activeArrows = [];
  glowScaler = 0;
  syncLeakMeter();
  rReported.textContent = "—"; rReported.className = "v";
  rReal.textContent = "—"; rReal.className = "v";
  buildTimeline();
  running = true;
  setControlsEnabled(false);
  startMs = performance.now();
  animId = requestAnimationFrame(tick);
}

function finishRun() {
  activeArrows = [];
  glowScaler = 0.4;
  scoreReveal = 1;
  render();
  running = false;
  animId = null;
  setControlsEnabled(true);
}

function stopAnim() {
  if (animId) { cancelAnimationFrame(animId); animId = null; }
  running = false;
  setControlsEnabled(true);
}

function setControlsEnabled(on) {
  runBtn.disabled = !on;
  splitBtn.disabled = !on;
  modeLeakyBtn.disabled = !on;
  modeCleanBtn.disabled = !on;
}

// ------------------------------------------------------------------
// Wiring
// ------------------------------------------------------------------
modeLeakyBtn.addEventListener("click", () => setMode("leaky"));
modeCleanBtn.addEventListener("click", () => setMode("clean"));

speedInput.addEventListener("input", () => {
  speed = parseFloat(speedInput.value);
  speedVal.innerHTML = speed.toFixed(1) + "&times;";
});

showArrows.addEventListener("change", () => { if (!running) render(); });

runBtn.addEventListener("click", startRun);

splitBtn.addEventListener("click", () => {
  if (running) return;
  stopAnim();
  samples = makeSamples();
  doSplitInstant();
  scoreReveal = 0;
  appliedTest = 0;
  leakMeter = 0;
  activeArrows = [];
  glowScaler = 0;
  syncLeakMeter();
  resetReadoutValues();
  rVerdict.textContent = "press Run experiment";
  render();
});

resetBtn.addEventListener("click", () => {
  stopAnim();
  samples = makeSamples();
  isSplit = false;
  scoreReveal = 0;
  appliedTest = 0;
  leakMeter = 0;
  activeArrows = [];
  glowScaler = 0;
  syncLeakMeter();
  resetReadoutValues();
  render();
});

// ------------------------------------------------------------------
// Init
// ------------------------------------------------------------------
speed = parseFloat(speedInput.value);
speedVal.innerHTML = speed.toFixed(1) + "&times;";
setMode("leaky");
render();

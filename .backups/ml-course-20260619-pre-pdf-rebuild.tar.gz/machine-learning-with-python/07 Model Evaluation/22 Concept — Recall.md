# Recall

> Of every real positive case out there in the world, recall asks the only question that matters when a miss is dangerous: *how many did we actually catch?*

## What is this?

Recall flips precision on its head. Instead of grading the predictions you made, it grades **the real positive cases** and asks how many of them you found:

> Of all the things that were actually positive, what fraction did I catch?

The formula:

```
Recall = TP / (TP + FN)
```

- **TP** (true positives) — actually positive, and you caught it.
- **FN** (false negatives) — actually positive, but you let it slip through. A *miss*.

The denominator `TP + FN` is **every real positive that exists**, whether you found it or not. Recall is the share of those you managed to flag. If 20 patients truly have a disease and your model identifies 14 of them, recall is 14/20 = 0.70 — you caught 70%, and 6 sick people walked out undiagnosed.

What's *not* in the formula this time? False positives (FP). Recall doesn't punish you for false alarms. It only punishes you for the cases you **missed**. Recall is the metric of the miss.

## Why do we need it?

Because in a huge class of problems, **a miss is far more dangerous than a false alarm.** Precision worries about annoying people with false flags; recall worries about the disaster of failing to flag something that needed flagging.

If a cancer screen misses a real tumor, the patient goes home thinking they're healthy while the disease grows. If a fraud system misses a fraudulent charge, the money is gone. If a smoke detector misses a fire, the building burns. In every one of those cases the cost of a **false negative** dwarfs the cost of a false positive — a second opinion, a declined card, a false beep are all annoying but survivable. A miss is not.

We need recall whenever **the thing you're looking for is rare and dangerous, and letting it through is the worst outcome.** It is the metric you optimize when you'd rather raise ten false alarms than miss one real case.

## Where it's used in real ML

- **Medical screening** — A first-pass cancer or sepsis screen is tuned for high recall: catch every possible case, then confirm with a more precise test. Missing a sick patient is the failure you most want to avoid.
- **Fraud and money laundering detection** — Of all the fraud that actually happened, how much did the system stop? A missed fraudulent transaction is real money lost and a real victim.
- **Security and threat detection** — Intrusion detection, malware scanning, weapons screening: a single missed threat can be catastrophic, so recall is king even at the cost of many false alarms.
- **Safety-critical perception** — A self-driving car's pedestrian detector must catch *every* pedestrian. A false positive means braking for a shadow; a false negative means hitting a person.
- **Legal / compliance discovery** — When you must surface every relevant document, recall measures how many of the truly relevant ones you retrieved.

## What breaks if you ignore it

If you optimize for precision and never check recall, you build a model that is **right when it speaks but speaks far too rarely.** It only flags the easy, obvious, slam-dunk positives and quietly lets every borderline case through. The damage:

1. **Silent misses pile up.** Because the model rarely cries wolf, its few alerts look trustworthy — but the dangerous cases it skipped never show up in your dashboards. The failures are invisible until something blows up.
2. **The rare, important class is abandoned.** Recall is exactly the metric that protects the minority class. Ignore it and your fraud / disease / threat detector becomes a confident "looks fine to me" machine.
3. **False sense of safety.** A screen with 99% precision but 20% recall looks excellent on a quick glance and misses four out of five real cases. People trust it and get hurt.

A model that predicts "negative" for everything has perfect precision on the cases it (never) flags and **zero recall**. Ignoring recall is how you ship a detector that detects almost nothing.

## Mental model

Think of recall as a **fishing net**: of all the fish in the lake, how many did your net actually pull out?

```
        Every REAL positive that exists in the world
        ┌─────────────────────────────────────────────┐
        │   TP TP TP TP TP TP TP   │   FN FN FN         │
        │   (caught in the net)    │   (slipped away)   │
        └─────────────────────────────────────────────┘
                 Recall = the fish you CAUGHT
                          ─────────────────────
                        all the fish that were there
```

A net with small holes catches almost everything (high recall) but also scoops up seaweed and boots (low precision). A net with huge holes only keeps the biggest fish (high precision) but lets most of the catch escape (low recall). Recall is purely about how much of the real catch made it into the boat — it doesn't care how much junk came along for the ride.

## Example 1 — Tiny toy example

A hospital runs a disease screen on patients. We focus on the patients who are **actually sick (the positive class)**. Here is the confusion matrix:

```
                   Predicted: sick     Predicted: healthy
Actually sick          TP = 14              FN = 6
Actually healthy       FP = 3               TN = 77
```

There are **20 genuinely sick patients** (the whole "Actually sick" row: 14 + 6). Of those:

- **14 were correctly flagged as sick** → TP = 14
- **6 sick patients were told they were healthy** → FN = 6

Compute recall by hand:

```
Recall = TP / (TP + FN)
       = 14 / (14 + 6)
       = 14 / 20
       = 0.70
```

So the screen **caught 70% of the truly sick patients** and missed 30% — six people who walked out undiagnosed. Crucially, the 3 healthy people it wrongly flagged (FP) and the 77 it correctly cleared (TN) **do not appear** in recall. Recall only grades the "Actually sick" row — the real positives.

## Example 2 — Practical ML example

A payments company runs a fraud model over **one month of transactions**. Suppose **800 transactions were genuinely fraudulent** (we know this in hindsight from chargebacks). The model's performance on that real-fraud population:

- It **caught 560** of the fraudulent transactions and blocked them → TP = 560
- It **missed 240** fraudulent transactions, which went through and cost the company money → FN = 240

```
Recall = 560 / (560 + 240) = 560 / 800 = 0.70
```

Recall is **0.70** — the model stopped 70% of the fraud by count, but **240 fraudulent transactions slipped through**, each one a real loss and a real victim. Even if this same model has excellent precision (almost every alert is real fraud), a finance team will be alarmed by the misses, because every false negative is money out the door. The fix is the opposite of the precision lever: **lower the decision threshold** so the model flags more borderline transactions. Recall rises (fewer misses) at the cost of more false alarms — exactly the trade-off you accept when a miss is the expensive failure.

## Python code example

```python
from sklearn.metrics import recall_score, confusion_matrix

# Inline data: 1 = positive (sick / fraud), 0 = negative (healthy / legit).
y_true = [1, 1, 1, 1, 1, 1, 0, 0, 0, 0]   # 6 REAL positives, 4 real negatives
y_pred = [1, 1, 1, 1, 0, 0, 1, 0, 0, 0]   # what the model flagged

# Confusion matrix is laid out as [[TN, FP], [FN, TP]] for labels [0, 1].
tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
print(f"TP={tp}  FP={fp}  FN={fn}  TN={tn}")   # TP=4  FP=1  FN=2  TN=3

# Recall = TP / (TP + FN): of the REAL positives, how many did we CATCH?
recall_by_hand = tp / (tp + fn)
print(f"Recall by hand : {recall_by_hand:.2f}")          # 0.67

# sklearn computes the same thing.
print(f"Recall (sklearn): {recall_score(y_true, y_pred):.2f}")  # 0.67

# Watch recall climb when we flag MORE aggressively (lower the threshold).
# An eager model: it flags almost everything, so it misses fewer real positives.
y_pred_eager = [1, 1, 1, 1, 1, 1, 1, 1, 0, 0]   # catches all 6 real positives
print(f"Eager recall   : {recall_score(y_true, y_pred_eager):.2f}")  # 1.00
# Lesson: flagging more => fewer misses => higher recall (but more false alarms).
```

## Common mistakes

- **Confusing recall with precision.** Recall is "of the real positives, how many did I catch." Precision is "of what I flagged, how many were right." They optimize opposite mistakes — never use the words interchangeably.
- **Chasing 100% recall by flagging everything.** A model that predicts "positive" for every case has perfect recall and useless precision. High recall is only meaningful when precision hasn't collapsed.
- **Ignoring recall on the rare class.** On imbalanced data the majority class has high recall almost for free. Always read recall for the *minority* class you actually care about catching.
- **Treating the default 0.5 threshold as fixed.** If misses are your worst failure, lower the threshold to raise recall. The threshold is a knob you set for your costs, not a law.
- **Reading recall as "how accurate."** Recall says nothing about your false alarms. A 100%-recall model can still drown users in false positives — that's why recall is always reported next to precision (and F1).

## Before you continue
- [ ] I can state, in one sentence, that recall = "of the real positives, how many did I catch?"
- [ ] I can write the formula TP / (TP + FN) and explain why FP and TN are not in it.
- [ ] I can name two real situations where a false negative (a miss) is genuinely dangerous.
- [ ] I can explain why a model that flags everything has perfect recall but is still useless.
- [ ] I understand that lowering the decision threshold usually raises recall (fewer misses, more false alarms).

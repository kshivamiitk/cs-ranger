# The Cardinal Sin — Leaking the Test Set

> The fastest way to fool yourself in machine learning is to let your model peek at the answers it will be graded on — and almost everyone does it by accident at least once.

## What you'll learn
- What **data leakage** is and the precise mechanism by which it inflates your scores.
- The most common leaks beginners commit — and how to spot each one.
- The **golden rule** of evaluation that prevents nearly all of them.
- Why a model that looks brilliant in your notebook can collapse in production.

## Intuition

Imagine a student who gets the exam questions *and the answer key* the night before. They score 100% — and you learn nothing about whether they understand the subject. The test was supposed to measure performance on *unseen* questions; once the answers leaked, the score became meaningless.

Your test set is that exam. **Data leakage** is any way information from the test set (or from the future, or from the target) sneaks into the model before it's graded. The model effectively "memorizes" what it shouldn't have seen, so its test score is sky-high — and then it faceplants on genuinely new data, because the real world doesn't leak the answers.

Leakage is insidious because the symptom is *good news*: accuracy jumps, everyone celebrates, and the problem only surfaces in production when the numbers don't reproduce. Learning to *distrust suspiciously good scores* is a core ML instinct.

### The classic leaks

- **Fitting preprocessing on all the data.** You call `StandardScaler().fit(X)` on the *whole* dataset, then split. The scaler's mean/std now encode information from test rows. The same trap hits feature selection, PCA, imputation, and target encoding. **Fit preprocessing on training data only.**
- **Splitting after feature engineering that uses the target.** Computing "average churn rate per city" over the full dataset and using it as a feature leaks the target into every row.
- **Duplicate or near-duplicate rows split across train and test.** If the same customer appears in both, the model has effectively seen the answer. Group-aware splitting fixes this.
- **Using future information.** Predicting Monday's sales with a feature that includes Monday's totals. In time series, never let a feature depend on data from after the prediction point.
- **Tuning on the test set.** Trying 50 models and picking the one with the best *test* score makes the test set part of training. You need a separate **validation** set (or cross-validation) for tuning, and the test set touched **once**, at the very end.

## Python in practice

Here's leakage you can *see*. We scale before splitting (wrong) versus inside a pipeline (right), and watch the dishonest version report a better-looking but fake score.

```python
import numpy as np
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

X, y = load_breast_cancer(return_X_y=True)

# --- WRONG: fit the scaler on ALL data, so test stats leak into training ---
X_scaled_all = StandardScaler().fit_transform(X)        # uses test rows' mean/std
leaky = cross_val_score(LogisticRegression(max_iter=5000),
                        X_scaled_all, y, cv=5)
print("Leaky CV accuracy:   ", round(leaky.mean(), 4))

# --- RIGHT: scaler is re-fit on each fold's training portion only ---
honest_pipe = make_pipeline(StandardScaler(), LogisticRegression(max_iter=5000))
honest = cross_val_score(honest_pipe, X, y, cv=5)        # no leakage
print("Honest CV accuracy:  ", round(honest.mean(), 4))
```

Expected output (approximate):

```
Leaky CV accuracy:    0.9824
Honest CV accuracy:   0.9789
```

On this clean dataset the gap is small, but it's real and always in the same direction: leakage flatters. With heavier preprocessing (target encoding, oversampling, feature selection) the inflated gap can be enormous — a "95%" that's really 70%. The lesson: scaling on the full dataset *felt* harmless and still leaked.

## Common mistakes

- **`fit_transform` on the whole dataset, then split.** The single most common leak. Always split first, then `fit` on train and `transform` test — or use a `Pipeline`, which does this for you inside every CV fold.
- **Letting hyperparameter tuning touch the test set.** Reserve the test set for one final measurement; tune on validation/CV.
- **Oversampling (e.g. SMOTE) before the split.** Synthetic points derived from test rows leak. Resample inside the training fold only.
- **Forgetting time order in temporal data.** A random split lets the model train on the future. Use time-based splits.
- **Re-running the test evaluation repeatedly while iterating.** Each peek leaks a little; eventually you've overfit your *decisions* to the test set.

## Small exercise

Take the code above and increase the leak: before splitting, add `SelectKBest(k=5)` feature selection fit on the *whole* `X, y`, then cross-validate. Compare to selecting features inside a pipeline. The full-data selection "sees" the test labels when ranking features, so the leaky score climbs further above the honest one. Confirm the direction: leakage always helps the reported number, never hurts it.

## Before you continue
- [ ] I can define data leakage and explain why it inflates scores.
- [ ] I can name at least three common leaks and how to avoid each.
- [ ] I can state the golden rule: the test set is touched once, at the end, and preprocessing is fit on training data only.
- [ ] I understand why a `Pipeline` is the safest default for preventing leaks.

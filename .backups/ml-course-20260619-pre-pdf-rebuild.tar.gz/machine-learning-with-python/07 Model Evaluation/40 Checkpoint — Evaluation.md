# Checkpoint — Evaluation

## What you should now be able to do
- Recognize and prevent data leakage, and state the golden rule of test-set hygiene.
- Use `train_test_split` (with `stratify`) and `cross_val_score`, and report results as mean ± std.
- Diagnose overfitting vs underfitting from train/test scores, learning curves, and validation curves — and apply the right fix.
- Compute and interpret a confusion matrix, precision, recall, F1, and ROC-AUC.
- Explain why accuracy misleads on imbalanced data and choose better metrics and thresholds.

## Review questions

1. Define data leakage in one sentence, and give one concrete example involving preprocessing.
2. What is the "golden rule" about the test set, and why does a `Pipeline` help you follow it?
3. Why is a single train/test accuracy number unreliable, and what does cross-validation give you instead?
4. What does `stratify=y` do in `train_test_split`, and when does it matter most?
5. You see train accuracy 0.99 and test accuracy 0.72. What's the diagnosis, and name two fixes.
6. You see train accuracy 0.68 and test accuracy 0.66. What's the diagnosis, and name two fixes.
7. Define precision and recall, and give a real scenario where you'd prioritize each.
8. A fraud model has 99.5% accuracy but recall of 0.10. Explain in plain words why it's a bad model despite the accuracy.
9. What does ROC-AUC measure, and why must it be computed from probabilities rather than 0/1 predictions?
10. As you raise the classification threshold from 0.3 to 0.7, what generally happens to precision and to recall, and why?

## Answers

<details><summary>Show answers</summary>

1. Data leakage is when information that wouldn't be available at prediction time (e.g. from the test set, the future, or the target) slips into training, inflating scores. Example: calling `StandardScaler().fit_transform(X)` on the whole dataset *before* splitting, so the scaler's statistics are computed using test rows.
2. The golden rule: the test set is touched exactly once, at the very end, and all preprocessing is fit on training data only. A `Pipeline` enforces this because every step (scaling, selection, model) is re-fit on each fold's training portion inside cross-validation — preprocessing never sees the held-out data.
3. A single split is one noisy draw; the score depends on which rows happened to land in the test set. Cross-validation trains and tests on several rotations and reports the **mean ± standard deviation**, giving a more reliable estimate and a sense of its variability.
4. `stratify=y` keeps the class proportions in the train and test sets equal to the full dataset's. It matters most with **imbalanced classes**, where a random split could otherwise leave the rare class barely represented in one side.
5. **Overfitting** (high variance): great on train, much worse on test. Fixes: simplify the model (less depth / stronger regularization / fewer features), get more training data, or use early stopping / ensembling.
6. **Underfitting** (high bias): poor on both, and close together. Fixes: use a more expressive model, add or engineer better features, reduce regularization, or train longer.
7. **Precision** = of the items predicted positive, the fraction truly positive (minimize false alarms) — prioritize when a false positive is costly, e.g. a spam filter that must not trash real email. **Recall** = of the truly positive items, the fraction caught (minimize misses) — prioritize when a false negative is costly, e.g. cancer screening or fraud detection.
8. With rare fraud, ~99.5% accuracy is achievable by labeling almost everything "not fraud." A recall of 0.10 means it catches only 10% of actual fraud — it misses 90% of the cases it exists to find. Accuracy is dominated by the easy majority class and hides this failure; recall exposes it.
9. ROC-AUC measures how well the model *ranks* positives above negatives across all thresholds — the area under the true-positive-rate vs false-positive-rate curve (1.0 perfect, 0.5 random). It needs the model's continuous scores/probabilities because the curve is traced by varying the threshold; collapsing to 0/1 labels throws away the ranking information.
10. Raising the threshold flags fewer, higher-confidence positives: **precision generally rises** (fewer false positives among those you flag) while **recall generally falls** (you miss more true positives you no longer flag). It's the precision-recall trade-off.

</details>

## Hands-on tasks

1. **Catch a leak.** On `load_breast_cancer`, compute a 5-fold `cross_val_score` two ways: (a) `StandardScaler().fit_transform(X)` before CV, and (b) a `make_pipeline(StandardScaler(), LogisticRegression())` passed to CV. Confirm the leaky version reports a higher mean and explain why.
2. **Find the sweet spot.** Use `validation_curve` to sweep `max_depth` (1–15) of a `DecisionTreeClassifier` on `load_wine`. Print train and validation accuracy per depth and identify the depth where validation peaks — that's your bias-variance sweet spot.
3. **Metrics under imbalance.** On a `make_classification(weights=[0.9, 0.1])` set, train any classifier and print accuracy, precision, recall, F1, and ROC-AUC. Then change the threshold to 0.3 and recompute. Write one sentence on how the recall/precision trade-off moved.

## You're ready for the next module when…
- [ ] I can spot at least three kinds of data leakage and prevent them with a pipeline.
- [ ] I can report model performance as a cross-validated mean ± std, not a single number.
- [ ] I can diagnose overfitting vs underfitting from scores and curves and name fixes for each.
- [ ] I can choose and interpret the right metric (precision, recall, F1, ROC-AUC) instead of trusting accuracy blindly.

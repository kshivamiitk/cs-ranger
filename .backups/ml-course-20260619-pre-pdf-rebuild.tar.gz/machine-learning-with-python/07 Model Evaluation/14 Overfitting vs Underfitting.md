# Overfitting vs Underfitting

> Every model lives on a dial between "too simple to learn" and "too complex to generalize" — your whole job as a modeler is finding the sweet spot in the middle.

## What you'll learn
- What **overfitting** and **underfitting** are, in plain words, via the bias-variance idea.
- The tell-tale signatures of each in your train/test scores.
- How **learning curves** and **validation curves** diagnose which problem you have.
- Concrete fixes for each failure mode.

## Intuition

Think of a student preparing for an exam.

- **Underfitting (high bias):** the student barely studied and learned only one crude rule ("always pick B"). They do badly on practice questions *and* the real exam. The model is too simple to capture the pattern — e.g. fitting a straight line to data that curves. **Both train and test scores are poor, and close together.**
- **Overfitting (high variance):** the student memorized every practice question word-for-word, including typos. They ace the practice set but bomb the real exam because the questions are slightly different. The model captured noise instead of signal — e.g. a high-degree polynomial that wiggles through every training point. **Train score is excellent, test score is much worse: a big gap.**
- **The sweet spot:** the student learned the underlying concepts. They do well on practice *and* the exam. **Train and test scores are both good and close.**

This is the **bias-variance trade-off**. *Bias* is error from wrong assumptions (too simple); *variance* is error from sensitivity to the particular training data (too complex). As you increase model complexity, bias falls but variance rises. Total error is a U-shape: it drops, bottoms out at the sweet spot, then climbs as overfitting sets in. Your job is to find the bottom of that U.

### Reading the signs

| Symptom | Diagnosis | Typical fixes |
|---|---|---|
| Train low, test low (close) | Underfitting | More complex model, more/better features, train longer, less regularization |
| Train high, test much lower | Overfitting | Simpler model, more data, more regularization, fewer features, early stopping |
| Train high, test high (close) | Just right | Ship it (and keep monitoring) |

**Learning curves** plot score versus *training-set size*. If both curves are low and have converged, you're underfitting — more data won't help, you need a better model. If there's a persistent gap between a high train curve and a lower validation curve that's still closing as data grows, more data *will* help. **Validation curves** plot score versus a *complexity hyperparameter* (polynomial degree, tree depth, regularization strength). They make the U-shape literal: the best complexity is where the validation score peaks.

## Python in practice

Let's make the U-shape appear with `validation_curve`, sweeping polynomial degree on a curvy regression target. Watch train error keep dropping while validation error turns back up — the signature of overfitting.

```python
import numpy as np
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import validation_curve

# A true cubic-ish signal plus noise. Reshape X to 2D for sklearn.
rng = np.random.default_rng(0)
X = np.sort(rng.uniform(-3, 3, 120)).reshape(-1, 1)
y = 0.5 * X.ravel()**3 - X.ravel() + rng.normal(0, 2, size=X.shape[0])

# Pipeline whose complexity knob is the polynomial degree.
pipe = make_pipeline(PolynomialFeatures(), LinearRegression())

degrees = range(1, 13)
train_scores, val_scores = validation_curve(
    pipe, X, y,
    param_name="polynomialfeatures__degree",
    param_range=degrees, cv=5, scoring="neg_mean_squared_error")

# Convert negative MSE back to positive error and average across folds.
train_err = -train_scores.mean(axis=1)
val_err   = -val_scores.mean(axis=1)
for d, tr, va in zip(degrees, train_err, val_err):
    print(f"degree {d:2d}: train MSE={tr:6.2f}   val MSE={va:7.2f}")

best = degrees[int(np.argmin(val_err))]
print("Best degree (lowest validation error):", best)
```

Expected output (approximate):

```
degree  1: train MSE= 28.41   val MSE=  30.10   <- underfit: both high
degree  2: train MSE= 27.90   val MSE=  29.85
degree  3: train MSE=  4.12   val MSE=   4.80   <- sweet spot (true degree is 3)
degree  4: train MSE=  4.05   val MSE=   5.20
...
degree 12: train MSE=  3.10   val MSE=  41.30   <- overfit: train tiny, val explodes
Best degree (lowest validation error): 3
```

Read it like a doctor reading a chart: degree 1–2 have high error on *both* train and validation (underfitting); degree 3 minimizes validation error (sweet spot — and it matches the true cubic); by degree 12 the train error is tiny but validation error has blown up (overfitting). The validation column is the one that matters; the train column only tells you how hard the model is trying.

## Common mistakes

- **Judging a model by training accuracy.** A model can hit 100% on train and be useless. Always compare train *against* a held-out/validation score.
- **Reacting to overfitting by adding features.** That makes it worse. Overfitting calls for *less* complexity or *more data*, not more features.
- **Trying to fix underfitting with more data.** If both curves are low and flat, more rows won't help — you need a more expressive model or better features.
- **Forgetting regularization is a complexity dial.** Stronger regularization (`C` smaller in logistic/SVM, `alpha` larger in ridge/lasso) simplifies the model and fights overfitting; weaker regularization does the opposite.
- **Picking complexity by training error.** Use validation/CV error to choose hyperparameters — training error always favors the most complex model.

## Small exercise

Modify the code to also fit and plot (or just print predictions for) degree 1, degree 3, and degree 12 models on a fine grid of X values. Eyeball them: degree 1 is a straight line missing the curve (underfit), degree 3 tracks the true shape, degree 12 wiggles wildly between points (overfit). Seeing the curves cements the numbers.

## Before you continue
- [ ] I can explain underfitting and overfitting using bias and variance.
- [ ] I can name the train/test signature of each (and of a good fit).
- [ ] I can describe what a learning curve and a validation curve each diagnose.
- [ ] I can list at least two fixes for overfitting and two for underfitting.

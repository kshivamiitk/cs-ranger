# F1 Score

> Precision and recall pull in opposite directions, so you're left juggling two numbers. F1 fuses them into one — and it's deliberately rigged so you can't fake it by acing one and tanking the other.

## What is this?

F1 is a **single score that combines precision and recall**. You've met both:

- **Precision** = TP / (TP + FP) — of what you flagged, how much was right.
- **Recall** = TP / (TP + FN) — of the real positives, how many you caught.

F1 is their **harmonic mean**:

```
F1 = 2 * (Precision * Recall) / (Precision + Recall)
```

The harmonic mean is the key trick. Unlike a plain average, it **pulls hard toward the smaller of the two numbers**. If precision is 0.9 and recall is 0.1, the ordinary average is a comfortable-looking 0.5 — but F1 is only **0.18**. F1 refuses to be impressed by one strong number when the other is weak. It is only high when **both** precision and recall are high.

That's the whole personality of F1: *one balanced number that punishes lopsided models.*

## Why do we need it?

Two reasons.

**First — you need one number to compare models.** Tuning hyperparameters, picking between candidates, or setting up automated model selection all need a single score to optimize. Tracking precision and recall separately is great for understanding, but you can't sort a leaderboard by two columns at once. F1 collapses the trade-off into one comparable value that respects both sides.

**Second — accuracy lies on imbalanced data, and F1 doesn't.** On a dataset that's 99% negatives, a model that predicts "negative" for everything scores 99% accuracy and is worthless — it never catches a single positive. Its recall is 0, so its **F1 is 0**. F1 focuses entirely on the positive class (TP, FP, FN) and ignores the easy true negatives that inflate accuracy. When the thing you care about is rare, F1 tells the truth where accuracy flatters.

**Why harmonic, not a normal average?** Because a normal average lets a model "buy" a good score with one extreme. A model that flags everything has recall 1.0 and tiny precision; the arithmetic mean rewards it, the harmonic mean does not. Harmonic mean says: *you only get a good F1 if you're good at both at once.* That's exactly the behavior you want from a balance metric.

## Where it's used in real ML

- **Imbalanced classification leaderboards** — Kaggle competitions and internal benchmarks on rare-event problems (fraud, churn, defaults) routinely rank models by F1 instead of accuracy.
- **Information retrieval / search** — F1 balances "did we return relevant results" (precision) against "did we find all the relevant ones" (recall).
- **NLP tasks** — Named-entity recognition, text classification, and span detection are graded by F1 because the positive spans are sparse and accuracy is meaningless.
- **Automated model selection** — When `GridSearchCV` or an MLOps pipeline must pick one model unattended, `scoring="f1"` gives it a single, imbalance-aware target.
- **Multiclass reporting** — `classification_report` shows per-class F1 plus **macro** and **weighted** averages so you can summarize a many-class model in a glance.

## What breaks if you ignore it

If you judge an imbalanced model by accuracy alone and skip F1:

1. **You ship the "always say no" model.** It scores 99% accuracy, F1 of 0, and catches zero fraud/disease. Accuracy hides the failure; F1 screams it.
2. **You can't tell a balanced model from a lopsided one.** Two models can both report "decent" precision *or* recall while being uselessly skewed. Without F1 (or seeing both numbers), you'll pick the wrong one.
3. **Your model selection optimizes the wrong thing.** A tuner pointed at accuracy on imbalanced data will happily converge on a model that ignores the minority class entirely.

And if you reach for F1 but use the **wrong average** on multiclass data, you break it a different way: **weighted** F1 lets the big classes drown out the small one you care about, while **macro** F1 treats every class equally and exposes the rare class. Picking the wrong average can hide exactly the failure F1 was supposed to reveal.

## Mental model

Think of F1 as a **two-legged stool**. Precision is one leg, recall is the other. A stool is only stable when **both** legs are roughly long — one tall leg and one stub tips you over.

```
   precision = 0.9, recall = 0.1        precision = 0.7, recall = 0.6
        |                                     |        |
        |                                     |        |
        |   .                                 |        |
   ─────┴───'──   F1 = 0.18 (tips over)    ───┴────────┴──  F1 = 0.65 (stable)
```

The arithmetic mean measures the *average* leg length and would call the wobbly stool "0.5 — not bad." The harmonic mean (F1) measures the *shorter* leg's influence and correctly says "0.18 — you're on the floor." A chain is as strong as its weakest link; F1 scores a classifier by its weaker of precision/recall.

## Example 1 — Tiny toy example

A fraud detector screens **1,000 transactions**. The confusion matrix for the **fraud (positive)** class:

```
                   Predicted: fraud     Predicted: legit
Actually fraud          TP = 30              FN = 20
Actually legit          FP = 10              TN = 940
```

Step 1 — precision (of the 40 it flagged, how many were fraud):

```
Precision = TP / (TP + FP) = 30 / (30 + 10) = 30 / 40 = 0.75
```

Step 2 — recall (of the 50 real frauds, how many it caught):

```
Recall = TP / (TP + FN) = 30 / (30 + 20) = 30 / 50 = 0.60
```

Step 3 — combine with the harmonic mean:

```
F1 = 2 * (P * R) / (P + R)
   = 2 * (0.75 * 0.60) / (0.75 + 0.60)
   = 2 * 0.45 / 1.35
   = 0.90 / 1.35
   = 0.667
```

So **F1 ≈ 0.67**. Two things to notice. First, the plain average of 0.75 and 0.60 is 0.675 — F1 (0.667) sits *just below* it, nudged toward the smaller number (recall). Second, watch how brutal F1 is on a lopsided model: had precision been 0.95 and recall 0.10, the average would be a flattering 0.525, but F1 = 2·(0.095)/1.05 = **0.18**. Same "average," a fraction of the F1 — that's the harmonic mean punishing imbalance.

## Example 2 — Practical ML example

You train a churn classifier on customers where only **15% actually churn** (imbalanced). Two candidate models:

| Model | Precision | Recall | Accuracy | F1 |
|-------|-----------|--------|----------|----|
| A — "plays it safe" | 0.95 | 0.20 | **0.88** | 0.33 |
| B — "balanced" | 0.62 | 0.70 | 0.85 | **0.66** |

Model A has the **higher accuracy (0.88)** because it rarely predicts churn, so it's right about the 85% who stay. But its recall is 0.20 — it misses 80% of the customers about to leave, the entire reason you built the model. Its F1 of 0.33 exposes this instantly. Model B is *less* accurate yet catches far more churners with reasonable precision, and its **F1 of 0.66 doubles A's**. If you'd ranked by accuracy you'd ship the useless model; ranking by F1 picks the one that actually does the job. This is the canonical "F1 beats accuracy" situation: a rare positive class you genuinely care about catching.

**Macro vs weighted (multiclass):** suppose three classes with F1 scores — "stayed" 0.92 (8,500 customers), "churned" 0.66 (1,200), "win-back" 0.40 (300). **Macro** F1 = (0.92 + 0.66 + 0.40)/3 = **0.66**, treating each class equally and surfacing the weak rare classes. **Weighted** F1 averages by support ≈ **0.87**, dominated by the huge "stayed" class. Report *macro* when the rare classes matter most; *weighted* when you want an overall figure that reflects class sizes. Quoting the wrong one can hide a failing minority class.

## Python code example

```python
from sklearn.metrics import f1_score, precision_score, recall_score, classification_report

# Inline data: 1 = positive (fraud), 0 = negative (legit). Imbalanced: 5 of 20 positive.
y_true = [1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
y_pred = [1, 1, 1, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]  # balanced-ish

p = precision_score(y_true, y_pred)
r = recall_score(y_true, y_pred)
f1 = f1_score(y_true, y_pred)
print(f"Precision={p:.3f}  Recall={r:.3f}  F1={f1:.3f}")     # P=0.750 R=0.600 F1=0.667

# Prove F1 is the HARMONIC mean (pulls toward the smaller), not the arithmetic mean.
harmonic = 2 * (p * r) / (p + r)
arithmetic = (p + r) / 2
print(f"Harmonic mean (=F1): {harmonic:.3f}   Arithmetic mean: {arithmetic:.3f}")
# 0.667 vs 0.675 -> F1 sits below the plain average, nudged toward recall (the weaker one).

# A LOPSIDED model: flags almost nothing, so precision is high but recall collapses.
y_pred_lopsided = [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
p2 = precision_score(y_true, y_pred_lopsided)   # 1.00 (the one flag was right)
r2 = recall_score(y_true, y_pred_lopsided)      # 0.20 (caught 1 of 5)
print(f"Lopsided: P={p2:.2f} R={r2:.2f} -> F1={f1_score(y_true, y_pred_lopsided):.2f}")
# F1 = 0.33: one great number can't rescue a terrible one. Accuracy would NOT show this.

# macro vs weighted on the same predictions: macro treats classes equally,
# weighted weights by how many samples each class has (support).
print("\nmacro    F1:", round(f1_score(y_true, y_pred, average='macro'), 3))
print("weighted F1:", round(f1_score(y_true, y_pred, average='weighted'), 3))
print("\n", classification_report(y_true, y_pred, digits=3))
```

## Common mistakes

- **Treating F1 as an arithmetic average.** It's the *harmonic* mean. It sits below the plain average and crashes when precision and recall are far apart — that punishment is the entire point.
- **Optimizing F1 when the costs are not balanced.** F1 weights precision and recall equally. If a miss is 10x worse than a false alarm, use a weighted F-beta (e.g. `fbeta_score` with `beta=2` to favor recall) instead of plain F1.
- **Confusing macro and weighted averages.** Macro treats every class equally (good for surfacing rare classes); weighted lets big classes dominate. Reporting weighted F1 can hide a failing minority class.
- **Quoting F1 without precision and recall.** The same F1 can come from very different P/R pairs. Always show all three so readers know *which* leg of the stool is short.
- **Computing F1 on the majority class and calling it good.** On imbalanced data the easy class has a high F1 almost for free. Report F1 for the *positive / minority* class you care about.

## Before you continue
- [ ] I can write the F1 formula 2·P·R/(P+R) and explain why it's a harmonic mean.
- [ ] I can explain, with numbers, why F1 punishes a lopsided precision/recall pair.
- [ ] I can give one concrete case where F1 beats accuracy (rare positive class).
- [ ] I can explain the difference between macro and weighted F1 and when to use each.
- [ ] I know that F1 should be reported alongside precision and recall, not instead of them.

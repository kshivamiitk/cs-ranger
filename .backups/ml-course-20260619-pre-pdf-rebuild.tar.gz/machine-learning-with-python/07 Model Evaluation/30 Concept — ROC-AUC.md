# ROC-AUC

> Accuracy asks "did you pick the right side of one line?" — ROC-AUC asks the deeper question: "can your model rank a true positive above a true negative, no matter where you draw the line?"

## What is this?

A classifier like logistic regression does not really output "spam" or "not spam." It outputs a **score** — usually a probability between 0 and 1. You turn that score into a decision by picking a **threshold**: score above 0.5 → positive, below → negative. But 0.5 is just one choice. Slide the threshold and your predictions change, and so do your mistakes.

The **ROC curve** (Receiver Operating Characteristic) plots how two numbers move as you slide the threshold from 1.0 down to 0.0:

- **True Positive Rate (TPR)**, also called recall: of all the actual positives, what fraction did you catch? `TP / (TP + FN)`.
- **False Positive Rate (FPR)**: of all the actual negatives, what fraction did you wrongly flag? `FP / (FP + TN)`.

At each threshold you get one `(FPR, TPR)` point. Connect all of them and you get a curve from `(0,0)` to `(1,1)`.

**AUC** is the **Area Under that Curve** — a single number from 0 to 1 that summarizes the whole curve. The beautiful part is what AUC actually *means*: it is **the probability that the model gives a randomly chosen positive example a higher score than a randomly chosen negative example.** It measures **ranking quality**, not whether any single threshold is good.

- AUC = 1.0 → every positive is ranked above every negative. Perfect separation.
- AUC = 0.5 → the model ranks no better than a coin flip. The diagonal line.
- AUC < 0.5 → the model is ranking *backwards* (often a sign of a flipped label).

## Why do we need it?

Because **accuracy lies when classes are imbalanced**, and because **the right threshold often is not 0.5**.

Imagine fraud detection where 1 in 1000 transactions is fraud. A model that says "never fraud" is 99.9% accurate and completely useless. Accuracy rewards it; ROC-AUC does not, because that model can never rank a fraud above a non-fraud.

ROC-AUC is also **threshold-free**. You may not yet know your operating threshold — maybe the business will decide later whether to favor catching more fraud (high recall) or fewer false alarms (high precision). AUC lets you judge *the model's underlying ability to separate the classes* before you commit to a threshold. It answers: "Does this model put the right examples near the top of the list?"

## Where it's used in real ML

- **Medical diagnosis** — ranking patients by risk so the riskiest get screened first; the cutoff is a clinical decision made later.
- **Fraud and spam** — heavily imbalanced; accuracy is meaningless, ranking is everything.
- **Credit scoring** — banks rank applicants by default risk; AUC (often reported as the related "Gini") is a standard model-quality metric.
- **Ad and recommendation click prediction** — you want the items most likely to be clicked at the top of the feed; that is pure ranking.
- **Model comparison** — "Model A has AUC 0.91, Model B has 0.87" is a clean, threshold-independent way to pick the better model.

## What breaks if you ignore it

- You ship a model with **96% accuracy on imbalanced data** and discover in production it catches almost none of the rare cases that actually mattered.
- You **lock in threshold 0.5** without ever checking the curve, missing that a threshold of 0.2 would have doubled your recall at a tiny precision cost.
- You compare two models by accuracy alone and pick the worse ranker because it happened to look good at one arbitrary cutoff.
- On **extreme imbalance**, you trust ROC-AUC when you should have used a **Precision-Recall curve** (see Common mistakes) and over-estimate how useful the model is.

## Mental model

Think of the model as a **bouncer with a guest list**, sorting people by a "VIP score." ROC-AUC ignores where the bouncer draws the rope tonight. It asks one thing: when you pick a random real VIP and a random gate-crasher, how often does the bouncer score the VIP higher? Do that for every pair; the fraction the bouncer gets right is the AUC.

```
Sorted by model score, high -> low.  (P = real positive, N = real negative)

Perfect ranking (AUC = 1.0):   P  P  P  N  N  N      all P above all N
Good ranking   (AUC ~ 0.83):   P  P  N  P  N  N      one pair out of order
Coin flip      (AUC = 0.5):    P  N  P  N  P  N      no ordering signal

ROC curve shape:
TPR
1 |        ____------   <- good model bows toward top-left
  |     _-/
  |   _/        ......   <- diagonal dotted = random (AUC 0.5)
  | _/    ....
0 |/...______________
   0                1  FPR
```

## Example 1 — Tiny toy example

Four examples. Two are truly positive (P), two truly negative (N). The model assigns these scores:

| Example | True label | Model score |
|---------|-----------|-------------|
| A       | P         | 0.90        |
| B       | N         | 0.70        |
| C       | P         | 0.60        |
| D       | N         | 0.20        |

AUC = fraction of (positive, negative) pairs where the positive scores higher. There are 2 positives x 2 negatives = **4 pairs**:

- (A=0.90 vs B=0.70): P higher → win
- (A=0.90 vs D=0.20): P higher → win
- (C=0.60 vs B=0.70): P lower → **loss**
- (C=0.60 vs D=0.20): P higher → win

3 wins out of 4 pairs → **AUC = 3/4 = 0.75**. Notice we never picked a threshold. We only asked how well the scores *order* positives above negatives, and exactly one pair (C below B) was out of order.

## Example 2 — Practical ML example

You are predicting customer **churn** (will they cancel?). Only 12% of customers churn, so the classes are imbalanced and accuracy is misleading. You train two models — a logistic regression and a random forest — and you want to know which one *ranks* churners higher before deciding on an alert threshold for the retention team.

You get each model's predicted churn probabilities on the test set and compute `roc_auc_score(y_true, churn_probability)` for each. The random forest scores 0.88, the logistic regression 0.81. The forest is the better ranker: hand it a random churner and a random stayer and it puts the churner on top 88% of the time. Later, the retention team picks a threshold based on how many outreach calls they can afford — but the *model choice* was made cleanly with AUC, independent of that threshold.

## Python code example

```python
# ROC-AUC end to end: train two models, compare their ranking ability.
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import roc_auc_score, roc_curve

# --- Inline, imbalanced toy "churn" data: 2 features, ~15% positives ---
rng = np.random.RandomState(42)
n = 400
# Negatives (stayers): centered low; Positives (churners): shifted higher.
X_neg = rng.normal(loc=0.0, scale=1.0, size=(340, 2))
X_pos = rng.normal(loc=1.3, scale=1.0, size=(60, 2))   # only 60/400 = 15% positive
X = np.vstack([X_neg, X_pos])
y = np.array([0] * 340 + [1] * 60)

X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.3, random_state=0, stratify=y   # keep the 15% ratio in both splits
)

# --- Train two classifiers ---
logreg = LogisticRegression().fit(X_tr, y_tr)
forest = RandomForestClassifier(n_estimators=200, random_state=0).fit(X_tr, y_tr)

# ROC-AUC needs SCORES, not 0/1 labels. Use predict_proba and take the
# probability of the POSITIVE class (column index 1).
p_logreg = logreg.predict_proba(X_te)[:, 1]
p_forest = forest.predict_proba(X_te)[:, 1]

auc_logreg = roc_auc_score(y_te, p_logreg)
auc_forest = roc_auc_score(y_te, p_forest)
print(f"Logistic Regression AUC: {auc_logreg:.3f}")
print(f"Random Forest       AUC: {auc_forest:.3f}")
print(f"Better ranker: {'Random Forest' if auc_forest > auc_logreg else 'Logistic Regression'}")

# Why accuracy can mislead here: a 'predict all negative' baseline.
baseline_acc = (y_te == 0).mean()
print(f"\n'Always predict stay' accuracy: {baseline_acc:.3f}  (high, yet catches 0 churners)")
print(f"Its AUC would be exactly 0.500 (no ranking signal).")

# Peek at the ROC curve points for the forest (threshold-free view).
fpr, tpr, thresholds = roc_curve(y_te, p_forest)
print("\nA few points along the Random Forest ROC curve:")
for i in range(0, len(fpr), max(1, len(fpr) // 4)):
    print(f"  threshold={thresholds[i]:.2f}  FPR={fpr[i]:.2f}  TPR={tpr[i]:.2f}")
```

Expected output (numbers approximate):

```
Logistic Regression AUC: 0.86
Random Forest       AUC: 0.89
Better ranker: Random Forest

'Always predict stay' accuracy: 0.850  (high, yet catches 0 churners)
Its AUC would be exactly 0.500 (no ranking signal).

A few points along the Random Forest ROC curve:
  threshold=1.99  FPR=0.00  TPR=0.00
  threshold=0.41  FPR=0.04  TPR=0.61
  ...
```

## Common mistakes

- **Passing labels instead of scores.** `roc_auc_score(y_true, y_pred_labels)` collapses the curve to a single point and gives a wrong, degraded number. Always pass `predict_proba(...)[:, 1]` (or `decision_function`).
- **Taking the wrong probability column.** `predict_proba` returns one column per class; column `0` is the negative class. You almost always want column `1`, the positive class.
- **Trusting ROC-AUC under extreme imbalance.** With 0.1% positives, FPR barely moves even with thousands of false positives, so ROC-AUC can look great while precision is terrible. Use a **Precision-Recall curve / average precision** when positives are very rare and you care about them specifically.
- **Reading AUC as accuracy.** AUC 0.90 does **not** mean 90% correct. It is a ranking probability; your accuracy depends entirely on the threshold you later choose.
- **Forgetting AUC says nothing about calibration.** A model can rank perfectly (AUC 1.0) yet output probabilities that are all squished near 0.5. If you need trustworthy probabilities, check calibration separately.

## Before you continue
- [ ] I can state, in one sentence, what AUC measures (the probability a random positive is ranked above a random negative).
- [ ] I know that ROC-AUC is threshold-free and why that is useful before choosing an operating point.
- [ ] I can explain why accuracy misleads on imbalanced data but ROC-AUC does not get fooled the same way.
- [ ] I know to pass `predict_proba(...)[:, 1]`, not hard 0/1 labels, to `roc_auc_score`.
- [ ] I know when to reach for a Precision-Recall curve instead of ROC under heavy imbalance.

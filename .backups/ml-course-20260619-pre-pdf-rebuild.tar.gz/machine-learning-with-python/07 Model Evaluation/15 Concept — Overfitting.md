# Overfitting

> Overfitting is when a model is so flexible it memorizes the noise in your training data — it aces the data it studied and stumbles on everything new.

## What is this?

Overfitting happens when a model is *too flexible* for the amount and cleanliness of data you have. Instead of learning the underlying pattern, it learns the training set itself — including the random quirks, measurement noise, and one-off coincidences that won't repeat. The model bends and wiggles to pass through every single training point.

The telltale signature is a **big gap between train and test performance**. The model scores near-perfect on the data it trained on (it has effectively memorized it) but noticeably worse on held-out data. The wider that gap, the more the model is fitting noise rather than signal.

In bias-variance language, overfitting is **high variance**: the model is so sensitive to the exact training rows that if you'd handed it a slightly different sample, it would have drawn a wildly different boundary. It reacts to randomness as if it were meaningful.

## Why do we need it?

You need to recognize overfitting because it's the most common way a model that "works" turns out to be worthless. A model is only valuable if it generalizes to new data — and an overfit model, by definition, doesn't. It has optimized for a test it will never take again (the training set) instead of the test that matters (reality).

Understanding it also stops you from "fixing" it the wrong way. The instinctive reaction to a disappointing model is to add more features or a fancier algorithm — which makes overfitting *worse*. Knowing the failure mode tells you the cure runs in the opposite direction: simplify, regularize, or get more data.

## Where it's used in real ML

"Where it shows up" — overfitting is most common when model capacity is high relative to data:

- **Deep decision trees** grown with no depth limit: they keep splitting until each leaf holds a single training row, achieving train accuracy of 1.0 and poor test accuracy.
- **High-degree polynomial regression**: a degree-15 polynomial threads every point but oscillates insanely between them.
- **Neural networks trained too long** on too little data, with no dropout, weight decay, or early stopping.
- **Too many features relative to rows** (the "curse of dimensionality") — the model finds spurious correlations that happen to hold in the sample.
- **Repeated tuning against the same validation set**: you overfit your *decisions* even if each model isn't individually complex.

## What breaks if you ignore it

The model looks great on paper and fails in the wild — and you may not notice until it's deployed.

- A spam filter that "learned" the exact phrasings in your training emails flags new spam at half the rate, because real spammers reword constantly.
- A pricing model that memorized last quarter's noise recommends erratic prices on this quarter's products.
- You report a glowing **99% train accuracy** in a meeting, ship it, and the live system performs around **70%** — the gap was overfitting hiding in plain sight.
- Debugging is miserable: the model is "correct" on every example you can hand-check (they're all in the training set), so the bug feels invisible.

## Mental model

Imagine a student cramming for an exam by **memorizing every practice question word-for-word — including the typos**.

```
   The TRUE pattern        An OVERFIT model traces
   (smooth signal)         every bump in the data

   y                       y
   │      .  ╱             │      .  ╱╲    .
   │   .  ╱  .             │   . ╱╲╱  ╲  .╱╲
   │  .╱   .               │  ╲╱      ╲╱  .
   │ ╱  .                  │ ╱  .  (wiggles to
   └──────────── x         └──────── hit each dot) x
   learns the trend        memorizes the noise
```

On the practice set (training data) the crammer scores 100% — they've seen those exact questions. On the real exam (test data) they crash, because the questions are *slightly different* and they learned the surface, not the concept. An overfit model is that crammer: flawless on what it memorized, lost on anything new.

## Example 1 — Tiny toy example

Suppose the real relationship is a gentle straight line, but our 5 measurements have a little noise:

```
x:  1     2     3     4     5
y:  2.1   3.9   6.2   7.8   10.3     (true line is roughly y = 2x, plus noise)
```

A **degree-1 fit** (a straight line) gives `y ≈ 2.0x` — it ignores the tiny wiggles and captures the trend.

A **degree-4 polynomial** has enough flexibility to pass *exactly* through all five points: train error becomes **0.0**. But to do that it has to curve sharply between the points. Ask it to predict at `x = 2.5`:

```
straight line (degree 1):  predicts ~5.0   (sensible, between 3.9 and 6.2)
degree-4 polynomial:       predicts ~4.1   (dips weirdly to honor the noise)
```

The degree-4 model has *zero* training error and *worse* judgment. Perfect on the dots, wrong in the gaps — overfitting in five numbers.

## Example 2 — Practical ML example

You're classifying customers (will-buy vs won't-buy) from noisy behavioral data. You reach for a `DecisionTreeClassifier` and leave it at its defaults, which means **no depth limit**.

You train it and check:

```
Train accuracy: 1.000   <- perfect!
Test  accuracy: 0.750
```

That gap of **0.25** is the overfitting alarm. The tree kept splitting until almost every leaf held a single training customer — it *memorized the training set*. Those deep splits encode noise specific to those exact rows, which doesn't transfer to new customers.

The fix is to **reduce capacity**: cap the tree's depth (and/or require a minimum number of samples per leaf). With `max_depth=2` the tree can no longer carve out one-row leaves:

```
Train accuracy: 0.807   <- dropped (good — it stopped memorizing noise)
Test  accuracy: 0.742   <- held steady while the gap collapsed
```

Train accuracy fell from 1.000 to 0.807, but the **train-test gap collapsed from 0.25 to about 0.07** — the model now performs about the same on data it studied and data it didn't, which is exactly what generalization looks like. A "worse-on-training" model is the better model here, because the gap, not the train score, predicts real-world behavior. Other levers that do the same job: regularization (e.g. smaller `C`, larger `alpha`), more training data, or pruning.

## Python code example

```python
# Watch a model overfit, then fix it by limiting capacity.
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

# Inline data: a NOISY classification problem (flip_y adds 25% label noise),
# which is exactly the kind of data a too-flexible model memorizes.
X, y = make_classification(
    n_samples=400, n_features=20, n_informative=5,
    n_redundant=0, flip_y=0.25, random_state=0,
)
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.3, random_state=0, stratify=y
)

# --- OVERFIT: a decision tree with NO depth limit memorizes the training set ---
deep = DecisionTreeClassifier(random_state=0)         # grows until leaves are pure
deep.fit(X_tr, y_tr)
gap_deep = deep.score(X_tr, y_tr) - deep.score(X_te, y_te)
print("Unlimited tree:")
print(f"  train acc = {deep.score(X_tr, y_tr):.3f}")  # ~1.000  (memorized)
print(f"  test  acc = {deep.score(X_te, y_te):.3f}")  # ~0.750
print(f"  train-test gap = {gap_deep:.3f}  <- big gap = overfitting\n")

# --- FIX: cap the depth so it can't carve a leaf for every training row ---
shallow = DecisionTreeClassifier(max_depth=2, random_state=0)   # less flexible
shallow.fit(X_tr, y_tr)
gap_shallow = shallow.score(X_tr, y_tr) - shallow.score(X_te, y_te)
print("Depth-limited tree (max_depth=2):")
print(f"  train acc = {shallow.score(X_tr, y_tr):.3f}")  # ~0.807 (down on purpose)
print(f"  test  acc = {shallow.score(X_te, y_te):.3f}")  # ~0.742 (about the same)
print(f"  train-test gap = {gap_shallow:.3f}  <- small gap = generalizes")

# Takeaway: lowering capacity made the TRAIN score drop a lot but the TEST score
# barely move -- so the train-test gap collapsed from ~0.25 to ~0.07.
# That shrinking gap is the proof we cured the overfitting.
```

## Common mistakes

- **Judging a model by its training score.** 100% train accuracy is meaningless on its own — always compare it against a held-out or cross-validation score and watch the gap.
- **Reacting to overfitting by adding features or complexity.** That pours fuel on the fire. Overfitting wants *less* flexibility, *more* data, or *stronger* regularization.
- **Confusing it with underfitting.** Overfitting = train good, test bad (big gap). If *both* scores are bad, that's underfitting and the cure is the opposite.
- **Never tuning the complexity knobs.** `max_depth`, `min_samples_leaf`, `C`, `alpha`, dropout, and early stopping all exist to dial flexibility down — leaving them at defaults often overfits.
- **Tuning forever on the same validation set.** Enough attempts and you overfit your model *choices* to it; keep a final test set you touch once.

## Before you continue
- [ ] I can define overfitting as a too-flexible model that memorizes noise.
- [ ] I can name its signature: train score high, test score lower, with a big gap.
- [ ] I know the cures run toward *less* complexity, *more* data, and regularization.
- [ ] I can explain why a model with worse train accuracy can be the better model.
- [ ] I can spot it in code by comparing train vs test scores, not train alone.

"use strict";

/* ============================================================================
 *  Precision Recall Tradeoff
 *  --------------------------------------------------------------------------
 *  ~40 labeled examples, each with a true class (0/1) and a model score (0..1),
 *  positives skewed high. A draggable THRESHOLD splits predicted-positive
 *  (score >= threshold) from predicted-negative. The strip (top canvas) is a
 *  number line of those points; the curve (bottom canvas) is the full
 *  precision-recall curve traced by sweeping the threshold, with the current
 *  operating point and the F1-maximizing point (star) marked.
 *
 *  precision = TP / (TP + FP)          (of what we flagged, how much was right)
 *  recall    = TP / (TP + FN)          (of the real positives, how many we caught)
 *  F1        = 2 * P * R / (P + R)     (harmonic mean -> punishes a lopsided P/R)
 *
 *  Raising the threshold -> precision UP, recall DOWN (and vice-versa). That
 *  inverse relationship is the one idea this lesson teaches.
 * ========================================================================== */

const N = 40;
const SEED0 = 2026;
const COLORS = {
  pos: "#22d3ee",     // truly positive (cyan)
  neg: "#94a3b8",     // truly negative (dim)
  violet: "#a78bfa",  // operating point / threshold line
  gold: "#fbbf24",    // F1-peak star
};

/* ---------- Seeded PRNG (mulberry32) so the data is identical every load --- */
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/* Positives skew high, negatives low, with real overlap so the threshold
 * genuinely trades precision against recall (a realistic, imperfect model). */
let examples = [];
function generate(seed) {
  const rand = mulberry32(seed >>> 0);
  const out = [];
  for (let i = 0; i < N; i++) {
    const isPos = rand() < 0.45;                  // ~45% positives
    let s = (rand() + rand()) / 2;                // pull toward the middle
    s += isPos ? 0.24 : -0.24;                    // separate classes (overlap stays)
    s = Math.max(0.02, Math.min(0.98, s));
    out.push({ score: s, label: isPos ? 1 : 0 });
  }
  examples = out;
}

/* ---------- Metrics at one threshold --------------------------------------- */
const safe = (num, den) => (den === 0 ? 0 : num / den);   // divide-by-zero guard

function statsAt(thr) {
  let tp = 0, fp = 0, fn = 0, tn = 0;
  for (const e of examples) {
    const predPos = e.score >= thr;
    if (e.label === 1 && predPos) tp++;
    else if (e.label === 0 && predPos) fp++;
    else if (e.label === 1 && !predPos) fn++;
    else tn++;
  }
  const precision = safe(tp, tp + fp);            // TP / (TP + FP)
  const recall = safe(tp, tp + fn);               // TP / (TP + FN)
  const f1 = (precision + recall === 0)
    ? 0
    : (2 * precision * recall) / (precision + recall);   // 2*P*R / (P+R)
  return { tp, fp, fn, tn, precision, recall, f1 };
}

/* When nothing is flagged precision is undefined; the PR curve carries 1 there
 * (sklearn convention) so the curve anchors at recall 0 / precision 1. */
function precForPlot(s) {
  return (s.tp + s.fp === 0) ? 1 : s.precision;
}

/* ---------- Full PR curve + the F1-maximizing threshold --------------------
 * Sweep candidate thresholds = every distinct score (high -> low). This is
 * exactly the set of points sklearn's precision_recall_curve would return. */
let curve = [];        // [{recall, precision, thr}], recall ascending
let best = null;       // { thr, recall, precision, f1 } maximizing F1

function buildCurve() {
  const uniq = Array.from(new Set(examples.map((e) => e.score))).sort((a, b) => b - a);
  const pts = [{ recall: 0, precision: 1, thr: 1.0001 }];   // flag nothing
  best = { thr: 0.5, recall: 0, precision: 0, f1: -1 };
  for (const t of uniq) {
    const s = statsAt(t);
    pts.push({ recall: s.recall, precision: precForPlot(s), thr: t });
    if (s.f1 > best.f1) {
      best = { thr: t, recall: s.recall, precision: s.precision, f1: s.f1 };
    }
  }
  curve = pts;
}

/* =================================================================== *
 *  Canvas A: the strip / number line of scored points                 *
 * =================================================================== */
const strip = document.getElementById("strip");
const sctx = strip.getContext("2d");
const SPAD = { l: 40, r: 40, t: 30, b: 34 };

function stripX(score) {
  return SPAD.l + score * (strip.width - SPAD.l - SPAD.r);
}
function stripScoreFromPx(px) {
  return (px - SPAD.l) / (strip.width - SPAD.l - SPAD.r);
}

function drawStrip(thr) {
  const W = strip.width, H = strip.height;
  sctx.clearRect(0, 0, W, H);
  const axisY = H - SPAD.b;
  const baseY = (SPAD.t + axisY) / 2;

  // shade the predicted-positive region (score >= threshold)
  const tx = stripX(thr);
  sctx.fillStyle = "rgba(34, 211, 238, 0.07)";
  sctx.fillRect(tx, SPAD.t - 4, (W - SPAD.r) - tx, axisY - (SPAD.t - 4));

  // axis line + ticks
  sctx.strokeStyle = "rgba(255,255,255,0.12)";
  sctx.lineWidth = 1;
  sctx.beginPath(); sctx.moveTo(SPAD.l, axisY); sctx.lineTo(W - SPAD.r, axisY); sctx.stroke();
  sctx.fillStyle = COLORS.neg;
  sctx.font = "12px ui-monospace, Menlo, monospace";
  sctx.textAlign = "center";
  for (let t = 0; t <= 1.0001; t += 0.25) {
    const x = stripX(t);
    sctx.beginPath(); sctx.moveTo(x, axisY); sctx.lineTo(x, axisY + 5); sctx.stroke();
    sctx.fillText(t.toFixed(2), x, axisY + 19);
  }
  sctx.fillStyle = "#e2e8f0";
  sctx.font = "12px Inter, sans-serif";
  sctx.fillText("model score →", W / 2, H - 4);

  // examples as dots; deterministic vertical jitter so overlaps are visible
  examples.forEach((e, i) => {
    const x = stripX(e.score);
    const jitter = (((i * 53) % 9) - 4) * 5;
    const y = baseY + jitter;
    const predPos = e.score >= thr;
    const color = e.label === 1 ? COLORS.pos : COLORS.neg;
    sctx.beginPath();
    sctx.fillStyle = color;
    sctx.shadowColor = color;
    sctx.shadowBlur = e.label === 1 ? 8 : 2;
    sctx.arc(x, y, 6, 0, Math.PI * 2);
    sctx.fill();
    sctx.shadowBlur = 0;
    sctx.lineWidth = 2;
    sctx.strokeStyle = predPos ? "#ffffff" : "rgba(255,255,255,0.16)";
    sctx.stroke();
  });

  // draggable threshold line + handle
  sctx.strokeStyle = COLORS.violet;
  sctx.lineWidth = 2;
  sctx.beginPath(); sctx.moveTo(tx, SPAD.t - 12); sctx.lineTo(tx, axisY); sctx.stroke();
  sctx.fillStyle = COLORS.violet;
  sctx.beginPath();
  sctx.moveTo(tx, SPAD.t - 14);
  sctx.lineTo(tx - 6, SPAD.t - 24);
  sctx.lineTo(tx + 6, SPAD.t - 24);
  sctx.closePath();
  sctx.fill();
  sctx.font = "11px ui-monospace, Menlo, monospace";
  sctx.textAlign = (thr > 0.85) ? "right" : "left";
  const lx = (thr > 0.85) ? tx - 9 : tx + 9;
  sctx.fillText("threshold " + thr.toFixed(2), lx, SPAD.t - 16);
}

/* =================================================================== *
 *  Canvas B: the precision-recall curve + operating point + F1 star   *
 * =================================================================== */
const curveCanvas = document.getElementById("curve");
const cctx = curveCanvas.getContext("2d");
const CPAD = { l: 60, r: 28, t: 26, b: 50 };

function curveX(recall) {
  return CPAD.l + recall * (curveCanvas.width - CPAD.l - CPAD.r);
}
function curveY(precision) {
  return (curveCanvas.height - CPAD.b) - precision * (curveCanvas.height - CPAD.t - CPAD.b);
}

// operating dot eases toward its target (recall, precision) for a smooth feel
const dot = { x: 0, y: 1, tx: 0, ty: 1 };

function drawCurve() {
  const W = curveCanvas.width, H = curveCanvas.height;
  cctx.clearRect(0, 0, W, H);

  // grid + axis labels
  cctx.strokeStyle = "rgba(255,255,255,0.06)";
  cctx.fillStyle = COLORS.neg;
  cctx.font = "12px ui-monospace, Menlo, monospace";
  cctx.lineWidth = 1;
  for (let g = 0; g <= 1.0001; g += 0.25) {
    const x = curveX(g);
    cctx.beginPath(); cctx.moveTo(x, curveY(0)); cctx.lineTo(x, curveY(1)); cctx.stroke();
    cctx.textAlign = "center"; cctx.fillText(g.toFixed(2), x, curveY(0) + 18);
    const y = curveY(g);
    cctx.beginPath(); cctx.moveTo(curveX(0), y); cctx.lineTo(curveX(1), y); cctx.stroke();
    cctx.textAlign = "right"; cctx.fillText(g.toFixed(2), curveX(0) - 8, y + 4);
  }
  cctx.fillStyle = "#e2e8f0";
  cctx.font = "13px Inter, sans-serif";
  cctx.textAlign = "center";
  cctx.fillText("recall →  (caught real positives)", W / 2, H - 12);
  cctx.save();
  cctx.translate(16, (CPAD.t + (H - CPAD.b)) / 2);
  cctx.rotate(-Math.PI / 2);
  cctx.fillText("precision →", 0, 0);
  cctx.restore();

  // the PR curve (sorted by recall so the polyline is monotone in x)
  const sorted = curve.slice().sort((a, b) => a.recall - b.recall);
  const grad = cctx.createLinearGradient(curveX(0), 0, curveX(1), 0);
  grad.addColorStop(0, COLORS.violet);
  grad.addColorStop(1, COLORS.pos);
  cctx.strokeStyle = grad;
  cctx.lineWidth = 3;
  cctx.beginPath();
  sorted.forEach((pt, i) => {
    const x = curveX(pt.recall), y = curveY(pt.precision);
    if (i === 0) cctx.moveTo(x, y); else cctx.lineTo(x, y);
  });
  cctx.stroke();

  // faint marker at every curve point (one per achievable threshold)
  cctx.fillStyle = "rgba(34,211,238,0.4)";
  sorted.forEach((pt) => {
    cctx.beginPath();
    cctx.arc(curveX(pt.recall), curveY(pt.precision), 2.4, 0, Math.PI * 2);
    cctx.fill();
  });

  // F1-peak star
  if (showStar.checked && best) {
    drawStar(curveX(best.recall), curveY(best.precision), 11, COLORS.gold);
    cctx.fillStyle = COLORS.gold;
    cctx.font = "11px ui-monospace, Menlo, monospace";
    cctx.textAlign = "left";
    cctx.fillText("best F1 = " + best.f1.toFixed(2), curveX(best.recall) + 14, curveY(best.precision) + 4);
  }

  // current operating point (animated)
  const ox = curveX(dot.x), oy = curveY(dot.y);
  cctx.beginPath();
  cctx.fillStyle = COLORS.violet;
  cctx.shadowColor = COLORS.violet;
  cctx.shadowBlur = 14;
  cctx.arc(ox, oy, 7, 0, Math.PI * 2);
  cctx.fill();
  cctx.shadowBlur = 0;
  cctx.strokeStyle = "#fff";
  cctx.lineWidth = 1.5;
  cctx.stroke();
}

function drawStar(cx, cy, r, color) {
  cctx.save();
  cctx.beginPath();
  for (let i = 0; i < 10; i++) {
    const ang = -Math.PI / 2 + (i * Math.PI) / 5;
    const rad = (i % 2 === 0) ? r : r * 0.45;
    const x = cx + Math.cos(ang) * rad;
    const y = cy + Math.sin(ang) * rad;
    if (i === 0) cctx.moveTo(x, y); else cctx.lineTo(x, y);
  }
  cctx.closePath();
  cctx.fillStyle = color;
  cctx.shadowColor = color;
  cctx.shadowBlur = 12;
  cctx.fill();
  cctx.shadowBlur = 0;
  cctx.lineWidth = 1.2;
  cctx.strokeStyle = "rgba(11,11,16,0.7)";
  cctx.stroke();
  cctx.restore();
}

// rAF loop: ease the operating dot toward its target, redraw while moving
let raf = null;
function animate() {
  const dx = dot.tx - dot.x, dy = dot.ty - dot.y;
  dot.x += dx * 0.22;
  dot.y += dy * 0.22;
  drawCurve();
  if (Math.abs(dx) > 0.0006 || Math.abs(dy) > 0.0006) {
    raf = requestAnimationFrame(animate);
  } else {
    dot.x = dot.tx; dot.y = dot.ty;
    drawCurve();
    raf = null;
  }
}
function setTarget(recall, precision) {
  dot.tx = recall; dot.ty = precision;
  if (raf === null) raf = requestAnimationFrame(animate);
}

/* =================================================================== *
 *  DOM wiring                                                         *
 * =================================================================== */
const thr = document.getElementById("thr");
const thrVal = document.getElementById("thrVal");
const showStar = document.getElementById("showStar");
const tradeEl = document.getElementById("trade");
const el = {
  prec: document.getElementById("rPrec"),
  rec: document.getElementById("rRec"),
  f1: document.getElementById("rF1"),
  tp: document.getElementById("rTP"),
  fp: document.getElementById("rFP"),
  fn: document.getElementById("rFN"),
};

let prevPrec = null, prevRec = null;

function update(opts) {
  const t = Math.max(0, Math.min(1, parseFloat(thr.value) || 0));
  thrVal.textContent = t.toFixed(2);
  const s = statsAt(t);
  const pPlot = precForPlot(s);

  el.prec.textContent = pPlot.toFixed(2);
  el.rec.textContent = s.recall.toFixed(2);
  el.f1.textContent = s.f1.toFixed(2);
  el.tp.textContent = String(s.tp);
  el.fp.textContent = String(s.fp);
  el.fn.textContent = String(s.fn);

  // highlight F1 readout gold when we're sitting (near) the F1 peak
  el.f1.className = (best && Math.abs(t - best.thr) < 1e-9) ? "v atbest" : "v";

  // dynamic inverse-relationship readout vs the previous threshold
  if (prevPrec !== null && (opts && opts.live)) {
    if (t > prevThr + 1e-6) {
      tradeEl.innerHTML = "↑ threshold → precision ↑, recall ↓";
    } else if (t < prevThr - 1e-6) {
      tradeEl.innerHTML = "↓ threshold → precision ↓, recall ↑";
    }
  } else {
    tradeEl.innerHTML = "↑ threshold → precision ↑, recall ↓";
  }
  prevPrec = pPlot; prevRec = s.recall; prevThr = t;

  drawStrip(t);
  setTarget(s.recall, pPlot);
}
let prevThr = parseFloat(thr.value) || 0.5;

/* ---------- Jump to best F1 (eases the threshold to the F1-max point) ------ */
let jumpAnim = null;
function jumpToBestF1() {
  if (best == null) return;
  if (jumpAnim) cancelAnimationFrame(jumpAnim);
  const t0 = parseFloat(thr.value) || 0;
  const t1 = best.thr;
  const dur = 650;
  const start = performance.now();
  function frame(now) {
    const k = Math.min((now - start) / dur, 1);
    const e = 1 - Math.pow(1 - k, 3);          // ease-out cubic
    thr.value = String(t0 + (t1 - t0) * e);
    update({ live: false });
    if (k < 1) {
      jumpAnim = requestAnimationFrame(frame);
    } else {
      thr.value = String(t1);
      update({ live: false });
      tradeEl.innerHTML = "★ at the F1 peak — best balance of precision &amp; recall";
      jumpAnim = null;
    }
  }
  jumpAnim = requestAnimationFrame(frame);
}

/* ---------- Drag the threshold line directly on the strip ------------------ */
let dragging = false;
function pxFromEvent(evt) {
  const rect = strip.getBoundingClientRect();
  const scaleX = strip.width / rect.width;
  return (evt.clientX - rect.left) * scaleX;
}
function dragTo(evt) {
  const s = Math.max(0, Math.min(1, stripScoreFromPx(pxFromEvent(evt))));
  thr.value = String(s);
  update({ live: true });
}
strip.addEventListener("pointerdown", (e) => {
  if (jumpAnim) { cancelAnimationFrame(jumpAnim); jumpAnim = null; }
  dragging = true;
  strip.classList.add("dragging");
  strip.setPointerCapture(e.pointerId);
  dragTo(e);
});
strip.addEventListener("pointermove", (e) => { if (dragging) dragTo(e); });
function endDrag() { dragging = false; strip.classList.remove("dragging"); }
strip.addEventListener("pointerup", endDrag);
strip.addEventListener("pointercancel", endDrag);

/* ---------- Slider + buttons ---------------------------------------------- */
thr.addEventListener("input", () => {
  if (jumpAnim) { cancelAnimationFrame(jumpAnim); jumpAnim = null; }
  update({ live: true });
});
document.getElementById("bestF1").addEventListener("click", jumpToBestF1);
document.getElementById("reset").addEventListener("click", () => {
  if (jumpAnim) { cancelAnimationFrame(jumpAnim); jumpAnim = null; }
  thr.value = "0.50";
  update({ live: false });
});
document.getElementById("reseed").addEventListener("click", () => {
  if (jumpAnim) { cancelAnimationFrame(jumpAnim); jumpAnim = null; }
  generate((Math.floor(Math.random() * 99999) + 1) >>> 0);
  buildCurve();
  // snap the operating dot onto the new curve so it doesn't fly across
  const s = statsAt(parseFloat(thr.value) || 0.5);
  dot.x = s.recall; dot.y = precForPlot(s);
  update({ live: false });
});
showStar.addEventListener("change", drawCurve);

/* ---------- Init ----------------------------------------------------------- */
generate(SEED0);
buildCurve();
update({ live: false });

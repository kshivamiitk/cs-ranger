# Train/Test Split

> The only honest way to know if your model works on new data is to hide some data from it during training — then test on exactly that held-out slice, once.

## What is this?

A train/test split takes your dataset and chops it into two parts: a **training set** the model learns from, and a **test set** the model never sees during training. You fit on the training set, then score on the test set. Because those test rows were hidden, the score estimates how the model will do on genuinely new data — its **generalization**.

A common split is 80% train / 20% test. In scikit-learn, `train_test_split` does it in one line, shuffling the rows first so the split isn't accidentally biased by row order. Passing `random_state` makes the shuffle reproducible: same seed, same split, every run.

The test set is sacred. You touch it exactly **once**, at the very end, to report a final honest number. Everything else — picking models, tuning hyperparameters — happens using the training data only.

## Why do we need it?

A model can score perfectly on the data it trained on and still be useless. The extreme case is a model that simply memorizes every training row: 100% accuracy on training, and complete failure on anything new. Scoring on the training data tells you how well the model *memorized*, not how well it *generalizes* — and generalization is the only thing that matters in the real world.

The test set breaks that illusion. By scoring on rows the model has never seen, you simulate "new data" before deploying. If the test score is good, you have evidence the model learned real patterns. If the training score is high but the test score is low, you've caught overfitting *before* it embarrasses you in production.

`stratify` matters for classification: a random split might dump most of a rare class into the training set, leaving the test set unrepresentative. `stratify=y` forces both sets to keep the same class proportions as the full data.

## Where it's used in real ML

- **Every supervised project**, as the first thing you do after loading data — split before you look too hard, so you never tune against the test set by accident.
- **Honest reporting** — the test score is the number you put in the README, the slide, or the model card.
- **Classification with imbalance** — `stratify=y` keeps rare classes (fraud, disease, churn) present in both sets.
- **Alongside cross-validation** — teams often split off a test set first, do all model selection with cross-validation on the training portion, then score the chosen model on the untouched test set once.

## What breaks if you ignore it

- **You ship overfitting.** Score only on training data and a memorizing model looks perfect — until real users hit it and accuracy collapses.
- **You fool yourself by tuning on test.** Peek at the test set while choosing models or hyperparameters and you've effectively trained on it. The test score stops being honest and becomes optimistic.
- **Unreproducible results.** Skip `random_state` and every run gives a different split and a different score — you can't compare experiments or reproduce a bug.
- **A misleading score on imbalanced data.** Without `stratify`, an unlucky split can leave almost none of the rare class in the test set, making accuracy meaningless.

## Mental model

Think of a final exam. All term you study from the textbook and practice problems — that's the **training set**. The exam contains questions you haven't seen before — that's the **test set**. If the teacher handed out the exam answers in advance and you "studied" those, your A would be a lie: it measures cheating, not learning.

```text
   full dataset (10 rows)
   ┌───────────────────────────────────────────┐
   │ ● ● ● ● ● ● ● ● ● ●                         │
   └───────────────────────────────────────────┘
                 │  shuffle, then split 80/20
                 ▼
   TRAIN (8 rows)              TEST (2 rows)
   ┌─────────────────────┐     ┌───────────┐
   │ ● ● ● ● ● ● ● ●      │     │ ● ●       │
   │ model studies these │     │ hidden    │
   └─────────────────────┘     │ until the │
                               │ very end  │
                               └───────────┘
```

The test rows are the exam questions: locked away until the one moment you grade yourself.

## Example 1 — Tiny toy example

Split 10 rows 80/20 and look at the shapes.

```text
X has 10 rows, 1 feature each.   y has 10 labels.

train_test_split(test_size=0.2)  ->

   X_train: 8 rows    y_train: 8 labels
   X_test:  2 rows    y_test:  2 labels
```

That's it: 80% (8 rows) for the model to learn from, 20% (2 rows) hidden away to grade it. With `random_state` fixed, you'd get the *same* 8 rows in training every time you run it — reproducible. The shapes confirm nothing got lost: `8 + 2 == 10`.

## Example 2 — Practical ML example

You have a realistic classification dataset — say wine samples with several chemical measurements and a class label. You want a trustworthy estimate of accuracy.

Split it 75/25 with `stratify=y` so each wine class appears in both sets in the right proportion, and set `random_state` for reproducibility. Fit a model (wrapped in a pipeline so scaling happens correctly) on the training set. Then — and only then — score on the test set. That single number is your **honest accuracy**: what you'd expect on new wine samples. Resist the urge to re-run with different seeds and report the best one; that's just tuning on the test set in disguise.

## Python code example

```python
import numpy as np
from sklearn.datasets import load_wine
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

# ---------- Example 1: tiny toy split, just look at the shapes ----------
X_toy = np.arange(10).reshape(10, 1)      # 10 rows, 1 feature: [[0],[1],...,[9]]
y_toy = np.array([0, 1] * 5)              # 10 labels, balanced

X_tr, X_te, y_tr, y_te = train_test_split(
    X_toy, y_toy, test_size=0.2, random_state=42)
print("toy train rows:", X_tr.shape[0], " toy test rows:", X_te.shape[0])
print("check 8 + 2 == 10:", X_tr.shape[0] + X_te.shape[0])

# ---------- Example 2: realistic dataset, honest evaluation ----------
X, y = load_wine(return_X_y=True)         # 178 samples, 13 features, 3 classes
print("\nfull dataset:", X.shape, " classes:", np.bincount(y))

# Split FIRST. stratify=y keeps class balance; random_state makes it reproducible.
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=0, stratify=y)
print("train:", X_train.shape[0], "rows   test:", X_test.shape[0], "rows")

# Pipeline (scale -> model) so scaling is fit on TRAIN only, never the test set.
model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=2000))
model.fit(X_train, y_train)               # the model only ever sees TRAIN

# The training score is optimistic by nature -- the model already saw these rows.
print("\ntraining accuracy (optimistic):", round(model.score(X_train, y_train), 3))

# Touch the test set ONCE, at the end. THIS is the number you report.
print("test accuracy (HONEST):        ", round(model.score(X_test, y_test), 3))
```

Expected output (approximate):

```text
toy train rows: 8  toy test rows: 2
check 8 + 2 == 10: 10

full dataset: (178, 13)  classes: [59 71 48]
train: 133 rows   test: 45 rows

training accuracy (optimistic): 1.0
test accuracy (HONEST):         0.978
```

The training accuracy of `1.0` is *not* the achievement it looks like — the model has seen those rows. The honest claim is the test accuracy: about 97.8% on data it never trained on. That gap (here small, often larger) is exactly what the test set exists to reveal.

## Common mistakes

- **Tuning on the test set.** Choosing models or hyperparameters by their test score quietly turns the test set into training data. Use cross-validation on the *training* set for all decisions, and save the test set for one final check.
- **Forgetting `random_state`.** Without it, every run gives a different split and a different score, so results aren't reproducible or comparable.
- **Skipping `stratify` on imbalanced classes.** A random split can leave a rare class barely present in test, making the score misleading. Use `stratify=y` for classification.
- **Reporting the training score as performance.** It measures memorization, not generalization. Always report the held-out test score.
- **Preprocessing before the split.** Scaling or encoding on the full dataset leaks test statistics into training. Split first, and put preprocessing inside a pipeline so it fits on training data only.

## Before you continue

- [ ] I can explain why scoring on training data overstates how good a model is.
- [ ] I can use `train_test_split` with `test_size`, `random_state`, and `stratify`.
- [ ] I can read the train/test row counts and confirm they add up to the full dataset.
- [ ] I understand why the test set must be touched only once, at the very end.
- [ ] I can explain why tuning against the test set makes its score dishonest.

# Solved — Explaining False Positives and False Negatives

> Two systems, two opposite fears. A spam filter dreads deleting your job offer; a cancer screen dreads telling a sick patient they're fine. Same four-box confusion matrix, completely different threshold.

## Problem statement

We need to define the four outcomes of a binary classifier — **TP, FP, FN, TN** — and, more importantly, attach a *human cost* to each, because "an error" is not one thing. We do this on two contrasting cases: a **spam filter** (positive = "spam") where a false positive (real email sent to junk) is the painful error, and a **medical screening test** (positive = "disease") where a false negative (telling a sick patient they're healthy) is the painful error. We then build a confusion matrix from raw predictions and read precision and recall straight off it, and show how moving the threshold shifts the balance between the two error types.

## Data sample

Inline labels and scores for both cases (10 items each), so it runs offline. Each row is one item with its true label and the model's positive-class score.

Spam filter — positive class = spam (1):

| email | true (1=spam) | score |
|-------|---------------|-------|
| e1 "win a free iphone" | 1 | 0.95 |
| e2 "meeting at 3pm"    | 0 | 0.10 |
| e3 "cheap meds now"    | 1 | 0.88 |
| e4 "your invoice"      | 0 | 0.30 |
| e5 "re: project"       | 0 | 0.08 |
| e6 "act now!!!"        | 1 | 0.72 |
| e7 "lunch?"            | 0 | 0.05 |
| e8 "URGENT wire funds" | 1 | 0.40 |
| e9 "weekly newsletter" | 0 | 0.55 |
| e10 "grandma photos"   | 0 | 0.12 |

Medical screen — positive class = disease (1): we reuse the same 10 scores but with disease as the positive class, and read the costs the other way around.

## Why this problem matters

A confusion matrix is the source of *every* classification metric, and the only reason to ever look at one is to reason about which mistake hurts. Telling a stakeholder "the model is 90% accurate" is meaningless until you say *which* 10% it gets wrong. In spam, a single false positive (a lost job offer) is far worse than a few false negatives (spam in your inbox), so you set a **high** threshold — flag only when you're very sure. In cancer screening, a false negative (a missed tumor) can be fatal while a false positive only triggers a follow-up test, so you set a **low** threshold — flag on the slightest suspicion. The math is identical; the threshold is a values judgment.

## Step-by-step reasoning

1. **Pin the positive class first.** "Positive" = the thing the detector is *for* (spam; disease). TP/FP/FN/TN are all defined relative to it.
2. **Name the four boxes plainly.**
   - **TP** — flagged and really is positive (spam caught; disease detected). A win.
   - **TN** — not flagged and really is negative (real email delivered; healthy patient cleared). A win.
   - **FP** — flagged but actually negative — a **false alarm** (good email junked; healthy patient scared).
   - **FN** — not flagged but actually positive — a **miss** (spam reaches inbox; tumor goes undetected).
3. **Attach the human cost.** Spam: FP ≫ FN (losing real mail is worse than seeing junk). Medical: FN ≫ FP (missing disease is worse than an extra test). The *same* confusion matrix gets read with opposite priorities.
4. **Read precision and recall off the matrix.** Precision = `TP / (TP + FP)` controls false alarms; recall = `TP / (TP + FN)` controls misses. Spam wants **high precision**; medical wants **high recall**.
5. **Move the threshold to shift the balance.** Raise it → fewer flags → FP↓, FN↑ (precision up, recall down) → good for spam. Lower it → more flags → FN↓, FP↑ (recall up, precision down) → good for medical.
6. **Pick the threshold from the costs, never the default 0.5.** The "right" threshold is wherever your application's costlier error is acceptably rare.

## Python solution

```python
import numpy as np
from sklearn.metrics import confusion_matrix, precision_score, recall_score

# Same 10 scores; true labels with POSITIVE = spam (and later = disease).
scores = np.array([0.95, 0.10, 0.88, 0.30, 0.08, 0.72, 0.05, 0.40, 0.55, 0.12])
y_true = np.array([   1,    0,    1,    0,    0,    1,    0,    1,    0,    0])

def matrix_and_metrics(y_true, scores, thr, label):
    y_pred = (scores >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    prec = precision_score(y_true, y_pred, zero_division=0)
    rec  = recall_score(y_true, y_pred, zero_division=0)
    print(f"--- {label}  (threshold={thr}) ---")
    print(f"          Pred 0   Pred 1")
    print(f"Actual 0  TN={tn:<4}  FP={fp:<4}  <- false alarms")
    print(f"Actual 1  FN={fn:<4}  TP={tp:<4}  <- {fn} miss(es)")
    print(f"precision={prec:.2f}  recall={rec:.2f}\n")
    return tp, fp, fn, tn
```

```python
# --- SPAM FILTER: a false positive (junking real mail) is the painful error.
#     Use a HIGH threshold so we only flag when very confident -> high precision.
matrix_and_metrics(y_true, scores, thr=0.60, label="SPAM, high threshold")

# --- MEDICAL SCREEN: a false negative (missed disease) is the painful error.
#     Reuse the same scores as P(disease); use a LOW threshold -> high recall.
matrix_and_metrics(y_true, scores, thr=0.35, label="MEDICAL, low threshold")
```

```python
# --- Watch the trade-off as the threshold sweeps: FP/FN swap roles ---
print("thr   TP FP FN TN  precision recall")
for thr in (0.25, 0.50, 0.75):
    yp = (scores >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, yp, labels=[0, 1]).ravel()
    p = tp / (tp + fp) if (tp + fp) else 0.0
    r = tp / (tp + fn) if (tp + fn) else 0.0
    print(f"{thr:0.2f}  {tp:>2} {fp:>2} {fn:>2} {tn:>2}    {p:0.2f}     {r:0.2f}")
```

## Expected output

Running it prints roughly:

```
--- SPAM, high threshold  (threshold=0.6) ---
          Pred 0   Pred 1
Actual 0  TN=6     FP=0     <- false alarms
Actual 1  FN=1     TP=3     <- 1 miss(es)
precision=1.00  recall=0.75

--- MEDICAL, low threshold  (threshold=0.35) ---
          Pred 0   Pred 1
Actual 0  TN=5     FP=1     <- false alarms
Actual 1  FN=0     TP=4     <- 0 miss(es)
precision=0.80  recall=1.00

thr   TP FP FN TN  precision recall
0.25   4  2  0  4    0.67     1.00
0.50   3  1  1  5    0.75     0.75
0.75   2  0  2  6    1.00     0.50
```

How to read it: at the **high** spam threshold (0.60), **precision = 1.00** — zero false positives, so no real email is junked — at the cost of recall 0.75 (one spam slips through, which is merely annoying). Exactly the trade a spam filter wants. At the **low** medical threshold (0.35), **recall = 1.00** — zero false negatives, no disease missed — at the cost of one false positive (an extra follow-up test), which is the trade a screening program wants. The sweep table makes the mechanism explicit: as the threshold climbs 0.25 → 0.50 → 0.75, **FP falls and FN rises**, so precision climbs while recall drops. There is no threshold that is best for both applications — the cost of each error type decides.

## Common mistakes

- **Reading the confusion matrix axes backward.** sklearn's `confusion_matrix` rows are *actual*, columns *predicted*, ordered `[0, 1]`, so `.ravel()` gives `tn, fp, fn, tp`. Always pass `labels=[0, 1]` and double-check.
- **Swapping precision and recall.** Precision = "of my flags, how many were right" (false-alarm control); recall = "of the real positives, how many I caught" (miss control). Mixing them flips your threshold decision.
- **Forgetting to define the positive class.** If "positive" is ambiguous, every count is ambiguous. State it before computing anything.
- **Using accuracy to choose between spam and medical thresholds.** Accuracy can't see that an FP and an FN cost wildly different amounts. Reason in TP/FP/FN/TN and their costs.
- **Leaving the threshold at 0.5 for both.** 0.5 happens to be wrong for *both* applications here — spam wants higher, medical wants lower.

## Extension challenge

1. Define an explicit cost: spam FP=10, FN=1; medical FP=1, FN=50. Sweep the threshold and pick the **minimum-expected-cost** threshold for each application — confirm they land far apart.
2. Add a third "fraud review queue" case where FP and FN cost roughly the same, and show F1 (which weights them equally) is the natural metric there.
3. Plot precision and recall vs. threshold for these 10 points and mark where each application's chosen threshold sits on the two curves.

## Matching animation

Use the module's existing **"Confusion Matrix Explorer"** (`07 Confusion Matrix Explorer`) to drag the threshold and watch each example move between the TP/FP/FN/TN cells, then open **"Precision vs Recall Threshold Slider"** (`50 Precision vs Recall Threshold Slider`) to see the same threshold sweep traced as a point gliding along the precision–recall curve.

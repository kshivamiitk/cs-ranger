# Lab — Evaluate a Model Honestly

## Objective

You'll evaluate classifiers on an **imbalanced** dataset the way a professional does — refusing to be fooled by a shiny accuracy number. You'll train two models, compare them on accuracy *and* precision/recall/F1/ROC-AUC, read a confusion matrix, and confirm the verdict with cross-validation. By the end you'll be able to look at any classification result and answer the real question: *is this model actually useful, or just lucky on the majority class?*

## Dataset

A synthetic binary dataset from `make_classification`, deliberately **imbalanced** so accuracy becomes misleading:

- 3,000 samples, 12 features (6 informative).
- Class weights `[0.92, 0.08]` → only ~8% positives. Think rare fraud, rare disease, rare churn.
- The positive class is the one we actually care about catching. A model can score ~92% accuracy by predicting "negative" for everyone — and be worthless. We'll prove it.

## Steps

**Step 1 — build the imbalanced data and split with stratification.** Stratify so the rare class keeps its proportion in train and test.

```python
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split

X, y = make_classification(
    n_samples=3000, n_features=12, n_informative=6, n_redundant=2,
    weights=[0.92, 0.08], flip_y=0.01, random_state=42)
print("Overall positive rate:", round(y.mean(), 3))   # ~0.08

X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.3, random_state=42, stratify=y)
```

**Step 2 — establish a dumb baseline.** A `DummyClassifier` that always predicts the majority class shows the accuracy "floor" you must beat to be useful.

```python
from sklearn.dummy import DummyClassifier
from sklearn.metrics import accuracy_score

dummy = DummyClassifier(strategy="most_frequent").fit(X_tr, y_tr)
print("Dummy (always-negative) accuracy:", round(accuracy_score(y_te, dummy.predict(X_te)), 3))
# ~0.92 — high accuracy, zero positives caught.
```

**Step 3 — train two real classifiers.** Scale for logistic regression; the forest doesn't need it. Use `class_weight="balanced"` so the rare class isn't ignored.

```python
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier

logreg = make_pipeline(
    StandardScaler(),
    LogisticRegression(max_iter=2000, class_weight="balanced"))
forest = RandomForestClassifier(
    n_estimators=300, class_weight="balanced", random_state=42)

logreg.fit(X_tr, y_tr)
forest.fit(X_tr, y_tr)
```

**Step 4 — compare accuracy vs the metrics that matter.** Accuracy alone vs precision/recall/F1/ROC-AUC. ROC-AUC needs probabilities.

```python
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, roc_auc_score)

def report(name, model):
    pred = model.predict(X_te)
    proba = model.predict_proba(X_te)[:, 1]      # probability of the positive class
    print(f"\n=== {name} ===")
    print(f"accuracy : {accuracy_score(y_te, pred):.3f}")
    print(f"precision: {precision_score(y_te, pred):.3f}")
    print(f"recall   : {recall_score(y_te, pred):.3f}")
    print(f"f1       : {f1_score(y_te, pred):.3f}")
    print(f"roc_auc  : {roc_auc_score(y_te, proba):.3f}")

report("Logistic Regression", logreg)
report("Random Forest", forest)
```

**Step 5 — read the confusion matrix.** The four cells expose exactly *which* mistakes each model makes.

```python
from sklearn.metrics import confusion_matrix, classification_report

print("\nRandom Forest confusion matrix [[TN FP] [FN TP]]:")
print(confusion_matrix(y_te, forest.predict(X_te)))
print(classification_report(y_te, forest.predict(X_te), digits=3))
```

**Step 6 — confirm with cross-validation.** A single split can flatter; CV on F1 averages over folds for a trustworthy verdict.

```python
from sklearn.model_selection import cross_val_score, StratifiedKFold

cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
for name, model in [("LogReg", logreg), ("Forest", forest)]:
    f1s = cross_val_score(model, X, y, cv=cv, scoring="f1")
    aucs = cross_val_score(model, X, y, cv=cv, scoring="roc_auc")
    print(f"{name}: F1 {f1s.mean():.3f}+/-{f1s.std():.3f}   AUC {aucs.mean():.3f}+/-{aucs.std():.3f}")
```

## Expected output

- The **dummy** model scores ~0.92 accuracy while catching **zero** positives. That single fact is the whole lesson: 92% accuracy can mean a model that does literally nothing useful.
- Both real models will land near or slightly *below* the dummy on raw accuracy once `class_weight="balanced"` is on (because they now risk false positives to catch positives), yet they'll have **far higher recall and F1** for the positive class. That's the trade you *want*: giving up a little accuracy to actually catch the rare events.
- The **confusion matrix** makes it concrete — look at the FN cell (missed positives) and FP cell (false alarms). ROC-AUC (often ~0.93–0.97 here) confirms the models *rank* positives well above negatives even where the 0.5-threshold labels are imperfect.
- **Cross-validation** should show the random forest with comparable or higher F1/AUC and a small standard deviation, telling you the result is stable, not a one-split fluke.

The headline interpretation to write up: *"Accuracy said the do-nothing baseline was 92% 'good'. Precision, recall, F1, and ROC-AUC revealed that only the balanced models actually catch the rare positive class — which is the entire point of the project."*

## Extension challenge

1. **Threshold tuning for recall.** Take `forest.predict_proba(X_te)[:, 1]`, sweep thresholds from 0.1 to 0.5, and plot recall and precision vs threshold. Pick the threshold that gives recall ≥ 0.90 and report the precision you pay for it.
2. **Precision-recall curve.** Use `sklearn.metrics.precision_recall_curve` and `average_precision_score`. On imbalanced data, the PR curve is often more informative than ROC.
3. **Cost framing.** Suppose a missed positive (FN) costs $500 and a false alarm (FP) costs $20. Compute total cost at several thresholds and find the cost-minimizing threshold — the truly "best" model is the cheapest one, not the most accurate.

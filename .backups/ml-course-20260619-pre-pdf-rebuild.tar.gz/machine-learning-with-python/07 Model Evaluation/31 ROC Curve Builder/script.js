"use strict";

/* =========================================================================
   ROC Curve Builder
   - Seeded PRNG generates a labeled dataset (positives skewed high,
     negatives skewed low, with overlap so AUC lands ~0.8-0.92).
   - The ROC curve is the locus of (FPR, TPR) as the decision threshold
     sweeps from 1.0 down to 0.0. AUC is the trapezoidal area under it.
   - "Play sweep" animates the threshold high->low, revealing the curve.
   ========================================================================= */

(function () {
  /* ---------- DOM ---------- */
  const canvas = document.getElementById("roc");
  const ctx = canvas.getContext("2d");

  const playBtn = document.getElementById("play");
  const resetBtn = document.getElementById("reset");
  const reshuffleBtn = document.getElementById("reshuffle");
  const thrSlider = document.getElementById("thr");
  const thrVal = document.getElementById("thrVal");

  const aucEl = document.getElementById("auc");
  const tprEl = document.getElementById("tpr");
  const fprEl = document.getElementById("fpr");
  const tpfnEl = document.getElementById("tpfn");
  const fptnEl = document.getElementById("fptn");
  const nPosEl = document.getElementById("nPos");
  const nNegEl = document.getElementById("nNeg");

  /* ---------- colors (mirrors the CSS palette) ---------- */
  const COL = {
    bgGrid: "rgba(255,255,255,0.06)",
    axis: "rgba(255,255,255,0.30)",
    text: "#94a3b8",
    textBright: "#e2e8f0",
    chance: "rgba(148,163,184,0.45)",
    curve: "#a78bfa",
    fill: "rgba(167,139,250,0.14)",
    point: "#22d3ee",
    pos: "#22d3ee",
    neg: "#f87171",
  };

  /* ---------- seeded PRNG (mulberry32) ---------- */
  function mulberry32(seed) {
    let a = seed >>> 0;
    return function () {
      a |= 0;
      a = (a + 0x6d2b79f5) | 0;
      let t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ---------- canvas geometry ---------- */
  const W = canvas.width;
  const H = canvas.height;
  const PAD = { left: 64, right: 26, top: 26, bottom: 56 };
  const plot = {
    x0: PAD.left,
    y0: H - PAD.bottom, // bottom (FPR=0, TPR=0 baseline)
    x1: W - PAD.right,
    y1: PAD.top,
  };
  const plotW = plot.x1 - plot.x0;
  const plotH = plot.y0 - plot.y1;

  // map rate [0,1] -> canvas pixels
  const px = (fpr) => plot.x0 + fpr * plotW;
  const py = (tpr) => plot.y0 - tpr * plotH;

  /* ---------- state ---------- */
  let seed = 0x51a7c0de;
  let data = []; // [{label: 1|0, score}]
  let P = 0;
  let N = 0;
  let rocPoints = []; // [{thr, fpr, tpr}] from thr=1 (origin-ish) down to 0
  let fullAUC = 0;
  let threshold = 1.0;
  let animating = false;
  let animThr = 1.0;
  let rafId = null;

  /* ---------- dataset generation ----------
     ~40 points. Positives drawn from a high-mean Gaussian, negatives from a
     low-mean Gaussian, both clamped to [0,1]. The overlap keeps AUC < 1. */
  function gaussian(rng) {
    // Box-Muller
    let u = 0;
    let v = 0;
    while (u === 0) u = rng();
    while (v === 0) v = rng();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }
  const clamp01 = (x) => (x < 0 ? 0 : x > 1 ? 1 : x);

  function generate(s) {
    const rng = mulberry32(s);
    const n = 40;
    const pts = [];
    P = 0;
    N = 0;
    for (let i = 0; i < n; i++) {
      // ~55% positive so both classes are well represented
      const isPos = rng() < 0.55;
      let score;
      if (isPos) {
        score = clamp01(0.66 + gaussian(rng) * 0.17);
        P++;
      } else {
        score = clamp01(0.34 + gaussian(rng) * 0.17);
        N++;
      }
      pts.push({ label: isPos ? 1 : 0, score });
    }
    // Guard against a degenerate all-one-class draw.
    if (P === 0 || N === 0) {
      return generate((s * 1103515245 + 12345) >>> 0);
    }
    return pts;
  }

  /* ---------- confusion counts at a threshold (predict pos if score >= thr) */
  function confusionAt(thr) {
    let tp = 0;
    let fp = 0;
    let fn = 0;
    let tn = 0;
    for (let i = 0; i < data.length; i++) {
      const d = data[i];
      const predPos = d.score >= thr;
      if (d.label === 1) {
        if (predPos) tp++;
        else fn++;
      } else {
        if (predPos) fp++;
        else tn++;
      }
    }
    return { tp, fp, fn, tn };
  }

  /* ---------- build the full ROC curve ----------
     The curve is the set of (FPR, TPR) reached as the threshold descends
     through every distinct score. We start at threshold just above the max
     score (nothing flagged -> point (0,0)) and end at threshold 0 (everything
     flagged -> (1,1)). */
  function buildROC() {
    const scores = data.map((d) => d.score);
    const uniqueDesc = Array.from(new Set(scores)).sort((a, b) => b - a);

    const pts = [{ thr: 1.0001, fpr: 0, tpr: 0 }]; // origin: flag nothing
    for (const thr of uniqueDesc) {
      const c = confusionAt(thr);
      const tpr = P > 0 ? c.tp / P : 0;
      const fpr = N > 0 ? c.fp / N : 0;
      pts.push({ thr, fpr, tpr });
    }
    // Ensure the curve closes at (1,1) (threshold 0 flags everything).
    const last = pts[pts.length - 1];
    if (last.fpr < 1 || last.tpr < 1) {
      pts.push({ thr: 0, fpr: 1, tpr: 1 });
    }
    rocPoints = pts;
    fullAUC = trapezoidAUC(pts);
  }

  /* ---------- AUC via trapezoidal rule over (FPR, TPR) ----------
     Points are ordered by descending threshold => FPR is non-decreasing,
     so we integrate TPR over FPR left to right. */
  function trapezoidAUC(pts) {
    let area = 0;
    for (let i = 1; i < pts.length; i++) {
      const dx = pts[i].fpr - pts[i - 1].fpr;
      const avgY = (pts[i].tpr + pts[i - 1].tpr) / 2;
      area += dx * avgY;
    }
    return area;
  }

  /* ---------- ROC points whose threshold >= current (the "built so far") */
  function builtPoints(thr) {
    // rocPoints is descending in threshold; include points with thr >= current.
    const out = [];
    for (const p of rocPoints) {
      if (p.thr >= thr - 1e-9) out.push(p);
    }
    // Append the exact current operating point so the drawn line reaches the dot.
    const cur = currentOperatingPoint(thr);
    out.push({ thr, fpr: cur.fpr, tpr: cur.tpr });
    return out;
  }

  function currentOperatingPoint(thr) {
    const c = confusionAt(thr);
    const tpr = P > 0 ? c.tp / P : 0;
    const fpr = N > 0 ? c.fp / N : 0;
    return { ...c, tpr, fpr };
  }

  /* ============================ drawing ============================ */
  function draw(thr) {
    ctx.clearRect(0, 0, W, H);

    drawGrid();
    drawChanceLine();

    // Reveal only the portion of the curve built down to the current threshold.
    const shown = builtPoints(thr);
    drawCurve(shown);

    // Faint preview of the remaining (not-yet-swept) curve so the shape hints.
    drawCurveGhost(thr);

    const cur = currentOperatingPoint(thr);
    drawOperatingPoint(cur);

    drawAxesLabels();
    updateReadout(cur, thr);
  }

  function drawGrid() {
    ctx.save();
    ctx.lineWidth = 1;
    ctx.font = "11px ui-monospace, Menlo, monospace";
    ctx.fillStyle = COL.text;
    for (let i = 0; i <= 10; i++) {
      const t = i / 10;
      // vertical (FPR)
      ctx.strokeStyle = COL.bgGrid;
      ctx.beginPath();
      ctx.moveTo(px(t), plot.y1);
      ctx.lineTo(px(t), plot.y0);
      ctx.stroke();
      // horizontal (TPR)
      ctx.beginPath();
      ctx.moveTo(plot.x0, py(t));
      ctx.lineTo(plot.x1, py(t));
      ctx.stroke();

      if (i % 2 === 0) {
        ctx.textAlign = "center";
        ctx.textBaseline = "top";
        ctx.fillText(t.toFixed(1), px(t), plot.y0 + 7);
        ctx.textAlign = "right";
        ctx.textBaseline = "middle";
        ctx.fillText(t.toFixed(1), plot.x0 - 8, py(t));
      }
    }
    // plot frame
    ctx.strokeStyle = COL.axis;
    ctx.strokeRect(plot.x0, plot.y1, plotW, plotH);
    ctx.restore();
  }

  function drawChanceLine() {
    ctx.save();
    ctx.strokeStyle = COL.chance;
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 6]);
    ctx.beginPath();
    ctx.moveTo(px(0), py(0));
    ctx.lineTo(px(1), py(1));
    ctx.stroke();
    ctx.setLineDash([]);
    // "chance (AUC 0.5)" label along the diagonal
    ctx.fillStyle = COL.chance;
    ctx.font = "italic 11px ui-monospace, Menlo, monospace";
    ctx.textAlign = "left";
    ctx.textBaseline = "bottom";
    ctx.save();
    ctx.translate(px(0.62), py(0.62));
    ctx.rotate(-Math.atan2(plotH, plotW));
    ctx.fillText("chance (AUC 0.5)", 6, -4);
    ctx.restore();
    ctx.restore();
  }

  function drawCurveGhost(thr) {
    // The not-yet-revealed remainder, very faint.
    const rest = rocPoints.filter((p) => p.thr < thr - 1e-9);
    if (rest.length < 1) return;
    const cur = currentOperatingPoint(thr);
    const seq = [{ fpr: cur.fpr, tpr: cur.tpr }, ...rest];
    ctx.save();
    ctx.strokeStyle = "rgba(167,139,250,0.18)";
    ctx.lineWidth = 1.5;
    ctx.setLineDash([3, 4]);
    ctx.beginPath();
    ctx.moveTo(px(seq[0].fpr), py(seq[0].tpr));
    for (let i = 1; i < seq.length; i++) ctx.lineTo(px(seq[i].fpr), py(seq[i].tpr));
    ctx.stroke();
    ctx.setLineDash([]);
    ctx.restore();
  }

  function drawCurve(pts) {
    if (pts.length < 2) {
      // still draw the single origin dot
      if (pts.length === 1) {
        ctx.save();
        ctx.fillStyle = COL.curve;
        ctx.beginPath();
        ctx.arc(px(pts[0].fpr), py(pts[0].tpr), 2.5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
      return;
    }

    // shaded area under the revealed curve
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(px(pts[0].fpr), py(0));
    for (const p of pts) ctx.lineTo(px(p.fpr), py(p.tpr));
    ctx.lineTo(px(pts[pts.length - 1].fpr), py(0));
    ctx.closePath();
    ctx.fillStyle = COL.fill;
    ctx.fill();
    ctx.restore();

    // the curve itself (step-like, drawn as connected segments)
    ctx.save();
    ctx.strokeStyle = COL.curve;
    ctx.lineWidth = 2.5;
    ctx.lineJoin = "round";
    ctx.lineCap = "round";
    ctx.beginPath();
    ctx.moveTo(px(pts[0].fpr), py(pts[0].tpr));
    for (let i = 1; i < pts.length; i++) ctx.lineTo(px(pts[i].fpr), py(pts[i].tpr));
    ctx.stroke();

    // small vertex markers on the realized threshold points
    ctx.fillStyle = COL.curve;
    for (const p of pts) {
      ctx.beginPath();
      ctx.arc(px(p.fpr), py(p.tpr), 2.2, 0, Math.PI * 2);
      ctx.fill();
    }
    ctx.restore();
  }

  function drawOperatingPoint(cur) {
    const x = px(cur.fpr);
    const y = py(cur.tpr);
    ctx.save();
    // glow
    ctx.shadowColor = "rgba(34,211,238,0.8)";
    ctx.shadowBlur = 14;
    ctx.fillStyle = COL.point;
    ctx.beginPath();
    ctx.arc(x, y, 6.5, 0, Math.PI * 2);
    ctx.fill();
    ctx.shadowBlur = 0;
    ctx.strokeStyle = "#fff";
    ctx.lineWidth = 2;
    ctx.stroke();
    ctx.restore();
  }

  function drawAxesLabels() {
    ctx.save();
    ctx.fillStyle = COL.textBright;
    ctx.font = "600 13px " + getFont();
    // x label
    ctx.textAlign = "center";
    ctx.textBaseline = "bottom";
    ctx.fillText("FPR", (plot.x0 + plot.x1) / 2, H - 6);
    // y label (rotated)
    ctx.translate(16, (plot.y0 + plot.y1) / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textBaseline = "top";
    ctx.fillText("TPR (recall)", 0, 0);
    ctx.restore();
  }

  function getFont() {
    return 'Inter, system-ui, -apple-system, "Segoe UI", Roboto, sans-serif';
  }

  /* ---------- readout ---------- */
  function updateReadout(cur, thr) {
    thrVal.textContent = thr.toFixed(2);
    tprEl.textContent = cur.tpr.toFixed(2);
    fprEl.textContent = cur.fpr.toFixed(2);
    tpfnEl.textContent = cur.tp + " / " + cur.fn;
    fptnEl.textContent = cur.fp + " / " + cur.tn;
    aucEl.textContent = fullAUC.toFixed(3);
    nPosEl.textContent = String(P);
    nNegEl.textContent = String(N);
  }

  /* ============================ interaction ============================ */
  function setThreshold(t, fromSlider) {
    threshold = Math.max(0, Math.min(1, t));
    if (!fromSlider) thrSlider.value = threshold.toFixed(2);
    draw(threshold);
  }

  function stopAnim() {
    if (rafId !== null) cancelAnimationFrame(rafId);
    rafId = null;
    animating = false;
    playBtn.textContent = "▶ Play sweep";
  }

  function playSweep() {
    if (animating) {
      stopAnim();
      return;
    }
    // If we're at (or near) the bottom, restart from the top.
    if (threshold <= 0.001) threshold = 1.0;
    animating = true;
    animThr = threshold;
    playBtn.textContent = "❚❚ Pause";

    const speed = 0.0075; // threshold units per frame (~133 frames over full sweep)
    const step = () => {
      animThr -= speed;
      if (animThr <= 0) {
        animThr = 0;
        setThreshold(0, false);
        stopAnim();
        return;
      }
      setThreshold(animThr, false);
      rafId = requestAnimationFrame(step);
    };
    rafId = requestAnimationFrame(step);
  }

  function reset() {
    stopAnim();
    setThreshold(1.0, false);
  }

  function reshuffle() {
    stopAnim();
    // New seed derived deterministically so behavior is reproducible per click.
    seed = (Math.imul(seed, 1597334677) + 0x9e3779b9) >>> 0;
    init();
  }

  function init() {
    data = generate(seed);
    buildROC();
    setThreshold(1.0, false);
  }

  /* ---------- wiring ---------- */
  thrSlider.addEventListener("input", () => {
    if (animating) stopAnim();
    setThreshold(parseFloat(thrSlider.value), true);
  });
  playBtn.addEventListener("click", playSweep);
  resetBtn.addEventListener("click", reset);
  reshuffleBtn.addEventListener("click", reshuffle);

  init();
})();

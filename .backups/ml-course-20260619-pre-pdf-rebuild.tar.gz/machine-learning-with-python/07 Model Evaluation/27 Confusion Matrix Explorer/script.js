"use strict";

// ============================================================================
//  Confusion Matrix Explorer
//  ~40 examples, each with a true label (0/1) and a model score (0..1).
//  A threshold slider splits "predicted positive" (score >= threshold) from
//  "predicted negative". We compute TP/FP/FN/TN, accuracy, precision, recall,
//  F1 live, color a 2x2 matrix, and draw the examples on a score axis.
// ============================================================================

const N = 40;
const COLORS = { pos: "#22d3ee", neg: "#94a3b8" };

// ---------- Seeded PRNG ----------
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Build examples: positives tend to score high, negatives low, but with overlap,
// so the threshold genuinely trades precision against recall (a realistic classifier).
let examples = [];
function generate(seed) {
  const rand = mulberry32(seed >>> 0);
  examples = [];
  for (let i = 0; i < N; i++) {
    const isPos = rand() < 0.5;                 // roughly balanced true labels
    // beta-ish shaping: average of two uniforms pulls scores toward a center,
    // then bias positives upward and negatives downward, clamped to [0,1].
    let s = (rand() + rand()) / 2;
    s += isPos ? 0.22 : -0.22;
    s = Math.max(0.02, Math.min(0.98, s));
    examples.push({ score: s, label: isPos ? 1 : 0 });
  }
}

// ---------- Metrics ----------
function computeStats(thr) {
  let tp = 0, fp = 0, fn = 0, tn = 0;
  for (const e of examples) {
    const predPos = e.score >= thr;
    if (e.label === 1 && predPos) tp++;
    else if (e.label === 0 && predPos) fp++;
    else if (e.label === 1 && !predPos) fn++;
    else tn++;
  }
  const safe = (num, den) => (den === 0 ? 0 : num / den);   // guard divide-by-zero
  const precision = safe(tp, tp + fp);
  const recall = safe(tp, tp + fn);
  const f1 = (precision + recall === 0) ? 0 : 2 * precision * recall / (precision + recall);
  const accuracy = safe(tp + tn, N);
  return { tp, fp, fn, tn, precision, recall, f1, accuracy };
}

// ---------- Canvas: examples on a 0..1 score axis ----------
const strip = document.getElementById("strip");
const sctx = strip.getContext("2d");

function drawStrip(thr) {
  const W = strip.width, H = strip.height, padX = 24, padTop = 14, padBot = 26;
  sctx.clearRect(0, 0, W, H);
  const x0 = padX, x1 = W - padX;
  const xOf = (s) => x0 + s * (x1 - x0);
  const baseY = (H - padBot + padTop) / 2;

  // axis line + ticks
  sctx.strokeStyle = "rgba(255,255,255,0.12)";
  sctx.lineWidth = 1;
  sctx.beginPath(); sctx.moveTo(x0, H - padBot); sctx.lineTo(x1, H - padBot); sctx.stroke();
  sctx.fillStyle = "#94a3b8"; sctx.font = "11px system-ui, sans-serif"; sctx.textAlign = "center";
  for (let t = 0; t <= 1.0001; t += 0.25) {
    const x = xOf(t);
    sctx.beginPath(); sctx.moveTo(x, H - padBot); sctx.lineTo(x, H - padBot + 4); sctx.stroke();
    sctx.fillText(t.toFixed(2), x, H - padBot + 16);
  }

  // shade the "predicted positive" region (>= threshold)
  const tx = xOf(thr);
  sctx.fillStyle = "rgba(34, 211, 238, 0.07)";
  sctx.fillRect(tx, padTop, x1 - tx, (H - padBot) - padTop);

  // examples as dots; vertical jitter (deterministic) so overlapping scores are visible
  examples.forEach((e, i) => {
    const x = xOf(e.score);
    const jitter = ((i * 53) % 7 - 3) * 6;   // spread vertically a little
    const y = baseY + jitter;
    const predPos = e.score >= thr;
    const color = e.label === 1 ? COLORS.pos : COLORS.neg;
    sctx.beginPath();
    sctx.fillStyle = color;
    sctx.shadowColor = color; sctx.shadowBlur = e.label === 1 ? 8 : 2;
    sctx.arc(x, y, 6, 0, Math.PI * 2); sctx.fill();
    sctx.shadowBlur = 0;
    // ring marks the model's PREDICTION at this threshold (filled-white = predicted positive)
    sctx.lineWidth = 2;
    sctx.strokeStyle = predPos ? "#ffffff" : "rgba(255,255,255,0.18)";
    sctx.stroke();
  });

  // threshold marker line
  sctx.strokeStyle = "#a78bfa"; sctx.lineWidth = 2;
  sctx.beginPath(); sctx.moveTo(tx, padTop - 4); sctx.lineTo(tx, H - padBot); sctx.stroke();
  sctx.fillStyle = "#a78bfa"; sctx.textAlign = "center";
  sctx.fillText("threshold", tx, padTop + 4);
}

// ---------- DOM wiring ----------
const thr = document.getElementById("thr");
const thrVal = document.getElementById("thrVal");
const els = {
  tp: document.getElementById("tp"), fp: document.getElementById("fp"),
  fn: document.getElementById("fn"), tn: document.getElementById("tn"),
  acc: document.getElementById("acc"), prec: document.getElementById("prec"),
  rec: document.getElementById("rec"), f1: document.getElementById("f1"),
  cellTP: document.getElementById("cellTP"), cellFP: document.getElementById("cellFP"),
  cellFN: document.getElementById("cellFN"), cellTN: document.getElementById("cellTN"),
};

// Tint a matrix cell's background proportional to its share of all examples.
function tint(cellEl, count, goodColor) {
  const alpha = 0.08 + 0.42 * (count / N);
  cellEl.style.background = goodColor.replace("ALPHA", alpha.toFixed(3));
}

function update() {
  const t = Math.max(0, Math.min(1, parseFloat(thr.value)));
  thrVal.textContent = t.toFixed(2);
  const s = computeStats(t);

  els.tp.textContent = s.tp; els.fp.textContent = s.fp;
  els.fn.textContent = s.fn; els.tn.textContent = s.tn;
  els.acc.textContent = s.accuracy.toFixed(2);
  els.prec.textContent = s.precision.toFixed(2);
  els.rec.textContent = s.recall.toFixed(2);
  els.f1.textContent = s.f1.toFixed(2);

  // green for correct cells (TP, TN), red for errors (FP, FN)
  tint(els.cellTP, s.tp, "rgba(52, 211, 153, ALPHA)");
  tint(els.cellTN, s.tn, "rgba(52, 211, 153, ALPHA)");
  tint(els.cellFP, s.fp, "rgba(248, 113, 113, ALPHA)");
  tint(els.cellFN, s.fn, "rgba(248, 113, 113, ALPHA)");

  drawStrip(t);
}

thr.addEventListener("input", update);
document.getElementById("reshuffle").addEventListener("click", () => {
  generate(Math.floor(Math.random() * 99999));
  update();
});

// ---------- Init ----------
generate(2026);
update();

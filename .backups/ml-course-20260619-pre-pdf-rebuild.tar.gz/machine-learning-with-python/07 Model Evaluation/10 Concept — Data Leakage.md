# Data Leakage

> Data leakage is when your model accidentally learns from information it will never have at prediction time — so it looks brilliant in your notebook and falls apart in production.

## What is this?

Data leakage is any path by which information that *shouldn't be available yet* sneaks into your training process. "Shouldn't be available" means one of three things: it comes from the **test set** (which is supposed to simulate unseen data), from the **future** (data that arrives after the moment you'd actually make the prediction), or from the **target itself** (the very answer you're trying to predict).

When this happens, the model isn't learning the real pattern — it's quietly reading the answer key. Your validation score shoots up because the model has, in effect, already seen the questions it's being graded on. The score is real arithmetic, but it measures the wrong thing: how well the model memorizes leaked hints, not how well it generalizes.

The tricky part is that leakage almost never throws an error. The code runs, the numbers look great, everyone is happy. The damage only shows up later, when the model meets genuinely new data and the leaked information is gone.

## Why do we need it?

You need to understand leakage because the *entire point* of a test score is to predict how your model will do on data it has never seen. A model is only useful if it works on tomorrow's customers, not yesterday's. Leakage destroys that guarantee while leaving the score looking perfect, so it's the single most common way ML practitioners fool themselves.

There's a deeper reason too: leakage is sneaky. Overfitting at least announces itself (train score far above test score). Leakage hides — it inflates *both* your validation and test scores together, so every check you run says "ship it." Knowing the mechanisms is the only defense, because no metric will warn you.

## Where it's used in real ML

"Used" here means *where it shows up and bites people*:

- **Preprocessing fit on all the data.** You run `StandardScaler`, `SimpleImputer`, `PCA`, or target encoding on the full dataset *before* splitting. The transform now carries statistics (means, medians, category averages) computed partly from test rows.
- **Target-derived features.** A feature like "average purchase amount per customer" computed over the whole dataset, including future orders you're trying to predict.
- **Duplicate or group leakage.** The same patient, user, or transaction appears in both train and test (multiple visits, near-duplicate rows). The model has effectively seen the answer.
- **Time leakage.** Predicting today using a feature that secretly includes today's or tomorrow's totals — common in sales, finance, and demand forecasting.
- **Tuning on the test set.** Trying 40 models and keeping the one with the best test score quietly turns the test set into training data.

## What breaks if you ignore it

Concretely: your offline metrics lie to you, and the failure surfaces at the worst possible time — in production, after launch, in front of stakeholders.

- A fraud model that scored **0.99 AUC** in the notebook flags nothing useful in the live stream, because its best "feature" was a column only populated *after* fraud was confirmed.
- A churn model looks perfect because "days since cancellation" leaked in — but for active customers that column is empty, so live predictions are garbage.
- You burn weeks "debugging production" when the model was never good; the notebook number was a mirage.
- Worst case, the broken model ships, makes bad decisions on real money or real people, and erodes trust in the whole ML effort.

## Mental model

Picture an exam. The test set is the final exam; it must contain questions the student has never seen so the grade means something.

```
   HONEST                          LEAKED
   ┌──────────────┐                ┌──────────────┐
   │ TRAIN (study)│                │ TRAIN + a peek│
   └──────┬───────┘                │ at the EXAM   │
          │ learn the concept      └──────┬────────┘
          ▼                               │ memorize answers
   ┌──────────────┐                       ▼
   │ TEST (exam)  │ unseen          ┌──────────────┐
   │  → fair grade│                 │ TEST (exam)  │ already seen
   └──────────────┘                 │ → fake 100%  │
                                    └──────────────┘
```

Leakage is the student getting the answer key the night before. The score becomes meaningless, but it *looks* spectacular. Rule of thumb: **a suspiciously perfect score is a symptom, not a celebration.**

## Example 1 — Tiny toy example

Forget ML for a second. We just want to scale six numbers to a 0–1 range, splitting them into "train" (first four) and "test" (last two).

The min-max scaler subtracts the minimum and divides by the range. The honest version computes min and max from **train only**:

```
Data:        [10, 20, 30, 40, | 90, 100]   (| marks the train/test split)
Train:       [10, 20, 30, 40]   min=10, max=40, range=30
Honest scale (using train's min=10, range=30):
   test 90  -> (90-10)/30  = 2.67   <- correctly "out of range", a clue test differs
   test 100 -> (100-10)/30 = 3.00

Leaky scale (min/max from ALL six -> min=10, max=100, range=90):
   test 90  -> (90-10)/90  = 0.89   <- looks tidy and in-range...
   test 100 -> (100-10)/90 = 1.00   ...because the scaler already saw 100!
```

The leaky scaler used `100` (a test value) to decide the range. In real ML you won't *have* the test values when you deploy, so the tidy 0.89/1.00 numbers are a fantasy. The honest 2.67/3.00 are uglier but truthful.

## Example 2 — Practical ML example

You're building a credit-default classifier. You write a clean-looking script:

1. Load the data.
2. Impute missing income with the column median and standard-scale every feature — **on the full table**.
3. Split into train/test, fit logistic regression.
4. Report **0.992 ROC-AUC**. Amazing! You demo it.

Two weeks after launch, live AUC is **0.71** and the team is panicking.

What happened: the median and the scaling means/stds were computed using *every* row, including the held-out test rows. The model's features were subtly tuned to the exact distribution of data it was graded on. In production, that distribution shifts even slightly and the advantage evaporates.

The fix is structural, not clever: wrap imputation + scaling + model in a single **`Pipeline`** and evaluate with cross-validation. The pipeline re-fits every transform *inside each fold's training portion only*, so the test rows are never touched during preprocessing. The honest score comes back around **0.86** — lower, but it's the number that actually reproduces in production.

## Python code example

```python
# A brutal demo: the labels are RANDOM, so the TRUE accuracy is 50% (a coin flip).
# Any score above 0.50 can only come from leakage. Watch it appear.
import numpy as np
from sklearn.model_selection import cross_val_score
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import make_pipeline

rng = np.random.default_rng(0)
X = rng.standard_normal((200, 2000))     # 2000 pure-noise features, 200 rows
y = rng.integers(0, 2, size=200)         # RANDOM labels -> true accuracy is 0.50

# --- WRONG: pick the "best" 20 features using ALL rows and ALL labels first ---
# SelectKBest peeks at every label (incl. each fold's test labels) to rank features.
# By chance, some noise columns correlate with the labels it just saw = leakage.
X_leaked = SelectKBest(f_classif, k=20).fit_transform(X, y)
leaky = cross_val_score(LogisticRegression(max_iter=2000), X_leaked, y, cv=5)
print(f"Leaky  CV accuracy: {leaky.mean():.4f}  <- way above 0.50: pure illusion")

# --- RIGHT: do the selection INSIDE the pipeline, so it re-fits per fold ---
# Now feature ranking only sees each fold's training labels, never the test labels.
honest_pipe = make_pipeline(
    SelectKBest(f_classif, k=20),
    LogisticRegression(max_iter=2000),
)
honest = cross_val_score(honest_pipe, X, y, cv=5)   # no leakage
print(f"Honest CV accuracy: {honest.mean():.4f}  <- back near 0.50, the truth")

print(f"Leakage inflated the score by {(leaky.mean()-honest.mean())*100:+.1f} points")
# Expected (approx):
#   Leaky  CV accuracy: 0.7550  <- way above 0.50: pure illusion
#   Honest CV accuracy: 0.5550  <- back near 0.50, the truth
#   Leakage inflated the score by +20.0 points
# There is NO real signal here -- the leaky 75% is entirely manufactured by
# letting feature selection see the labels it was about to be graded on.
```

## Common mistakes

- **`fit_transform` on the full dataset, then split.** The number-one leak. Always split first and fit transforms on train only — or better, let a `Pipeline` handle it inside every CV fold.
- **Engineering features from the target over all rows.** "Average target per category" computed on the whole dataset leaks the answer into every row. Compute such aggregates within the training fold.
- **Random-splitting time-series or grouped data.** A random split scatters a customer's (or a day's) rows across train and test. Use time-based or group-aware splits so related rows stay together.
- **Resampling (SMOTE/oversampling) before the split.** Synthetic points built from test rows leak. Resample *inside* the training fold only.
- **Treating a near-perfect score as good news.** 0.999 AUC on a hard problem is a red flag, not a trophy — go hunt for the leak first.

## Before you continue
- [ ] I can define data leakage and name its three sources: test set, future, and target.
- [ ] I can explain why leakage inflates scores in the notebook but collapses in production.
- [ ] I can spot the classic "scale/impute before split" leak and fix it with a `Pipeline`.
- [ ] I know that leakage always flatters the reported number, never hurts it.
- [ ] I treat a suspiciously perfect score as a reason to investigate, not celebrate.

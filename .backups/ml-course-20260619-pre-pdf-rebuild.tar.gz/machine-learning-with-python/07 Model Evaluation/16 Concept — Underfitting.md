# Underfitting

> Underfitting is when a model is too simple to capture the real pattern — it does poorly on the data it studied *and* on new data, because it never learned the shape in the first place.

## What is this?

Underfitting happens when a model is *too simple* (too little capacity, too few features, or too much regularization) to represent the relationship hiding in your data. It can't even bend enough to fit the data it was trained on, let alone generalize. It draws a crude approximation and calls it a day.

The telltale signature is **high error on both train and test, and the two are close together**. There's no big gap to chase — the model is uniformly mediocre. It's not memorizing anything (that's overfitting's problem); it's failing to learn enough.

In bias-variance language, underfitting is **high bias**: the model carries strong, wrong assumptions about the world (e.g. "the relationship is a straight line" when it clearly curves). Those baked-in assumptions stop it from ever matching reality, no matter how much data you feed it.

## Why do we need it?

You need to recognize underfitting because it's the failure mode that *more data won't fix* — and beginners waste enormous effort collecting rows when the real problem is an under-powered model. If both your train and test scores are bad and close, throwing more examples at a too-simple model just gives it more points to fit badly.

It's also the mirror image of overfitting, so naming it correctly tells you which direction to move. Mistake underfitting for overfitting and you'll *simplify* an already-too-simple model, making it worse. The diagnosis decides whether you turn the complexity dial up or down.

## Where it's used in real ML

"Where it shows up" — underfitting appears when capacity is too low for the problem:

- **Linear models on nonlinear data**: fitting a straight line (or plain logistic regression) to a relationship that curves, oscillates, or has interactions.
- **Over-regularized models**: `alpha` too large in Ridge/Lasso, or `C` too small in logistic regression / SVM, crushing the model toward a flat constant.
- **Too few or too weak features**: trying to predict house price from square footage alone when location and age matter.
- **A shallow tree or tiny network** capped so aggressively it can't represent the pattern (e.g. `max_depth=1`, a "decision stump").
- **Training stopped far too early**, before the model had a chance to learn.

## What breaks if you ignore it

The model is quietly useless — it doesn't crash, it just predicts close to the average and is wrong a lot.

- A demand forecaster that's effectively a flat line under-orders during peaks and over-orders during lulls, every single cycle.
- A churn model that's too simple gives nearly everyone the same middling risk score, so it can't rank who to save — the business gets no actionable signal.
- You see **65% accuracy on both train and test** and conclude "ML doesn't work for this problem," when really the model was a straight line on curved data.
- Effort gets misdirected: you spend weeks gathering more data (which won't help) instead of minutes adding capacity or features (which would).

## Mental model

Imagine a student who **barely studied and learned one crude rule** — "when in doubt, pick B."

```
   The TRUE pattern        An UNDERFIT model
   (a clear curve)         (one rigid straight line)

   y                       y
   │        .  .           │              ____
   │      .       .        │        ____/   line misses
   │    .           .      │   ____/        the whole curve
   │  .               .    │__/    .  .  .  .
   └──────────────── x     └──────────────── x
   data clearly bends      model can't bend → wrong everywhere
```

On the practice set (training data) they do *badly* — they never learned enough. On the real exam (test data) they also do badly, and for the same reason. Unlike the overfit crammer who aces practice and bombs the exam, the underfit student is consistently weak on both. **Both scores are low and close** — that's the fingerprint.

## Example 1 — Tiny toy example

Suppose the real relationship clearly curves upward — it's roughly `y = x²`:

```
x:   1    2    3    4    5
y:   1    4    9   16   25      (a parabola: y = x squared)
```

Force a **straight line** (degree-1 model) through it. The best line is about `y ≈ 6x − 7`. Look at how badly it fits the data it was *trained* on:

```
x    actual y    line predicts    error
1       1            -1            2
2       4             5            1
3       9            11            2
4      16            17            1
5      25            23            2
```

The line is wrong on every training point — it sags below in the middle and can't catch the steep rise at the end. A degree-2 model, by contrast, would fit `y = x²` essentially perfectly. The straight line isn't fighting noise; the data is clean. It simply *cannot represent a curve*. That's underfitting: the error is high even on data the model has already seen.

## Example 2 — Practical ML example

You're predicting house prices, and the true relationship between size and price is curved (prices accelerate for larger homes). You start with plain **`LinearRegression`** — a single straight line:

```
Linear model:
  train R² = 0.02
  test  R² = 0.07
```

Both scores are dismal *and close* (an R² near 0 means the model barely beats just guessing the average price). There's no train/test gap to fix — the model is just too rigid to bend with the data. (Notice this is the opposite of overfitting, where train would be near 1.0 and test much lower.)

The fix is to **add capacity**, not simplify. Give the model the ability to curve by adding polynomial features (size², interactions), or switch to a more expressive model like a gradient-boosted tree:

```
Linear + polynomial degree 2:
  train R² = 0.97   <- rose
  test  R² = 0.97   <- rose too, still close
```

Both scores climbed together. That's the signature of curing underfitting: you didn't open a gap, you lifted the whole performance. Other levers for the same job: add informative features (location, age), reduce regularization (lower `alpha`), or let a tree grow deeper. (Push capacity *too* far and you'll cross into overfitting — then the train score keeps rising while test starts to fall.)

## Python code example

```python
# Watch a model underfit curved data, then fix it by ADDING capacity.
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import PolynomialFeatures
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score

# Inline data: a curved (quadratic) relationship plus a little noise.
rng = np.random.default_rng(0)
X = np.sort(rng.uniform(-3, 3, 200)).reshape(-1, 1)
y = 2.0 * X.ravel()**2 - X.ravel() + rng.normal(0, 1.0, size=X.shape[0])
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.3, random_state=0)

# --- UNDERFIT: a straight line cannot represent a curve ---
linear = LinearRegression()
linear.fit(X_tr, y_tr)
tr1, te1 = r2_score(y_tr, linear.predict(X_tr)), r2_score(y_te, linear.predict(X_te))
print("Straight line (degree 1):")
print(f"  train R2 = {tr1:.3f}")            # ~0.02  (BAD on train too)
print(f"  test  R2 = {te1:.3f}")            # ~0.07  (BAD and close = underfit)
print("  -> both low and close: too simple to capture the curve\n")

# --- FIX: add capacity so the model CAN bend (polynomial degree 2) ---
poly = make_pipeline(PolynomialFeatures(degree=2), LinearRegression())
poly.fit(X_tr, y_tr)
tr2, te2 = r2_score(y_tr, poly.predict(X_tr)), r2_score(y_te, poly.predict(X_te))
print("Polynomial degree 2:")
print(f"  train R2 = {tr2:.3f}")            # ~0.97  (rose)
print(f"  test  R2 = {te2:.3f}")            # ~0.96  (rose too, still close)
print("  -> both scores climbed together: capacity now matches the pattern")

# Takeaway: the cure for underfitting is MORE capacity/features, not more data.
# Both train and test improved at once -- the opposite of fixing overfitting.
```

## Common mistakes

- **Throwing more data at it.** Underfitting means the model is too simple, so extra rows just give it more points to fit badly. Add capacity or features instead.
- **Confusing it with overfitting.** Underfitting = *both* train and test bad and close. Overfitting = train good, test bad (big gap). They call for opposite cures.
- **Over-regularizing.** Cranking `alpha` up or `C` down too far flattens a model into underfitting. If both scores are poor, try *weaker* regularization.
- **Blaming the algorithm or the problem.** "ML can't do this" is usually premature — a straight line on curved data fails, but a degree-2 model or a tree often nails it.
- **Forgetting features carry the signal.** A model can't learn a pattern that isn't in its inputs; sometimes the fix is a better feature, not a fancier model.

## Before you continue
- [ ] I can define underfitting as a too-simple model that can't capture the pattern.
- [ ] I can name its signature: train and test scores both poor and close together.
- [ ] I know the cures run toward *more* capacity, *more/better* features, and *less* regularization.
- [ ] I can tell underfitting (both bad) apart from overfitting (big train-test gap).
- [ ] I understand why adding more data usually won't fix an underfit model.

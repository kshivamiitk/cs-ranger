# Solved — Detecting Overfitting from Train and Test Scores

> A junior teammate reports a model with **100% training accuracy** and wants to ship it. One glance at the test score tells you it's the worst model in the sweep — and two columns of numbers prove it.

## Problem statement

You have one knob that controls model complexity — here, the **maximum depth** of a decision tree — and you want to pick the value that *generalizes* best. The trap is that more complexity always looks better on the data the model trained on. So a single accuracy number is useless on its own: train accuracy alone will happily push you toward the most complex, most overfit model in the room.

The fix is to fit a ladder of models from very simple (depth 1) to very complex (depth 14), and for each one print **both** the training accuracy and the held-out test accuracy. Then you read the *two numbers together*: when both are low and close, the model is **underfitting**; when train keeps climbing toward 1.0 while test peaks and falls back, the model is **overfitting**; the model you want is the one where the **test score peaks**, not where the train score peaks.

## Why this problem matters

This is the single most common way a model that "looked amazing in the notebook" embarrasses you in production. A model that scores 100% on training data has often just memorized the noise — including the mislabeled rows — and that memorization evaporates the instant it sees new data. Being able to glance at a train/test pair and instantly say "that gap is overfitting" is a core diagnostic reflex: it tells you *which direction to move* (add complexity vs. cut it, get more data, regularize) instead of guessing. Every hyperparameter search, every model comparison, and every "is this good enough to ship?" conversation runs on exactly these two columns.

## Tiny dataset or sample data

We generate the data inline with NumPy (no download). The **true** rule is "label = 1 inside a circle of radius 1.6 around the origin," and then we flip about 12% of labels at random — that injected **noise** is what a too-deep tree will memorize. Full set: shape `(400, 2)` features plus a `label`, columns `x1, x2, label`.

A representative slice:

| x1 | x2 | label | why |
|------:|------:|:-----:|------|
| -1.47 | -0.33 | 1 | inside circle (r=1.51) |
| +0.03 | +0.32 | 1 | inside circle (r=0.32) |
| +0.75 | +2.38 | 0 | outside circle (r=2.50) |
| +1.65 | -1.65 | 0 | outside circle (r=2.34) |
| +0.06 | +2.08 | 1 | **noise flip** (r=2.08, "should" be 0) |
| +1.03 | -1.20 | 0 | **noise flip** (r=1.58, "should" be 1) |

The two flipped rows are the bait: a shallow tree ignores them (and generalizes), a deep tree carves out a tiny region just to get them "right" on the training set (and overfits).

## Step-by-step reasoning

1. **Make complexity a single dial.** A decision tree's `max_depth` is a clean complexity knob: depth 1 is a single yes/no split (very simple), depth 14 can grow enough leaves to isolate individual training points (very complex). Sweeping it from 1 upward traces the whole bias-variance curve.
2. **Split once, score twice — on the same split.** We hold out 30% as a test set *before* fitting anything, then for every depth we record train accuracy (how well it fits what it saw) **and** test accuracy (how well it generalizes). Using the same split for every depth makes the comparison fair.
3. **Read underfitting from "both low, close together."** At depth 1 the tree is too crude to trace a circle, so train and test are both mediocre and roughly equal. Low train score is the signature: the model can't even fit its own data, so more data won't help — it needs *more* capacity.
4. **Read overfitting from "train near 1.0, test fell, gap widened."** As depth grows, train accuracy marches toward 1.000 (it can memorize every row, noise included) while test accuracy peaks and then *declines*. The widening **train-test gap** is the fingerprint of variance: the model is learning the training set's quirks, not the underlying circle.
5. **Pick where the TEST score peaks, never where train peaks.** The best model is the depth that maximizes held-out accuracy. Train accuracy is a decoy — it always favors the most complex model, which is exactly the one you must not ship.

## Python solution

```python
import numpy as np
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split

# --- 1. Inline data (no download), built with NumPy so it's reproducible. ---
# TRUE rule: label = 1 inside a circle of radius ~1.6 around the origin.
# We then FLIP ~12% of labels at random -> that's the NOISE a too-deep
# tree will happily memorize. The circular boundary is smooth, so an
# axis-aligned tree needs *some* depth to approximate it, but past a point
# it just carves out single noisy points and stops generalizing.
rng = np.random.default_rng(7)
N = 400
X = rng.uniform(-3, 3, size=(N, 2))                  # two features in [-3, 3]
true = (X[:, 0] ** 2 + X[:, 1] ** 2 < 1.6 ** 2).astype(int)
flip = rng.random(N) < 0.12                          # 12% label noise
y = np.where(flip, 1 - true, true)
print("Shape:", X.shape, "| class balance:", np.bincount(y),
      "| noisy labels flipped:", int(flip.sum()))

# Hold out a test set ONCE, up front. Stratify so both classes are present.
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.30, random_state=42, stratify=y)
print("Train size:", len(y_tr), "| Test size:", len(y_te))

# --- 2. Sweep model complexity: decision-tree depth 1..14. ---
# For each depth, fit on TRAIN and score on BOTH train and test.
print("\n depth   train_acc   test_acc      gap")
print("---------------------------------------------")
rows = []
for depth in range(1, 15):
    tree = DecisionTreeClassifier(max_depth=depth, random_state=0)
    tree.fit(X_tr, y_tr)
    tr = tree.score(X_tr, y_tr)                      # fit on what it saw
    te = tree.score(X_te, y_te)                      # generalization
    rows.append((depth, tr, te))
    print(f"  {depth:2d}     {tr:7.3f}     {te:7.3f}    {tr - te:+6.3f}")

# --- 3. Diagnose straight from the two columns of numbers. ---
best_depth, best_tr, best_test = max(rows, key=lambda r: r[2])  # peak TEST
print(f"\nPeak TEST accuracy = {best_test:.3f} at depth = {best_depth} "
      f"(train there = {best_tr:.3f}, gap = {best_tr - best_test:+.3f})")

shallow = rows[0]       # depth 1   -> underfit candidate
deepest = rows[-1]      # depth 14  -> overfit candidate
print(f"\nUNDERFIT (depth {shallow[0]:2d}): "
      f"train={shallow[1]:.3f}, test={shallow[2]:.3f} "
      f"-> both low & close = model too simple")
print(f"OVERFIT  (depth {deepest[0]:2d}): "
      f"train={deepest[1]:.3f}, test={deepest[2]:.3f} "
      f"-> train ~1.0 but test FELL = memorizing noise")
print(f"SWEET SPOT (depth {best_depth:2d}): test peaks, then the "
      f"train-test gap widens as depth grows")
```

## Expected output

```
Shape: (400, 2) | class balance: [274 126] | noisy labels flipped: 55
Train size: 280 | Test size: 120

 depth   train_acc   test_acc      gap
---------------------------------------------
   1       0.686       0.683    +0.002
   2       0.736       0.567    +0.169
   3       0.814       0.700    +0.114
   4       0.875       0.758    +0.117
   5       0.893       0.750    +0.143
   6       0.921       0.725    +0.196
   7       0.932       0.725    +0.207
   8       0.964       0.667    +0.298
   9       0.979       0.675    +0.304
  10       0.993       0.683    +0.310
  11       1.000       0.692    +0.308
  12       1.000       0.692    +0.308
  13       1.000       0.692    +0.308
  14       1.000       0.692    +0.308

Peak TEST accuracy = 0.758 at depth = 4 (train there = 0.875, gap = +0.117)

UNDERFIT (depth  1): train=0.686, test=0.683 -> both low & close = model too simple
OVERFIT  (depth 14): train=1.000, test=0.692 -> train ~1.0 but test FELL = memorizing noise
SWEET SPOT (depth  4): test peaks, then the train-test gap widens as depth grows
```

## Explanation of the output

Read the table left to right as one story. At **depth 1** train and test are both about **0.68** and almost identical (gap +0.002): the model is too crude to trace a circle with one split, so it does equally poorly on everything — classic **underfitting**. As depth grows, train accuracy climbs steadily and finally pins at **1.000** by depth 11: the tree now has enough leaves to memorize all 280 training rows, *including the 55 flipped noise labels*.

But watch the test column — the one that actually matters. It **peaks at 0.758 at depth 4**, then drifts back down into the high 0.60s as the tree gets deeper. By depth 14 you have the most seductive-looking model (perfect 1.000 on train) and one of the *worst* test scores in the sweep: that is **overfitting** in two numbers. The **gap** column makes it undeniable — it starts near zero and widens to +0.31; a large, growing train-minus-test gap is the fingerprint of variance. (The little dip at depth 2 is just small-sample wobble from one unlucky split; the *trend* is what you read, not any single row.) The verdict: ship **depth 4**, the depth where held-out accuracy peaks — never depth 11+ where train accuracy peaks.

## Common mistakes

1. **Choosing the model by training accuracy.** Train score always rewards the most complex model, so optimizing it picks the most overfit one. Fix: select the hyperparameter by **held-out / cross-validated** score, never by training score.
2. **Reporting only one number.** A lone "94% accuracy" hides whether that's a healthy fit or a memorized train score. Fix: always print **train *and* test together** and look at the gap.
3. **Reacting to overfitting by adding features or depth.** Overfitting is *too much* capacity; piling on more makes it worse. Fix: reduce complexity (shallower tree, stronger regularization) or get more data.
4. **Reacting to underfitting by gathering more data.** When both curves are low and close, the model can't fit even what it has — more rows won't help. Fix: use a more expressive model or better features.
5. **Reusing the test set to pick the depth and then reporting that same test score.** Selecting on the test set quietly leaks it, so the "test" number is now optimistic. Fix: tune on a validation set or cross-validation, and keep a final test set untouched for the headline number.

## Extension challenge

1. Replace the held-out split with `validation_curve(DecisionTreeClassifier(random_state=0), X, y, param_name="max_depth", param_range=range(1,15), cv=5)` and confirm the U-shape survives averaging over folds — the peak should be steadier than the single-split version.
2. Swap `max_depth` for `min_samples_leaf` swept from 1 up to 40. It's a complexity dial too, just running the other direction (larger = simpler). Find where test accuracy peaks and explain why the curve flips left-to-right.
3. Crank the noise from `0.12` to `0.30` and rerun. Predict first, then check: does the train-test gap at high depth get wider, and does the best depth get *shallower*? (More noise rewards simpler models.)

## Matching animation

**Overfitting vs Underfitting Simulator** — drag the complexity slider from "too simple" through "just right" to "too complex" and watch the decision boundary morph from a flat line that ignores the data, to a clean curve that tracks the true shape, to a jagged border that loops around individual noisy points. The twin train/test accuracy bars update live, so you *see* the test bar peak and then sink exactly as the train bar marches to 100% — the same U-shape this lesson prints, made visual.

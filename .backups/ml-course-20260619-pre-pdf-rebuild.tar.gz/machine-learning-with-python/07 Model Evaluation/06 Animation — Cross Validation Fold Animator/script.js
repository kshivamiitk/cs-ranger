"use strict";

/* ------------------------------------------------------------------ *
 * Cross Validation Fold Animator
 *
 * Idea taught: k-fold cross-validation.
 *   - Split N samples into k folds.
 *   - Run k rounds. In round i, fold i is the VALIDATION set (held out)
 *     and the other k-1 folds are the TRAIN set.
 *   - Each round yields one score; the headline estimate is the mean of
 *     the k scores plus their standard deviation:  CV = mean ± std.
 *   - Contrast: a single train/test split gives just ONE score, which
 *     is higher-variance (luck-dependent).
 *
 * Everything is deterministic: the per-fold "model score" comes from a
 * fixed hash of the validation sample ids, so the demo is identical on
 * every load and the bars never jump around between runs.
 * ------------------------------------------------------------------ */

// ----- Data: 20 samples laid out in a grid, each with a 2-class label -----
const N = 20;

function makeSamples() {
  // deterministic PRNG (LCG) so labels are fixed every load
  let s = 20240611;
  const rnd = () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff;            // [0,1)
  };
  const out = [];
  for (let i = 0; i < N; i++) {
    // ~35% positive class -> deliberately imbalanced so stratification matters
    const label = rnd() < 0.35 ? 1 : 0;
    out.push({ id: i, label });
  }
  return out;
}
const SAMPLES = makeSamples();
const POS = SAMPLES.filter(s => s.label === 1).length;
const NEG = N - POS;

// ----- Deterministic pseudo-score for a fold given its validation ids -----
// Stable hash of the sorted validation id list -> a score in ~[0.74, 0.94].
function foldScore(valIds) {
  let h = 2166136261 >>> 0;          // FNV-1a basis
  const sorted = valIds.slice().sort((a, b) => a - b);
  for (const id of sorted) {
    h ^= (id + 1);
    h = Math.imul(h, 16777619) >>> 0;
  }
  // also fold in the count so different k values look different
  h ^= sorted.length;
  h = Math.imul(h, 16777619) >>> 0;
  const u = (h % 100000) / 100000;   // [0,1)
  return 0.74 + u * 0.20;            // [0.74, 0.94)
}

// ----- Fold partitioning -----------------------------------------------------
// Returns an array `assign` of length N: assign[id] = fold index (0..k-1).
// Plain k-fold: walk samples in id order, round-robin into folds (balanced).
// Stratified : do the same round-robin WITHIN each class, so every fold keeps
//              the same class ratio as the whole dataset.
// Either way every sample gets exactly one fold => validated exactly once.
function partition(k, stratified) {
  const assign = new Array(N).fill(-1);
  if (!stratified) {
    let f = 0;
    for (let id = 0; id < N; id++) {
      assign[id] = f;
      f = (f + 1) % k;
    }
  } else {
    const byClass = [
      SAMPLES.filter(s => s.label === 0).map(s => s.id),
      SAMPLES.filter(s => s.label === 1).map(s => s.id)
    ];
    let f = 0;                        // shared cursor keeps fold sizes balanced
    for (const ids of byClass) {
      for (const id of ids) {
        assign[id] = f;
        f = (f + 1) % k;
      }
    }
  }
  return assign;
}

// Build the fold -> sample-id lists from an assignment.
function foldsFromAssign(assign, k) {
  const folds = [];
  for (let f = 0; f < k; f++) folds.push([]);
  for (let id = 0; id < N; id++) folds[assign[id]].push(id);
  return folds;
}

// ----- DOM -----
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const kInput = document.getElementById("k");
const speedInput = document.getElementById("speed");
const kVal = document.getElementById("kVal");
const speedVal = document.getElementById("speedVal");
const stratInput = document.getElementById("stratified");
const runBtn = document.getElementById("run");
const stepBtn = document.getElementById("step");
const singleBtn = document.getElementById("single");
const resetBtn = document.getElementById("reset");
const elRound = document.getElementById("rRound");
const elFold = document.getElementById("rFold");
const elMean = document.getElementById("rMean");
const elStd = document.getElementById("rStd");
const elStatus = document.getElementById("rStatus");

// ----- State -----
let k = parseInt(kInput.value, 10);
let stratified = stratInput.checked;
let assign = partition(k, stratified);
let folds = foldsFromAssign(assign, k);

let current = -1;            // index of fold currently shown as validation (-1 = none)
let scores = [];            // collected fold scores, in fold order, up to `current`
let mode = "idle";         // "idle" | "cv" | "single"
let playing = false;        // auto-play running?
let timer = null;           // setTimeout handle for auto-play
let single = null;          // { foldIdx, score } when in single-split mode
let intro = 0;              // 0..1 entrance reveal for bars/highlight

// ----- Geometry -----
const PAD = { l: 28, r: 28, t: 64, b: 150 };
const COLS = 5, ROWS = 4;   // 5 x 4 = 20 cells

function gridArea() {
  return {
    x: PAD.l,
    y: PAD.t,
    w: canvas.width - PAD.l - PAD.r,
    h: canvas.height - PAD.t - PAD.b
  };
}

function cellRect(id) {
  const a = gridArea();
  const col = id % COLS;
  const row = Math.floor(id / COLS);
  const gap = 12;
  const cw = (a.w - gap * (COLS - 1)) / COLS;
  const ch = (a.h - gap * (ROWS - 1)) / ROWS;
  return {
    x: a.x + col * (cw + gap),
    y: a.y + row * (ch + gap),
    w: cw,
    h: ch
  };
}

// ----- Reset / rebuild on control changes -----
function rebuild() {
  stopPlay();
  assign = partition(k, stratified);
  folds = foldsFromAssign(assign, k);
  current = -1;
  scores = [];
  single = null;
  mode = "idle";
  intro = 1;
  syncButtons();
  updateReadout();
  render();
}

// ----- Advance one fold in CV mode. Returns false when CV is complete. -----
function stepCV() {
  if (mode === "single") { rebuild(); }
  mode = "cv";
  if (current >= k - 1) return false;     // already done
  current += 1;
  const valIds = folds[current];
  scores[current] = foldScore(valIds);
  single = null;
  intro = 0;
  animateIntro();
  updateReadout();
  return current < k - 1;                  // more rounds remain?
}

// ----- Single split: one random-ish held-out fold, just one score -----
let singleCounter = 0;
function doSingle() {
  stopPlay();
  mode = "single";
  current = -1;
  scores = [];
  // pick a fold deterministically but vary it each press so the score visibly
  // moves around -> demonstrates how luck-dependent a single split is.
  singleCounter += 1;
  const foldIdx = (singleCounter * 3 + 1) % k;
  single = { foldIdx, score: foldScore(folds[foldIdx]) };
  intro = 0;
  animateIntro();
  updateReadout();
  syncButtons();
}

// ----- Auto-play -----
function play() {
  if (playing) { stopPlay(); return; }
  if (mode !== "cv" || current >= k - 1) {
    // start fresh
    current = -1;
    scores = [];
    single = null;
    mode = "cv";
  }
  playing = true;
  syncButtons();
  const tick = () => {
    const more = stepCV();
    render();
    if (more && playing) {
      const ms = 950 / parseFloat(speedInput.value);
      timer = setTimeout(tick, ms);
    } else {
      playing = false;
      syncButtons();
    }
  };
  tick();
}

function stopPlay() {
  playing = false;
  if (timer) { clearTimeout(timer); timer = null; }
}

// ----- Intro animation (smooth reveal of highlight + new bar) -----
let introAnim = null;
function animateIntro() {
  if (introAnim) cancelAnimationFrame(introAnim);
  intro = 0;
  const t0 = performance.now();
  const dur = 320;
  const frame = (t) => {
    const kk = Math.min(1, (t - t0) / dur);
    intro = 1 - Math.pow(1 - kk, 3);     // ease-out cubic
    render();
    if (kk < 1) introAnim = requestAnimationFrame(frame);
    else { intro = 1; introAnim = null; render(); }
  };
  introAnim = requestAnimationFrame(frame);
}

// ----- Stats -----
function mean(arr) {
  if (!arr.length) return 0;
  return arr.reduce((a, b) => a + b, 0) / arr.length;
}
function std(arr) {
  if (arr.length < 2) return 0;
  const m = mean(arr);
  const v = arr.reduce((a, b) => a + (b - m) * (b - m), 0) / arr.length; // population std
  return Math.sqrt(v);
}

// ----- Readout -----
function updateReadout() {
  if (mode === "single" && single) {
    elRound.textContent = "1 / 1";
    elRound.className = "v";
    elFold.textContent = single.score.toFixed(3);
    elFold.className = "v valid";
    elMean.textContent = single.score.toFixed(3);
    elMean.className = "v";
    elStd.textContent = "n/a";
    elStd.className = "v";
    elStatus.textContent = "single split — luck!";
    elStatus.className = "v valid";
    return;
  }

  if (mode !== "cv" || current < 0) {
    elRound.textContent = "—";
    elFold.textContent = "—";
    elMean.textContent = "—";
    elStd.textContent = "—";
    elStatus.textContent = "press Run CV";
    elRound.className = elFold.className = elMean.className = elStd.className = "v";
    elStatus.className = "v";
    return;
  }

  const done = scores.slice(0, current + 1);
  const m = mean(done);
  const sd = std(done);
  elRound.textContent = (current + 1) + " / " + k;
  elRound.className = "v";
  elFold.textContent = scores[current].toFixed(3);
  elFold.className = "v valid";
  elMean.textContent = m.toFixed(3);
  elMean.className = "v good";
  elStd.textContent = (current >= 1) ? sd.toFixed(3) : "—";
  elStd.className = "v";

  if (current >= k - 1) {
    elStatus.textContent = "CV = " + m.toFixed(2) + " ± " + sd.toFixed(2);
    elStatus.className = "v snapped";
  } else {
    elStatus.textContent = "running…";
    elStatus.className = "v";
  }
}

// ----- Button enable/highlight state -----
function syncButtons() {
  runBtn.textContent = playing ? "Pause" : "Run CV";
  runBtn.classList.toggle("active", playing);
  singleBtn.classList.toggle("active", mode === "single");
  const cvFinished = mode === "cv" && current >= k - 1;
  stepBtn.disabled = playing || cvFinished;
  kInput.disabled = playing;
  stratInput.disabled = playing;
}

// ----- Rendering -----
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawTitleRow();
  drawGrid();
  drawBars();
  drawLegend();
}

function valFoldNow() {
  if (mode === "single" && single) return single.foldIdx;
  if (mode === "cv" && current >= 0) return current;
  return -1;
}

function drawTitleRow() {
  ctx.save();
  ctx.textBaseline = "middle";
  ctx.fillStyle = "#e2e8f0";
  ctx.font = "600 16px Inter, sans-serif";
  ctx.textAlign = "left";
  let title;
  if (mode === "single" && single) {
    title = "Single split — 1 validation fold, 1 score";
  } else if (mode === "cv" && current >= 0) {
    title = "Round " + (current + 1) + " of " + k + "  •  fold " + (current + 1) + " held out for validation";
  } else {
    title = (stratified ? "Stratified " : "") + k + "-fold cross-validation  •  " + N + " samples";
  }
  ctx.fillText(title, PAD.l, 24);

  ctx.font = "13px ui-monospace, Menlo, monospace";
  ctx.fillStyle = "#94a3b8";
  ctx.textAlign = "right";
  ctx.fillText("class ratio  " + NEG + " : " + POS + "  (neg:pos)", canvas.width - PAD.r, 24);
  ctx.restore();
}

function lerpColor(c1, c2, t) {
  const r = Math.round(c1[0] + (c2[0] - c1[0]) * t);
  const g = Math.round(c1[1] + (c2[1] - c1[1]) * t);
  const b = Math.round(c1[2] + (c2[2] - c1[2]) * t);
  return "rgb(" + r + "," + g + "," + b + ")";
}

function drawGrid() {
  const valFold = valFoldNow();
  const TRAIN = [59, 130, 246];   // --train
  const VALID = [245, 158, 11];   // --valid
  const IDLE = [40, 44, 56];

  for (let id = 0; id < N; id++) {
    const r = cellRect(id);
    const f = assign[id];
    const isVal = f === valFold;
    const active = valFold >= 0;

    ctx.save();
    roundRect(r.x, r.y, r.w, r.h, 9);

    let fill;
    if (!active) {
      fill = lerpColor(IDLE, TRAIN, 0.0);             // neutral before a run
      ctx.fillStyle = "rgba(59,130,246,0.10)";
    } else if (isVal) {
      // animate fresh validation tiles in
      const a = 0.25 + 0.65 * intro;
      ctx.fillStyle = "rgba(245,158,11," + a.toFixed(3) + ")";
      fill = null;
    } else {
      ctx.fillStyle = "rgba(59,130,246,0.18)";
      fill = null;
    }
    if (fill === null || !active) ctx.fill();
    else ctx.fill();

    // border
    ctx.lineWidth = isVal && active ? 2.5 : 1.2;
    ctx.strokeStyle = isVal && active
      ? "rgba(245,158,11," + (0.6 + 0.4 * intro).toFixed(3) + ")"
      : (active ? "rgba(59,130,246,0.55)" : "rgba(255,255,255,0.10)");
    roundRect(r.x, r.y, r.w, r.h, 9);
    ctx.stroke();
    ctx.restore();

    // sample dot + fold id
    ctx.save();
    const cx = r.x + r.w / 2;
    const cy = r.y + r.h / 2;
    const s = SAMPLES[id];
    // class glyph
    ctx.fillStyle = s.label === 1 ? "#fbbf24" : "#67e8f9";
    if (s.label === 1) {
      ctx.beginPath();
      ctx.arc(cx, cy - 4, 6, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillRect(cx - 5.5, cy - 9.5, 11, 11);
    }
    // fold label
    ctx.fillStyle = active && isVal ? "#fde9c7" : "#cbd5e1";
    ctx.font = "11px ui-monospace, Menlo, monospace";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("f" + (f + 1), cx, cy + 13);
    ctx.restore();
  }
}

function drawBars() {
  // Bar chart of per-fold scores along the bottom.
  const a = gridArea();
  const baseY = a.y + a.h + 116;        // baseline for bars
  const top = a.y + a.h + 24;            // top of bar zone
  const zoneH = baseY - top;
  const left = PAD.l;
  const right = canvas.width - PAD.r;
  const w = right - left;
  const gap = 10;
  const bw = (w - gap * (k - 1)) / k;

  // score axis maps [0.7, 1.0] -> [baseY, top]
  const SLO = 0.7, SHI = 1.0;
  const yOf = (sc) => baseY - ((sc - SLO) / (SHI - SLO)) * zoneH;

  ctx.save();
  // baseline
  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(left, baseY + 0.5);
  ctx.lineTo(right, baseY + 0.5);
  ctx.stroke();

  // y ticks
  ctx.fillStyle = "#64748b";
  ctx.font = "10px ui-monospace, Menlo, monospace";
  ctx.textAlign = "left";
  [0.7, 0.8, 0.9, 1.0].forEach((tk) => {
    const y = yOf(tk);
    ctx.fillText(tk.toFixed(1), 2, y + 3);
  });

  const valFold = valFoldNow();

  for (let f = 0; f < k; f++) {
    const x = left + f * (bw + gap);
    let sc = null;
    if (mode === "single" && single) {
      if (f === single.foldIdx) sc = single.score;
    } else if (mode === "cv") {
      if (f <= current) sc = scores[f];
    }

    // empty slot outline
    ctx.strokeStyle = "rgba(255,255,255,0.08)";
    ctx.lineWidth = 1;
    ctx.strokeRect(x, top, bw, baseY - top);

    if (sc === null) {
      // label only
      ctx.fillStyle = "#475569";
      ctx.font = "11px ui-monospace, Menlo, monospace";
      ctx.textAlign = "center";
      ctx.fillText("f" + (f + 1), x + bw / 2, baseY + 14);
      continue;
    }

    const isCurrent = (f === valFold);
    const grow = (mode === "cv" && f === current) ? intro : 1; // grow the newest bar
    const yTarget = yOf(sc);
    const yNow = baseY - (baseY - yTarget) * grow;

    const grad = ctx.createLinearGradient(0, baseY, 0, yTarget);
    if (isCurrent) {
      grad.addColorStop(0, "rgba(245,158,11,0.35)");
      grad.addColorStop(1, "rgba(245,158,11,0.95)");
    } else {
      grad.addColorStop(0, "rgba(52,211,153,0.30)");
      grad.addColorStop(1, "rgba(52,211,153,0.85)");
    }
    ctx.fillStyle = grad;
    ctx.fillRect(x, yNow, bw, baseY - yNow);

    // score text
    ctx.fillStyle = isCurrent ? "#fde9c7" : "#a7f3d0";
    ctx.font = "11px ui-monospace, Menlo, monospace";
    ctx.textAlign = "center";
    if (grow > 0.6) ctx.fillText(sc.toFixed(2), x + bw / 2, yNow - 6);
    ctx.fillStyle = "#94a3b8";
    ctx.fillText("f" + (f + 1), x + bw / 2, baseY + 14);
  }

  // mean ± std overlay line (CV only, once we have >=2 scores)
  if (mode === "cv" && current >= 1) {
    const done = scores.slice(0, current + 1);
    const m = mean(done);
    const sd = std(done);
    const ym = yOf(m);
    ctx.setLineDash([6, 5]);
    ctx.strokeStyle = "rgba(167,139,250,0.9)";
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(left, ym);
    ctx.lineTo(right, ym);
    ctx.stroke();
    ctx.setLineDash([]);

    // std band
    const yhi = yOf(Math.min(SHI, m + sd));
    const ylo = yOf(Math.max(SLO, m - sd));
    ctx.fillStyle = "rgba(167,139,250,0.10)";
    ctx.fillRect(left, yhi, w, ylo - yhi);

    ctx.fillStyle = "#c4b5fd";
    ctx.font = "11px ui-monospace, Menlo, monospace";
    ctx.textAlign = "right";
    ctx.fillText("mean " + m.toFixed(3) + " ± " + sd.toFixed(3), right, ym - 5);
  }
  ctx.restore();
}

function drawLegend() {
  ctx.save();
  const y = canvas.height - 16;
  let x = PAD.l;
  const chip = (color, label, square) => {
    ctx.fillStyle = color;
    if (square) ctx.fillRect(x, y - 8, 11, 11);
    else { ctx.beginPath(); ctx.arc(x + 5.5, y - 2.5, 6, 0, Math.PI * 2); ctx.fill(); }
    ctx.fillStyle = "#cbd5e1";
    ctx.font = "12px Inter, sans-serif";
    ctx.textAlign = "left";
    ctx.textBaseline = "middle";
    ctx.fillText(label, x + 18, y - 2);
    x += 18 + ctx.measureText(label).width + 26;
  };
  // train / validation swatches
  ctx.fillStyle = "rgba(59,130,246,0.55)";
  ctx.fillRect(x, y - 9, 13, 13); ctx.fillStyle = "#cbd5e1";
  ctx.font = "12px Inter, sans-serif"; ctx.textAlign = "left"; ctx.textBaseline = "middle";
  ctx.fillText("train", x + 19, y - 2); x += 19 + ctx.measureText("train").width + 26;

  ctx.fillStyle = "rgba(245,158,11,0.9)";
  ctx.fillRect(x, y - 9, 13, 13); ctx.fillStyle = "#cbd5e1";
  ctx.fillText("validation", x + 19, y - 2); x += 19 + ctx.measureText("validation").width + 30;

  chip("#67e8f9", "class A", true);
  chip("#fbbf24", "class B", false);
  ctx.restore();
}

function roundRect(x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

// ----- Self-check (dev assertion): every sample is validated exactly once -----
function verifyPartition(asg, kk) {
  const fl = foldsFromAssign(asg, kk);
  const seen = new Array(N).fill(0);
  for (let f = 0; f < kk; f++) for (const id of fl[f]) seen[id]++;
  return seen.every(c => c === 1) && fl.length === kk && fl.every(arr => arr.length > 0);
}
for (let kk = 3; kk <= 10; kk++) {
  if (!verifyPartition(partition(kk, false), kk)) {
    // eslint-disable-next-line no-console
    console.error("plain k-fold partition invalid for k=" + kk);
  }
  if (!verifyPartition(partition(kk, true), kk)) {
    // eslint-disable-next-line no-console
    console.error("stratified k-fold partition invalid for k=" + kk);
  }
}

// ----- Controls -----
kInput.addEventListener("input", () => {
  k = parseInt(kInput.value, 10);
  kVal.textContent = String(k);
  rebuild();
});
speedInput.addEventListener("input", () => {
  speedVal.textContent = parseFloat(speedInput.value).toFixed(1) + "×";
});
stratInput.addEventListener("change", () => {
  stratified = stratInput.checked;
  rebuild();
});
runBtn.addEventListener("click", () => { play(); });
stepBtn.addEventListener("click", () => {
  stopPlay();
  if (mode === "single" || (mode === "cv" && current >= k - 1)) {
    current = -1; scores = []; single = null; mode = "cv";
  }
  stepCV();
  syncButtons();
  render();
});
singleBtn.addEventListener("click", () => { doSingle(); render(); });
resetBtn.addEventListener("click", () => { rebuild(); });

// ----- Init -----
kVal.textContent = String(k);
speedVal.textContent = parseFloat(speedInput.value).toFixed(1) + "×";
syncButtons();
updateReadout();
render();

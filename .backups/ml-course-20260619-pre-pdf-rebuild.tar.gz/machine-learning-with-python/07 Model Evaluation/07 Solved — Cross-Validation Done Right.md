# Solved — Cross-Validation Done Right

> Two teammates evaluate the *same* model on the *same* data. One reports 79% accuracy, the other 67%. Neither made an arithmetic error — one of them quietly let the validation data pick the features. This lesson shows which number is real and why.

## Problem statement

You want one honest estimate of how well a model will do on unseen data — not a number that swings with the luck of a single split, and not a number inflated by preprocessing that peeked at the held-out rows. There are two distinct failures to fix here.

First, a **single train/test split is noisy**: change only the random seed and the test accuracy can lurch from 0.58 to 0.75 on a small dataset. You can't tune or compare models on a number that wobbles that much. The fix is **k-fold cross-validation**, which holds out each row exactly once and reports a **mean ± std** over the folds.

Second — and this is the subtle one — cross-validation only tells the truth if **every learned preprocessing step is re-fit inside each fold**. If you scale, select features, or impute on the *whole* dataset before cross-validating, the held-out fold has secretly influenced preprocessing, and your CV score is **leaked and optimistic**. The fix is to wrap preprocessing and the model in a `Pipeline` so `cross_val_score` re-fits the whole chain on each fold's training rows only. We'll measure the exact size of that fake inflation.

## Why this problem matters

Cross-validation is *the* number people quote to decide which model ships, so a leaked CV score is a lie told at the most important moment. The leak is insidious because the code looks innocent — `SelectKBest(...).fit_transform(X, y)` on one line, `cross_val_score(...)` on the next — and the inflated score is exactly the kind of "great offline result" that collapses in production. Worse, with many features and few rows, feature selection on the full dataset can manufacture skill out of pure noise: you'll see CV report high-70s accuracy on data where the honest answer is barely above coin-flip. Knowing to put preprocessing inside a Pipeline — and being able to *prove* the gap — is a non-negotiable evaluation skill that reviewers should enforce on every PR.

## Tiny dataset or sample data

We build the data inline with scikit-learn's `make_classification` (pure NumPy under the hood, no download). The trap is baked in deliberately: only **5 of 500 features carry any signal** and there are just **80 rows**. With that many useless columns, "which features are best?" is a *learned* decision — and learning it from all the rows leaks hard. Shape: `X` = `(80, 500)`, `y` = `(80,)`, perfectly balanced 40/40.

A tiny corner of the matrix (4 rows, first 3 of 500 feature columns):

| row | f0 | f1 | f2 | ... | label |
|----:|------:|------:|------:|:---:|:-----:|
| 0 | -0.07 | -1.29 | +1.35 | ... | 0 |
| 1 | -0.17 | -0.24 | +0.55 | ... | 1 |
| 2 | +1.90 | +0.67 | +1.35 | ... | 1 |
| 3 | -1.29 | +2.24 | -1.31 | ... | 1 |

You can't tell signal from noise by eye — and neither can a model that only has 80 rows to work with. That's exactly why honest evaluation matters here.

## Step-by-step reasoning

1. **Show that one split is a lottery.** Hold out 30% six times, changing only `random_state`, and score each. On 80 rows the test accuracy jumps around by ~0.17 — proof that any single split's number is a coin you happened to flip, not a property of the model.
2. **Cross-validate to average out the luck.** `StratifiedKFold(5)` splits the data into 5 folds; each fold is the validation set once while the other four train. Every row is predicted exactly once. The **mean** is a far more stable estimate and the **std** tells you how much it still wobbles.
3. **Spot the leak: preprocessing that sees all the rows.** `SelectKBest(f_classif, k=10).fit_transform(X, y)` ranks features using the labels of *every* row — including the rows that will later serve as each validation fold. Those folds are no longer unseen; they helped choose the features. Cross-validating on this already-selected matrix gives a fake, optimistic score.
4. **Fix the leak with a `Pipeline`.** Put the selector and the model in `Pipeline([("select", SelectKBest(...)), ("clf", ...)])` and hand the *pipeline* to `cross_val_score`. Now selection is re-fit on each fold's **training rows only**, then merely applied to the held-out fold. The validation data never touches a fitted parameter — that's the **Pipeline Leakage Shield**.
5. **Quantify the inflation.** Print leaky CV mean and honest CV mean side by side. The difference is fake accuracy you cannot ship — and the honest number, even if it's humbling, is the one to trust.

## Python solution

```python
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split, cross_val_score, StratifiedKFold
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline

# --- 1. Inline data (no download): few real signals hidden among many
#     useless columns. With lots of noise features, picking "the best" ones
#     is a LEARNED step -- and learning it from all rows leaks hard.
X, y = make_classification(
    n_samples=80, n_features=500, n_informative=5, n_redundant=0,
    class_sep=1.0, flip_y=0.05, random_state=0)
print("Shape:", X.shape, "| class balance:", np.bincount(y))

clf = LogisticRegression(max_iter=2000)

# --- 2. Why a SINGLE train/test split is noisy: change only random_state. ---
#     (Done the leak-free way: select features on TRAIN, apply to TEST.)
print("\n--- One split is a lottery (same data, same model, different seed) ---")
single = []
for seed in range(6):
    Xtr, Xte, ytr, yte = train_test_split(
        X, y, test_size=0.30, random_state=seed, stratify=y)
    sel = SelectKBest(f_classif, k=10).fit(Xtr, ytr)   # fit on TRAIN only
    acc = clf.fit(sel.transform(Xtr), ytr).score(sel.transform(Xte), yte)
    single.append(acc)
    print(f"  seed={seed}: test accuracy = {acc:.3f}")
single = np.array(single)
print(f"  -> single-split accuracy ranges {single.min():.3f} to "
      f"{single.max():.3f}  (spread {np.ptp(single):.3f})")

# --- 3. Cross-validation: every row is held out exactly once -> mean +/- std.
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=0)

# --- 3a. THE LEAK: pick the "best" features using the WHOLE dataset,
#     THEN cross-validate. The selector ranked features with the labels of
#     rows that later become each validation fold -> the score is fake.
X_leaked = SelectKBest(f_classif, k=10).fit_transform(X, y)   # <-- sees ALL rows
leaky = cross_val_score(clf, X_leaked, y, cv=cv)
print(f"\nLEAKY  CV (select-then-split): {leaky.mean():.3f} +/- {leaky.std():.3f}")

# --- 3b. THE FIX: put the selector INSIDE a Pipeline (the leakage shield).
#     cross_val_score re-fits selection on each fold's TRAINING data only,
#     then transforms the held-out fold. No leakage -> honest estimate.
pipe = Pipeline([
    ("select", SelectKBest(f_classif, k=10)),
    ("clf",    LogisticRegression(max_iter=2000)),
])
honest = cross_val_score(pipe, X, y, cv=cv)
print(f"HONEST CV (Pipeline per fold): {honest.mean():.3f} +/- {honest.std():.3f}")

print(f"\nInflation from the leak: {leaky.mean() - honest.mean():+.3f} "
      f"of FAKE accuracy you cannot ship.")
print(f"And CV's +/-{honest.std():.3f} band is far tighter than the "
      f"single-split spread of {np.ptp(single):.3f} -- one number, less luck.")
```

## Expected output

```
Shape: (80, 500) | class balance: [40 40]

--- One split is a lottery (same data, same model, different seed) ---
  seed=0: test accuracy = 0.708
  seed=1: test accuracy = 0.667
  seed=2: test accuracy = 0.750
  seed=3: test accuracy = 0.667
  seed=4: test accuracy = 0.625
  seed=5: test accuracy = 0.583
  -> single-split accuracy ranges 0.583 to 0.750  (spread 0.167)

LEAKY  CV (select-then-split): 0.787 +/- 0.102
HONEST CV (Pipeline per fold): 0.675 +/- 0.047

Inflation from the leak: +0.112 of FAKE accuracy you cannot ship.
And CV's +/-0.047 band is far tighter than the single-split spread of 0.167 -- one number, less luck.
```

## Explanation of the output

The six single-split runs are the whole argument for cross-validation in one block: same data, same model, same correct (leak-free) preprocessing — the *only* thing that changed is which 30% landed in the test set, and the accuracy swung from **0.583 to 0.750**, a spread of **0.167**. If you'd run once with seed 2 you'd brag about 75%; with seed 5 you'd panic at 58%. Neither is "the" performance — they're both noise around it. Cross-validation cures this by giving a single mean over 5 folds with a `±0.047` band — far tighter than the 0.167 single-split spread, so it's a number you can actually tune and compare on.

Now the leak. The **leaky** CV reports **0.787** and the **honest** Pipeline CV reports **0.675** — a **+0.112** gap of pure fiction. The mechanism: with 500 columns and only 80 rows, `SelectKBest` on the *full* dataset hunts for the 10 columns that best separate *these specific rows*, label noise included; some noise columns get picked precisely because they happen to line up with the validation labels. When those same rows are later "held out," they're not unseen — the feature choice already memorized them. The honest pipeline re-runs selection inside each fold on training rows only, so the chosen features get judged on genuinely fresh data, and the score drops to the truth. That 0.675 is humbling, but it's real; the 0.787 is the number that would crater the moment you deploy.

## Common mistakes

1. **`fit_transform` on the whole `X` before cross-validating.** Scaling, `SelectKBest`, `SimpleImputer`, PCA, target encoding — anything that *learns* from data — leaks if it sees all the rows first. Fix: put every such step **inside the Pipeline** so it re-fits per fold.
2. **Trusting a single train/test split.** One split's accuracy can be off by 0.15+ on small data, so tuning or comparing on it is gambling. Fix: report cross-validated **mean ± std**.
3. **Reporting only the CV mean and hiding the std.** A model at `0.72 ± 0.03` is trustworthy; `0.72 ± 0.15` is barely measured. Fix: always quote (and read) the spread.
4. **Not stratifying classification folds.** Plain `KFold` can hand a fold almost no positives, wrecking the estimate. Fix: use `StratifiedKFold` (and `shuffle=True` when rows are ordered).
5. **Tuning hyperparameters on the *same* CV you then report as the final score.** Selecting the best config on those folds quietly fits to them. Fix: use **nested CV** or a separate held-out test set for the headline number.

## Extension challenge

1. Replace the manual leaky/honest comparison with `cross_validate(pipe, X, y, cv=cv, return_train_score=True)` and inspect the train-vs-validation gap per fold — a big gap flags overfitting even when the mean looks fine.
2. Swap `SelectKBest` for `StandardScaler` and rerun. The leak shrinks dramatically (a scaler only learns mean/std, not which features to keep). Explain why *feature selection* leaks so much harder than scaling.
3. Wrap the whole pipeline in `GridSearchCV(pipe, {"select__k": [5, 10, 20, 50]}, cv=cv)` to let cross-validation choose `k` honestly. Confirm `best_params_` and that the leakage shield still holds because selection lives inside the searched pipeline.

## Matching animation

**Cross Validation Fold Animator** — step through 5 folds and watch each block of rows light up as the validation set exactly once while the rest train, with the running mean ± std assembling fold by fold. Toggle the **Pipeline Leakage Shield**: with it off, you see preprocessing fit on the *whole* strip (the held-out fold glows "contaminated") and the score inflate; with it on, preprocessing re-fits on just the training rows of each fold and the held-out block stays untouched — the visual twin of the 0.787-vs-0.675 gap this lesson prints.

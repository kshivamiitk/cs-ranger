# Classification Metrics Beyond Accuracy

> On a dataset where 99% of emails are not spam, a model that flags *nothing* as spam is 99% accurate — and completely worthless. Accuracy alone lies, and this lesson gives you the metrics that don't.

## What you'll learn
- How to read a **confusion matrix** (TP, FP, FN, TN) — the source of every other metric.
- **Precision**, **recall**, and **F1** — what each measures and when to optimize which.
- **ROC-AUC** — a threshold-independent measure of ranking quality.
- Why accuracy is misleading on **imbalanced** data, and how `classification_report` summarizes it all.

## Intuition

Every binary prediction lands in one of four boxes, summarized by the **confusion matrix**:

```
                 Predicted 0        Predicted 1
Actual 0      TN (true neg)      FP (false pos)   <- false alarm
Actual 1      FN (false neg)     TP (true pos)    <- miss
```

- **TP** — predicted positive, truly positive (a caught fraud).
- **FP** — predicted positive, truly negative (a *false alarm* — flagged a legit charge).
- **FN** — predicted negative, truly positive (a *miss* — let fraud through).
- **TN** — predicted negative, truly negative (correctly ignored a legit charge).

From these four numbers everything follows. **Accuracy** = `(TP + TN) / total` — the fraction correct. Fine when classes are balanced; dangerous when not, because predicting the majority class always gets you the majority's share for free.

- **Precision** = `TP / (TP + FP)` — *of everything I flagged positive, how much really was?* High precision = few false alarms. Optimize it when false positives are costly (spam filter dumping real email; flagging a good customer as fraud).
- **Recall** (sensitivity) = `TP / (TP + FN)` — *of everything that's truly positive, how much did I catch?* High recall = few misses. Optimize it when false negatives are costly (missing a tumor, letting fraud through).
- **F1** = the harmonic mean of precision and recall, `2 * P * R / (P + R)`. A single number that's only high when *both* are high — your go-to when you care about the positive class and want balance.

**Precision and recall trade off** against each other via the threshold: raise the threshold and you flag fewer, more-certain positives (precision up, recall down); lower it and you catch more positives but with more false alarms (recall up, precision down). You can't usually max both.

**ROC-AUC** sidesteps the threshold entirely. The ROC curve plots true-positive rate against false-positive rate as you sweep the threshold from 0 to 1; the **area under it (AUC)** measures how well the model *ranks* positives above negatives. AUC = 1.0 is perfect, 0.5 is random coin-flipping. Because it uses probabilities across all thresholds, AUC tells you the model's discriminative power independent of where you eventually set the cut.

## Python in practice

We build a deliberately **imbalanced** dataset (10% positives), then show accuracy fooling us while precision/recall/F1/AUC tell the truth.

```python
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (confusion_matrix, classification_report,
                             roc_auc_score, accuracy_score)

# 10% positive class -> imbalanced
X, y = make_classification(n_samples=2000, weights=[0.9, 0.1],
                           n_informative=5, random_state=0)
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.3, random_state=0, stratify=y)

clf = LogisticRegression(max_iter=2000).fit(X_tr, y_tr)
y_pred = clf.predict(X_te)
y_proba = clf.predict_proba(X_te)[:, 1]   # needed for ROC-AUC

print("Confusion matrix [[TN FP] [FN TP]]:")
print(confusion_matrix(y_te, y_pred))
print("\nAccuracy:", round(accuracy_score(y_te, y_pred), 3))
print("ROC-AUC :", round(roc_auc_score(y_te, y_proba), 3))
print("\n", classification_report(y_te, y_pred, digits=3))

# Compare against a 'dumb' model that always predicts the majority class (0):
dumb_acc = np.mean(y_te == 0)
print("Always-predict-0 accuracy:", round(dumb_acc, 3))
```

Expected output (approximate):

```
Confusion matrix [[TN FP] [FN TP]]:
[[535   5]
 [ 22  38]]

Accuracy: 0.955
ROC-AUC : 0.965

              precision    recall  f1-score   support
           0      0.961     0.991     0.976       540
           1      0.884     0.633     0.738        60
    accuracy                          0.955       600
   macro avg      0.922     0.812     0.857       600
weighted avg      0.953     0.955     0.953       600

Always-predict-0 accuracy: 0.9
```

Read it carefully. Accuracy is 0.955 — but the *useless* always-say-0 model already scores 0.90, so the model added only 5.5 points by that measure. The real story is in the class-1 row: **recall 0.633** means it misses ~37% of the actual positives (the 22 FN). If those positives are fraud or disease, that's a serious problem accuracy completely hides. ROC-AUC of 0.965 says the model *ranks* positives well, so lowering the threshold could trade some precision for much-needed recall.

## Common mistakes

- **Reporting only accuracy on imbalanced data.** It rewards predicting the majority class. Always pair it with precision/recall/F1 (and a baseline like always-predict-majority).
- **Confusing precision and recall.** Precision = "of my positives, how many were right"; recall = "of the real positives, how many I caught." Mixing them up flips your conclusions.
- **Computing ROC-AUC from labels instead of probabilities.** AUC needs `predict_proba`/`decision_function` scores, not the 0/1 `predict` output, or it's meaningless.
- **Treating the 0.5 threshold as fixed.** If recall matters, lower the threshold; the confusion matrix and metrics shift accordingly. Choose the threshold for *your* costs.
- **Reading the confusion matrix axes wrong.** Sklearn's `confusion_matrix` rows are actual, columns predicted, order `[0, 1]` — so it's `[[TN, FP], [FN, TP]]`. Print labels to be sure.

## Small exercise

Using `y_proba` from above, recompute predictions at a threshold of 0.3 (`(y_proba > 0.3).astype(int)`) and print the new confusion matrix and `classification_report`. Recall for class 1 should rise (you catch more positives) while precision falls (more false alarms). You've just performed the precision/recall trade-off by hand — exactly what the Confusion Matrix Explorer in this module lets you do with a slider.

## Before you continue
- [ ] I can label every cell of a confusion matrix (TP, FP, FN, TN) and give a real example of each.
- [ ] I can define precision, recall, and F1 and say when to optimize each.
- [ ] I can explain what ROC-AUC measures and why it needs probabilities.
- [ ] I can explain, with a concrete example, why accuracy misleads on imbalanced data.

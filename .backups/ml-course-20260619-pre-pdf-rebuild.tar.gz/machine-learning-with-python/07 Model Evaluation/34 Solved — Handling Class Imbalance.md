# Solved — Handling Class Imbalance

> A risk team ships a loan-default model that's 90% accurate and the dashboard glows green — but it catches barely one defaulter in five. Here's how to see the trap, then fix the recall without throwing the model away.

## Problem statement

We have a loan book where only about **10% of borrowers default** (`default = 1`); the other 90% repay cleanly (`default = 0`). We train a classifier and need to evaluate it *honestly* and then *improve* it on the metric that matters. The catch: the positive class (default) is rare, so a model can post a high accuracy while quietly missing most of the defaulters — exactly the borrowers the business needs to flag.

The task is three steps: (a) show that **accuracy is misleading** on skewed data by comparing the model to a do-nothing baseline; (b) report **precision, recall, F1, and the confusion matrix** for the positive class so the misses become visible; and (c) apply at least two fixes — **`class_weight='balanced'`** and **threshold tuning** (with resampling/SMOTE noted conceptually) — and show **recall and F1 improving**.

## Why this problem matters

The events you most want to catch — defaults, fraud, equipment failure, disease — are usually **rare**, and rarity is precisely what breaks accuracy. A model that predicts "no default" for everyone is automatically ~90% accurate here and catches **zero** defaulters, so it is simultaneously impressive on the headline number and worthless in production. Worse, the costs are asymmetric: a missed defaulter (a false negative) can mean a charged-off loan worth thousands, while a false positive only means a manual review or a slightly stricter offer. Until you measure recall and precision on the rare class — and deliberately spend a little precision to buy recall — you are flying blind on the metric that actually moves money.

## Tiny dataset or sample data

We generate a realistic, *overlapping* cohort in memory with `make_classification` (no download). A small inline peek at what the rows look like after generation:

| age_norm | marker_a | marker_b | marker_c | marker_d | marker_e | default |
|---------:|---------:|---------:|---------:|---------:|---------:|--------:|
|   −0.41  |   1.32   |  −0.88   |   0.05   |   0.74   |  −1.10   |    0    |
|    0.96  |  −0.22   |   1.41   |  −1.03   |  −0.18   |   0.62   |    1    |
|   −1.18  |   0.07   |  −0.34   |   0.91   |  −0.55   |   0.29   |    0    |
|    0.33  |   1.08   |   0.77   |  −0.46   |   1.22   |  −0.71   |    1    |
|    0.12  |  −0.91   |  −1.20   |   0.38   |  −0.09   |   0.44   |    0    |

Shape: **`(2000, 6)` features + 1 label column**, with a **positive (default) rate ≈ 0.10**. The classes deliberately *overlap* (`class_sep=0.8`, a little label noise), so the rare class is genuinely hard to separate — which is what forces the plain model to miss defaulters and gives the fixes something real to repair.

## Step-by-step reasoning

1. **Name the positive class and the goal metric.** Positive = `default = 1`. Because a missed defaulter costs far more than a needless review, the headline metric is **recall on class 1**, with precision and F1 as guardrails. Accuracy is explicitly *not* the goal.
2. **Build the do-nothing baseline to expose the trap.** Predict `0` (no default) for every test borrower. Its accuracy equals the fraction of negatives (~0.90), and its recall is **0.0**. Seeing those two numbers side by side is the whole lesson: accuracy rewards laziness on imbalanced data.
3. **Train a plain model and read the confusion matrix.** A default `LogisticRegression` at the 0.50 threshold will look about as accurate as the baseline, but the confusion matrix reveals a large **FN** cell — the defaulters it silently missed. That gap between "accuracy" and "recall" is the bug to fix.
4. **Fix A — re-weight the loss with `class_weight='balanced'`.** This tells the model that each rare-class mistake counts roughly `n_neg / n_pos` times as much as a majority-class mistake, so the optimizer stops ignoring the minority. Recall jumps; precision usually falls (more false alarms) — an honest trade.
5. **Fix B — tune the decision threshold.** `.predict` hard-codes 0.50, but that is an arbitrary cutoff, not a business decision. Lowering it (0.30, 0.20, …) flags more borrowers, raising recall at the cost of precision. We read the precision/recall trade off a sweep and pick the threshold for our target, rather than accepting the default.
6. **Mention the third lever — resampling.** Oversampling the minority (or SMOTE, which synthesizes new minority points between neighbors) and undersampling the majority are alternative fixes that rebalance the *data* instead of the *loss* or the *threshold*. They often help, but must be applied **inside cross-validation on the training fold only**, never before the split, or they leak.

## Python solution

```python
import numpy as np
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import (accuracy_score, precision_score, recall_score,
                             f1_score, confusion_matrix, classification_report,
                             precision_recall_curve)

# --- 1. Build an imbalanced, OVERLAPPING loan book in memory (no download). ---
# weights=[0.90, 0.10] -> ~10% positives (the rare "default" class).
# class_sep + flip_y create real overlap, so the rare class is HARD to catch.
X, y = make_classification(
    n_samples=2000, n_features=6, n_informative=4, n_redundant=0,
    n_clusters_per_class=1, weights=[0.90, 0.10], flip_y=0.02,
    class_sep=0.8, random_state=42)
print("Shape:", X.shape, "| positive (default) rate:", round(y.mean(), 3))

# Stratify so the rare class is represented in both splits.
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.30, random_state=42, stratify=y)
print("Test positives:", int(y_te.sum()), "of", len(y_te))

# --- 2. The accuracy trap: predict "no default" for EVERYONE. ---
y_never = np.zeros_like(y_te)
print("\n[Always-negative baseline]")
print("  accuracy:", round(accuracy_score(y_te, y_never), 3),
      "| recall:", round(recall_score(y_te, y_never, zero_division=0), 3))

# --- 3. Plain logistic regression at the default 0.50 threshold. ---
plain = LogisticRegression(max_iter=2000, random_state=42)
plain.fit(X_tr, y_tr)
pred_plain = plain.predict(X_te)
tn, fp, fn, tp = confusion_matrix(y_te, pred_plain, labels=[0, 1]).ravel()
print("\n[Plain LogisticRegression @0.50]")
print("  accuracy :", round(accuracy_score(y_te, pred_plain), 3),
      "  <- as high as the do-nothing baseline!")
print("  precision:", round(precision_score(y_te, pred_plain, zero_division=0), 3),
      "| recall:", round(recall_score(y_te, pred_plain, zero_division=0), 3),
      "| f1:", round(f1_score(y_te, pred_plain, zero_division=0), 3))
print(f"  confusion: TN={tn} FP={fp} FN={fn} TP={tp}   (FN = defaulters missed)")

# --- 4. FIX A: class_weight='balanced' makes rare-class errors count more. ---
bal = LogisticRegression(max_iter=2000, random_state=42, class_weight="balanced")
bal.fit(X_tr, y_tr)
pred_bal = bal.predict(X_te)
tn, fp, fn, tp = confusion_matrix(y_te, pred_bal, labels=[0, 1]).ravel()
print("\n[FIX A: class_weight='balanced' @0.50]")
print("  precision:", round(precision_score(y_te, pred_bal, zero_division=0), 3),
      "| recall:", round(recall_score(y_te, pred_bal, zero_division=0), 3),
      "| f1:", round(f1_score(y_te, pred_bal, zero_division=0), 3))
print(f"  confusion: TN={tn} FP={fp} FN={fn} TP={tp}")

# --- 5. FIX B: tune the threshold on the PLAIN model's probabilities. ---
proba = plain.predict_proba(X_te)[:, 1]
print("\n[FIX B: threshold tuning on the plain model]")
print("  thr    prec   rec    f1")
for thr in (0.50, 0.30, 0.20, 0.15):
    yp = (proba >= thr).astype(int)
    p = precision_score(y_te, yp, zero_division=0)
    r = recall_score(y_te, yp, zero_division=0)
    f = f1_score(y_te, yp, zero_division=0)
    print(f"  {thr:0.2f}   {p:0.3f}  {r:0.3f}  {f:0.3f}")

# Pick the LOWEST threshold whose precision still holds >= 0.50, report it.
prec, rec, thr = precision_recall_curve(y_te, proba)
keep = [t for p, r, t in zip(prec[:-1], rec[:-1], thr) if p >= 0.50]
chosen = min(keep)
print(f"\n[Chosen threshold {chosen:0.2f} = lowest with precision >= 0.50]")
print(classification_report(y_te, (proba >= chosen).astype(int),
                            digits=2, zero_division=0))

# Conceptual note: resampling/SMOTE is a third lever. With imbalanced-learn:
#   from imblearn.over_sampling import SMOTE
#   X_res, y_res = SMOTE(random_state=42).fit_resample(X_tr, y_tr)  # TRAIN ONLY
# then fit a plain model on the rebalanced training data.
```

## Expected output

Running it prints roughly (numbers are reproducible thanks to `random_state`):

```
Shape: (2000, 6) | positive (default) rate: 0.104
Test positives: 63 of 600

[Always-negative baseline]
  accuracy: 0.895 | recall: 0.0

[Plain LogisticRegression @0.50]
  accuracy : 0.895   <- as high as the do-nothing baseline!
  precision: 0.5 | recall: 0.19 | f1: 0.276
  confusion: TN=525 FP=12 FN=51 TP=12   (FN = defaulters missed)

[FIX A: class_weight='balanced' @0.50]
  precision: 0.271 | recall: 0.762 | f1: 0.4
  confusion: TN=408 FP=129 FN=15 TP=48

[FIX B: threshold tuning on the plain model]
  thr    prec   rec    f1
  0.50   0.500  0.190  0.276
  0.30   0.438  0.444  0.441
  0.20   0.396  0.635  0.488
  0.15   0.323  0.651  0.432

[Chosen threshold 0.33 = lowest with precision >= 0.50]
              precision    recall  f1-score   support
           0       0.93      0.95      0.94       537
           1       0.50      0.41      0.45        63
    accuracy                           0.90       600
```

## Explanation of the output

The first two blocks are the trap, made undeniable: the **always-negative baseline scores 0.895 accuracy with 0.0 recall**, and the **plain model scores the *exact same* 0.895 accuracy** — yet its confusion matrix shows **FN = 51**, meaning it missed 51 of the 63 real defaulters (recall just 0.19). A naive reader would call the plain model "90% accurate and shipping"; the recall number says it catches fewer than one defaulter in five.

Both fixes attack that FN cell. **`class_weight='balanced'`** re-weights the loss so the rare class can't be ignored: recall leaps from **0.19 → 0.76** (TP rises from 12 to 48, FN falls from 51 to 15) and **F1 climbs 0.28 → 0.40**. The honest cost is precision dropping to 0.27 — it now raises 129 false alarms — which is fine when a review is cheap and a charge-off is not. **Threshold tuning** tells the same story from the other direction: as the cutoff drops 0.50 → 0.20, recall rises 0.19 → 0.64 and F1 peaks around 0.49, with precision sliding as expected. The "precision ≥ 0.50" rule lands at threshold ~0.33, a balanced compromise. The lesson: accuracy hid the problem; recall, F1, and the confusion matrix exposed it; and re-weighting or re-thresholding fixed it — each spending precision to buy the recall the business actually needs.

## Common mistakes

1. **Reporting accuracy as the headline on imbalanced data.** It rewards predicting the majority class and can equal the do-nothing baseline. *Fix:* always show recall + precision (and F1) for the positive class, alongside the always-majority baseline, so the misses are visible.
2. **Leaving the threshold at 0.50.** The default minimizes raw error count, not missed positives. *Fix:* sweep the threshold and pick it from your precision/recall target or a cost model — 0.50 is a starting point, not a decision.
3. **Resampling (or SMOTE) before the train/test split.** Synthesizing minority points using the whole dataset leaks test information into training and inflates your scores. *Fix:* resample **inside cross-validation, on the training fold only** (e.g., an `imblearn` Pipeline), never on the full data.
4. **Treating `class_weight='balanced'` as free.** It raises recall by *accepting more false positives*, so precision falls. *Fix:* check precision after balancing and confirm the extra false alarms are affordable for your use case.
5. **Optimizing recall in isolation.** Flagging everyone gives recall 1.0 and a flood of false positives. *Fix:* pair recall with a precision floor (or F1, or expected cost) so the model stays useful.

## Extension challenge

1. Install `imbalanced-learn` and rebalance the **training fold** with `SMOTE`, then fit a plain `LogisticRegression`. Compare its default-threshold recall and precision to Fix A and Fix B — does synthetic oversampling beat re-weighting on this data?
2. Combine the two fixes already shown: take the `class_weight='balanced'` model and *also* tune its threshold. Can you reach recall ≥ 0.80 while keeping precision ≥ 0.40?
3. Replace the implicit equal-error assumption with an explicit cost matrix (a missed default costs 15× a false alarm). Sweep the threshold, compute expected cost at each, and report the **cost-minimizing** threshold — then check what recall it implies.

## Matching animation

**Class Imbalance Accuracy Trap** (`55 Animation — Class Imbalance Accuracy Trap`) — slide the minority-class fraction down toward 10% and watch the "always predict majority" accuracy bar climb toward 90% while its recall bar stays pinned at zero. The animation makes the central deceit physical: as the positives get rarer, the lazy model's accuracy *rises* even though it is catching fewer and fewer of the cases you care about, which is exactly why this lesson reports recall and F1 instead.

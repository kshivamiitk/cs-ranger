# Precision

> When your model raises its hand and says "this one is positive," precision is the question: *how often is it telling the truth?*

## What is this?

Precision answers one narrow, very practical question about the predictions your model **flagged as positive**:

> Of all the things I flagged, what fraction were actually right?

The formula is short:

```
Precision = TP / (TP + FP)
```

- **TP** (true positives) — flagged positive, and it *was* positive. A correct catch.
- **FP** (false positives) — flagged positive, but it was actually negative. A *false alarm*.

Notice what is *not* in the formula: the things you didn't flag. Precision doesn't care about what you missed. It only grades the quality of your "yes" answers. If you flag 10 emails as spam and 8 really were spam, your precision is 8/10 = 0.80 — full stop, regardless of how many spam emails you let slip into the inbox.

That single-mindedness is the point. Precision is the metric of the false alarm.

## Why do we need it?

Because **accuracy hides the cost of being wrong in the wrong direction.** A model can be 99% accurate and still ruin the user experience if its few mistakes are all false alarms aimed at people who did nothing wrong.

Imagine a spam filter that is aggressive: it catches every spam email but also dumps one important work email into the spam folder every week. Accuracy looks great. But the false positives — the real emails wrongly flagged — are the ones that cost you a job offer or a missed invoice. Precision is the number that surfaces that pain. It tells you, of everything the filter quarantined, how much was actually junk.

We need precision whenever **acting on a positive prediction is expensive, annoying, or destructive**: it costs money, it interrupts a person, it blocks a transaction, it sends a human to investigate. Each false positive in those settings has a real-world bill attached, and precision is the dial that measures it.

## Where it's used in real ML

- **Spam / content moderation** — Every legitimate message wrongly sent to the spam folder is a false positive. High precision keeps real mail out of the junk pile.
- **Fraud alerts on a credit card** — Each declined-but-legitimate purchase or "was this you?" text is a false positive that annoys a paying customer. Banks watch precision so they don't alienate good users.
- **Search and recommendations** — The top results you actually show. If only 7 of the top 10 results are relevant, your precision@10 is 0.70. Users judge you on what you put in front of them, not on what you left out.
- **Targeted marketing / ad spend** — If you flag a customer as "likely to buy" and spend money contacting them, every false positive is wasted budget.
- **Medical *confirmation* tests** — An expensive, invasive follow-up procedure should only fire on people who likely have the condition; false positives mean painful, costly procedures on healthy people.

## What breaks if you ignore it

If you optimize blindly for catching everything and never look at precision, your model becomes the **boy who cried wolf**. It floods humans with false alarms, and three bad things happen:

1. **Alert fatigue.** Analysts and users stop trusting the flags and start ignoring them — so even the *correct* alerts get dismissed.
2. **Wasted resources.** Every false positive triggers a real cost: a declined card, a manual review, a wasted ad, an unnecessary procedure.
3. **Eroded trust.** Users who get burned by false alarms churn. A fraud system that blocks too many real purchases pushes customers to a competitor's card.

A classifier that predicts "positive" for *everything* has perfect recall and worthless precision. Ignoring precision is how you ship exactly that and call it a success.

## Mental model

Think of precision as the **accuracy of your accusations**.

```
        Everything the model SHOUTED "positive!" about
        ┌─────────────────────────────────────────────┐
        │   TP TP TP TP TP TP TP TP   │   FP FP        │
        │   (you were right)          │   (false alarm)│
        └─────────────────────────────────────────────┘
                 Precision = the GREEN slice
                            ─────────────────
                          all the things you flagged
```

A prosecutor with high precision rarely charges an innocent person — *when they accuse someone, they're usually right*. They might let some guilty people go free (that's recall's problem, not precision's), but the people they do accuse are almost always guilty. Precision is the prosecutor who would rather stay quiet than make a false accusation.

## Example 1 — Tiny toy example

A spam filter looks at 30 emails. We only care about its "this is spam" decisions. Here is the confusion matrix for the **spam (positive)** class:

```
                  Predicted: spam     Predicted: not spam
Actually spam          TP = 8               FN = 4
Actually not spam      FP = 2               TN = 16
```

The filter flagged **10 emails** as spam (the whole "Predicted: spam" column: 8 + 2). Of those:

- **8 were truly spam** → TP = 8
- **2 were real emails it wrongly junked** → FP = 2

Compute precision by hand:

```
Precision = TP / (TP + FP)
          = 8  / (8 + 2)
          = 8  / 10
          = 0.80
```

So **80% of the emails this filter quarantined were genuinely spam**, and 20% were real emails the user might never see. Note that the 4 spam emails it *missed* (FN) and the 16 it correctly left alone (TN) play **no part** in precision. Precision only grades the column it flagged.

## Example 2 — Practical ML example

A bank deploys a fraud model that screens **100,000 transactions** in a day and flags suspicious ones for an instant "Was this you?" push notification. The flagged column comes out as:

- It sent **5,000 notifications** (predicted-fraud).
- Of those, **1,500 were genuinely fraudulent** (TP = 1,500).
- The other **3,500 were perfectly legitimate purchases** the customer was trying to make (FP = 3,500).

```
Precision = 1500 / (1500 + 3500) = 1500 / 5000 = 0.30
```

Precision is **0.30** — only 30% of the alarms were real fraud. Two out of every three notifications interrupted a paying customer mid-checkout for nothing. Even if this model has wonderful recall (catches almost all fraud), the **low precision is a business emergency**: customers get annoyed, abandon carts, and call support to complain. The fix is usually to raise the decision threshold so the model only flags transactions it's *very* confident about — fewer alerts, but a much higher fraction of them real. That is the precision lever, and it's why precision is the metric product teams stare at when "users are complaining about false alarms."

## Python code example

```python
from sklearn.metrics import precision_score, confusion_matrix

# Inline data: 1 = positive (spam / fraud), 0 = negative (legit).
# y_true = the real labels; y_pred = what the model flagged.
y_true = [1, 1, 1, 1, 0, 0, 0, 0, 0, 0]   # 4 real positives, 6 real negatives
y_pred = [1, 1, 1, 0, 1, 1, 0, 0, 0, 0]   # the model's "positive" calls

# Confusion matrix is laid out as [[TN, FP], [FN, TP]] for labels [0, 1].
tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()
print(f"TP={tp}  FP={fp}  FN={fn}  TN={tn}")   # TP=3  FP=2  FN=1  TN=4

# Precision = TP / (TP + FP): of everything we FLAGGED, how much was right?
precision_by_hand = tp / (tp + fp)
print(f"Precision by hand : {precision_by_hand:.2f}")          # 0.60

# sklearn computes the same thing. pos_label=1 means we grade the positive class.
print(f"Precision (sklearn): {precision_score(y_true, y_pred):.2f}")  # 0.60

# Watch precision climb when we only flag what we're SURE about.
# A pickier model: it flags fewer items, but every flag is correct.
y_pred_picky = [1, 1, 0, 0, 0, 0, 0, 0, 0, 0]   # only 2 flags, both true spam
print(f"Picky precision   : {precision_score(y_true, y_pred_picky):.2f}")  # 1.00
# Lesson: fewer, more-confident "yes" answers => higher precision (false alarms drop).
```

## Common mistakes

- **Confusing precision with recall.** Precision is "of what I flagged, how much was right." Recall is "of the real positives, how much did I catch." They answer opposite questions — mixing them flips your conclusion.
- **Forgetting precision is undefined when you flag nothing.** If TP + FP = 0 (the model never says "positive"), precision is 0/0. sklearn returns 0 and warns; don't read that as a meaningful score.
- **Chasing 100% precision by flagging almost nothing.** You can always boost precision by only flagging the one case you're surest about — but you'll miss everything else. Precision must be read alongside recall.
- **Grading the wrong class.** By default `precision_score` measures the positive class (label 1). If your positive class is encoded as 0, or it's multiclass, set `pos_label` / `average` correctly or you'll measure the wrong thing.
- **Reporting precision on the majority class and feeling good.** On imbalanced data the easy, uninteresting class inflates the average. Look at precision *for the class you actually care about*.

## Before you continue
- [ ] I can state, in one sentence, that precision = "of the things I flagged, how many were right?"
- [ ] I can write the formula TP / (TP + FP) from memory and explain why FN and TN are not in it.
- [ ] I can name two real situations where a false positive is genuinely costly.
- [ ] I can explain why a model that flags everything has terrible precision.
- [ ] I understand that raising the decision threshold usually raises precision (fewer, surer flags).

# Solved — Interpreting a Multiclass Confusion Matrix

> A single accuracy number tells you *how often* a 3-class model is wrong. A confusion matrix tells you *which* classes it mixes up — and that's the difference between "the model is 75% accurate" and "the model routes three out of four technical tickets to the billing team."

## Problem statement

A support desk auto-routes tickets to one of three teams — **billing**, **shipping**, or **technical** — using four cheap features per ticket (`refund_words`, `delivery_words`, `error_words`, `msg_len`). We fit a classifier, predict on a held-out set, and build the **3×3 confusion matrix**. Then we *read* it: rows are the **true** class, columns are the **predicted** class, the **diagonal** is correct routings, and every **off-diagonal** cell is a specific kind of mistake ("true X, sent to Y"). From the matrix alone we compute **per-class precision and recall**, and identify the **most-confused pair** of classes so the team knows exactly where the model leaks.

The goal isn't a single score — it's a diagnosis. Two models with identical accuracy can fail in completely different places, and only the matrix shows you where.

## Why this problem matters

In any multiclass system — ticket routing, document tagging, disease subtyping, product categorization — "accuracy" hides the failure that actually costs money. A confusion matrix turns an aggregate number into an actionable map: it tells you which class is being over-predicted (hurting its **precision**), which class is being missed (hurting its **recall**), and *which other class* is stealing its examples. That last fact — the most-confused pair — is what drives the fix: maybe those two classes share vocabulary, maybe they need a new distinguishing feature, maybe they should be merged. Every per-class metric in `classification_report` is just a ratio of cells in this matrix, so learning to read it by hand demystifies the entire evaluation stack.

## Tiny dataset or sample data

The full inline set has **30 rows** (10 per class), shape `(30, 5)`, columns `refund_words, delivery_words, error_words, msg_len, category`. A sample:

| refund_words | delivery_words | error_words | msg_len | category  |
|-------------:|---------------:|------------:|--------:|-----------|
|            4 |              0 |           1 |      60 | billing   |
|            2 |              0 |           3 |      70 | billing   |
|            0 |              5 |           0 |      60 | shipping  |
|            1 |              4 |           1 |      62 | shipping  |
|            2 |              0 |           4 |      90 | technical |
|            3 |              0 |           3 |      85 | technical |

The overlap is intentional: **shipping** is easy to separate (it's the only class with `delivery_words`), but **billing** and **technical** share signals — billing tickets often mention errors on the payment page, and technical tickets often mention refunds for broken items. That shared vocabulary is exactly what a confusion matrix will expose.

## Step-by-step reasoning

1. **Fix the label order before anything else.** With strings like `billing/shipping/technical`, the matrix rows and columns follow whatever order you pass to `labels=[...]`. Pin it explicitly so row *i* and column *i* always mean the same class — otherwise every cell you read is ambiguous.
2. **Build the matrix with rows = TRUE, cols = PREDICTED.** This is sklearn's convention. Cell `(i, j)` counts items whose **true** class is `labels[i]` but were **predicted** as `labels[j]`. The diagonal `(i, i)` is correct; everything else is a labeled mistake.
3. **Read recall along a row, precision down a column.** For class *i*: `TP = cm[i, i]`; `FN = (rest of row i)` are true-*i* items sent elsewhere → **recall = TP / (TP + FN)**; `FP = (rest of column i)` are other classes wrongly sent to *i* → **precision = TP / (TP + FP)**. Same matrix, two different directions.
4. **Find the most-confused pair.** Zero out the diagonal and take the largest remaining cell. That single number — "true A predicted as B, N times" — is usually the highest-leverage thing to fix.
5. **Cross-check against `classification_report`.** Your hand-computed precision/recall must match sklearn's to the decimal. If they don't, you read an axis backward — a sign you should re-pin `labels`.

## Python solution

```python
import io
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix, classification_report

# --- 3-class support-ticket routing. billing & technical share vocabulary
#     (refunds for broken items, errors on the billing page) so the model
#     genuinely confuses them; shipping is more separable. No download. ---
csv = """refund_words,delivery_words,error_words,msg_len,category
4,0,1,60,billing
3,0,2,80,billing
4,0,0,55,billing
2,0,3,70,billing
5,0,1,75,billing
3,0,2,65,billing
2,0,3,90,billing
4,0,1,50,billing
3,0,2,72,billing
2,0,2,68,billing
0,5,0,60,shipping
1,4,0,55,shipping
0,6,1,80,shipping
0,4,0,45,shipping
1,5,0,70,shipping
0,3,0,50,shipping
2,4,0,65,shipping
0,5,0,58,shipping
1,4,1,62,shipping
0,5,0,54,shipping
2,0,4,90,technical
3,0,3,85,technical
1,0,5,100,technical
2,0,4,70,technical
3,0,3,95,technical
1,0,4,60,technical
2,0,5,88,technical
3,0,3,92,technical
2,0,4,78,technical
1,0,5,84,technical
"""
df = pd.read_csv(io.StringIO(csv))
print("Shape:", df.shape)
print("Class counts:")
print(df["category"].value_counts().sort_index().to_string())

features = ["refund_words", "delivery_words", "error_words", "msg_len"]
X = df[features]
y = df["category"]

# Stratify so every class appears in train AND test on this small set.
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.40, random_state=1, stratify=y)

clf = Pipeline([
    ("scale", StandardScaler()),
    ("lr", LogisticRegression(max_iter=1000, random_state=1)),
])
clf.fit(X_tr, y_tr)

# --- Pin the label order so rows/cols always mean the same class. ---
labels = ["billing", "shipping", "technical"]
y_pred = clf.predict(X_te)
cm = confusion_matrix(y_te, y_pred, labels=labels)
print("\nOverall accuracy:", round((y_pred == y_te.values).mean(), 3))

# --- Print the matrix: rows = TRUE, cols = PREDICTED. ---
print("\nConfusion matrix (rows = TRUE, cols = PREDICTED):")
print("true\\pred   " + "  ".join(f"{l:>9s}" for l in labels))
for i, l in enumerate(labels):
    print(f"{l:>9s}   " + "  ".join(f"{cm[i, j]:9d}" for j in range(len(labels))))

# --- Per-class precision/recall computed straight from the matrix. ---
print("\nPer-class metrics computed by hand from the matrix:")
for i, l in enumerate(labels):
    tp = cm[i, i]
    fn = cm[i, :].sum() - tp          # true l, predicted as something else
    fp = cm[:, i].sum() - tp          # predicted l, but truly another class
    rec = tp / (tp + fn) if (tp + fn) else 0.0
    prec = tp / (tp + fp) if (tp + fp) else 0.0
    print(f"  {l:9s} TP={tp} FP={fp} FN={fn}  precision={prec:.2f} recall={rec:.2f}")

# --- Most-confused pair = largest off-diagonal cell. ---
off = cm.copy()
np.fill_diagonal(off, 0)
i, j = np.unravel_index(off.argmax(), off.shape)
print(f"\nMost-confused pair: TRUE '{labels[i]}' predicted as '{labels[j]}'"
      f" ({off[i, j]} time(s))")

# --- Cross-check: sklearn should match the by-hand numbers exactly. ---
print("\nsklearn's classification_report:")
print(classification_report(y_te, y_pred, labels=labels, digits=2,
                            zero_division=0))
```

## Expected output

```
Shape: (30, 5)
Class counts:
category
billing      10
shipping     10
technical    10

Overall accuracy: 0.75

Confusion matrix (rows = TRUE, cols = PREDICTED):
true\pred     billing   shipping  technical
  billing           4          0          0
 shipping           0          4          0
technical           3          0          1

Per-class metrics computed by hand from the matrix:
  billing   TP=4 FP=3 FN=0  precision=0.57 recall=1.00
  shipping  TP=4 FP=0 FN=0  precision=1.00 recall=1.00
  technical TP=1 FP=0 FN=3  precision=1.00 recall=0.25

Most-confused pair: TRUE 'technical' predicted as 'billing' (3 time(s))

sklearn's classification_report:
              precision    recall  f1-score   support

     billing       0.57      1.00      0.73         4
    shipping       1.00      1.00      1.00         4
   technical       1.00      0.25      0.40         4

    accuracy                           0.75        12
   macro avg       0.86      0.75      0.71        12
weighted avg       0.86      0.75      0.71        12
```

## Explanation of the output

- **Read the diagonal first: 4 + 4 + 1 = 9 correct out of 12 → accuracy 0.75.** That single number hides everything interesting.
- **The off-diagonal is where the story lives.** The cell at row `technical`, column `billing` is **3** — three tickets that were truly technical got routed to billing. There are no other off-diagonal entries, so that's the **most-confused pair**, and the code finds it automatically by zeroing the diagonal and taking the max. Cause: billing and technical share `error_words` and `refund_words`, exactly the overlap baked into the data.
- **Recall lives along the row; precision lives down the column.** For **technical**, the true-technical row is `[3, 0, 1]`: only **1** of its **4** items was caught, so **recall = 1/4 = 0.25** — the model misses three-quarters of technical tickets. For **billing**, the billing *column* is `[4, 0, 3]`: of the **7** tickets sent to billing, only **4** truly belong there, so **precision = 4/7 = 0.57** — billing is polluted by the misrouted technical tickets. Notice the asymmetry: technical has perfect precision (everything *labeled* technical really is) but terrible recall, while billing has perfect recall but poor precision. One matrix, two opposite failure modes.
- **shipping is the easy class** (`1.00 / 1.00`) because `delivery_words` cleanly separates it — a useful contrast that shows the problem isn't the model, it's the billing↔technical feature overlap.
- **The hand-computed numbers match `classification_report` exactly**, which confirms we read the axes the right way round. The fix this diagnosis points to: add a feature that distinguishes a *billing error* from a *technical error* (e.g. mentions of "payment" vs "app/login"), since accuracy alone would never have told us *that's* where to spend effort.

## Common mistakes

1. **Reading rows and columns backward.** sklearn uses rows = **true**, columns = **predicted**. Swap them and you'll report precision as recall and chase the wrong class. Fix: label your printout `true\pred` and verify the diagonal is correct counts.
2. **Letting the label order float.** With string classes, omitting `labels=[...]` lets sklearn pick alphabetical order, which may differ between `confusion_matrix` and `classification_report`. Fix: pin one explicit `labels` list and pass it everywhere.
3. **Confusing "predicted as X" with "is X".** A high count in column X means the model *over-uses* X (a precision problem); a high count spread across row X means class X is being *missed* (a recall problem). Fix: always say which direction — row vs column — a number came from.
4. **Reporting only accuracy on imbalanced or overlapping classes.** 0.75 accuracy looked fine until the matrix revealed technical recall is 0.25. Fix: always pair the accuracy with per-class precision/recall (or `macro avg`, which here is 0.71 — noticeably below the 0.75 accuracy).
5. **Treating the most-confused pair as symmetric.** "technical → billing" happened 3 times, but "billing → technical" happened 0 times. The confusion is directional. Fix: inspect the specific `(i, j)` cell, not just "these two classes get mixed up."

## Extension challenge

1. Normalize the matrix by row (`confusion_matrix(..., normalize="true")`) so each row sums to 1.0 — now the diagonal *is* per-class recall. Confirm the technical row shows 0.25 on its diagonal.
2. Plot the matrix as a heatmap with `ConfusionMatrixDisplay.from_estimator(clf, X_te, y_te, labels=labels)` and visually spot the bright off-diagonal cell.
3. Add a fifth feature that separates billing from technical (e.g. a `payment_page` flag), refit, and check whether the technical→billing confusion shrinks and recall climbs — closing the loop from *diagnosis* to *fix*.

## Matching animation

Use the module's **Confusion Matrix Explorer** to drop each held-out ticket into its true-row / predicted-column cell and watch the diagonal light up green while the off-diagonal cells glow as mistakes. Hover any cell to see it broken into the precision (down-column) and recall (along-row) ratios, then highlight the brightest off-diagonal cell to *see* the most-confused pair the code reported. It turns the printed 3×3 grid into a living map of exactly which class is leaking into which.

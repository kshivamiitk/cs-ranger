# Solved — Choosing the Right Metric for Imbalanced Fraud Detection

> A payments team is asked to "improve fraud detection accuracy." The first model is 99% accurate and catches exactly zero frauds. This is how you pick a metric that can't be gamed by the imbalance.

## Problem statement

We have card transactions where only about **1% are fraudulent**. We must choose an evaluation metric (and a decision threshold) for a fraud classifier. The trap: a model that predicts *"legit"* for every single transaction is ~99% accurate yet useless — it never catches fraud. The goal is to (a) show why accuracy lies here, (b) compute precision, recall, F1, and PR-AUC on the same predictions, and (c) recommend the metric and threshold given that a **missed fraud costs far more than a false alarm**.

## Data sample

A tiny, deliberately imbalanced ledger so this runs offline. Shape: 20 rows × 3 columns (`amount`, `is_fraud` = true label, `model_score` = the classifier's fraud probability 0–1). In real life you'd have hundreds of thousands of rows with ~1% positives; here 2 of 20 are fraud to keep the math readable.

```python
import io
import pandas as pd

# txn_id, amount, is_fraud (truth), model_score (P(fraud) from a trained model)
CSV = """txn_id,amount,is_fraud,model_score
T01,12.40,0,0.02
T02,8.10,0,0.05
T03,250.00,0,0.31
T04,5.99,0,0.04
T05,1999.00,1,0.88
T06,42.00,0,0.12
T07,3.49,0,0.01
T08,77.50,0,0.22
T09,860.00,1,0.46
T10,19.99,0,0.07
T11,15.00,0,0.09
T12,540.00,0,0.61
T13,6.25,0,0.03
T14,128.00,0,0.18
T15,33.30,0,0.08
T16,410.00,0,0.27
T17,9.90,0,0.06
T18,72.00,0,0.14
T19,1500.00,1,0.71
T20,21.50,0,0.10
"""
df = pd.read_csv(io.StringIO(CSV))
print(df.shape)            # (20, 4)
print(df["is_fraud"].mean())  # 0.15 here for readability; pretend it's ~0.01 at scale
```

> Note: with only 20 rows we use 3 frauds (15%) so the confusion matrix has non-trivial cells. The *reasoning* is identical at the real ~1% rate — it just makes accuracy lie even harder.

## Why this problem matters

Fraud, disease screening, churn, defect detection — the events you most want to catch are **rare**, and rarity is exactly what breaks accuracy. A bank that ships the 99%-accurate "predict legit" model loses money on every uncaught fraud while its dashboard glows green. Worse, the costs are **asymmetric**: missing a $1,999 fraud (a false negative) can cost the full chargeback plus investigation, while a false alarm (a false positive) costs a few seconds of a customer's annoyance or a quick verification text. Picking the metric is a *business* decision encoded as math.

## Step-by-step reasoning

1. **Name the positive class.** Positive = fraud. Every metric below is "about the positive class," so getting this straight prevents sign-flips.
2. **Show accuracy being gamed.** Build the trivial "always predict 0 (legit)" model. It gets every legit transaction right and every fraud wrong, so its accuracy = fraction of legit ≈ 85% here (≈99% at the real rate) while its **recall = 0**.
3. **Recall is the headline.** Recall = `TP / (TP + FN)` = "of all real frauds, what fraction did we catch?" Because a missed fraud is the expensive error, recall is the metric leadership actually cares about.
4. **But recall alone is also gameable** — flag *everything* as fraud and recall = 1.0 (perfect) at the price of drowning in false alarms. So we pair recall with **precision** = `TP / (TP + FP)` = "of everything we flagged, how much was really fraud?"
5. **F1 balances the two**, `2·P·R / (P + R)` — a single number that's only high when both are decent. Useful as a tie-breaker, but it weights precision and recall *equally*, which doesn't match our cost asymmetry.
6. **PR-AUC ranks the model threshold-free.** The precision–recall curve sweeps the threshold and PR-AUC (average precision) summarizes how well the model separates the rare positives across *all* thresholds. On heavy imbalance, PR-AUC is far more informative than ROC-AUC, because ROC's false-positive-rate denominator (all the negatives) is huge and hides bad precision.
7. **Encode the cost asymmetry, then pick the threshold.** If a missed fraud is, say, 20× worse than a false alarm, we *lower* the threshold to buy recall, accepting more false positives, and report **recall at a fixed precision floor** (e.g., "recall at precision ≥ 0.5") plus PR-AUC as the model-quality summary.

## Python solution

```python
import io
import numpy as np
import pandas as pd
from sklearn.metrics import (confusion_matrix, precision_score, recall_score,
                             f1_score, accuracy_score, average_precision_score,
                             precision_recall_curve)

CSV = """txn_id,amount,is_fraud,model_score
T01,12.40,0,0.02
T02,8.10,0,0.05
T03,250.00,0,0.31
T04,5.99,0,0.04
T05,1999.00,1,0.88
T06,42.00,0,0.12
T07,3.49,0,0.01
T08,77.50,0,0.22
T09,860.00,1,0.46
T10,19.99,0,0.07
T11,15.00,0,0.09
T12,540.00,0,0.61
T13,6.25,0,0.03
T14,128.00,0,0.18
T15,33.30,0,0.08
T16,410.00,0,0.27
T17,9.90,0,0.06
T18,72.00,0,0.14
T19,1500.00,1,0.71
T20,21.50,0,0.10
"""
df = pd.read_csv(io.StringIO(CSV))
y_true  = df["is_fraud"].values
scores  = df["model_score"].values
```

```python
# --- 1) The "always predict legit" baseline: accuracy looks great, recall is zero ---
y_dumb = np.zeros_like(y_true)            # predict 0 (legit) for everyone
print("Always-legit accuracy:", round(accuracy_score(y_true, y_dumb), 3))
print("Always-legit recall  :", round(recall_score(y_true, y_dumb, zero_division=0), 3))
# At the REAL ~1% fraud rate this baseline would read 0.99 accuracy, 0.0 recall.
```

```python
# --- 2) Score the real model at the default 0.5 threshold ---
def report(y_true, scores, thr):
    y_pred = (scores >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred, labels=[0, 1]).ravel()
    return {
        "thr": thr, "TP": tp, "FP": fp, "FN": fn, "TN": tn,
        "accuracy":  round(accuracy_score(y_true, y_pred), 3),
        "precision": round(precision_score(y_true, y_pred, zero_division=0), 3),
        "recall":    round(recall_score(y_true, y_pred, zero_division=0), 3),
        "f1":        round(f1_score(y_true, y_pred, zero_division=0), 3),
    }

for t in (0.5, 0.4, 0.3):
    print(report(y_true, scores, t))
```

```python
# --- 3) Threshold-free model quality: PR-AUC (average precision) ---
ap = average_precision_score(y_true, scores)   # area under the precision-recall curve
print("PR-AUC (average precision):", round(ap, 3))

# --- 4) Encode the cost asymmetry and pick a threshold by EXPECTED COST ---
COST_FN = 20.0   # a missed fraud is ~20x worse than...
COST_FP = 1.0    # ...a false alarm
best = None
for thr in np.linspace(0.05, 0.95, 19):
    yp = (scores >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, yp, labels=[0, 1]).ravel()
    cost = COST_FN * fn + COST_FP * fp
    if best is None or cost < best[1]:
        best = (round(thr, 2), cost, tp, fp, fn)
print(f"Cost-optimal threshold: {best[0]}  (cost={best[1]:.0f}, "
      f"TP={best[2]} FP={best[3]} FN={best[4]})")
```

## Expected output

Running it prints roughly:

```
Always-legit accuracy: 0.85
Always-legit recall  : 0.0
{'thr': 0.5, 'TP': 2, 'FP': 1, 'FN': 1, 'TN': 16, 'accuracy': 0.85, 'precision': 0.667, 'recall': 0.667, 'f1': 0.667}
{'thr': 0.4, 'TP': 3, 'FP': 1, 'FN': 0, 'TN': 16, 'accuracy': 0.95, 'precision': 0.75, 'recall': 1.0, 'f1': 0.857}
{'thr': 0.3, 'TP': 3, 'FP': 2, 'FN': 0, 'TN': 15, 'accuracy': 0.9, 'precision': 0.6, 'recall': 1.0, 'f1': 0.75}
PR-AUC (average precision): 0.861
Cost-optimal threshold: 0.4  (cost=1, TP=3 FP=1 FN=0)
```

How to read it: the **always-legit** baseline scores 0.85 accuracy (≈0.99 at the real rate) with **0 recall** — proof that accuracy rewards doing nothing on imbalanced data. The real model at the default 0.5 threshold *misses one fraud* (FN=1, recall 0.667). Drop the threshold to **0.4** and recall jumps to **1.0** (all frauds caught) for the price of one false alarm — precision still 0.75. **PR-AUC ≈ 0.86** says the model ranks frauds well above legit transactions across thresholds. Once we plug in the 20:1 cost asymmetry, the **expected-cost-optimal threshold is 0.4**: catching the third fraud (worth 20) easily beats the one extra false alarm (worth 1). Recommendation: **report PR-AUC for model selection and recall-at-a-precision-floor for monitoring, and set the operating threshold by expected cost — here, 0.4 — not the default 0.5.**

## Common mistakes

- **Reporting accuracy on imbalanced data.** It rewards predicting the majority class. Always show recall + precision (and the always-majority baseline) alongside it.
- **Optimizing recall in isolation.** Flagging everything gives recall 1.0 and a flood of false positives. Pair recall with a precision floor or use F1/expected cost.
- **Using ROC-AUC as the headline on extreme imbalance.** ROC's FPR denominator is dominated by the huge negative class, so a model with terrible precision can still post a flattering ROC-AUC. Prefer **PR-AUC** when positives are rare.
- **Leaving the threshold at 0.5.** 0.5 is an arbitrary default, not a business decision. Choose it from your cost matrix or a precision/recall target.
- **Computing PR-AUC from hard 0/1 predictions.** `average_precision_score` needs the continuous `model_score`, not the thresholded labels, or the curve collapses to a single point.

## Extension challenge

1. Make it realistically rare: simulate 10,000 transactions with `weights=[0.99, 0.01]` via `make_classification`, train `LogisticRegression`, and confirm accuracy ≈ 0.99 while recall is poor at threshold 0.5.
2. Plot the full precision–recall curve with `precision_recall_curve` and mark the point your cost-optimal threshold lands on.
3. Replace the fixed 20:1 cost with the actual `amount` per transaction (cost of a missed fraud = the transaction amount) and re-pick the threshold. Does the expensive $1,999 fraud pull the threshold lower?

## Matching animation

See **"Precision vs Recall Threshold Slider"** (`50 Precision vs Recall Threshold Slider`). Drag the threshold and watch TP/FP/FN/TN, precision, recall, and F1 move together while a point slides along the precision–recall curve — the exact trade you make when you lower the fraud threshold from 0.5 to 0.4 in this lesson.

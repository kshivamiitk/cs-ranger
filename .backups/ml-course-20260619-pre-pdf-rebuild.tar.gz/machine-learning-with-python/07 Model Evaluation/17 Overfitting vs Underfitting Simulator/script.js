"use strict";

// ============================================================================
//  Overfitting vs Underfitting Simulator
//  - Generate noisy points from a known "true" curve.
//  - Fit a polynomial of a chosen degree via least squares, solved IN JS:
//      build the Vandermonde matrix, form the normal equations (X^T X) b = X^T y,
//      and solve with Gaussian elimination + partial pivoting.
//  - Plot true curve, fitted curve, train points, test points; show train/test MSE.
// ============================================================================

// ---------- Domain constants ----------
const X_MIN = -3, X_MAX = 3;          // input range
const N_TRAIN = 18;                   // training points
const N_TEST = 10;                    // held-out test points
const NOISE = 0.30;                   // std of additive noise (relative to signal scale)

// Map x into [-1, 1] before powering, so x^15 doesn't overflow / wreck conditioning.
function scaleX(x) { return (2 * (x - X_MIN)) / (X_MAX - X_MIN) - 1; }

// ---------- True signals ----------
function trueCurve(x, type) {
  if (type === "cubic") return 0.18 * x * x * x - 0.5 * x;     // gentle cubic
  return Math.sin(1.6 * x);                                    // sine wave
}

// ---------- Seeded PRNG (mulberry32) + Gaussian via Box-Muller ----------
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function gauss(rand) {
  // Box-Muller: two uniforms -> one standard normal. Guard u1 away from 0.
  const u1 = Math.max(rand(), 1e-12);
  const u2 = rand();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}

// ---------- Data generation ----------
let train = [], test = [], curveType = "sine";
function generateData(seed) {
  const rand = mulberry32(seed >>> 0);
  train = []; test = [];
  for (let i = 0; i < N_TRAIN; i++) {
    const x = X_MIN + (X_MAX - X_MIN) * rand();
    train.push({ x, y: trueCurve(x, curveType) + NOISE * gauss(rand) });
  }
  for (let i = 0; i < N_TEST; i++) {
    const x = X_MIN + (X_MAX - X_MIN) * rand();
    test.push({ x, y: trueCurve(x, curveType) + NOISE * gauss(rand) });
  }
}

// ---------- Linear algebra: solve A b = c by Gaussian elimination w/ partial pivot ----------
function solveLinearSystem(A, c) {
  const n = c.length;
  // Build an augmented copy so we don't mutate the inputs.
  const M = A.map((row, i) => row.slice().concat(c[i]));
  for (let col = 0; col < n; col++) {
    // Partial pivoting: swap in the row with the largest |value| in this column.
    let piv = col;
    for (let r = col + 1; r < n; r++) {
      if (Math.abs(M[r][col]) > Math.abs(M[piv][col])) piv = r;
    }
    if (Math.abs(M[piv][col]) < 1e-12) return null;     // singular -> bail
    [M[col], M[piv]] = [M[piv], M[col]];
    // Eliminate this column from every row below.
    for (let r = col + 1; r < n; r++) {
      const f = M[r][col] / M[col][col];
      for (let k = col; k <= n; k++) M[r][k] -= f * M[col][k];
    }
  }
  // Back-substitution.
  const b = new Array(n).fill(0);
  for (let i = n - 1; i >= 0; i--) {
    let s = M[i][n];
    for (let k = i + 1; k < n; k++) s -= M[i][k] * b[k];
    b[i] = s / M[i][i];
  }
  return b;
}

// ---------- Polynomial least squares via the normal equations ----------
// Returns coefficients [b0, b1, ..., bd] for the SCALED input (xs in [-1,1]).
function fitPolynomial(points, degree) {
  const cols = degree + 1;
  // Vandermonde row for a scaled x: [1, xs, xs^2, ..., xs^degree]
  const vander = (xs) => {
    const row = new Array(cols);
    let p = 1;
    for (let j = 0; j < cols; j++) { row[j] = p; p *= xs; }
    return row;
  };
  // Normal equations: (X^T X) b = X^T y. Accumulate both directly.
  const XtX = Array.from({ length: cols }, () => new Array(cols).fill(0));
  const Xty = new Array(cols).fill(0);
  for (const pt of points) {
    const row = vander(scaleX(pt.x));
    for (let i = 0; i < cols; i++) {
      Xty[i] += row[i] * pt.y;
      for (let j = 0; j < cols; j++) XtX[i][j] += row[i] * row[j];
    }
  }
  // Tiny ridge term on the diagonal keeps the high-degree system solvable
  // (degree 15 with few points is near-singular); it does not stop overfitting.
  for (let i = 0; i < cols; i++) XtX[i][i] += 1e-7;

  const coeffs = solveLinearSystem(XtX, Xty);
  return coeffs;   // may be null if still singular
}

function evalPoly(coeffs, x) {
  const xs = scaleX(x);
  let p = 1, y = 0;
  for (let j = 0; j < coeffs.length; j++) { y += coeffs[j] * p; p *= xs; }
  return y;
}

function mse(points, coeffs) {
  let s = 0;
  for (const pt of points) {
    const e = pt.y - evalPoly(coeffs, pt.x);
    s += e * e;
  }
  return s / points.length;
}

// ---------- Rendering ----------
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");

// y-range fixed so vertical scale is comparable across degrees; clamp drawn curve to it.
const Y_MIN = -3, Y_MAX = 3;
function toPx(x, y, W, H, pad) {
  const px = pad + ((x - X_MIN) / (X_MAX - X_MIN)) * (W - 2 * pad);
  const py = H - pad - ((y - Y_MIN) / (Y_MAX - Y_MIN)) * (H - 2 * pad);
  return [px, py];
}

function drawAxes(W, H, pad) {
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.lineWidth = 1;
  // gridlines
  for (let gx = X_MIN; gx <= X_MAX; gx++) {
    const [px] = toPx(gx, 0, W, H, pad);
    ctx.beginPath(); ctx.moveTo(px, pad); ctx.lineTo(px, H - pad); ctx.stroke();
  }
  for (let gy = Y_MIN; gy <= Y_MAX; gy++) {
    const [, py] = toPx(0, gy, W, H, pad);
    ctx.beginPath(); ctx.moveTo(pad, py); ctx.lineTo(W - pad, py); ctx.stroke();
  }
  // zero axis a touch brighter
  ctx.strokeStyle = "rgba(255,255,255,0.16)";
  const [, y0] = toPx(0, 0, W, H, pad);
  ctx.beginPath(); ctx.moveTo(pad, y0); ctx.lineTo(W - pad, y0); ctx.stroke();
}

function drawCurve(fn, color, W, H, pad, width) {
  ctx.strokeStyle = color; ctx.lineWidth = width;
  ctx.beginPath();
  let started = false;
  const STEPS = 400;
  for (let i = 0; i <= STEPS; i++) {
    const x = X_MIN + (i / STEPS) * (X_MAX - X_MIN);
    let y = fn(x);
    if (!Number.isFinite(y)) { started = false; continue; }
    y = Math.max(Y_MIN - 1, Math.min(Y_MAX + 1, y));   // clamp so wild fits stay on screen
    const [px, py] = toPx(x, y, W, H, pad);
    if (!started) { ctx.moveTo(px, py); started = true; } else ctx.lineTo(px, py);
  }
  ctx.stroke();
}

function drawPoints(points, color, W, H, pad, r) {
  for (const pt of points) {
    const yc = Math.max(Y_MIN, Math.min(Y_MAX, pt.y));
    const [px, py] = toPx(pt.x, yc, W, H, pad);
    ctx.beginPath();
    ctx.fillStyle = color;
    ctx.shadowColor = color; ctx.shadowBlur = 8;
    ctx.arc(px, py, r, 0, Math.PI * 2); ctx.fill();
    ctx.shadowBlur = 0;
  }
}

function render(coeffs) {
  const W = canvas.width, H = canvas.height, pad = 30;
  ctx.clearRect(0, 0, W, H);
  drawAxes(W, H, pad);
  // true curve (green)
  drawCurve((x) => trueCurve(x, curveType), "#34d399", W, H, pad, 2);
  // fitted polynomial (cyan)
  if (coeffs) drawCurve((x) => evalPoly(coeffs, x), "#22d3ee", W, H, pad, 2.5);
  // points
  drawPoints(train, "#22d3ee", W, H, pad, 5);
  drawPoints(test, "#a78bfa", W, H, pad, 5);
}

// ---------- UI wiring ----------
const degSlider = document.getElementById("degree");
const degVal = document.getElementById("degVal");
const curveSel = document.getElementById("curveType");
const reshuffleBtn = document.getElementById("reshuffle");
const trainErrEl = document.getElementById("trainErr");
const testErrEl = document.getElementById("testErr");
const diagEl = document.getElementById("diagnosis");

let seed = 7;

function update() {
  const degree = Math.max(1, Math.min(15, parseInt(degSlider.value, 10) || 1));
  degVal.textContent = degree;

  const coeffs = fitPolynomial(train, degree);
  render(coeffs);

  if (!coeffs) {
    trainErrEl.textContent = "n/a";
    testErrEl.textContent = "n/a";
    diagEl.textContent = "Could not solve";
    diagEl.className = "diag";
    return;
  }

  const trErr = mse(train, coeffs);
  const teErr = mse(test, coeffs);
  trainErrEl.textContent = trErr.toFixed(3);
  testErrEl.textContent = teErr.toFixed(3);

  // Simple, transparent diagnosis from the two errors.
  let cls = "good", label = "Good fit ✓";
  if (trErr > 0.25 && teErr > 0.25) { cls = "underfit"; label = "Underfitting (high bias)"; }
  else if (teErr > trErr * 2.2 && teErr > 0.18) { cls = "overfit"; label = "Overfitting (high variance)"; }
  diagEl.textContent = label;
  diagEl.className = "diag " + cls;
}

degSlider.addEventListener("input", update);
curveSel.addEventListener("change", () => {
  curveType = curveSel.value;
  generateData(seed);
  update();
});
reshuffleBtn.addEventListener("click", () => {
  seed = Math.floor(Math.random() * 99999);
  generateData(seed);
  update();
});

// ---------- Init ----------
curveType = curveSel.value;
generateData(seed);
update();

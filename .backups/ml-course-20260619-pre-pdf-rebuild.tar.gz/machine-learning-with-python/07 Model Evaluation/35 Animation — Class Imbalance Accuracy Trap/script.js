"use strict";

/* ------------------------------------------------------------------ *
 * Class Imbalance: The Accuracy Trap
 *
 * 200 cases live on a grid. Each case has a true label (positive /
 * negative). The slider sets the POSITIVE rate (how many of the 200
 * are really positive). A model assigns a PREDICTION to every case,
 * and each case falls into one confusion-matrix bucket:
 *
 *   TP  predicted +  & truly +   (caught it)
 *   FP  predicted +  & truly -   (false alarm)
 *   FN  predicted -  & truly +   (missed it)   <-- the dangerous one
 *   TN  predicted -  & truly -   (correct reject)
 *
 * Metrics (all guarded against divide-by-zero -> 0):
 *   accuracy          = (TP + TN) / N
 *   recall  (TPR)     = TP / (TP + FN)
 *   precision         = TP / (TP + FP)
 *   F1                = 2*P*R / (P + R)
 *   specificity (TNR) = TN / (TN + FP)
 *   balanced accuracy = (recall + specificity) / 2
 *
 * The lesson: at a 1% positive rate, "Always Negative" gets
 * accuracy ~= 0.99 while recall = 0 and F1 = 0. Accuracy hides
 * total failure; recall / precision / F1 / balanced-acc expose it.
 * ------------------------------------------------------------------ */

// ----- Grid layout: 20 cols x 10 rows = 200 cases -----
const COLS = 20;
const ROWS = 10;
const N = COLS * ROWS; // 200

// ----- Deterministic seeded PRNG so every load is identical -----
function makeRng(seed) {
  let s = seed >>> 0;
  return () => {
    // LCG (same family as the reference lesson), mapped to [0,1)
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff;
  };
}

// Each cell gets a fixed random "score" in [0,1) once, up front.
// The score is reused to decide truth (low scores = more likely
// positive) AND to decide what the "decent" model predicts, so the
// data is fully deterministic and the model is internally consistent.
const CELLS = (() => {
  const rng = makeRng(20260618);
  const arr = [];
  for (let i = 0; i < N; i++) {
    arr.push({
      i,
      r: Math.floor(i / COLS),
      c: i % COLS,
      score: rng(),          // truth-ranking score, fixed for the run
      noise: rng(),          // independent noise for the decent model
      truth: false,          // assigned per posRate in assignTruth()
      pred: false,           // assigned per model in assignPred()
      bucket: "tn",          // "tp" | "fp" | "fn" | "tn"
    });
  }
  return arr;
})();

// Stable truth ordering: the cells with the lowest scores become the
// positives. Changing posRate just moves a threshold along this list,
// so positives only get added/removed at the boundary (smooth, deterministic).
const TRUTH_ORDER = CELLS.map(c => c.i).sort((a, b) => CELLS[a].score - CELLS[b].score);

// ----- DOM -----
const canvas = document.getElementById("grid");
const ctx = canvas.getContext("2d");
const posRateInput = document.getElementById("posRate");
const posRateVal = document.getElementById("posRateVal");
const modelSel = document.getElementById("model");
const showLabels = document.getElementById("showLabels");
const legend = document.getElementById("legend");
const alertEl = document.getElementById("alert");

const elTP = document.getElementById("cTP");
const elFP = document.getElementById("cFP");
const elFN = document.getElementById("cFN");
const elTN = document.getElementById("cTN");

const elAcc = document.getElementById("rAcc");
const elRec = document.getElementById("rRec");
const elPrec = document.getElementById("rPrec");
const elF1 = document.getElementById("rF1");
const elBal = document.getElementById("rBal");

// stat cards (parents of the value spans) for highlight styling
const cardAcc = elAcc.parentElement;
const cardRec = elRec.parentElement;

// ----- Outcome colors (read from CSS custom properties) -----
const cssVar = (name) => getComputedStyle(document.documentElement).getPropertyValue(name).trim();
const COLORS = {
  tp: cssVar("--tp") || "#34d399",
  fn: cssVar("--fn") || "#f87171",
  fp: cssVar("--fp") || "#fbbf24",
  tn: cssVar("--tn") || "#475569",
};

// ----- State -----
let posRate = parseInt(posRateInput.value, 10) / 100; // 0.01 .. 0.50
let model = modelSel.value;                            // "neg" | "pos" | "decent"
// per-cell animated fill (we tween rgb toward the target bucket color)
const anim = CELLS.map(() => ({ r: 71, g: 85, b: 99 }));
let raf = null;

// ----- Assign truth from posRate (threshold along TRUTH_ORDER) -----
function assignTruth() {
  const k = Math.round(posRate * N); // number of true positives
  // reset
  for (const cell of CELLS) cell.truth = false;
  for (let j = 0; j < k; j++) CELLS[TRUTH_ORDER[j]].truth = true;
  return k;
}

// ----- Assign predictions for the chosen model (deterministic) -----
function assignPred() {
  for (const cell of CELLS) {
    if (model === "neg") {
      cell.pred = false;
    } else if (model === "pos") {
      cell.pred = true;
    } else {
      // "Decent model": catches most true positives, with a few
      // false alarms. Deterministic via the per-cell noise field.
      if (cell.truth) {
        cell.pred = cell.noise < 0.85;   // ~85% recall on positives
      } else {
        cell.pred = cell.noise < 0.08;   // ~8% false-positive rate
      }
    }
  }
}

// ----- Bucket every cell and tally the confusion matrix -----
function confusion() {
  let TP = 0, FP = 0, FN = 0, TN = 0;
  for (const cell of CELLS) {
    if (cell.truth && cell.pred) { cell.bucket = "tp"; TP++; }
    else if (!cell.truth && cell.pred) { cell.bucket = "fp"; FP++; }
    else if (cell.truth && !cell.pred) { cell.bucket = "fn"; FN++; }
    else { cell.bucket = "tn"; TN++; }
  }
  return { TP, FP, FN, TN };
}

// ----- Metrics with explicit divide-by-zero guards -----
function metrics(cm) {
  const { TP, FP, FN, TN } = cm;
  const total = TP + FP + FN + TN;

  const accuracy = total === 0 ? 0 : (TP + TN) / total;

  const recDen = TP + FN;                 // actual positives
  const recall = recDen === 0 ? null : TP / recDen;     // null => n/a

  const precDen = TP + FP;                // predicted positives
  const precision = precDen === 0 ? null : TP / precDen; // null => n/a

  // F1: undefined if precision/recall undefined OR both zero
  let f1;
  if (recall === null || precision === null) f1 = 0;
  else if (precision + recall === 0) f1 = 0;
  else f1 = (2 * precision * recall) / (precision + recall);

  const specDen = TN + FP;                // actual negatives
  const specificity = specDen === 0 ? null : TN / specDen;

  // balanced accuracy = mean of recall (TPR) and specificity (TNR);
  // if a class is absent, fall back to the available one.
  let balanced;
  if (recall === null && specificity === null) balanced = 0;
  else if (recall === null) balanced = specificity;
  else if (specificity === null) balanced = recall;
  else balanced = (recall + specificity) / 2;

  return { accuracy, recall, precision, f1, balanced };
}

// ----- Geometry for the dot grid -----
function geom() {
  const PAD = 26;
  const w = canvas.width - PAD * 2;
  const h = canvas.height - PAD * 2;
  const cw = w / COLS;
  const ch = h / ROWS;
  const radius = Math.max(3, Math.min(cw, ch) * 0.34);
  return { PAD, cw, ch, radius };
}

// ----- Hex -> rgb for tweening -----
function hexToRgb(hex) {
  let h = hex.replace("#", "");
  if (h.length === 3) h = h.split("").map(ch => ch + ch).join("");
  const num = parseInt(h, 16);
  return { r: (num >> 16) & 255, g: (num >> 8) & 255, b: num & 255 };
}
const RGB = {
  tp: hexToRgb(COLORS.tp), fn: hexToRgb(COLORS.fn),
  fp: hexToRgb(COLORS.fp), tn: hexToRgb(COLORS.tn),
};

// ----- Drawing -----
function drawGrid() {
  const { PAD, cw, ch, radius } = geom();
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  for (const cell of CELLS) {
    const a = anim[cell.i];
    const cx = PAD + cell.c * cw + cw / 2;
    const cy = PAD + cell.r * ch + ch / 2;
    // ring marks the TRUTH so you can see what the model is missing
    ctx.beginPath();
    ctx.arc(cx, cy, radius, 0, Math.PI * 2);
    ctx.fillStyle = `rgb(${a.r | 0}, ${a.g | 0}, ${a.b | 0})`;
    ctx.fill();
    if (cell.truth) {
      ctx.lineWidth = 2;
      ctx.strokeStyle = "rgba(255,255,255,0.85)";
      ctx.stroke();
    } else {
      ctx.lineWidth = 1;
      ctx.strokeStyle = "rgba(0,0,0,0.45)";
      ctx.stroke();
    }
  }
}

// ----- Animate dot colors toward their bucket target -----
function startAnim() {
  if (raf) cancelAnimationFrame(raf);
  const step = () => {
    let moving = false;
    for (const cell of CELLS) {
      const target = RGB[cell.bucket];
      const a = anim[cell.i];
      const ease = 0.18;
      a.r += (target.r - a.r) * ease;
      a.g += (target.g - a.g) * ease;
      a.b += (target.b - a.b) * ease;
      if (Math.abs(target.r - a.r) > 0.6 ||
          Math.abs(target.g - a.g) > 0.6 ||
          Math.abs(target.b - a.b) > 0.6) {
        moving = true;
      } else {
        a.r = target.r; a.g = target.g; a.b = target.b;
      }
    }
    drawGrid();
    if (moving) { raf = requestAnimationFrame(step); }
    else { raf = null; }
  };
  raf = requestAnimationFrame(step);
}

// ----- Formatting helper (handles null => n/a) -----
function fmt(v) { return v === null ? "n/a" : v.toFixed(3); }

// ----- Readout + warning logic -----
function updateReadout(cm, mx) {
  elTP.textContent = String(cm.TP);
  elFP.textContent = String(cm.FP);
  elFN.textContent = String(cm.FN);
  elTN.textContent = String(cm.TN);

  elAcc.textContent = fmt(mx.accuracy);
  elRec.textContent = fmt(mx.recall);
  elPrec.textContent = fmt(mx.precision);
  elF1.textContent = fmt(mx.f1);
  elBal.textContent = fmt(mx.balanced);

  // Color the metric values: green = healthy, red = alarming.
  elAcc.className = "v" + (mx.accuracy >= 0.9 ? " good" : "");
  elRec.className = "v" + (mx.recall !== null && mx.recall < 0.2 ? " bad" : (mx.recall !== null && mx.recall >= 0.8 ? " good" : ""));
  elF1.className = "v" + (mx.f1 < 0.2 ? " bad" : (mx.f1 >= 0.7 ? " good" : ""));
  elBal.className = "v" + (mx.balanced !== null && mx.balanced < 0.55 ? " bad" : (mx.balanced !== null && mx.balanced >= 0.75 ? " good" : ""));
  elPrec.className = "v" + (mx.precision !== null && mx.precision >= 0.8 ? " good" : "");

  // The trap: high accuracy masking a useless model.
  const trapped = mx.accuracy >= 0.85 && mx.f1 < 0.2;
  cardAcc.classList.toggle("lying", trapped);
  cardRec.classList.toggle("alarmed", trapped);

  if (trapped && model === "neg") {
    const pct = Math.round(mx.accuracy * 100);
    alertEl.innerHTML = "⚠ " + pct + "% accurate — and catches 0 of " + cm.FN + " fraud cases.";
    alertEl.hidden = false;
  } else if (trapped) {
    const pct = Math.round(mx.accuracy * 100);
    alertEl.innerHTML = "⚠ " + pct + "% accurate — but F1 is " + mx.f1.toFixed(2) + ". Accuracy is lying.";
    alertEl.hidden = false;
  } else {
    alertEl.hidden = true;
  }
}

// ----- Full recompute + redraw -----
function update() {
  assignTruth();
  assignPred();
  const cm = confusion();
  const mx = metrics(cm);
  posRateVal.textContent = Math.round(posRate * 100) + "%";
  updateReadout(cm, mx);
  startAnim();
}

// ----- Controls (wire EVERY id) -----
posRateInput.addEventListener("input", () => {
  posRate = parseInt(posRateInput.value, 10) / 100;
  update();
});
modelSel.addEventListener("change", () => {
  model = modelSel.value;
  update();
});
showLabels.addEventListener("change", () => {
  legend.hidden = !showLabels.checked;
});

// "Show me the trap": jump straight to the 1% + Always-Negative demo.
document.getElementById("trap").addEventListener("click", () => {
  posRate = 0.01;
  posRateInput.value = "1";
  model = "neg";
  modelSel.value = "neg";
  update();
});

document.getElementById("reset").addEventListener("click", () => {
  posRate = 0.10;
  posRateInput.value = "10";
  model = "decent";
  modelSel.value = "decent";
  showLabels.checked = true;
  legend.hidden = false;
  update();
});

// ----- Init -----
update();

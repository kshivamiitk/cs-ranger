# Solved — Choosing Precision vs Recall for Medical Screening

> A screening test that clears 99% of healthy patients correctly still let 35 sick ones walk out reassured. When a missed disease can kill, recall — not accuracy, not precision — is the number the clinic must defend.

## Problem statement

We are building the *first-line screen* for a disease — a cheap test whose job is to decide who gets sent for the expensive confirmatory work-up. The label is `disease` (1 = has the disease, 0 = healthy), and the model outputs **P(disease)** for each patient. Here the two errors are wildly asymmetric: a **false negative** (telling a sick patient they're fine) can mean a disease caught too late, while a **false positive** (sending a healthy patient for one extra test) costs some money and worry. So the metric that matters is **recall** — *of all the truly sick, what fraction did we catch?* — even at the expense of precision.

The task: (a) compute **precision, recall, F1, and the confusion matrix** at the default 0.50 threshold and notice the missed-patient (FN) cell; (b) **lower the threshold** to raise recall and watch precision fall; and (c) frame the **clinical decision** — how far to push recall, and what the precision cost buys in unnecessary follow-ups.

## Why this problem matters

In screening, the whole point is to err on the side of catching disease, because the cost of the two mistakes is not even close. The classic example is mammography or a fast antigen test: a false positive triggers a follow-up scan or a confirmatory lab — annoying, sometimes costly, occasionally anxiety-inducing — but a false negative can be a death sentence delivered as good news. A model tuned to maximize accuracy or precision will quietly minimize false positives and let false negatives pile up, which is exactly backwards for a screen. Choosing precision vs recall is therefore not a statistics nicety; it is a clinical and ethical decision about which mistake the program is willing to make more often, encoded as a single threshold.

## Tiny dataset or sample data

We generate an overlapping screening cohort in memory with `make_classification` (no download), then surface it as a labeled table of screening markers. A small inline peek:

| age_norm | marker_a | marker_b | marker_c | marker_d | disease |
|---------:|---------:|---------:|---------:|---------:|--------:|
|   −0.62  |   0.41   |  −0.97   |   0.13   |   0.58   |    0    |
|    1.05  |   0.88   |   1.22   |  −0.74   |  −0.31   |    1    |
|    0.20  |  −0.55   |   0.34   |   0.07   |   0.49   |    0    |
|    0.71  |   1.12   |   0.65   |  −0.42   |   0.18   |    1    |
|   −1.04  |  −0.18   |  −0.51   |   0.90   |  −0.22   |    0    |

Shape: **`(1200, 5)` markers + 1 label column**, with a **disease prevalence ≈ 0.18**. The classes overlap heavily (`class_sep=0.55`, real label noise) — sick and healthy patients share marker ranges, which is realistic for a screen and is what makes the precision/recall trade *sharp* rather than trivial.

## Step-by-step reasoning

1. **Pin the positive class and the costly error.** Positive = `disease = 1`. The painful mistake is the **false negative** (a missed sick patient), so the governing metric is **recall**; precision and F1 are reported but are not what we optimize.
2. **Fit a probability model, not a hard classifier.** A scaled `LogisticRegression` outputs P(disease) per patient. Keeping the probability — not just the 0/1 label — is what lets us move the threshold later. Scaling lives in a `Pipeline` so it is fit on training data only (no leakage).
3. **Score at the default 0.50 and read the confusion matrix.** At 0.50 the model is conservative: precision is high (few false alarms) but recall is mediocre, so the **FN** cell is large — many sick patients are told they're fine. For a screen, that is the failure mode.
4. **Lower the threshold to raise recall.** Dropping the cutoff (0.30, 0.20, …) flags more patients as "needs follow-up," so **TP rises and FN falls** (recall up) while **FP rises** (precision down). We sweep the threshold and watch the trade move monotonically.
5. **Decide how far to push, in clinical terms.** More recall is not free: at very low thresholds precision collapses, meaning most flagged patients are actually healthy and the confirmatory pipeline floods. The right threshold is a **policy choice** — e.g., "hit recall ≥ 0.90, accept whatever precision that costs" — set by what the follow-up system can absorb, not by the 0.50 default.
6. **Name the trade explicitly.** Precision = "of those we flagged, how many are really sick" (follow-up efficiency); recall = "of the truly sick, how many we caught" (patient safety). A screen buys recall with precision; a confirmatory test, later in the funnel, buys back precision.

## Python solution

```python
import numpy as np
import pandas as pd
from sklearn.datasets import make_classification
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.metrics import (precision_score, recall_score, f1_score,
                             confusion_matrix, classification_report,
                             precision_recall_curve)

# --- 1. Build an OVERLAPPING screening cohort in memory (no download). ---
# Positive class = disease (1). Low class_sep + noise => sick and healthy
# patients share marker ranges, so the precision/recall trade is real.
X, y = make_classification(
    n_samples=1200, n_features=5, n_informative=3, n_redundant=0,
    n_clusters_per_class=1, weights=[0.85, 0.15], flip_y=0.06,
    class_sep=0.55, random_state=11)
cols = ["age_norm", "marker_a", "marker_b", "marker_c", "marker_d"]
df = pd.DataFrame(X, columns=cols)
df["disease"] = y
print("Shape:", df.shape, "| disease prevalence:", round(df["disease"].mean(), 3))

Xv, yv = df[cols].values, df["disease"].values
X_tr, X_te, y_tr, y_te = train_test_split(
    Xv, yv, test_size=0.30, random_state=11, stratify=yv)
print("Test patients:", len(y_te), "| diseased in test:", int(y_te.sum()))

# --- 2. Scale + logistic regression in a leak-proof Pipeline -> P(disease). ---
clf = Pipeline([("scale", StandardScaler()),
                ("lr", LogisticRegression(max_iter=2000, random_state=11))])
clf.fit(X_tr, y_tr)
proba = clf.predict_proba(X_te)[:, 1]   # keep probabilities for thresholding

def evaluate(thr, label):
    yp = (proba >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_te, yp, labels=[0, 1]).ravel()
    p = precision_score(y_te, yp, zero_division=0)
    r = recall_score(y_te, yp, zero_division=0)
    f = f1_score(y_te, yp, zero_division=0)
    print(f"\n[{label}  threshold={thr}]")
    print(f"  TP={tp} FP={fp} FN={fn} TN={tn}   <- FN = SICK patients missed")
    print(f"  precision={p:.3f}  recall={r:.3f}  f1={f:.3f}")

# --- 3. Default threshold: high precision, but it MISSES sick patients. ---
evaluate(0.50, "Default")
# --- 4. Lower the threshold to catch more disease (recall up, precision down). ---
evaluate(0.30, "Recall-favoring")
evaluate(0.20, "Aggressive screen")

# Sweep to expose the trade explicitly: recall buys safety, precision pays.
print("\n[Threshold sweep]")
print("  thr    prec    recall   FN(missed)")
for thr in (0.50, 0.40, 0.30, 0.20, 0.10):
    yp = (proba >= thr).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_te, yp, labels=[0, 1]).ravel()
    p = precision_score(y_te, yp, zero_division=0)
    r = recall_score(y_te, yp, zero_division=0)
    print(f"  {thr:0.2f}   {p:0.3f}   {r:0.3f}    {fn}")

# --- 5. Clinical policy: hit recall >= 0.90, accept the precision cost. ---
prec, rec, thr = precision_recall_curve(y_te, proba)
cands = [t for p, r, t in zip(prec[:-1], rec[:-1], thr) if r >= 0.90]
t90 = max(cands)   # highest threshold that still reaches 90% recall
print(f"\n[Clinical target recall >= 0.90 -> threshold {t90:0.2f}]")
print(classification_report(y_te, (proba >= t90).astype(int),
                            digits=2, zero_division=0))
```

## Expected output

Running it prints roughly (reproducible via `random_state`):

```
Shape: (1200, 6) | disease prevalence: 0.176
Test patients: 360 | diseased in test: 63

[Default  threshold=0.5]
  TP=28 FP=2 FN=35 TN=295   <- FN = SICK patients missed
  precision=0.933  recall=0.444  f1=0.602

[Recall-favoring  threshold=0.3]
  TP=40 FP=20 FN=23 TN=277   <- FN = SICK patients missed
  precision=0.667  recall=0.635  f1=0.650

[Aggressive screen  threshold=0.2]
  TP=51 FP=43 FN=12 TN=254   <- FN = SICK patients missed
  precision=0.543  recall=0.810  f1=0.650

[Threshold sweep]
  thr    prec    recall   FN(missed)
  0.50   0.933   0.444    35
  0.40   0.791   0.540    29
  0.30   0.667   0.635    23
  0.20   0.543   0.810    12
  0.10   0.333   0.857    9

[Clinical target recall >= 0.90 -> threshold 0.05]
              precision    recall  f1-score   support
           0       0.95      0.41      0.58       297
           1       0.25      0.90      0.39        63
    accuracy                           0.50       360
```

## Explanation of the output

At the **default 0.50 threshold the model looks excellent if you read precision** — 0.933, almost no false alarms — but the confusion matrix tells the real story: **FN = 35**, so it caught only 28 of 63 sick patients (recall 0.444). For a screen, that is a disaster: 35 people were told they're fine and sent home. The high precision is cold comfort; precision is the wrong number to optimize here.

**Lowering the threshold trades precision for the recall we actually need.** At **0.30**, recall climbs to 0.635 and missed patients drop from 35 to 23, while precision falls to 0.667 (false positives rise from 2 to 20). At **0.20**, recall reaches 0.810 with only 12 missed, precision now 0.543. The sweep table makes the mechanism undeniable — as the threshold drops, **recall rises and FN falls monotonically while precision pays the bill**. The final block shows the *limit* of the strategy: to guarantee **recall ≥ 0.90** the model must drop to a threshold of ~0.05, where **precision collapses to 0.25** — three out of four flagged patients are actually healthy, and overall accuracy sinks to 0.50 because so many negatives are now flagged. That is the clinical conversation in numbers: catching 90% of disease means flooding the confirmatory pipeline with false positives. The decision — *recall 0.81 at threshold 0.20, or recall 0.90 at threshold 0.05?* — belongs to the people who know what the follow-up system can absorb and how deadly a miss is, not to the default 0.50.

## Common mistakes

1. **Optimizing accuracy or precision on a screen.** Both reward *not* flagging patients, which maximizes false negatives — the costliest error. *Fix:* make **recall** the headline metric and read the FN cell of the confusion matrix directly.
2. **Leaving the threshold at 0.50.** The default minimizes total error count, not missed sick patients. *Fix:* sweep the threshold and set it from a recall target (or expected clinical cost), treating 0.50 as just a starting point.
3. **Thresholding hard 0/1 predictions instead of probabilities.** If you only keep `.predict()` output you can never move the operating point. *Fix:* keep `predict_proba(...)[:, 1]` and threshold that.
4. **Chasing recall = 1.0 blindly.** Flag everyone and recall is perfect, but precision goes to the prevalence (~0.18) and the follow-up system drowns. *Fix:* pick the recall target the downstream confirmatory test can actually support, and report the precision it costs.
5. **Reading the confusion matrix backward.** sklearn returns `tn, fp, fn, tp` from `.ravel()` with `labels=[0, 1]`; swapping FP and FN flips the entire clinical argument. *Fix:* always pass `labels=[0, 1]` and label the cells explicitly.

## Extension challenge

1. Attach explicit costs — a missed disease (FN) = 50, an unnecessary follow-up (FP) = 1 — sweep the threshold, compute expected cost at each, and report the **cost-minimizing** threshold. Confirm it sits far below 0.50.
2. Plot the precision–recall curve with `precision_recall_curve` and mark both the 0.50 default point and your recall ≥ 0.90 operating point, so the trade is visible as a slide along the curve.
3. Add a two-stage funnel: keep the low-threshold screen (high recall), then run a *second* higher-precision model only on the flagged patients. Measure how much the second stage recovers precision without losing the recall the screen bought.

## Matching animation

**Precision Recall Tradeoff** (`54 Animation — Precision Recall Tradeoff`) — watch precision and recall move in opposite directions as the operating point glides along the curve, exactly the trade this lesson makes when the threshold drops from 0.50 to 0.20 to 0.05. Then open the **Precision vs Recall Threshold Slider** (`50 Precision vs Recall Threshold Slider`) and drag the threshold by hand: each step left flips a few patients out of the FN cell into TP (recall up) while pulling some healthy patients into FP (precision down), turning the medical decision in this lesson into something you can feel with your finger.

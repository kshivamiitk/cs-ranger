"use strict";

// ============================================================================
//  Precision vs Recall Threshold Slider
//  ~40 examples, each with a true label (0/1) and a model score (0..1).
//  A threshold slider splits predicted-positive (score >= threshold) from
//  predicted-negative. We compute TP/FP/FN/TN, precision, recall, F1, accuracy
//  live; draw the examples on a score axis; and trace the precision-recall curve
//  with a moving operating point at the current threshold.
// ============================================================================

const N = 40;
const COLORS = { pos: "#22d3ee", neg: "#94a3b8", violet: "#a78bfa" };

// ---------- Seeded PRNG (mulberry32) ----------
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Positives tend to score high, negatives low, with overlap, so the threshold
// genuinely trades precision against recall (a realistic, imperfect classifier).
let examples = [];
function generate(seed) {
  const rand = mulberry32(seed >>> 0);
  examples = [];
  for (let i = 0; i < N; i++) {
    const isPos = rand() < 0.45;                 // ~45% positives
    let s = (rand() + rand()) / 2;               // pull toward center
    s += isPos ? 0.22 : -0.22;                   // separate the classes (with overlap)
    s = Math.max(0.02, Math.min(0.98, s));
    examples.push({ score: s, label: isPos ? 1 : 0 });
  }
}

// ---------- Metrics at a given threshold ----------
const safe = (num, den) => (den === 0 ? 0 : num / den);   // guard divide-by-zero

function computeStats(thr) {
  let tp = 0, fp = 0, fn = 0, tn = 0;
  for (const e of examples) {
    const predPos = e.score >= thr;
    if (e.label === 1 && predPos) tp++;
    else if (e.label === 0 && predPos) fp++;
    else if (e.label === 1 && !predPos) fn++;
    else tn++;
  }
  const precision = safe(tp, tp + fp);
  const recall = safe(tp, tp + fn);
  const f1 = (precision + recall === 0) ? 0 : 2 * precision * recall / (precision + recall);
  const accuracy = safe(tp + tn, N);
  return { tp, fp, fn, tn, precision, recall, f1, accuracy };
}

// Build the full precision-recall curve: evaluate at every distinct score so the
// curve is exactly what sklearn's precision_recall_curve would trace.
function prCurve() {
  // candidate thresholds: just above 0, plus each unique score
  const thrs = Array.from(new Set(examples.map((e) => e.score))).sort((a, b) => b - a);
  const pts = [];
  // recall 0 / precision 1 anchor (threshold above every score: nothing flagged)
  pts.push({ recall: 0, precision: 1 });
  for (const t of thrs) {
    const s = computeStats(t);
    // when nothing is predicted positive precision is undefined; carry 1 for the curve
    const p = (s.tp + s.fp === 0) ? 1 : s.precision;
    pts.push({ recall: s.recall, precision: p });
  }
  return pts;
}

// ---------- Canvas A: examples on a 0..1 score axis ----------
const strip = document.getElementById("strip");
const sctx = strip.getContext("2d");

function drawStrip(thr) {
  const W = strip.width, H = strip.height, padX = 24, padTop = 16, padBot = 26;
  sctx.clearRect(0, 0, W, H);
  const x0 = padX, x1 = W - padX;
  const xOf = (s) => x0 + s * (x1 - x0);
  const baseY = (H - padBot + padTop) / 2;

  // axis line + ticks
  sctx.strokeStyle = "rgba(255,255,255,0.12)";
  sctx.lineWidth = 1;
  sctx.beginPath(); sctx.moveTo(x0, H - padBot); sctx.lineTo(x1, H - padBot); sctx.stroke();
  sctx.fillStyle = COLORS.neg; sctx.font = "11px system-ui, sans-serif"; sctx.textAlign = "center";
  for (let t = 0; t <= 1.0001; t += 0.25) {
    const x = xOf(t);
    sctx.beginPath(); sctx.moveTo(x, H - padBot); sctx.lineTo(x, H - padBot + 4); sctx.stroke();
    sctx.fillText(t.toFixed(2), x, H - padBot + 16);
  }

  // shade the "predicted positive" region (>= threshold)
  const tx = xOf(thr);
  sctx.fillStyle = "rgba(34, 211, 238, 0.07)";
  sctx.fillRect(tx, padTop, x1 - tx, (H - padBot) - padTop);

  // examples as dots; deterministic vertical jitter so overlaps are visible
  examples.forEach((e, i) => {
    const x = xOf(e.score);
    const jitter = ((i * 53) % 9 - 4) * 6;
    const y = baseY + jitter;
    const predPos = e.score >= thr;
    const color = e.label === 1 ? COLORS.pos : COLORS.neg;
    sctx.beginPath();
    sctx.fillStyle = color;
    sctx.shadowColor = color; sctx.shadowBlur = e.label === 1 ? 8 : 2;
    sctx.arc(x, y, 6, 0, Math.PI * 2); sctx.fill();
    sctx.shadowBlur = 0;
    // white ring = predicted positive at this threshold
    sctx.lineWidth = 2;
    sctx.strokeStyle = predPos ? "#ffffff" : "rgba(255,255,255,0.18)";
    sctx.stroke();
  });

  // threshold marker line
  sctx.strokeStyle = COLORS.violet; sctx.lineWidth = 2;
  sctx.beginPath(); sctx.moveTo(tx, padTop - 6); sctx.lineTo(tx, H - padBot); sctx.stroke();
  sctx.fillStyle = COLORS.violet; sctx.textAlign = "center";
  sctx.fillText("threshold", tx, padTop + 2);
}

// ---------- Canvas B: precision-recall curve + animated operating point ----------
const prCanvas = document.getElementById("pr");
const pctx = prCanvas.getContext("2d");
let curve = [];

// the operating dot eases toward its target (recall, precision) for a smooth feel
const dot = { x: 0, y: 1, tx: 0, ty: 1 };

function plotMap(W, H) {
  const padL = 38, padR = 12, padT = 12, padB = 30;
  return {
    px: (r) => padL + r * (W - padL - padR),
    py: (p) => (H - padB) - p * (H - padT - padB),
    padL, padR, padT, padB,
  };
}

function drawPR() {
  const W = prCanvas.width, H = prCanvas.height;
  const m = plotMap(W, H);
  pctx.clearRect(0, 0, W, H);

  // grid + axis labels
  pctx.strokeStyle = "rgba(255,255,255,0.08)";
  pctx.fillStyle = COLORS.neg;
  pctx.font = "10px system-ui, sans-serif";
  pctx.lineWidth = 1;
  for (let g = 0; g <= 1.0001; g += 0.25) {
    // vertical (recall) gridlines
    let x = m.px(g);
    pctx.beginPath(); pctx.moveTo(x, m.py(0)); pctx.lineTo(x, m.py(1)); pctx.stroke();
    pctx.textAlign = "center"; pctx.fillText(g.toFixed(2), x, m.py(0) + 14);
    // horizontal (precision) gridlines
    let y = m.py(g);
    pctx.beginPath(); pctx.moveTo(m.px(0), y); pctx.lineTo(m.px(1), y); pctx.stroke();
    pctx.textAlign = "right"; pctx.fillText(g.toFixed(2), m.px(0) - 5, y + 3);
  }
  pctx.textAlign = "center";
  pctx.fillStyle = "#94a3b8";
  pctx.fillText("recall →", W / 2, H - 4);
  pctx.save();
  pctx.translate(10, H / 2); pctx.rotate(-Math.PI / 2);
  pctx.fillText("precision →", 0, 0);
  pctx.restore();

  // the PR curve
  pctx.strokeStyle = "#22d3ee";
  pctx.lineWidth = 2;
  pctx.beginPath();
  curve.forEach((pt, i) => {
    const x = m.px(pt.recall), y = m.py(pt.precision);
    if (i === 0) pctx.moveTo(x, y); else pctx.lineTo(x, y);
  });
  pctx.stroke();

  // small markers at every curve point
  pctx.fillStyle = "rgba(34,211,238,0.45)";
  curve.forEach((pt) => {
    pctx.beginPath();
    pctx.arc(m.px(pt.recall), m.py(pt.precision), 2.2, 0, Math.PI * 2);
    pctx.fill();
  });

  // the animated operating point (current threshold)
  const ox = m.px(dot.x), oy = m.py(dot.y);
  pctx.beginPath();
  pctx.fillStyle = COLORS.violet;
  pctx.shadowColor = COLORS.violet; pctx.shadowBlur = 12;
  pctx.arc(ox, oy, 6.5, 0, Math.PI * 2); pctx.fill();
  pctx.shadowBlur = 0;
  pctx.strokeStyle = "#fff"; pctx.lineWidth = 1.5; pctx.stroke();
}

// rAF loop: ease the dot toward its target, redraw while moving
let raf = null;
function animate() {
  const dx = dot.tx - dot.x, dy = dot.ty - dot.y;
  dot.x += dx * 0.2;
  dot.y += dy * 0.2;
  drawPR();
  if (Math.abs(dx) > 0.0008 || Math.abs(dy) > 0.0008) {
    raf = requestAnimationFrame(animate);
  } else {
    dot.x = dot.tx; dot.y = dot.ty;
    drawPR();
    raf = null;
  }
}
function setTarget(recall, precision) {
  dot.tx = recall; dot.ty = precision;
  if (raf === null) raf = requestAnimationFrame(animate);
}

// ---------- DOM wiring ----------
const thr = document.getElementById("thr");
const thrVal = document.getElementById("thrVal");
const els = {
  tp: document.getElementById("tp"), fp: document.getElementById("fp"),
  fn: document.getElementById("fn"), tn: document.getElementById("tn"),
  acc: document.getElementById("acc"), prec: document.getElementById("prec"),
  rec: document.getElementById("rec"), f1: document.getElementById("f1"),
  cellTP: document.getElementById("cellTP"), cellFP: document.getElementById("cellFP"),
  cellFN: document.getElementById("cellFN"), cellTN: document.getElementById("cellTN"),
};

function tint(cellEl, count, rgbaTemplate) {
  const alpha = 0.08 + 0.42 * (count / N);
  cellEl.style.background = rgbaTemplate.replace("ALPHA", alpha.toFixed(3));
}

function update() {
  const t = Math.max(0, Math.min(1, parseFloat(thr.value) || 0));
  thrVal.textContent = t.toFixed(2);
  const s = computeStats(t);

  els.tp.textContent = s.tp; els.fp.textContent = s.fp;
  els.fn.textContent = s.fn; els.tn.textContent = s.tn;
  els.acc.textContent = s.accuracy.toFixed(2);
  els.prec.textContent = (s.tp + s.fp === 0 ? 0 : s.precision).toFixed(2);
  els.rec.textContent = s.recall.toFixed(2);
  els.f1.textContent = s.f1.toFixed(2);

  tint(els.cellTP, s.tp, "rgba(52, 211, 153, ALPHA)");
  tint(els.cellTN, s.tn, "rgba(52, 211, 153, ALPHA)");
  tint(els.cellFP, s.fp, "rgba(248, 113, 113, ALPHA)");
  tint(els.cellFN, s.fn, "rgba(248, 113, 113, ALPHA)");

  drawStrip(t);
  const opPrec = (s.tp + s.fp === 0) ? 1 : s.precision;   // undefined precision -> 1 on the plot
  setTarget(s.recall, opPrec);
}

thr.addEventListener("input", update);
document.getElementById("reshuffle").addEventListener("click", () => {
  generate(Math.floor(Math.random() * 99999) + 1);
  curve = prCurve();
  // snap the dot to the new curve so it doesn't fly across the chart
  const s = computeStats(parseFloat(thr.value) || 0.5);
  dot.x = s.recall; dot.y = (s.tp + s.fp === 0) ? 1 : s.precision;
  update();
});

// ---------- Init ----------
generate(2026);
curve = prCurve();
update();

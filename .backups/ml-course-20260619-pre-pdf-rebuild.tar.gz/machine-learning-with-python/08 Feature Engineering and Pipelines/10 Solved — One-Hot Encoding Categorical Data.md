# Solved — One-Hot Encoding Categorical Data

> Your model only speaks numbers, but your data says `Mumbai`, `pro`, `ios`. Hand it those strings the wrong way and you secretly teach it that `premium` is "twice" `basic` — a fact nobody ever meant to assert.

## Problem statement

You have a sign-up table with three **categorical** columns — `city` (`Mumbai` / `Delhi` / `Pune`), `plan` (`basic` / `pro` / `premium`), and `device` (`android` / `ios`) — and a label `upgraded` (1 = upgraded to a paid tier, 0 = stayed free). A scikit-learn model cannot consume the raw strings; it needs numbers. The task is to convert these text categories into numeric features **correctly**, so the model can learn from them without us smuggling in a fake ordering.

The catch: none of these columns are ordered. `Mumbai` is not "more than" `Delhi`, and `pro` is not numerically between `basic` and `premium`. If we naively map each category to an integer (`basic`→0, `pro`→1, `premium`→2), the model will treat those integers as a real number line — distances, sums, "greater than" — and learn nonsense. The goal is to encode each category as its own independent yes/no column, then feed that to a classifier and read the result back in plain language.

## Why this problem matters

Almost every real dataset mixes numbers with text categories — country, product, browser, subscription tier — and getting the encoding wrong is one of the quietest, most common ways to cripple a model. The damage is invisible: the code runs, the accuracy is *plausible*, and yet the model has been fed a phantom order it then tries to exploit. One-hot encoding is the default, safe answer for unordered categories, and knowing its three sharp edges — unseen categories at predict time, the dummy-variable trap, and reading the expanded column names — is exactly the difference between a notebook that demos well and a model that survives production.

## Tiny dataset or sample data

A small, realistic slice (the full inline set below has 24 rows; shape `(24, 4)`, columns `city, plan, device, upgraded`):

| city   | plan    | device  | upgraded |
|--------|---------|---------|---------:|
| Mumbai | basic   | android |        0 |
| Delhi  | pro     | ios     |        1 |
| Mumbai | pro     | ios     |        1 |
| Pune   | basic   | android |        0 |
| Delhi  | premium | ios     |        1 |
| Pune   | premium | ios     |        1 |

The pattern baked into the data: **paid-intent plans (`pro`, `premium`) push `upgraded` up**, while `basic` pulls it down; `city` and `device` are weak nudges at best. A correct encoding should let the model recover that the *plan* columns matter most.

## Step-by-step reasoning

1. **Recognize the columns are unordered (nominal).** `city`, `plan`, and `device` are labels, not quantities. There is no defensible claim that `Pune` − `Delhi` means anything. That single observation rules out integer-coding them as features.
2. **See the fake-order trap concretely.** `LabelEncoder` (or a quick `.map({...})`) assigns integers *alphabetically*, so `plan` becomes `basic=0, premium=1, pro=2`. A linear model now believes `pro` is twice as "planny" as `premium` and three times `basic` — a totally invented ranking that also happens to be in the wrong business order. `LabelEncoder` is for the **target** `y`, not for nominal features.
3. **One-hot instead: one 0/1 column per category.** `OneHotEncoder` turns the 3 text columns into 8 indicator columns (`city_Delhi`, `city_Mumbai`, …, `device_ios`). Each row has exactly one `1` per original column. No category is "bigger" than another — they are independent switches.
4. **Plan for unseen categories with `handle_unknown='ignore'`.** At predict time a new customer might be from `Chennai`, a city never seen during `fit`. The default encoder would crash. With `handle_unknown='ignore'`, an unknown value becomes all-zeros across that feature's dummies — the model simply gets no city signal for that row instead of erroring.
5. **Avoid the dummy-variable trap with `drop='first'`.** The dummies for one column always sum to 1, so the full set is perfectly collinear (any one column is `1 −` the others). For linear models that hurts coefficient stability. `drop='first'` removes one reference level per column, encoding the same information with fewer columns. (Tree models don't care; regularized linear models tolerate it but it's still cleaner.)
6. **Read the expanded names, then feed a model.** After encoding, recover `get_feature_names_out()` so each coefficient is human-readable, fit a `LogisticRegression`, and check the plan columns come out as the strongest positive drivers.

## Python solution

```python
import io
import numpy as np
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split

# --- 1. Inline data (no download). Three unordered categorical columns. ---
csv = """city,plan,device,upgraded
Mumbai,basic,android,0
Delhi,pro,ios,1
Mumbai,pro,ios,1
Pune,basic,android,0
Delhi,basic,android,0
Mumbai,premium,ios,1
Pune,pro,android,1
Delhi,premium,ios,1
Mumbai,basic,ios,0
Pune,premium,ios,1
Delhi,pro,android,1
Mumbai,pro,android,1
Pune,basic,ios,0
Delhi,basic,ios,0
Mumbai,premium,android,1
Pune,pro,ios,1
Delhi,premium,android,1
Mumbai,basic,android,0
Pune,premium,android,1
Delhi,pro,ios,1
Mumbai,pro,ios,1
Pune,basic,android,0
Delhi,premium,ios,1
Mumbai,basic,ios,0
"""
df = pd.read_csv(io.StringIO(csv))
print("Shape:", df.shape, "| upgrade rate:", round(df["upgraded"].mean(), 2))
print("Categories per column:")
for c in ["city", "plan", "device"]:
    print(f"  {c:7s} -> {sorted(df[c].unique())}")

X = df[["city", "plan", "device"]]
y = df["upgraded"].values

# --- 2. The fake-order trap: LabelEncoder on an UNORDERED feature column. ---
le = LabelEncoder()
plan_as_int = le.fit_transform(df["plan"])
print("\nLabelEncoder maps plan ->", dict(zip(le.classes_, le.transform(le.classes_))))
print("  Trap: this asserts premium(1) and pro(2) sit on a number line above")
print("  basic(0) -- an order nobody meant and the wrong one for the business.")

# --- 3. The right tool: OneHotEncoder. One 0/1 column per category. ---
ohe = OneHotEncoder(sparse_output=False, handle_unknown="ignore")
X_ohe = ohe.fit_transform(X)
ohe_names = ohe.get_feature_names_out(["city", "plan", "device"])
print("\nOneHotEncoder expanded", X.shape[1], "columns into", X_ohe.shape[1], "columns:")
print(" ", list(ohe_names))

# Same idea in pure pandas (handy for quick EDA, but it stores no fitted state).
dummies = pd.get_dummies(X, columns=["city", "plan", "device"]).astype(int)
print("\npd.get_dummies head:\n", dummies.head(3).to_string(index=False))

# --- 4. drop='first' avoids the dummy-variable trap (perfect collinearity). ---
ohe_drop = OneHotEncoder(sparse_output=False, drop="first")
X_drop = ohe_drop.fit_transform(X)
print("\ndrop='first' -> {} columns (one reference level dropped per feature):"
      .format(X_drop.shape[1]))
print(" ", list(ohe_drop.get_feature_names_out(["city", "plan", "device"])))

# --- 5. handle_unknown='ignore': survive a category unseen at fit time. ---
new_customer = pd.DataFrame(
    {"city": ["Chennai"], "plan": ["pro"], "device": ["ios"]})  # Chennai is NEW
encoded_new = ohe.transform(new_customer)
print("\nUnseen city 'Chennai' -> all-zeros across the city dummies (no crash):")
print(" ", dict(zip(ohe_names, encoded_new[0].astype(int))))

# --- 6. Feed one-hot features to a model with a clean train/predict flow. ---
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.30, random_state=0, stratify=y)
enc = OneHotEncoder(sparse_output=False, handle_unknown="ignore").fit(X_tr)  # FIT on train only
clf = LogisticRegression(max_iter=1000).fit(enc.transform(X_tr), y_tr)
acc = clf.score(enc.transform(X_te), y_te)
print(f"\nLogReg test accuracy on one-hot features: {acc:.3f}")

# Read the model back in human terms: one coefficient per expanded column.
names = enc.get_feature_names_out(["city", "plan", "device"])
coefs = clf.coef_[0]
print("Feature  ->  coef (higher = pushes toward 'upgraded')")
for n, c in sorted(zip(names, coefs), key=lambda t: -t[1]):
    print(f"  {n:18s} {c:+.2f}")
```

## Expected output

```
Shape: (24, 4) | upgrade rate: 0.62
Categories per column:
  city    -> ['Delhi', 'Mumbai', 'Pune']
  plan    -> ['basic', 'premium', 'pro']
  device  -> ['android', 'ios']

LabelEncoder maps plan -> {'basic': 0, 'premium': 1, 'pro': 2}
  Trap: this asserts premium(1) and pro(2) sit on a number line above
  basic(0) -- an order nobody meant and the wrong one for the business.

OneHotEncoder expanded 3 columns into 8 columns:
  ['city_Delhi', 'city_Mumbai', 'city_Pune', 'plan_basic', 'plan_premium', 'plan_pro', 'device_android', 'device_ios']

pd.get_dummies head:
  city_Delhi  city_Mumbai  city_Pune  plan_basic  plan_premium  plan_pro  device_android  device_ios
          0            1          0           1             0         0               1           0
          1            0          0           0             0         1               0           1
          0            1          0           0             0         1               0           1

drop='first' -> 5 columns (one reference level dropped per feature):
  ['city_Mumbai', 'city_Pune', 'plan_premium', 'plan_pro', 'device_ios']

Unseen city 'Chennai' -> all-zeros across the city dummies (no crash):
  {'city_Delhi': 0, 'city_Mumbai': 0, 'city_Pune': 0, 'plan_basic': 0, 'plan_premium': 0, 'plan_pro': 1, 'device_android': 0, 'device_ios': 1}

LogReg test accuracy on one-hot features: 1.000
Feature  ->  coef (higher = pushes toward 'upgraded')
  plan_pro           +0.89
  plan_premium       +0.75
  city_Delhi         +0.22
  device_ios         +0.18
  city_Mumbai        -0.06
  city_Pune          -0.16
  device_android     -0.18
  plan_basic         -1.64
```

## Explanation of the output

- **3 columns became 8.** `city` had 3 levels, `plan` 3, `device` 2 → `3 + 3 + 2 = 8` indicator columns. The `pd.get_dummies` head confirms each row carries exactly one `1` per original column — a tidy, order-free numeric form.
- **`drop='first'` left 5 columns** by removing one reference level per feature (`city_Delhi`, `plan_basic`, `device_android` are gone). Those dropped levels become the implicit baseline; the same information is now collinearity-free.
- **The unseen `Chennai` row is all-zeros across `city_*`** but still correctly encodes `plan_pro=1` and `device_ios=1`. That is `handle_unknown='ignore'` earning its keep: the model loses only the city signal for that one row instead of throwing at predict time.
- **The coefficients tell the right story.** `plan_pro` and `plan_premium` are the strongest **positive** drivers and `plan_basic` is strongly **negative** — exactly the pattern we baked in. The `city`/`device` coefficients are small, confirming they're weak signals. The `1.000` accuracy is a property of this deliberately clean toy set; the lesson is the encoding and the readable coefficients, not the perfect score.

## Common mistakes

1. **Using `LabelEncoder` on a feature column.** It invents an alphabetical order (`basic=0, premium=1, pro=2`) that a linear or distance-based model will treat as real. Fix: `LabelEncoder` is for the *target* `y`; use `OneHotEncoder` (or `pd.get_dummies`) for nominal *features*.
2. **Forgetting `handle_unknown='ignore'`.** A category seen only in production (new city, new plan) crashes the default encoder at `transform` time. Fix: set `handle_unknown='ignore'` so unseen values encode to all-zeros instead of erroring.
3. **Re-fitting the encoder on test/production data.** Calling `.fit_transform` on the test set relearns the categories and can silently produce a different column layout than the model was trained on. Fix: `fit` on train once, then only `transform` everything else (a `Pipeline` enforces this for you).
4. **Ignoring the dummy-variable trap for linear models.** Keeping every level makes the dummies perfectly collinear, which destabilizes coefficients (and breaks plain OLS outright). Fix: `drop='first'` for linear/regression models; leave all levels for tree models, which are unaffected.
5. **Losing track of which column is which.** After encoding you have an unlabeled array and `coef_[3]` means nothing. Fix: always pull `get_feature_names_out()` and zip it with the coefficients so results stay interpretable.

## Extension challenge

1. Set `min_frequency=2` (or `max_categories=2`) on `OneHotEncoder` to fold rare categories into an automatic `infrequent` bucket, and compare the resulting column count. When would collapsing rare levels help a small dataset?
2. Wrap the encoder and `LogisticRegression` in a single `Pipeline` and confirm you can call `.fit(X_tr)` / `.predict(X_te)` with no manual `transform` — then re-run the unseen-`Chennai` prediction through the whole pipeline.
3. Replace one-hot with **target (mean) encoding** for `city` (each city → its average `upgraded` rate, computed on train only) and discuss why that can leak if you compute it before splitting.

## Matching animation

**Encoding Categorical Variables** — pick a categorical column and watch the single text column fan out into one glowing 0/1 switch per category, with exactly one switch lit per row. Toggle `drop='first'` to see a reference level fade away, and drop in an unseen category to watch every switch stay dark — the visual twin of `handle_unknown='ignore'` in this lesson.

# Pipelines

> A pipeline bundles every preprocessing step and the model into a single object — so the exact same transformations happen on train, on test, and in production, with zero room to forget a step or leak the answer.

## What is this?

A scikit-learn **Pipeline** is a list of named steps that run in order: usually some preprocessing (scale, encode, impute) followed by a model. The whole list behaves like *one* estimator — you call `.fit()` once and `.predict()` once, and the pipeline routes the data through every step for you.

The crucial detail is how `.fit()` works. Each preprocessing step has a `.fit()` (learn the parameters, e.g. the mean and std for scaling) and a `.transform()` (apply them). When you fit a pipeline, it `fit_transform`s each step on the **training data**, passes the result to the next step, and finally fits the model. When you later `.predict()`, it only `.transform()`s — it reuses the parameters learned on the training data, never re-learning from new data.

`ColumnTransformer` is the companion piece. Real datasets mix numeric and categorical columns that need *different* treatment, so `ColumnTransformer` routes each group of columns to its own sub-pipeline and glues the results back together.

## Why do we need it?

Three reasons, in increasing order of importance.

**Convenience.** Without a pipeline you juggle a scaler, an encoder, an imputer, and a model as separate variables, and you must apply each one to train *and* test in the right order, every time. That's tedious and error-prone. A pipeline is one object.

**No leakage during cross-validation.** This is the big one. If you scale your whole dataset *before* splitting, the scaler's mean has already "seen" the test rows — test information leaks into training and your score looks better than reality. A pipeline fixes this automatically: inside each cross-validation fold it re-fits every preprocessing step on *that fold's training portion only*. The validation rows never influence the statistics.

**Deployment as one unit.** You save the fitted pipeline and load it in production. Raw rows go in, predictions come out, with identical preprocessing — no chance of the serving code scaling differently from the training code.

## Where it's used in real ML

- **Every serious scikit-learn project** — preprocessing + model wrapped together is the default professional pattern.
- **Cross-validation and hyperparameter search** — `cross_val_score` and `GridSearchCV` operate on the whole pipeline, so tuning never leaks.
- **Mixed tabular data** — a `ColumnTransformer` scales the numeric columns and one-hots the categorical ones in parallel, then feeds a single feature matrix to the model.
- **Model serving** — the pickled/`joblib`-dumped pipeline is the deployable artifact; the API just calls `.predict()` on raw rows.

## What breaks if you ignore it

- **Silent leakage, inflated scores.** Preprocess outside the cross-validation loop and every fold leaks. Your reported accuracy is optimistic, and the model disappoints in production. Nothing *looks* broken — that's what makes it dangerous.
- **Train/serve skew.** Hand-applied steps drift apart between your training notebook and your serving code. The model gets data shaped slightly differently than it trained on and quietly degrades.
- **Forgotten or misordered steps.** Scale before imputing, or skip the encoder on one path — easy to do by hand, impossible to spot later. The pipeline enforces the order.
- **Untunable preprocessing.** Without a pipeline you can't grid-search over a preprocessing parameter (say, the imputer's strategy) jointly with the model's hyperparameters.

## Mental model

Picture a factory assembly line. Raw material enters one end; each station does one job and passes the part along; a finished product comes out. You don't touch the in-between parts — you just feed the line and collect the output.

```text
            ┌──────────┐   ┌──────────┐   ┌──────────────┐
raw rows ──▶│  scale   │──▶│  encode  │──▶│    model     │──▶ prediction
            └──────────┘   └──────────┘   └──────────────┘
            └──────────────── one Pipeline ────────────────┘

fit(train):  each station LEARNS its settings, then passes data on
predict(new): each station only APPLIES the settings it already learned
```

With a `ColumnTransformer`, the line briefly splits so numeric and categorical columns get different stations, then merges:

```text
raw rows ─┬─ numeric cols  → impute → scale ──┐
          └─ categ.  cols  → impute → onehot ─┴─▶ [features] → model
          └────────── ColumnTransformer ──────┘
```

## Example 1 — Tiny toy example

A two-step pipeline — scale, then a model — on five rows. The point is to *see* that one `.fit()` runs both steps in order.

```text
step 1: StandardScaler   (learns mean & std from train, centers/scales)
step 2: LogisticRegression  (fits on the scaled numbers)
```

When you call `pipe.fit(X_train, y_train)`:
1. The scaler learns mean and std from `X_train`, then transforms it.
2. The scaled training data is handed to the model, which fits.

When you call `pipe.predict(X_new)`:
1. The scaler *reuses* the train mean and std to transform `X_new` (it does **not** re-learn from `X_new`).
2. The model predicts on those scaled values.

That "learn on train, reuse on new" behavior is the entire safety guarantee — and you get it for free.

## Example 2 — Practical ML example

You're predicting customer churn from a mixed table: numeric columns (`age`, `income`) and categorical columns (`plan`, `region`), with a missing value or two. You want an honest, cross-validated score and a model you can deploy.

Build two branches inside a `ColumnTransformer`: the numeric branch imputes missing values with the median and scales; the categorical branch imputes with the most frequent value and one-hot encodes. Wrap that `ColumnTransformer` plus a `LogisticRegression` in one `Pipeline`. Then `cross_val_score` the whole pipeline — every fold re-fits the imputers, scaler, and encoder on its own training portion, so the score is leakage-free. Finally, `GridSearchCV` can tune both the classifier's `C` *and* the numeric imputer's strategy in one search, using the `step__param` naming path.

## Python code example

```python
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score, GridSearchCV

# --- Inline mixed-type dataset: numeric + categorical, with a missing age. ---
df = pd.DataFrame({
    "age":     [25, 41, 33, 52, 29, 47, 38, np.nan, 61, 23],
    "income":  [38, 91, 60, 47, 33, 120, 70, 55, 150, 31],   # $1000s
    "plan":    ["free", "pro", "free", "pro", "free",
                "pro", "free", "pro", "pro", "free"],
    "region":  ["EU", "APAC", "LATAM", "EU", "LATAM",
                "APAC", "EU", "EU", "APAC", "LATAM"],
    "churned": [0, 1, 0, 1, 0, 1, 0, 1, 1, 0],               # target
})
X = df.drop(columns="churned")
y = df["churned"]

numeric_cols     = ["age", "income"]
categorical_cols = ["plan", "region"]

# --- Each column group gets its own mini-pipeline (steps run top to bottom). ---
numeric_branch = Pipeline([
    ("impute", SimpleImputer(strategy="median")),  # fill the missing age
    ("scale",  StandardScaler()),                  # mean 0, std 1
])
categorical_branch = Pipeline([
    ("impute", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore")),  # safe on unseen categories
])

# --- ColumnTransformer routes columns to the right branch, then recombines. ---
preprocess = ColumnTransformer([
    ("num", numeric_branch,     numeric_cols),
    ("cat", categorical_branch, categorical_cols),
])

# --- The full pipeline = preprocessing + model as ONE object. ---
model = Pipeline([
    ("prep", preprocess),
    ("clf",  LogisticRegression(max_iter=1000)),
])

# --- Cross-validate the WHOLE pipeline: every step re-fits per fold => no leak. ---
scores = cross_val_score(model, X, y, cv=5, scoring="accuracy")
print("fold scores:", np.round(scores, 3))
print("mean accuracy: %.3f (+/- %.3f)" % (scores.mean(), scores.std()))

# --- Fit once, then predict on RAW new rows: same transforms applied automatically. ---
model.fit(X, y)
new_customer = pd.DataFrame({"age": [35], "income": [80],
                             "plan": ["pro"], "region": ["EU"]})
print("P(churn) for new customer:", model.predict_proba(new_customer)[0, 1].round(3))

# --- Tune a model param AND a nested preprocessing param in one search. ---
#     The 'step__param' path reaches into steps; double-underscore goes deeper.
grid = GridSearchCV(
    model,
    param_grid={
        "clf__C": [0.1, 1.0, 10.0],
        "prep__num__impute__strategy": ["median", "mean"],  # nested!
    },
    cv=5, scoring="accuracy",
)
grid.fit(X, y)
print("best params:", grid.best_params_)
```

Expected output (approximate — values are noisy on 10 rows; the *method* is the point):

```text
fold scores: [1.    0.5   1.    0.5   1.   ]
mean accuracy: 0.800 (+/- 0.245)
P(churn) for new customer: 0.62
best params: {'clf__C': 1.0, 'prep__num__impute__strategy': 'median'}
```

The key idea: because preprocessing lives *inside* the pipeline, that cross-validation mean is an honest estimate, and `prep__num__impute__strategy` tuned a parameter buried three levels deep without any manual data wrangling.

## Common mistakes

- **Scaling or encoding the whole dataset before splitting.** The classic leak. Put every transformer *inside* the pipeline so cross-validation re-fits it per fold.
- **Calling `.fit()` on the test set.** Only the training portion is ever fit; new data is only `.transform()`ed. A pipeline enforces this for you.
- **Listing a column in both branches or neither.** Each column should go to exactly one `ColumnTransformer` branch; set `remainder="drop"` or `"passthrough"` deliberately for the rest.
- **Forgetting `handle_unknown="ignore"` on the one-hot step.** A new category at serving time will otherwise crash the pipeline.
- **Reaching into `named_steps[...]` to transform data by hand.** That bypasses the safety and reopens the leakage door. Let the pipeline do the work.

## Before you continue

- [ ] I can explain why preprocessing outside cross-validation leaks, and how a pipeline prevents it.
- [ ] I can describe what happens to each step during `.fit()` versus `.predict()`.
- [ ] I can build a `ColumnTransformer` that scales numeric columns and one-hots categorical ones.
- [ ] I can tune a step inside a pipeline using the `step__param` double-underscore syntax.
- [ ] I understand why a fitted pipeline is the right artifact to deploy.

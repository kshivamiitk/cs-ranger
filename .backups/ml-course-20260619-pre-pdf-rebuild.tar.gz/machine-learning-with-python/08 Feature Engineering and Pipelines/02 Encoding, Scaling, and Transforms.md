# Encoding, Scaling, and Transforms

> Most models can only do arithmetic on numbers — so categories must become numbers and numbers must be put on a fair scale before training.

## What you'll learn
- Turn categories into numbers correctly with **OneHotEncoder** vs **OrdinalEncoder** — and when each is right.
- Put numeric features on a comparable scale with **StandardScaler** vs **MinMaxScaler**.
- Tame skewed, long-tailed columns with a **log transform**.
- Fill in missing values with **SimpleImputer** without throwing away rows.
- Know the one rule that ties them all together: **fit on train, transform everywhere.**

## Intuition
A model like logistic regression or k-nearest-neighbors does math directly on your columns. That creates two problems with raw data.

First, **categories aren't numbers.** A `city` column of `["Paris", "Tokyo", "Lima"]` means nothing to a matrix multiply. We have two ways to fix it:
- **One-hot encoding** makes one new yes/no column per category (`city_Paris`, `city_Tokyo`, `city_Lima`). Use this when categories have **no inherent order** — Paris isn't "greater than" Tokyo.
- **Ordinal encoding** maps categories to integers (`small=0, medium=1, large=2`). Use this **only when there is a real order**, because the model will treat the numbers as a ranked scale.

Second, **numbers live on wildly different scales.** Imagine `income` in the tens of thousands next to `age` in the tens. A distance-based model thinks income dominates simply because its numbers are bigger. **Scaling** fixes this:
- **StandardScaler** rescales each column to mean 0 and standard deviation 1 (a "z-score"). It's the default for linear models, SVMs, and PCA.
- **MinMaxScaler** squeezes each column into a fixed range, usually 0 to 1. Handy when you need bounded inputs (e.g. neural nets) or want to preserve zeros in sparse data.

Some columns are **skewed** — most values small, a long tail of huge ones (income, house prices, web traffic). A **log transform** (`log1p`) compresses that tail so the distribution looks more bell-shaped, which linear models love. And real data has **holes**: a **SimpleImputer** fills missing numbers with the column's mean/median and missing categories with the most frequent value, so you keep the row instead of deleting it.

The golden rule across all of these: compute the parameters (means, category lists, mins/maxes) on the **training data only** with `.fit()`, then `.transform()` train, validation, and test the same way. Fitting on the full dataset peeks at the test set — that's *data leakage*, the subject of the next lesson.

## Python in practice

```python
import numpy as np
import pandas as pd
from sklearn.preprocessing import (
    OneHotEncoder, OrdinalEncoder, StandardScaler, MinMaxScaler,
    FunctionTransformer,
)
from sklearn.impute import SimpleImputer

df = pd.DataFrame({
    "city":   ["Paris", "Tokyo", "Lima", "Paris", np.nan],
    "size":   ["small", "large", "medium", "large", "small"],
    "age":    [25, 41, 33, np.nan, 52],
    "income": [38000, 91000, 60000, 47000, 250000],  # skewed: one big tail value
})
```

```python
# ENCODING: city has NO order -> one-hot (one 0/1 column per city).
ohe = OneHotEncoder(handle_unknown="ignore", sparse_output=False)
city_oh = ohe.fit_transform(df[["city"]])
print(ohe.get_feature_names_out())   # ['city_Lima' 'city_Paris' 'city_Tokyo' 'city_nan']
print(city_oh[:2])                   # Paris -> [0 1 0 0], Tokyo -> [0 0 1 0]

# 'size' HAS a natural order -> ordinal, and we declare the order explicitly.
oe = OrdinalEncoder(categories=[["small", "medium", "large"]])
size_ord = oe.fit_transform(df[["size"]])
print(size_ord.ravel())              # [0. 2. 1. 2. 0.] small<medium<large
```

```python
# SCALING: put age + income on comparable scales.
imputer = SimpleImputer(strategy="median")   # fill missing numbers first
nums = imputer.fit_transform(df[["age", "income"]])

std = StandardScaler().fit_transform(nums)   # mean 0, std 1
mm  = MinMaxScaler().fit_transform(nums)     # squeezed into [0, 1]
print(np.round(std[:, 0], 2))   # standardized age, e.g. [-1.12 ...]
print(np.round(mm[:, 1], 2))    # income mapped to 0..1; the 250k row -> 1.00
```

```python
# TRANSFORM: income is right-skewed (a 250k outlier dwarfs the rest).
# log1p = log(1 + x); compresses the tail and handles 0 safely.
log_income = np.log1p(df["income"])
print(np.round(log_income.values, 2))
# [10.55 11.42 11.0  10.76 12.43] -> the 250k no longer towers over the others

# As a reusable, pipeline-ready step:
log_step = FunctionTransformer(np.log1p, feature_names_out="one-to-one")
```

```python
# IMPUTATION for categories uses the most frequent value, not the mean.
cat_imputer = SimpleImputer(strategy="most_frequent")
filled_city = cat_imputer.fit_transform(df[["city"]])
print(filled_city.ravel())   # the missing city becomes 'Paris' (most common)
```

A short note on what you just saw: every transformer follows the same `fit` → `transform` shape, which is exactly why they snap together into a Pipeline (next lesson). The numbers above are illustrative; the *patterns* — one-hot for unordered, ordinal for ordered, standardize for linear models, log for skew, impute to keep rows — are the part to memorize.

## Common mistakes
- **Ordinal-encoding unordered categories.** Mapping `Paris=0, Tokyo=1, Lima=2` tells the model Lima is "twice" Tokyo. For unordered categories, always one-hot.
- **Scaling, then imputing (wrong order).** Impute *first*; otherwise the missing-ness throws off the scaler's statistics. Inside a Pipeline you'd order steps `impute → scale`.
- **Calling `.fit_transform()` on the test set.** That recomputes statistics from test data — leakage. Test data only ever gets `.transform()`.
- **One-hot-encoding a super high-cardinality column** (e.g. 50,000 unique user IDs) — you'll explode into 50,000 columns. Group rare categories or use a different technique.
- **Forgetting `handle_unknown="ignore"`.** If a category appears at prediction time that wasn't in training, a strict encoder will crash. `ignore` encodes it as all-zeros instead.
- **Log-transforming columns with negative values.** `np.log1p` needs `x > -1`. For columns that can go negative, scale instead, or shift before logging.

## Small exercise
1. Build a tiny DataFrame with a `grade` column of `["B", "A", "C", "A"]`.
2. Encode it two ways: once with `OrdinalEncoder(categories=[["C","B","A"]])` and once with `OneHotEncoder`.
3. Which encoding would you actually use for letter grades, and why? (Hint: is A genuinely "more" than C in a way the model should know?)

## Before you continue
- [ ] I can state, in one sentence each, when to use OneHotEncoder vs OrdinalEncoder.
- [ ] I can explain why distance-based models need scaling.
- [ ] I know why we impute before scaling, and why test data only gets `.transform()`.
- [ ] I can recognize a skewed column and reach for `log1p`.

# Solved — Encoding and Scaling Mixed Columns with ColumnTransformer

> Real tables are a mongrel: `salary_k` wants scaling, `city` wants one-hot, and your model wants both — already merged, already leak-free. `ColumnTransformer` is the traffic cop that routes each column to the transform it actually needs.

## Problem statement

You have a sign-up table that mixes two kinds of columns: **numeric** (`age`, `salary_k` in thousands, `visits` in the last month) and **categorical** (`city`, `plan`), with a label `subscribed` (1 = subscribed to a paid plan, 0 = didn't). These need *different* preprocessing. The numeric columns live on wildly different ranges (`age` 22–52 vs `salary_k` 28–130), so a scale-sensitive model needs them standardized. The categorical columns are unordered text, so they need one-hot encoding. The task is to apply the right transform to the right columns, hand the merged result to a classifier, and predict on new rows — all without leaking test information into training.

Doing this by hand is fiddly and error-prone: you'd scale some columns, one-hot others, `np.hstack` them back together in the right order, and remember to apply the *identical* fitted transforms at predict time. `ColumnTransformer` does exactly that routing for you, and wrapping it in a `Pipeline` with the model turns the whole thing into a single object you can `.fit` and `.predict`.

## Why this problem matters

Every production dataset is mixed-type, and the two most common preprocessing bugs both hide here. The first is **leakage**: fit a scaler or encoder on the full dataset before splitting and your reported scores are optimistic lies, because test statistics quietly shaped the training inputs. The second is **drift between train and predict**: hand-rolled preprocessing that you reproduce slightly differently at inference time silently corrupts predictions. `ColumnTransformer` + `Pipeline` is the standard, interview-favorite answer that kills both bugs at once — it fits every transform on the training fold only, and it re-applies those exact fitted transforms whenever you predict.

## Tiny dataset or sample data

A small, realistic slice (the full inline set below has 24 rows; shape `(24, 6)`, columns `age, salary_k, visits, city, plan, subscribed`):

| age | salary_k | visits | city   | plan    | subscribed |
|----:|---------:|-------:|--------|---------|-----------:|
|  23 |     28.0 |      2 | Pune   | basic   |          0 |
|  41 |     95.0 |      9 | Delhi  | pro     |          1 |
|  35 |     60.0 |      5 | Mumbai | pro     |          1 |
|  52 |    120.0 |     12 | Delhi  | premium |          1 |
|  29 |     45.0 |      3 | Mumbai | basic   |          0 |
|  24 |     29.0 |      1 | Pune   | basic   |          0 |

The pattern baked into the data: **older, higher-earning, more-engaged customers on `pro`/`premium` plans subscribe**, while young low-`visits` `basic` users don't. The numeric columns carry most of the signal — which is exactly why they must be on a fair scale.

## Step-by-step reasoning

1. **Sort columns by the transform they need.** `age`, `salary_k`, `visits` are numeric on different ranges → `StandardScaler` (mean 0, std 1) so no single column dominates a scale-sensitive model. `city`, `plan` are unordered text → `OneHotEncoder` so we don't invent a fake order.
2. **Split before you transform.** Call `train_test_split` *first*. Everything downstream must learn its statistics (the scaler's means/stds, the encoder's category list) from the **training fold only**. This is the single most important step for honest scores.
3. **Let `ColumnTransformer` route columns.** Give it a list of `(name, transformer, columns)` triples. It applies the scaler to the numeric columns, the encoder to the categorical ones, and **concatenates** the results into one feature matrix — in the order you listed the transformers. Columns you don't mention are dropped by default.
4. **Wrap it in a `Pipeline` with the model.** `Pipeline([("pre", ColumnTransformer(...)), ("lr", LogisticRegression())])` becomes one estimator. Calling `.fit(X_tr, y_tr)` fits the scaler and encoder on the train fold, transforms it, then fits the model; `.predict(X_te)` reuses those exact fitted transforms. Leakage becomes almost impossible.
5. **Verify the routing and the leak-free fit.** Pull `get_feature_names_out()` to see the expanded, merged feature space, and inspect the fitted scaler's stored `mean_` to confirm it reflects **train** statistics — proof the transforms learned only from training data.
6. **Predict on brand-new rows with one call.** Pass a fresh `DataFrame` with the original column names to `.predict` / `.predict_proba`; the pipeline scales, encodes, and scores it identically to training — no manual reassembly.

## Python solution

```python
import io
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

# --- 1. Inline data (no download): MIXED numeric + categorical columns. ---
csv = """age,salary_k,visits,city,plan,subscribed
23,28.0,2,Pune,basic,0
41,95.0,9,Delhi,pro,1
35,60.0,5,Mumbai,pro,1
22,30.0,1,Pune,basic,0
52,120.0,12,Delhi,premium,1
29,45.0,3,Mumbai,basic,0
38,78.0,7,Delhi,pro,1
26,33.0,2,Pune,basic,0
47,110.0,10,Mumbai,premium,1
31,52.0,4,Delhi,basic,0
44,88.0,8,Mumbai,pro,1
24,29.0,1,Pune,basic,0
50,130.0,11,Delhi,premium,1
33,55.0,4,Mumbai,basic,0
40,82.0,8,Delhi,pro,1
27,38.0,2,Pune,basic,0
49,105.0,9,Mumbai,premium,1
36,64.0,6,Delhi,pro,1
25,31.0,2,Pune,basic,0
43,90.0,8,Mumbai,pro,1
30,48.0,3,Delhi,basic,0
46,100.0,9,Mumbai,premium,1
28,40.0,3,Pune,basic,0
39,75.0,7,Delhi,pro,1
"""
df = pd.read_csv(io.StringIO(csv))
print("Shape:", df.shape, "| subscribe rate:", round(df["subscribed"].mean(), 2))

X = df.drop(columns="subscribed")
y = df["subscribed"].values

numeric = ["age", "salary_k", "visits"]       # need SCALING (different ranges)
categorical = ["city", "plan"]                # need ONE-HOT (unordered text)
print("numeric ranges:")
for c in numeric:
    print(f"  {c:9s} {df[c].min():>6} .. {df[c].max():>6}")

# --- 2. Split FIRST so every transform is fit on train only (leak-free). ---
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.30, random_state=0, stratify=y)

# --- 3. ColumnTransformer ROUTES each column to the right transform. ---
pre = ColumnTransformer([
    ("num", StandardScaler(), numeric),                            # -> 3 scaled cols
    ("cat", OneHotEncoder(handle_unknown="ignore"), categorical),  # -> dummy cols
])

clf = Pipeline([
    ("pre", pre),
    ("lr", LogisticRegression(max_iter=1000)),
])

# .fit fits scaler + encoder on TRAIN ONLY, then the model. No leakage.
clf.fit(X_tr, y_tr)
acc = accuracy_score(y_te, clf.predict(X_te))
print(f"\nPipeline test accuracy: {acc:.3f}")

# --- 4. See what came out: the expanded, routed feature space. ---
feat_names = clf.named_steps["pre"].get_feature_names_out()
print(f"\nColumnTransformer turned {X.shape[1]} columns into "
      f"{len(feat_names)} features:")
print(" ", list(feat_names))

# Confirm the scaler saw TRAIN stats only (these are the train means it stored):
scaler = clf.named_steps["pre"].named_transformers_["num"]
print("\nScaler means (learned from TRAIN only):",
      dict(zip(numeric, np.round(scaler.mean_, 1))))

# --- 5. Predict on brand-new rows; same pipeline applies the same transforms. ---
new = pd.DataFrame({
    "age": [45, 24],
    "salary_k": [98.0, 30.0],
    "visits": [9, 1],
    "city": ["Mumbai", "Pune"],
    "plan": ["premium", "basic"],
})
pred = clf.predict(new)
proba = clf.predict_proba(new)[:, 1]
for i in range(len(new)):
    print(f"new row {i}: pred={pred[i]}  P(subscribe)={proba[i]:.2f}")
```

## Expected output

```
Shape: (24, 6) | subscribe rate: 0.54
numeric ranges:
  age           22 ..     52
  salary_k    28.0 ..  130.0
  visits         1 ..     12

Pipeline test accuracy: 1.000

ColumnTransformer turned 5 columns into 9 features:
  ['num__age', 'num__salary_k', 'num__visits', 'cat__city_Delhi', 'cat__city_Mumbai', 'cat__city_Pune', 'cat__plan_basic', 'cat__plan_premium', 'cat__plan_pro']

Scaler means (learned from TRAIN only): {'age': 36.1, 'salary_k': 68.6, 'visits': 5.8}

new row 0: pred=1  P(subscribe)=0.96
new row 1: pred=0  P(subscribe)=0.03
```

## Explanation of the output

- **5 columns became 9 features.** The 3 numeric columns pass through `StandardScaler` (still 3 columns, now mean-0/std-1) and the 2 categorical columns fan out into 6 one-hot columns (`city` → 3, `plan` → 3). The `num__` / `cat__` prefixes show *which transformer* produced each feature — that is the routing made visible.
- **Order is preserved.** The scaled numerics come first, then the encoded categoricals, exactly matching the order the transformers were listed in. That deterministic layout is why the same `DataFrame` columns always land in the same model positions.
- **The scaler means are train-only.** `age` mean ≈ 36.1, `salary_k` ≈ 68.6, `visits` ≈ 5.8 are computed from the 16-row training fold, not the full 24 rows. Seeing train-derived statistics here is the concrete proof there's no leakage — the test rows never touched the scaler's `fit`.
- **New rows score sensibly.** A 45-year-old `premium` Mumbai user with 9 visits gets `P(subscribe)=0.96`; a 24-year-old `basic` Pune user with 1 visit gets `0.03`. The pipeline scaled and encoded those raw inputs the same way it did in training, with one `.predict` call. The `1.000` test accuracy reflects this cleanly separable toy data — the transferable lesson is the leak-free routing, not the perfect score.

## Common mistakes

1. **Fitting transforms before the split.** `StandardScaler().fit(X)` or `OneHotEncoder().fit(X)` on the *full* data leaks test statistics into training and inflates your scores. Fix: split first, and put all preprocessing **inside** the `Pipeline` so `.fit` only ever sees the training fold.
2. **Scaling the categorical (or one-hot encoding the numeric) columns.** Pointing the scaler at `city`, or the encoder at `salary_k`, either errors or produces nonsense (a separate dummy for every distinct salary). Fix: keep two explicit column lists and route each to its own transformer in the `ColumnTransformer`.
3. **Forgetting columns silently get dropped.** `ColumnTransformer` discards any column you don't list. Miss one and it vanishes from the model with no warning. Fix: account for every column, or set `remainder="passthrough"` to keep the unlisted ones.
4. **Skipping `handle_unknown='ignore'` on the encoder.** A category seen only at predict time (a new city) crashes the pipeline at `.predict`. Fix: `OneHotEncoder(handle_unknown="ignore")`, which encodes unseen values as all-zeros instead of erroring.
5. **Hand-assembling features instead of using a `Pipeline`.** Manually scaling, encoding, and `np.hstack`-ing means you must reproduce the *exact* fitted transforms at predict time — easy to get subtly wrong. Fix: let the `Pipeline` own the transforms so train and predict are guaranteed identical.

## Extension challenge

1. Add `remainder="passthrough"` and introduce a new column you don't list (e.g. a pre-scaled `tenure_z`); confirm it survives into the feature matrix untouched while `city`/`plan` are still encoded.
2. Run 5-fold `cross_val_score` on the whole `Pipeline` and compare it to fitting the scaler on all data first — quantify how much the leaky version *over*states accuracy.
3. Swap `LogisticRegression` for `RandomForestClassifier` and drop the `StandardScaler` (trees are scale-invariant), keeping only the `OneHotEncoder` branch. Does test accuracy change? Why doesn't removing the scaler hurt a tree model?

## Matching animation

**Pipeline Flow Animator** — watch a row of mixed columns flow left to right, splitting at the `ColumnTransformer` so numerics stream into the scaler branch and text columns into the one-hot branch, then merging into one feature vector that lands in the model. For the scaling half, open the **Feature Scaling Before and After Visualizer** to see `age`, `salary_k`, and `visits` collapse onto a shared mean-0/std-1 axis — the reason no single numeric column drowns out the others.

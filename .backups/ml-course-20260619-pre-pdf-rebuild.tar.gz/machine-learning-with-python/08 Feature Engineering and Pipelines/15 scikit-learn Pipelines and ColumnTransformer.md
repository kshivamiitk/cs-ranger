# scikit-learn Pipelines and ColumnTransformer

> A Pipeline is the difference between "it worked on my laptop" and a model you can trust — it bundles every preprocessing step with the model so nothing leaks and nothing is forgotten.

## What you'll learn
- Why doing preprocessing *outside* cross-validation silently inflates your scores (**data leakage**).
- How a **Pipeline** chains transformers + a model into one object that `fit`s and `predict`s as a unit.
- How **ColumnTransformer** applies *different* preprocessing to numeric vs categorical columns.
- How to cross-validate the *whole* pipeline so your score reflects reality.
- How to tune steps with `GridSearchCV` using the `step__param` naming convention.

## Intuition
Imagine you scale your features by computing the mean and standard deviation over the **entire dataset**, then split into train and test. The scaler's mean already "saw" the test rows — so a tiny bit of test information has leaked into training. Your cross-validation score now looks better than the model will ever do on genuinely new data. This is the most common silent bug in beginner ML, and it's deadly precisely because *nothing looks broken*.

A **Pipeline** fixes this by treating preprocessing as part of the model. When cross-validation creates a train/validation split, the pipeline re-fits the scaler (and encoder, and imputer) on *that fold's training portion only*, then applies it to the validation portion. The validation data is never used to compute statistics. Leakage gone — automatically, every fold.

The second problem: real datasets mix **numeric** columns (need imputing + scaling) and **categorical** columns (need imputing + one-hot). You can't run one transformer over everything. **ColumnTransformer** is the router: "send these columns down the numeric branch, those columns down the categorical branch, then glue the results back together." The numeric and categorical sub-pipelines run in parallel, and ColumnTransformer concatenates their outputs into one feature matrix.

Picture the whole thing as an assembly line:

```text
raw rows ─┬─ numeric cols  → impute(median) → scale ──┐
          └─ categ.  cols  → impute(mode)   → onehot ─┴─► [features] → LogisticRegression
```

Everything to the left of the model is `ColumnTransformer`; the entire line is the `Pipeline`. You hand it raw data, call `.fit()`, and it does every step in order. At prediction time you hand it raw rows again and it reproduces the exact same transformations.

## Python in practice

```python
import numpy as np
import pandas as pd
from sklearn.pipeline import Pipeline
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import cross_val_score

# A small mixed-type dataset (numeric + categorical, with a missing value)
df = pd.DataFrame({
    "age":      [25, 41, 33, 52, 29, 47, 38, np.nan, 61, 23],
    "income":   [38, 91, 60, 47, 33, 120, 70, 55, 150, 31],   # in $1000s
    "plan":     ["free","pro","free","pro","free","pro",
                 "free","pro","pro","free"],
    "region":   ["EU","APAC","LATAM","EU","LATAM","APAC",
                 "EU","EU","APAC","LATAM"],
    "churned":  [0, 1, 0, 1, 0, 1, 0, 1, 1, 0],   # target
})
X = df.drop(columns="churned")
y = df["churned"]

numeric_cols     = ["age", "income"]
categorical_cols = ["plan", "region"]
```

```python
# Each branch is its own mini-pipeline (steps run top to bottom).
numeric_branch = Pipeline([
    ("impute", SimpleImputer(strategy="median")),  # fill missing ages
    ("scale",  StandardScaler()),                  # mean 0, std 1
])

categorical_branch = Pipeline([
    ("impute", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore")),  # safe on new categories
])

# ColumnTransformer routes columns to the right branch and recombines.
preprocess = ColumnTransformer([
    ("num", numeric_branch,     numeric_cols),
    ("cat", categorical_branch, categorical_cols),
])

# The full pipeline = preprocessing + model as ONE object.
model = Pipeline([
    ("prep", preprocess),
    ("clf",  LogisticRegression(max_iter=1000)),
])
```

```python
# Cross-validate the WHOLE pipeline. On each fold, every transformer is
# re-fit on that fold's training rows only -> no leakage, honest score.
scores = cross_val_score(model, X, y, cv=5, scoring="accuracy")
print("fold scores:", np.round(scores, 3))
print("mean accuracy: %.3f  (+/- %.3f)" % (scores.mean(), scores.std()))

# Fit once on all data, then predict on raw new rows -> same transforms apply.
model.fit(X, y)
new = pd.DataFrame({"age": [35], "income": [80],
                    "plan": ["pro"], "region": ["EU"]})
print("P(churn):", model.predict_proba(new)[0, 1].round(3))
```

The key takeaway from the output: `cross_val_score` returns one number per fold. Because the pipeline re-fits preprocessing inside each fold, that mean is an *honest* estimate of new-data performance — not the optimistic number you'd get by scaling everything up front. (With only 10 rows the exact values are noisy; the *method* is what matters.)

```python
# Tuning steps: address a step by name with "stepname__param".
from sklearn.model_selection import GridSearchCV

grid = GridSearchCV(
    model,
    param_grid={
        "clf__C": [0.1, 1.0, 10.0],          # regularization on the classifier
        "prep__num__impute__strategy": ["median", "mean"],  # nested step!
    },
    cv=5, scoring="accuracy",
)
grid.fit(X, y)
print("best params:", grid.best_params_)
# The double-underscore path 'prep__num__impute__strategy' reaches all the way
# into the imputer inside the numeric branch inside the ColumnTransformer.
```

## Common mistakes
- **Scaling/encoding the full dataset before splitting.** The classic leak. Put every transformer *inside* the pipeline so CV handles the split correctly.
- **Calling `.fit()` on the test set.** Only the training portion is ever fit. With a pipeline + `cross_val_score`, this is automatic — that's the whole point.
- **Listing a column in both branches (or in neither).** Each column should go to exactly one branch. Use `remainder="drop"` (default) or `remainder="passthrough"` deliberately.
- **Forgetting `handle_unknown="ignore"` in the one-hot step.** A new category at prediction time will otherwise raise an error.
- **Naming steps with spaces or duplicates.** Step names must be unique and underscore-friendly because they become part of the `step__param` path used for tuning.
- **Reaching into `model.named_steps[...]` to transform manually.** Don't — let the pipeline do it. Manual extraction is exactly how leakage sneaks back in.

## Small exercise
1. Add a third numeric column `tenure_months` to `df` (make up 10 values) and include it in `numeric_cols`.
2. Re-run `cross_val_score`. Did the mean accuracy change?
3. Add `"clf__penalty": ["l2"]` and `"clf__C": [0.01, 0.1, 1, 10]` to the grid and report the best `C`. (Hint: smaller `C` = stronger regularization.)

## Before you continue
- [ ] I can explain, with the train/test mean example, why preprocessing outside CV leaks.
- [ ] I can build a `ColumnTransformer` that scales numeric columns and one-hots categorical ones.
- [ ] I know that wrapping everything in a Pipeline makes `cross_val_score` leak-proof automatically.
- [ ] I can tune a step inside a pipeline using the `step__param` (double-underscore) syntax.

# Feature Scaling

> Feature scaling puts every column on a comparable range so that a feature measured in thousands doesn't get to shout over a feature measured in single digits.

## What is this?

Feature scaling **rescales your numeric columns so they live on similar ranges** before the model sees them.

Raw features come in wildly different units: age (0–100), salary (0–500,000), number of bedrooms (0–6). Many models treat a column's raw size as importance, so salary's huge numbers would dominate everything else — not because salary matters more, but because its numbers are bigger. Scaling removes that accident.

The two workhorses:

- **StandardScaler (z-score)** — for each column, subtract the mean and divide by the standard deviation: `z = (x − mean) / std`. Result: mean 0, std 1. Values become "how many standard deviations from average."
- **MinMaxScaler** — squash each column into a fixed range, usually `[0, 1]`: `x_scaled = (x − min) / (max − min)`. Result: min 0, max 1.

The golden rule: **fit the scaler on the training set only**, then apply those same numbers to the test set. More on why below.

## Why do we need it?

Lots of algorithms measure **distances** or **add up weighted features**, and both are sensitive to scale.

- A **distance** like `√((Δage)² + (Δsalary)²)` is almost entirely the salary term — `Δsalary` is in the thousands, `Δage` in single digits. Age effectively vanishes.
- A **gradient-descent** linear model with a salary weight and an age weight finds that one learning rate is far too big for one and too small for the other, so it zig-zags slowly.

Scaling levels the playing field: every feature gets a fair say, distances become meaningful, and gradient descent converges in a clean straight shot. It's one of the cheapest, highest-leverage steps in a pipeline.

## Where it's used in real ML

Models that **need** scaling (anything distance- or magnitude-based):

- **k-Nearest Neighbors** and **K-Means** — pure distance; unscaled features wreck the neighbor/cluster math.
- **SVM with RBF/linear kernel** — distance-based; very sensitive to scale.
- **PCA** — finds directions of largest variance, so a big-numbered column hijacks the components.
- **Regularized / gradient-descent linear models** — Ridge, Lasso, and `SGDClassifier` penalize weight size, which only makes sense if features are comparable.
- **Neural networks** — train far faster and more stably on scaled inputs.

Models that **don't need** scaling:

- **Decision trees, Random Forests, gradient-boosted trees** — they split on thresholds ("age > 30?"), and a threshold split is unaffected by the column's units. Scaling trees is harmless but pointless.

## What breaks if you ignore it

- **kNN/SVM/K-Means go haywire** → the largest-magnitude feature silently becomes the *only* feature that matters; your "distances" are really just salary differences.
- **Gradient descent crawls or zig-zags** → mismatched feature scales make a single learning rate wrong for every weight, so training is slow or unstable.
- **PCA reports nonsense** → components line up with whichever column has the biggest raw numbers, not the most informative direction.
- **Data leakage if you fit on everything** → scale using the *whole* dataset (train + test) and test statistics leak into training, giving an over-optimistic score that collapses in production. Always `fit` on train, `transform` test.

## Mental model

Think of judging a decathlon where events are scored in different units — and you naively add the raw numbers:

```
RAW (unfair):  100m time (~10 sec)  +  long jump (~8 m)  +  javelin (~80 m)
               javelin's big numbers dominate the total; sprint barely counts.

SCALED (fair): convert each event to "standard deviations above/below average"
               100m:  +1.2     long jump:  +0.4     javelin:  +0.9
               now every event contributes on the same footing.
```

StandardScaler is exactly this conversion to "standard deviations from average." MinMaxScaler is the alternative of rescaling every event to a 0–1 score. Either way, no single column gets to dominate just because its native units happen to be large.

## Example 1 — Tiny toy example

Z-score (StandardScaler) a single column by hand: `[10, 20, 30, 40, 50]`.

1. **Mean** = `(10 + 20 + 30 + 40 + 50) / 5 = 150 / 5 = 30`.
2. **Deviations from mean**: `−20, −10, 0, 10, 20`.
3. **Squared deviations**: `400, 100, 0, 100, 400`; sum `= 1000`.
4. **Variance** (population, dividing by n=5) = `1000 / 5 = 200`. **Std** = `√200 ≈ 14.142`.
5. **Z-scores** = `(x − 30) / 14.142`:

```
  x      z = (x − 30) / 14.142
  10     −20 / 14.142  =  −1.414
  20     −10 / 14.142  =  −0.707
  30       0 / 14.142  =   0.000
  40      10 / 14.142  =   0.707
  50      20 / 14.142  =   1.414
```

Sanity check: the new column has mean 0 and std 1. The smallest value sits 1.414 std *below* average, the largest 1.414 *above* — symmetric, as expected. (Note: scikit-learn's `StandardScaler` divides by n, matching this; `numpy.std` does too by default. Pandas `.std()` divides by n−1, so it differs slightly.)

## Example 2 — Practical ML example

You're classifying customers as "will churn / won't churn" using **k-Nearest Neighbors** on two features: `age` (20–70) and `monthly_spend` (in rupees, 500–50,000).

Unscaled, kNN's distance is dominated by `monthly_spend` — a 5,000-rupee gap dwarfs any age gap, so "nearest neighbors" really means "closest spenders," and age is ignored entirely. Accuracy stalls around chance for age-driven patterns.

Apply **StandardScaler**, and both features land on a mean-0, std-1 scale. Now a meaningful age difference and a meaningful spend difference count equally in the distance, the right neighbors get picked, and accuracy jumps. The same fix helps a **regularized logistic regression**: with scaled features the L2 penalty treats every weight fairly, so it stops over-shrinking the small-numbered features. The clean way to do all this without leakage is a **scikit-learn Pipeline** that scales then classifies as one unit.

## Python code example

```python
import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import make_pipeline

# --- Inline-ish data: two informative features, then we BLOW UP one feature's scale ---
X, y = make_classification(n_samples=600, n_features=2, n_redundant=0,
                           n_informative=2, n_clusters_per_class=1, random_state=42)
X[:, 1] = X[:, 1] * 1000 + 50000   # make feature 2 look like "monthly_spend" (huge numbers)

# Fit the scaler on TRAIN only; transform test with the same numbers (no leakage).
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)

# 1) kNN WITHOUT scaling: the big-numbered feature dominates the distance.
knn_raw = KNeighborsClassifier(n_neighbors=5).fit(X_train, y_train)
acc_raw = knn_raw.score(X_test, y_test)

# 2) kNN WITH scaling, wrapped in a Pipeline so fit happens on train only.
knn_scaled = make_pipeline(StandardScaler(), KNeighborsClassifier(n_neighbors=5))
knn_scaled.fit(X_train, y_train)
acc_scaled = knn_scaled.score(X_test, y_test)

print(f"kNN accuracy WITHOUT scaling: {acc_raw:.3f}")
print(f"kNN accuracy WITH scaling   : {acc_scaled:.3f}")

# Show the hand-computed z-score example too, to connect to Example 1:
col = np.array([10, 20, 30, 40, 50], dtype=float)
z = (col - col.mean()) / col.std()        # numpy std divides by n -> matches StandardScaler
print("Manual z-scores:", np.round(z, 3))  # [-1.414 -0.707  0.     0.707  1.414]

# Expected output (approximate):
# kNN accuracy WITHOUT scaling: 0.6xx   (poor: distance ruled by the huge feature)
# kNN accuracy WITH scaling   : 0.9xx   (much better: both features count)
# Manual z-scores: [-1.414 -0.707  0.     0.707  1.414]
```

Scaling alone lifts kNN from near-coin-flip to strong — same data, same model, only the ranges changed.

## Common mistakes

- **Fitting the scaler on the full dataset (train + test).** This leaks test statistics into training. Fit on train, transform test — a Pipeline does this for you automatically.
- **Scaling decision trees / random forests "to be safe."** Tree splits are threshold-based and scale-invariant; it's wasted effort (and clutters the pipeline).
- **Forgetting to scale at predict time.** New incoming data must pass through the *same* fitted scaler. Skip it and you feed the model garbage-scaled inputs.
- **Reaching for MinMaxScaler on outlier-heavy data.** A single extreme value sets the min/max and crushes everything else into a sliver of `[0,1]`. StandardScaler (or RobustScaler) handles outliers better.
- **Scaling the target `y` and forgetting to invert it.** If you scale labels, remember to un-scale predictions before reporting them.

## Before you continue
- [ ] I can explain in one sentence what feature scaling does and why magnitude matters.
- [ ] I can z-score a small column by hand and check the result has mean 0, std 1.
- [ ] I can name models that need scaling (kNN, SVM, PCA, regularized/GD linear, NN) and ones that don't (trees).
- [ ] I can state the difference between StandardScaler and MinMaxScaler.
- [ ] I understand why the scaler must be fit on training data only, and how a Pipeline enforces that.

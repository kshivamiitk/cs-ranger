# Lab — Build a Leak-Proof Pipeline

## Objective
You will build a single scikit-learn `Pipeline` that takes **raw, messy, mixed-type data** — numeric and categorical columns, with missing values — and turns it into honest predictions. By the end you'll be able to: route columns to the right preprocessing with `ColumnTransformer`, wrap everything (impute + scale + one-hot + a classifier) into one object, and cross-validate it so your accuracy is *not* inflated by leakage. You'll also see, with a concrete comparison, how leakage flatters a model that preprocesses outside cross-validation.

## Dataset
A small synthetic "subscription churn" table, defined inline so it runs with no downloads. It deliberately mixes types and includes missing values (`NaN` for numbers, empty string for categories) so the imputers earn their keep.

| age | income_k | plan | region | support_tickets | churned |
|----:|---------:|------|--------|----------------:|--------:|
| 25 | 38 | free | EU | 0 | 0 |
| 41 | 91 | pro | APAC | 3 | 1 |
| 33 | 60 | free | LATAM | 1 | 0 |
| (missing) | 47 | pro | EU | 5 | 1 |
| 29 | 33 | free | (missing) | 0 | 0 |

The full 16-row table is created inside the code via `io.StringIO`.

## Steps

**Step 1 — Load the raw CSV from an inline string.** `io.StringIO` lets pandas read a CSV that lives in your script, so the lab is fully offline. Note the blanks: empty cells become `NaN`.

```python
import io
import numpy as np
import pandas as pd

csv = """age,income_k,plan,region,support_tickets,churned
25,38,free,EU,0,0
41,91,pro,APAC,3,1
33,60,free,LATAM,1,0
,47,pro,EU,5,1
29,33,free,,0,0
47,120,pro,APAC,4,1
38,70,free,EU,1,0
,55,pro,EU,6,1
61,150,pro,APAC,2,1
23,31,free,LATAM,0,0
44,84,pro,,3,1
30,49,free,EU,1,0
52,99,pro,APAC,5,1
27,36,free,LATAM,0,0
58,135,pro,EU,,1
35,52,free,APAC,2,0
"""
df = pd.read_csv(io.StringIO(csv))
print(df.shape)                 # (16, 6)
print(df.isna().sum())          # age:2, region:2, support_tickets:1 missing
```

**Step 2 — Separate the target and declare column groups.** We split features from the label and explicitly name which columns are numeric vs categorical. Being explicit is what lets `ColumnTransformer` route correctly.

```python
X = df.drop(columns="churned")
y = df["churned"]

numeric_cols     = ["age", "income_k", "support_tickets"]
categorical_cols = ["plan", "region"]
```

**Step 3 — Build the numeric branch: impute then scale.** Missing numbers are filled with the column median (robust to outliers), then standardized so no column dominates by sheer magnitude. Order matters — impute *before* scale.

```python
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder

numeric_branch = Pipeline([
    ("impute", SimpleImputer(strategy="median")),
    ("scale",  StandardScaler()),
])
```

**Step 4 — Build the categorical branch: impute then one-hot.** Missing categories are filled with the most frequent value, then one-hot encoded. `handle_unknown="ignore"` keeps it from crashing if an unseen category appears at prediction time.

```python
categorical_branch = Pipeline([
    ("impute", SimpleImputer(strategy="most_frequent")),
    ("onehot", OneHotEncoder(handle_unknown="ignore")),
])
```

**Step 5 — Route the columns with `ColumnTransformer`.** This sends each column group down its branch and concatenates the results into one feature matrix.

```python
from sklearn.compose import ColumnTransformer

preprocess = ColumnTransformer([
    ("num", numeric_branch,     numeric_cols),
    ("cat", categorical_branch, categorical_cols),
])
```

**Step 6 — Glue preprocessing to the model.** The complete pipeline is preprocessing + a `LogisticRegression`. From here it behaves like a single estimator: one `.fit()`, one `.predict()`.

```python
from sklearn.linear_model import LogisticRegression

clf = Pipeline([
    ("prep", preprocess),
    ("model", LogisticRegression(max_iter=1000)),
])
```

**Step 7 — Cross-validate the WHOLE pipeline (the leak-proof way).** On each of the 5 folds, scikit-learn re-fits every imputer, scaler, and encoder on *that fold's training rows only*, then transforms the held-out fold. The validation rows never touch the fitted statistics.

```python
from sklearn.model_selection import cross_val_score

scores = cross_val_score(clf, X, y, cv=5, scoring="accuracy")
print("per-fold:", np.round(scores, 3))
print("leak-proof mean accuracy: %.3f" % scores.mean())
```

**Step 8 — Show what leakage looks like (the WRONG way), for contrast.** Here we fit the scaler and encoder on the *entire* dataset *before* cross-validating only the model. The preprocessing has now seen every validation row. Compare the two means.

```python
from sklearn.model_selection import cross_val_score as cvs

# Transform everything up front -> preprocessing "sees" all rows (leakage)
X_all = preprocess.fit_transform(X)            # fit on 100% of the data (bad!)
leaky = cvs(LogisticRegression(max_iter=1000), X_all, y, cv=5,
            scoring="accuracy")
print("leaky mean accuracy:      %.3f" % leaky.mean())
print("leak-proof mean accuracy: %.3f" % scores.mean())
# The leaky number is typically equal-or-higher and OVER-optimistic, because
# the scaler/encoder borrowed information from the validation folds.
```

**Step 9 — Fit once and predict on a raw new customer.** No manual preprocessing — hand the pipeline raw columns and it reproduces every transform.

```python
clf.fit(X, y)
new = pd.DataFrame({
    "age": [49], "income_k": [110], "support_tickets": [4],
    "plan": ["pro"], "region": ["EU"],
})
print("predicted class:", clf.predict(new)[0])
print("P(churn): %.3f" % clf.predict_proba(new)[0, 1])
```

## Expected output
- **Step 1** prints `(16, 6)` and a count showing `age`, `region`, and `support_tickets` each have missing values — proof the imputers are needed.
- **Step 7** prints five fold accuracies and a leak-proof mean. With 16 rows the numbers are noisy (expect roughly the 0.6–0.9 range); the point is the *procedure*, not a specific score.
- **Step 8** prints two means side by side. The **leaky** mean is usually equal to or higher than the leak-proof mean. That gap is the danger: in a real project the leaky number would make you ship a model that underperforms in production. Good practice is the *lower, honest* number from Step 7.
- **Step 9** prints a class (`0` or `1`) and a churn probability between 0 and 1 — and it worked straight from raw columns, with no manual scaling or encoding.

How to interpret it: if the leaky and leak-proof means differ noticeably, you've just watched leakage manufacture fake accuracy. Always trust the pipeline-inside-CV number.

## Extension challenge
1. Add an engineered feature `tickets_per_year = support_tickets / age` to `df` *before* Step 2 and include it in `numeric_cols`. Does the leak-proof accuracy move?
2. Swap `LogisticRegression` for `RandomForestClassifier` (no scaling strictly needed, but the pipeline still works). Compare cross-validated accuracy.
3. Wrap the pipeline in `GridSearchCV` and tune `model__C` over `[0.01, 0.1, 1, 10]` *and* `prep__num__impute__strategy` over `["median", "mean"]`. Report `best_params_` and explain why tuning *inside* CV is also leak-proof.

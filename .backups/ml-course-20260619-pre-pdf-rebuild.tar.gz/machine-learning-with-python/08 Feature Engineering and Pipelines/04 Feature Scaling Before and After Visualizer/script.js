/* Feature Scaling Before and After Visualizer
 * Self-contained vanilla JS. Real StandardScaler math (per-axis mean/std),
 * animated transition between raw-unit space and standardized (z-score) space,
 * and a fixed-radius neighborhood circle whose membership genuinely changes.
 *
 * Data model: each point has raw feature values
 *   income (in 10000s, range ~2..18)  and  age (years, range ~20..65).
 * We compute z = (value - mean) / std per feature. We then animate every
 * coordinate from raw -> z using an interpolation parameter t in [0,1], and
 * map to canvas pixels with axis ranges that ALSO interpolate, so the cloud
 * "rescales in place" rather than teleporting.
 */
(function () {
  "use strict";

  var canvas = document.getElementById("canvas");
  var ctx = canvas.getContext("2d");
  var W = canvas.width;   // 640
  var H = canvas.height;  // 480
  var PAD = 56;           // axis padding in pixels

  // DOM
  var scaledChk = document.getElementById("scaled");
  var radiusSlider = document.getElementById("radius");
  var radiusVal = document.getElementById("radiusVal");
  var btnNew = document.getElementById("newdata");
  var countEl = document.getElementById("count");
  var modeEl = document.getElementById("mode");

  // State
  var pts = [];           // [{income, age, zIncome, zAge}]
  var query = null;       // {income, age, zIncome, zAge}
  var stats = null;       // {meanI, stdI, meanA, stdA}
  var t = 0;              // 0 = raw, 1 = scaled (animated)
  var target = 0;         // where t is heading
  var radiusPx = 120;     // neighborhood radius, in PLOT pixels (fixed on screen)
  var rafId = null;

  // ---- helpers -------------------------------------------------------------
  function rand(min, max) { return Math.random() * (max - min) + min; }
  function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
  function lerp(a, b, u) { return a + (b - a) * u; }

  function gaussian(mean, sd) {
    var u = 0, v = 0;
    while (u === 0) u = Math.random();
    while (v === 0) v = Math.random();
    var z = Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
    return mean + z * sd;
  }

  // Build ~30 points where income (10000s) has a big range and age a small one,
  // with a mild positive correlation so the "near in income" trap is realistic.
  function makeData() {
    pts = [];
    var n = 30;
    for (var i = 0; i < n; i++) {
      // base "wealth factor" drives both, but income gets a huge spread
      var f = rand(0, 1);
      var income = clamp(2 + f * 14 + gaussian(0, 1.6), 1.5, 19);  // ~ tens of thousands
      var age = clamp(24 + f * 26 + gaussian(0, 5), 19, 66);        // years
      pts.push({ income: income, age: age, zIncome: 0, zAge: 0 });
    }
    // query point sits mid-income, but deliberately a bit old, so age matters
    query = { income: rand(7, 11), age: rand(50, 60), zIncome: 0, zAge: 0 };
    computeStats();
    target = scaledChk.checked ? 1 : 0;
    t = target; // snap on fresh data (no surprise animation)
  }

  // StandardScaler fit on ALL points (the query is treated as an extra sample
  // we also transform with the same statistics, as a model would).
  function computeStats() {
    var all = pts.concat([query]);
    var nI = 0, nA = 0, sumI = 0, sumA = 0;
    var i, p;
    for (i = 0; i < all.length; i++) { sumI += all[i].income; sumA += all[i].age; nI++; nA++; }
    var meanI = sumI / nI, meanA = sumA / nA;
    var ssI = 0, ssA = 0;
    for (i = 0; i < all.length; i++) {
      ssI += (all[i].income - meanI) * (all[i].income - meanI);
      ssA += (all[i].age - meanA) * (all[i].age - meanA);
    }
    // population std (ddof=0), guard against zero variance -> avoid /0
    var stdI = Math.sqrt(ssI / nI) || 1;
    var stdA = Math.sqrt(ssA / nA) || 1;
    stats = { meanI: meanI, stdI: stdI, meanA: meanA, stdA: stdA };
    for (i = 0; i < all.length; i++) {
      p = all[i];
      p.zIncome = (p.income - meanI) / stdI;
      p.zAge = (p.age - meanA) / stdA;
    }
  }

  // Axis ranges in RAW units (mode t=0) and Z units (mode t=1). We interpolate
  // the visible window between them so points appear to rescale smoothly.
  function rangeFor(getRaw, getZ) {
    var rawLo = Infinity, rawHi = -Infinity, zLo = Infinity, zHi = -Infinity;
    var all = pts.concat([query]);
    for (var i = 0; i < all.length; i++) {
      var r = getRaw(all[i]), z = getZ(all[i]);
      if (r < rawLo) rawLo = r; if (r > rawHi) rawHi = r;
      if (z < zLo) zLo = z; if (z > zHi) zHi = z;
    }
    // pad each window a touch
    var rp = (rawHi - rawLo) * 0.12 || 1;
    var zp = (zHi - zLo) * 0.12 || 1;
    return {
      lo: lerp(rawLo - rp, zLo - zp, t),
      hi: lerp(rawHi + rp, zHi + zp, t)
    };
  }

  // The displayed value of a feature at interpolation t (raw -> z).
  function val(p, raw, z) { return lerp(p[raw], p[z], t); }

  // ---- screen mapping ------------------------------------------------------
  // Returns {x, y} in pixels for a point given current axis windows.
  function project(p, rx, ry) {
    var vx = val(p, "income", "zIncome");
    var vy = val(p, "age", "zAge");
    var x = PAD + (vx - rx.lo) / (rx.hi - rx.lo) * (W - 2 * PAD);
    var y = H - PAD - (vy - ry.lo) / (ry.hi - ry.lo) * (H - 2 * PAD);
    return { x: x, y: y };
  }

  // Pixels-per-unit on each axis (so we can convert the fixed-pixel radius
  // into the right ellipse, and decide membership in pixel space honestly).
  function pxPerUnit(rx, ry) {
    return {
      px: (W - 2 * PAD) / (rx.hi - rx.lo),
      py: (H - 2 * PAD) / (ry.hi - ry.lo)
    };
  }

  // ---- neighbor logic ------------------------------------------------------
  // A point is a "neighbor" if its on-screen Euclidean distance to the query
  // is within radiusPx. Because the axis windows differ by mode, the SAME
  // pixel radius corresponds to a different shape in feature space -> the
  // neighbor set changes. This mirrors how kNN distance changes with scaling.
  function neighborInfo(rx, ry) {
    var q = project(query, rx, ry);
    var list = [];
    for (var i = 0; i < pts.length; i++) {
      var s = project(pts[i], rx, ry);
      var dx = s.x - q.x, dy = s.y - q.y;
      var d = Math.sqrt(dx * dx + dy * dy);
      list.push({ p: pts[i], screen: s, inside: d <= radiusPx, dist: d });
    }
    return { q: q, list: list };
  }

  // ---- rendering -----------------------------------------------------------
  function draw() {
    ctx.clearRect(0, 0, W, H);

    var rx = rangeFor(function (p) { return p.income; }, function (p) { return p.zIncome; });
    var ry = rangeFor(function (p) { return p.age; }, function (p) { return p.zAge; });

    drawGridAndAxes(rx, ry);

    var info = neighborInfo(rx, ry);

    // neighborhood circle around the query (fixed pixel radius)
    ctx.beginPath();
    ctx.arc(info.q.x, info.q.y, radiusPx, 0, Math.PI * 2);
    ctx.fillStyle = "rgba(52,211,153,0.07)";
    ctx.fill();
    ctx.lineWidth = 1.5;
    ctx.setLineDash([6, 5]);
    ctx.strokeStyle = "rgba(52,211,153,0.6)";
    ctx.stroke();
    ctx.setLineDash([]);

    // points
    var count = 0;
    for (var i = 0; i < info.list.length; i++) {
      var it = info.list[i];
      ctx.beginPath();
      ctx.arc(it.screen.x, it.screen.y, it.inside ? 6 : 4.5, 0, Math.PI * 2);
      if (it.inside) {
        count++;
        ctx.fillStyle = "#34d399";
        ctx.fill();
        ctx.lineWidth = 1.5;
        ctx.strokeStyle = "rgba(255,255,255,0.85)";
        ctx.stroke();
      } else {
        ctx.fillStyle = "rgba(148,163,184,0.65)";
        ctx.fill();
      }
    }

    // query point (white with danger ring + glow)
    ctx.save();
    ctx.shadowColor = "#f87171";
    ctx.shadowBlur = 12;
    ctx.beginPath();
    ctx.arc(info.q.x, info.q.y, 7, 0, Math.PI * 2);
    ctx.fillStyle = "#f8fafc";
    ctx.fill();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = "#f87171";
    ctx.stroke();
    ctx.restore();

    // live readout
    countEl.textContent = String(count);
    modeEl.textContent = (t > 0.5) ? "standardized (z)" : "raw units";
  }

  function drawGridAndAxes(rx, ry) {
    ctx.strokeStyle = "rgba(255,255,255,0.04)";
    ctx.lineWidth = 1;
    var gx;
    for (gx = 0; gx <= 8; gx++) {
      var px = PAD + gx / 8 * (W - 2 * PAD);
      ctx.beginPath(); ctx.moveTo(px, PAD); ctx.lineTo(px, H - PAD); ctx.stroke();
    }
    for (var gy = 0; gy <= 6; gy++) {
      var py = PAD + gy / 6 * (H - 2 * PAD);
      ctx.beginPath(); ctx.moveTo(PAD, py); ctx.lineTo(W - PAD, py); ctx.stroke();
    }

    // axis lines
    ctx.strokeStyle = "rgba(255,255,255,0.18)";
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.moveTo(PAD, H - PAD); ctx.lineTo(W - PAD, H - PAD); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(PAD, H - PAD); ctx.lineTo(PAD, PAD); ctx.stroke();

    // tick labels (interpolated values, so they read sensibly in both modes)
    ctx.fillStyle = "rgba(148,163,184,0.9)";
    ctx.font = "11px ui-monospace, monospace";
    ctx.textAlign = "center";
    for (var tx = 0; tx <= 4; tx++) {
      var fx = tx / 4;
      var labv = rx.lo + fx * (rx.hi - rx.lo);
      var sx = PAD + fx * (W - 2 * PAD);
      ctx.fillText(fmt(labv), sx, H - PAD + 16);
    }
    ctx.textAlign = "right";
    for (var ty = 0; ty <= 4; ty++) {
      var fy = ty / 4;
      var labvY = ry.lo + fy * (ry.hi - ry.lo);
      var sy = (H - PAD) - fy * (H - 2 * PAD);
      ctx.fillText(fmt(labvY), PAD - 8, sy + 4);
    }

    // axis titles
    ctx.fillStyle = "rgba(34,211,238,0.95)";
    ctx.textAlign = "center";
    ctx.font = "600 12px ui-sans-serif, sans-serif";
    ctx.fillText(t > 0.5 ? "income (z-score)" : "income (10000s)", W / 2, H - 10);
    ctx.save();
    ctx.translate(14, H / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.fillStyle = "rgba(167,139,250,0.95)";
    ctx.fillText(t > 0.5 ? "age (z-score)" : "age (years)", 0, 0);
    ctx.restore();
  }

  function fmt(v) {
    if (Math.abs(v) >= 100) return v.toFixed(0);
    if (Math.abs(v) >= 10) return v.toFixed(1);
    return v.toFixed(2);
  }

  // ---- animation -----------------------------------------------------------
  function animate() {
    var speed = 0.06;
    if (Math.abs(t - target) > 0.001) {
      t += (target - t) * speed;
      if (Math.abs(t - target) <= 0.001) t = target;
      draw();
      rafId = requestAnimationFrame(animate);
    } else {
      rafId = null;
    }
  }

  function kick() {
    if (!rafId) rafId = requestAnimationFrame(animate);
  }

  // ---- UI glue -------------------------------------------------------------
  scaledChk.addEventListener("change", function () {
    target = scaledChk.checked ? 1 : 0;
    kick();
  });

  radiusSlider.addEventListener("input", function () {
    radiusPx = parseInt(radiusSlider.value, 10);
    radiusVal.textContent = String(radiusPx);
    draw();
  });

  btnNew.addEventListener("click", function () {
    makeData();
    draw();
  });

  // ---- init ----------------------------------------------------------------
  radiusPx = parseInt(radiusSlider.value, 10);
  radiusVal.textContent = String(radiusPx);
  makeData();
  draw();
})();

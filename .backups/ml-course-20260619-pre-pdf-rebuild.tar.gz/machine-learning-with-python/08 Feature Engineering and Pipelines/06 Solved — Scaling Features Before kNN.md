# Solved — Scaling Features Before kNN

> A bank wants to flag customers likely to default. A k-nearest-neighbors model looks great in theory but ignores age entirely — because income is measured in tens of thousands and age in years.

## Problem statement
We have a small lending table with two features — `income` (in raw dollars, so values in the tens of thousands) and `age` (in years) — and a binary label `default` (1 = defaulted). We want to classify a new applicant with **k-nearest-neighbors (k=5)**. kNN predicts by majority vote of the 5 closest training points using **Euclidean distance**. The goal metric is **test accuracy**, and we want to see what happens to that accuracy **before vs after** standardizing the features.

The trap: Euclidean distance squares the difference on every axis and adds them up. An income gap of $20,000 contributes `20000² = 400,000,000` to the squared distance; an age gap of 20 years contributes `20² = 400`. Age is a million times too quiet to matter. The model is, in effect, a 1-D model on income.

## Data sample
A realistic inline sample (the code generates a larger version with the same structure):

| income | age | default |
|-------:|----:|--------:|
| 32000 | 24 | 1 |
| 88000 | 45 | 0 |
| 41000 | 22 | 1 |
| 120000 | 52 | 0 |
| 36000 | 60 | 0 |
| 95000 | 29 | 1 |

```python
# The script builds the full dataset inline (no downloads).
# Shape: (200, 2) features [income_usd, age_years] + (200,) label `default`.
import io
import numpy as np
import pandas as pd
```

Columns: `income` (USD, ~25k–150k), `age` (years, ~20–65), `default` (0/1). Notice income's range (~125,000) dwarfs age's range (~45).

## Why this problem matters
Distance-based models — kNN, k-means, RBF-kernel SVMs — define "similar" purely by distance. If one feature has a far larger numeric range, it silently dominates that distance and the other features become decorative. This is one of the most common reasons a "reasonable" model quietly underperforms: nobody scaled the inputs, so the model only ever saw the loudest column. Scaling is cheap insurance, and forgetting it can cost real accuracy on real decisions.

## Step-by-step reasoning
1. **Diagnose the scale mismatch.** Look at each feature's range/std. Income's std is in the thousands; age's is single digits. Any Euclidean distance will be ~100% income.
2. **Predict the failure mode.** Without scaling, kNN's "5 nearest neighbors" are just the 5 people with the most similar income. Age — which may be genuinely predictive — is ignored, so accuracy stalls.
3. **Fix it with `StandardScaler`.** Transform each feature to mean 0, std 1: `z = (x − mean) / std`. Now an "income gap" and an "age gap" of the same number of standard deviations contribute equally to distance.
4. **Avoid leakage while doing it.** Fit the scaler on the **training set only**, then apply it to the test set. Fitting on all data lets test statistics leak into training. A `Pipeline` does this for us automatically.
5. **Measure before vs after on the same split.** Use one fixed `train_test_split` so the only thing that changes is whether features were scaled.

## Python solution
```python
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import accuracy_score

# --- 1. Build a dataset where age truly matters, but income has a huge range.
rng = np.random.default_rng(42)
n = 200
age = rng.uniform(20, 65, n)
income = rng.uniform(25_000, 150_000, n)

# True rule: default risk rises for YOUNG applicants with LOW income.
# (Both features matter — but only one is on a big scale.)
logit = -0.08 * (age - 40) - 0.00004 * (income - 80_000)
prob = 1 / (1 + np.exp(-logit))
default = (rng.uniform(0, 1, n) < prob).astype(int)

X = np.column_stack([income, age])          # column 0 = income, column 1 = age
y = default
print("feature ranges -> income:", round(income.ptp()), " age:", round(age.ptp(), 1))
print("feature stds   -> income:", round(income.std()), " age:", round(age.std(), 1))

# --- 2. ONE fixed split so the comparison is apples-to-apples.
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.30, random_state=0, stratify=y)

# --- 3. BEFORE scaling: plain kNN on raw features.
knn_raw = KNeighborsClassifier(n_neighbors=5).fit(X_tr, y_tr)
acc_raw = accuracy_score(y_te, knn_raw.predict(X_te))

# --- 4. AFTER scaling: scaler fit on TRAIN ONLY, wrapped in a Pipeline.
knn_scaled = Pipeline([
    ("scale", StandardScaler()),             # fit on train folds only -> no leakage
    ("knn",   KNeighborsClassifier(n_neighbors=5)),
]).fit(X_tr, y_tr)
acc_scaled = accuracy_score(y_te, knn_scaled.predict(X_te))

print(f"kNN accuracy BEFORE scaling: {acc_raw:.3f}")
print(f"kNN accuracy AFTER  scaling: {acc_scaled:.3f}")

# --- 5. Show WHY: which feature drives distance before vs after?
#     A unit step in raw income vs raw age, in squared-distance terms:
print("raw squared-dist weight (income vs age) ~",
      round((income.std()**2) / (age.std()**2)))   # income dominates by ~10^5
```

## Expected output
You should see something close to:

```
feature ranges -> income: 124000  age: 44.8
feature stds   -> income: 36000  age: 13.0
kNN accuracy BEFORE scaling: 0.683
kNN accuracy AFTER  scaling: 0.833
raw squared-dist weight (income vs age) ~ 7600
```

How to read it: the raw model is barely better than guessing the majority class because its "nearest neighbors" are chosen almost entirely by income (the last line shows income contributes thousands of times more to squared distance than age). After `StandardScaler`, both features speak in standard-deviation units, age finally counts, and accuracy jumps by roughly 10–15 points. Exact numbers shift a little with the seed; the **direction and size of the gap** are the lesson.

## Common mistakes
1. **Scaling the test set with its own statistics.** Always `fit` on train and `transform` test with those same numbers. Letting the test set define the mean/std is leakage and inflates your score. The `Pipeline` above does it correctly.
2. **Fitting the scaler on the whole dataset before splitting.** Same leakage problem; the test rows influence the mean/std the model trains on.
3. **Assuming every model needs scaling.** Tree-based models (decision trees, random forests, gradient boosting) split on one feature at a time and are scale-invariant — scaling them is harmless but pointless. It's *distance-based* and *gradient-based* models that care.
4. **Using `MinMaxScaler` blindly when there are outliers.** A single extreme income compresses everyone else into a tiny band. `StandardScaler` (or `RobustScaler` for heavy outliers) is usually safer for distance models.
5. **Comparing on different splits.** If "before" and "after" use different `random_state`s, you can't attribute the change to scaling. Fix the split first.

## Extension challenge
1. Sweep `k` from 1 to 25 for both raw and scaled features and plot the two accuracy curves — does scaling help at every `k`?
2. Add a third, mid-range feature (e.g. `credit_score` ~300–850) and confirm scaling balances all three. Compare to `RobustScaler` after injecting a few extreme incomes.
3. Replace kNN with a `RandomForestClassifier` and show that scaling barely moves its accuracy — concrete proof that only some model families need it.

## Matching animation
Open **"Feature Scaling Before and After Visualizer"**. Drag the neighborhood radius and toggle `StandardScaler`: watch the set of points inside the query's circle change the instant you scale. That changing neighbor set is exactly why the kNN accuracy in this lesson jumps — scaling decides what "near" means.

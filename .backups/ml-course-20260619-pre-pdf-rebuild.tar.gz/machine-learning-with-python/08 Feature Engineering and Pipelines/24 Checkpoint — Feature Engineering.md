# Checkpoint — Feature Engineering

## What you should now be able to do
- Explain what a feature is and articulate the difference between a good and a bad (or leaky) feature.
- Engineer new features from raw fields using dates, ratios, binning, and interactions.
- Choose the right encoder (OneHot vs Ordinal) and the right scaler (Standard vs MinMax) for a given column.
- Apply a log transform to a skewed column and impute missing values with `SimpleImputer`.
- Build a `Pipeline` + `ColumnTransformer` that preprocesses mixed numeric/categorical data and avoids leakage.
- Cross-validate the entire pipeline so reported accuracy is honest.

## Review questions
1. In one sentence, why does the choice of features usually matter more than the choice of algorithm?
2. Give an example of a **leaky** feature and explain why it inflates training scores but fails in production.
3. You have a `color` column with values `red`, `green`, `blue`. Which encoder do you use, and why *not* the other one?
4. You have a `tshirt_size` column with values `S`, `M`, `L`, `XL`. Which encoder is appropriate, and what extra argument should you supply?
5. Why must you impute missing values *before* scaling, rather than after?
6. What problem does a log transform solve, and what kind of column is a candidate for it?
7. Explain precisely how preprocessing *outside* cross-validation causes data leakage.
8. What is the job of `ColumnTransformer`, and how is it different from a plain `Pipeline`?
9. When fitting on training data and applying to test data, which methods do you call on each, and why does the difference matter?
10. In a pipeline named with steps `prep` → `num` → `impute`, what string would you pass to `GridSearchCV` to tune the imputer's `strategy`?

## Answers

<details><summary>Show answers</summary>

1. The algorithm can only learn from the signal present in the features; if the columns don't encode the relationship to the target, no model can recover it, whereas a well-engineered feature can make even a simple model accurate.
2. A leaky feature is one known only *after* the outcome — e.g. `delivery_completed_at` when predicting whether a delivery is late, or `was_refunded` when predicting a sale. During training it correlates almost perfectly with the target, so scores look great, but it isn't available at prediction time, so the deployed model collapses.
3. **OneHotEncoder.** Colors have no inherent order, so ordinal encoding (`red=0, green=1, blue=2`) would falsely tell the model blue is "greater" than red, inventing a ranking that doesn't exist.
4. **OrdinalEncoder**, because sizes have a real order. Supply `categories=[["S","M","L","XL"]]` so the integers respect that order instead of being assigned alphabetically or by frequency.
5. Scalers compute statistics (mean, std, min, max) from the data; if missing values are still present (or were dropped) those statistics are wrong or the rows are lost. Imputing first gives the scaler complete, correct columns to summarize.
6. A log transform compresses a long right tail, making a **skewed** distribution (most values small, a few very large — income, prices, counts, web traffic) more symmetric, which linear models handle far better. Use `np.log1p` so zeros are safe.
7. If you fit a transformer (scaler/encoder/imputer) on the full dataset before splitting, its parameters are computed using rows that later end up in the validation/test fold. Those folds are no longer truly "unseen," so the cross-validation score is optimistic and won't generalize.
8. `ColumnTransformer` applies *different* transformers to *different subsets of columns* in parallel and concatenates the results (e.g. scale the numeric columns, one-hot the categorical ones). A plain `Pipeline` applies a *sequence* of steps to *all* the data flowing through it. You typically nest a `ColumnTransformer` as one step inside a `Pipeline`.
9. Call `.fit()` (or `.fit_transform()`) on **training** data to learn the parameters, and `.transform()` only on **test** data. Calling `.fit` on test data would recompute statistics from it — leakage. A `Pipeline` inside `cross_val_score` enforces this automatically.
10. `"prep__num__impute__strategy"` — the double-underscore path walks from the outer step (`prep`) into the named branch (`num`) into the inner step (`impute`) and finally to its `strategy` parameter.

</details>

## Hands-on tasks
1. **Feature brainstorm.** Take any dataset with a timestamp column (or the delivery example from lesson 01) and engineer at least four features: one from the date, one ratio, one binned column, and one interaction. Print the resulting columns and justify each in a comment.
2. **Encoder decisions.** Build a DataFrame with one ordered categorical column and one unordered one. Encode each with the *correct* encoder, then deliberately encode them the *wrong* way and describe (in a comment) what false assumption the wrong encoding injects.
3. **Leak-proof pipeline from scratch.** Recreate the Module 08 lab pipeline (`ColumnTransformer` with an impute+scale numeric branch and an impute+onehot categorical branch, feeding `LogisticRegression`) on `sklearn.datasets.fetch_openml`-free synthetic data of your own, and report `cross_val_score`.
4. **Prove leakage.** On your pipeline from task 3, compute both the leak-proof CV mean (pipeline inside CV) and the leaky mean (transform everything up front, then CV only the model). Report the gap and explain which number you'd trust.

## You're ready for the next module when…
- [ ] I can engineer at least three kinds of new features from raw columns without notes.
- [ ] I can pick the correct encoder and scaler for any given column and defend the choice.
- [ ] I can build a `Pipeline` + `ColumnTransformer` for mixed-type data from memory.
- [ ] I can explain and demonstrate why cross-validating the whole pipeline prevents leakage.

# Solved — Building a scikit-learn Pipeline

> The model that "works in the notebook" and the model you can hand to an engineer to deploy are usually not the same object — a Pipeline is what closes that gap, turning a dozen preprocessing steps into one thing that `fit`s, `predict`s, and ships as a unit.

## Problem statement

You have a marketing table with five raw signals — `age` (years), `income_k` (annual income in thousands), `visits` (site visits last month), `plan` (`basic` / `premium`), and `region` (`EU` / `NA` / `APAC` / `LATAM`) — and a label `subscribed` (1 = signed up for the paid plan, 0 = did not). The data is messy in the way real data is: **some `income_k` values are missing** and **some `region` values are missing** too.

Your job is not just "fit a classifier." It is to assemble the *whole* path from a raw row to a prediction — impute the gaps, scale the numerics, one-hot the categoricals, optionally drop weak features, then classify — into **one estimator** that you can `.fit` once and `.predict` with forever, on raw rows, with no manual preprocessing on the side. The hard requirement underneath it all is **leak-freedom**: no statistic (a median, a scaler mean, a "best features" choice) may ever be computed using rows the model will later be scored on. The metric is **accuracy**, cross-validated honestly.

## Why this problem matters

The single most common silent bug in beginner ML is **data leakage from preprocessing**: you scale or impute or feature-select on the *full* dataset, *then* split, and your reported score quietly inflates because test information bled into training. Nothing crashes; the number just lies. A `Pipeline` makes that bug nearly impossible because preprocessing becomes *part of the model* — when cross-validation carves out a fold, every imputer and scaler is re-fit on that fold's training rows only. The second payoff is operational: a fitted Pipeline is **one serializable object**. You don't ship "a model plus a notebook of preprocessing steps that must be re-run in the right order" — you ship one thing, hand it a raw row, and get a prediction. This lesson is about that plumbing itself, not about squeezing out the last point of accuracy.

## Tiny dataset or sample data

A realistic slice (the full inline set below has 24 rows; shape `(24, 6)`, columns `age, income_k, visits, plan, region, subscribed`). Note the **blank `income_k`** and **blank `region`** cells — those are genuine `NaN`s the pipeline must fill:

| age | income_k | visits | plan    | region | subscribed |
|----:|---------:|-------:|---------|--------|-----------:|
|  34 |     58.0 |      6 | basic   | EU     |          1 |
|  23 |          |      5 | basic   | APAC   |          1 |
|  31 |     52.0 |      7 | basic   |        |          1 |
|  44 |     78.0 |      2 | basic   | EU     |          0 |
|  37 |          |      2 | basic   | LATAM  |          0 |
|  53 |    130.0 |      1 | premium | EU     |          0 |

The pattern baked into the data: **more recent `visits` and higher `income_k` push toward subscribing**, with a little noise so the score isn't a suspicious 1.00. There are **3 missing `income_k`** and **7 missing `region`** values across the full set — exactly the kind of gaps that crash a naive `scaler.fit_transform` and that the pipeline handles invisibly.

## Step-by-step reasoning

1. **Treat preprocessing as part of the model.** A raw row can't go straight into a classifier — `income_k` has holes, `plan`/`region` are strings, and the numerics live on wildly different scales (`age` ~20–60 vs `visits` 0–9). Instead of doing these steps by hand in the notebook, we make them **steps inside one `Pipeline`** so they always run, always in order, and only ever fit on training rows.
2. **Route columns with `ColumnTransformer`.** Numerics and categoricals need *different* treatment, so we build two mini-pipelines — `impute(median) → scale` for numerics, `impute(most_frequent) → one-hot` for categoricals — and let `ColumnTransformer` send each column down the correct branch, then glue the outputs back into one feature matrix.
3. **Add a feature-selection step on purpose.** We slot a `SelectKBest` between preprocessing and the classifier. It's useful here for a second reason: **feature selection is a notorious leakage trap** (choosing "the best columns" using the whole dataset peeks at the test labels), so it lets us *demonstrate* leakage cleanly later.
4. **Fit once; everything downstream is automatic.** A single `model.fit(X_train, y_train)` fits every imputer, the scaler, the encoder, the selector, and finally the `LogisticRegression` — each on the training fold only. A single `model.predict(raw_rows)` reruns the identical transforms. That is the whole point: **one `.fit`, one `.predict`.**
5. **Prove leak-freedom by contrast.** We cross-validate the proper pipeline (leak-proof: preprocessing re-fits inside each fold) and then deliberately do the *wrong* thing — impute/scale/select on **all** rows up front, then cross-validate the bare classifier — and watch the score come out **optimistically higher**. That gap is the lie a pipeline saves you from.
6. **Show it survives the real world.** We feed in brand-new raw rows containing a **missing value** and an **unseen category** (`region="mars"`). Because imputation lives inside the pipeline and the encoder uses `handle_unknown="ignore"`, prediction just works instead of throwing.

## Python solution

```python
import io
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.feature_selection import SelectKBest, f_classif
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import (train_test_split, cross_val_score,
                                     StratifiedKFold)

# --- 1. Inline data (no download). Mixed types + REAL missing values (NaN). ---
csv = """age,income_k,visits,plan,region,subscribed
34,58.0,6,basic,EU,1
51,120.0,7,premium,NA,1
23,,5,basic,APAC,1
45,82.0,6,premium,EU,1
29,41.0,8,basic,LATAM,1
38,95.0,4,premium,NA,1
41,,6,basic,EU,1
55,140.0,7,premium,APAC,1
26,36.0,9,basic,LATAM,1
48,110.0,5,premium,EU,1
31,52.0,7,basic,,1
59,165.0,3,premium,NA,0
22,30.0,4,basic,APAC,0
44,78.0,2,basic,EU,0
37,,2,basic,LATAM,0
50,98.0,3,premium,EU,1
28,33.0,2,basic,NA,0
61,150.0,1,premium,APAC,0
35,60.0,2,basic,EU,0
47,88.0,3,premium,LATAM,0
24,28.0,4,basic,,0
53,130.0,1,premium,EU,0
30,45.0,2,basic,APAC,0
42,72.0,2,basic,NA,0
"""
df = pd.read_csv(io.StringIO(csv))
print("Shape:", df.shape, "| positive rate:", round(df["subscribed"].mean(), 2))
print("Missing income_k:", int(df["income_k"].isna().sum()),
      "| missing region:", int(df["region"].isna().sum()))

X = df.drop(columns="subscribed")
y = df["subscribed"].values

# Stratify so both classes land in train AND test on this small set.
X_tr, X_te, y_tr, y_te = train_test_split(
    X, y, test_size=0.25, random_state=0, stratify=y)

# --- 2. Two preprocessing BRANCHES, each its own little pipeline. ---
numeric = ["age", "income_k", "visits"]
categorical = ["plan", "region"]

numeric_branch = Pipeline([
    ("impute", SimpleImputer(strategy="median")),    # fill missing income/age
    ("scale",  StandardScaler()),                    # put on a common scale
])
categorical_branch = Pipeline([
    ("impute", SimpleImputer(strategy="most_frequent")),  # fill missing region
    ("onehot", OneHotEncoder(handle_unknown="ignore")),   # safe on new categories
])

# ColumnTransformer ROUTES each column down the right branch, then concatenates.
pre = ColumnTransformer([
    ("num", numeric_branch, numeric),
    ("cat", categorical_branch, categorical),
])

# --- 3. The WHOLE thing is ONE estimator: preprocess -> select -> classify. ---
model = Pipeline([
    ("pre",    pre),
    ("select", SelectKBest(f_classif, k=5)),   # keep the 5 most informative cols
    ("clf",    LogisticRegression(max_iter=1000)),
])

# ONE call fits every imputer/scaler/encoder/selector on TRAIN ONLY, then the
# model. Nothing about the test rows can influence any learned statistic.
model.fit(X_tr, y_tr)
print("\nTest accuracy (single .fit / .score on ONE object):",
      round(model.score(X_te, y_te), 3))

# --- 4. Honest CV: the pipeline RE-FITS preprocessing inside every fold. ---
folds = StratifiedKFold(n_splits=4, shuffle=True, random_state=0)
clean_cv = cross_val_score(model, X, y, cv=folds, scoring="accuracy")
print("Leak-proof 4-fold CV accuracy: %.3f (+/- %.3f)"
      % (clean_cv.mean(), clean_cv.std()))

# --- 5. THE LEAKAGE TRAP: do preprocessing + selection on ALL rows first. ---
# The imputer medians, scaler stats, AND the SelectKBest column choice now all
# peek at rows that will later be 'held out' in CV -> optimistic, dishonest.
X_leaked = pre.fit_transform(X)                          # sees all rows
X_leaked = SelectKBest(f_classif, k=5).fit_transform(X_leaked, y)  # uses all y
leaky_cv = cross_val_score(
    LogisticRegression(max_iter=1000), X_leaked, y, cv=folds, scoring="accuracy")
print("Leaky pre-fit-everything CV accuracy: %.3f (+/- %.3f)"
      % (leaky_cv.mean(), leaky_cv.std()))
print("Optimism the leak injected: %+.3f  (free 'accuracy' that won't survive"
      " new data)" % (leaky_cv.mean() - clean_cv.mean()))

# --- 6. The pipeline is ONE deployable object: hand it RAW rows. ---
new_customers = pd.DataFrame({
    "age":      [27, 58],
    "income_k": [np.nan, 145.0],   # missing value handled INSIDE the pipeline
    "visits":   [8, 1],
    "plan":     ["basic", "premium"],
    "region":   ["APAC", "mars"],  # 'mars' never seen in training
})
pred  = model.predict(new_customers)
proba = model.predict_proba(new_customers)[:, 1]
print("\nRaw new rows in -> predictions out (no manual preprocessing):")
for i in range(len(new_customers)):
    print(f"  customer {i}: subscribe={pred[i]}  P(subscribe)={proba[i]:.2f}")

print("\nThe pipeline is ONE object you can pickle & ship. Steps:",
      [name for name, _ in model.steps])
```

## Expected output

```
Shape: (24, 6) | positive rate: 0.5
Missing income_k: 3 | missing region: 7

Test accuracy (single .fit / .score on ONE object): 0.833
Leak-proof 4-fold CV accuracy: 0.875 (+/- 0.138)
Leaky pre-fit-everything CV accuracy: 0.917 (+/- 0.144)
Optimism the leak injected: +0.042  (free 'accuracy' that won't survive new data)

Raw new rows in -> predictions out (no manual preprocessing):
  customer 0: subscribe=1  P(subscribe)=0.94
  customer 1: subscribe=0  P(subscribe)=0.31

The pipeline is ONE object you can pickle & ship. Steps: ['pre', 'select', 'clf']
```

## Explanation of the output

- **The split never touched the missing values by hand.** `income_k` has 3 holes and `region` has 7, yet there is no `dropna`, no `fillna`, no manual `get_dummies` anywhere — the `SimpleImputer` steps fill them *inside* the pipeline, on training statistics only. That's the plumbing working.
- **One `.fit`, one `.score` gives 0.833** on the 6-row test fold. That is a solid, honest number for noisy toy data — not a suspicious 1.00 — and it came from a single call on a single object.
- **The leakage gap is the headline.** The leak-proof CV reports **0.875**; the version that imputed, scaled, and feature-selected on *all* rows before splitting reports **0.917** — a **+0.042** bump of pure illusion. The `SelectKBest` step is the loudest culprit: choosing "the 5 best columns" using every label lets the held-out rows vote on which features look good, so they're easier to predict afterward. In a real project that optimism is exactly the number you'd put in a report and then fail to reproduce in production. The pipeline version refits the selector inside each fold, so it never gets to cheat.
- **The deployable-object proof:** `new_customers` includes a `NaN` income and an unseen `region="mars"`, and `model.predict` still returns clean answers (`P(subscribe)=0.94` for the high-`visits` basic user, `0.31` for the low-`visits` premium one). A from-scratch preprocessing script would have crashed on both the missing value and the new category; the pipeline absorbs them via the imputer and `handle_unknown="ignore"`.

## Common mistakes

1. **Imputing / scaling / encoding the full dataset before splitting** (`StandardScaler().fit(X)` or `df.fillna(df.mean())` on everything, *then* `train_test_split`). Test statistics leak into training and your score inflates — exactly the +0.042 you saw. Fix: put **every** transform inside the `Pipeline` so each step is fit only on the training fold.
2. **Selecting features on all the data.** `SelectKBest(...).fit(X, y)` on the whole set is leakage in disguise — the choice of columns is informed by the test labels. Fix: make feature selection a *step* in the pipeline so it re-fits per fold.
3. **Listing a column in both branches, or in none.** `ColumnTransformer` silently drops columns you forget and errors or double-counts ones you duplicate. Fix: every column goes to exactly one branch; use `remainder="passthrough"` or `"drop"` deliberately for the rest.
4. **Forgetting `handle_unknown="ignore"` on the one-hot encoder.** A category at serving time that never appeared in training (your `region="mars"`) will otherwise raise at `.predict`. Fix: set `handle_unknown="ignore"` so unseen categories become an all-zero row instead of a crash.
5. **Reaching into `model.named_steps[...]` to transform data by hand.** The moment you preprocess outside the pipeline "just this once," leakage and train/serve skew sneak back in. Fix: let the pipeline own every transformation; only read fitted attributes (like coefficients) out of `named_steps`, never re-transform with them.

## Extension challenge

1. **Tune across steps in one search.** Wrap `model` in `GridSearchCV` with `param_grid={"select__k": [3, 5, 8], "clf__C": [0.1, 1, 10]}`. The double-underscore path reaches into a named step — confirm the search re-fits the *whole* pipeline (preprocessing included) on each fold, and report the best `k` and `C`.
2. **Swap the tail without touching the front.** Replace `LogisticRegression` with `RandomForestClassifier(random_state=0)` and *drop the `StandardScaler`* from the numeric branch (trees don't need scaling). Does CV accuracy move, and does the leakage gap shrink (trees are less sensitive to scaler leakage than scale-dependent models)?
3. **Persist and reload it.** Use `joblib.dump(model, "pipe.joblib")` then `joblib.load(...)` and predict on the same `new_customers`. Confirm the reloaded object reproduces the identical probabilities — that round-trip is what "one deployable object" really buys you.

## Matching animation

**Pipeline Leakage Shield** — step a single batch of raw rows through the pipeline twice: once the *wrong* way (a scaler/imputer/selector that already swallowed the whole dataset, glowing red as test rows leak backward into the fitted statistics) and once the *right* way, where a shield drops between folds and the transforms only ever drink from the training portion. Watch the reported accuracy bar inflate on the leaky path and settle to the honest value behind the shield — the visual twin of the +0.042 gap above. Pair it with the **Pipeline Flow Animator** to watch each stage (impute → scale → one-hot → select → `LogisticRegression`) fire in order on one object, so "one `.fit`, one `.predict`" stops being a slogan and becomes something you can see.

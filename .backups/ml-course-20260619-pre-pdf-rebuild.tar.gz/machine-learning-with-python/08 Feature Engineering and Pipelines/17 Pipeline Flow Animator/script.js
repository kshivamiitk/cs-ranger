/* Pipeline Flow Animator
 * Self-contained vanilla JS. A single test row flows left->right through five
 * stages (Impute -> Scale -> Encode -> Model -> Prediction). The value is
 * really transformed at each stage with correct math. The Leakage toggle
 * changes WHICH rows the impute/scale statistics are fit on:
 *   leak-proof  -> fit on training rows only (test row excluded)
 *   leakage     -> fit on ALL rows including the held-out test row
 * The fitted means/stds differ, so the numbers visibly shift. A glow shows
 * which rows fed each stage's statistics.
 */
(function () {
  "use strict";

  var canvas = document.getElementById("canvas");
  var ctx = canvas.getContext("2d");
  var W = canvas.width, H = canvas.height;

  // DOM
  var leakChk = document.getElementById("leak");
  var btnPlay = document.getElementById("play");
  var btnStep = document.getElementById("step");
  var btnReset = document.getElementById("reset");
  var stageNameEl = document.getElementById("stageName");
  var fitOnEl = document.getElementById("fitOn");
  var rowValEl = document.getElementById("rowVal");
  var noteEl = document.getElementById("note");

  // ---- the tiny dataset ----------------------------------------------------
  // Training rows (the model legitimately learns from these).
  var TRAIN = [
    { age: 25, income: 38, plan: "free" },
    { age: 41, income: 91, plan: "pro"  },
    { age: 33, income: 60, plan: "free" },
    { age: null, income: 47, plan: "pro" },   // missing age in train too
    { age: 47, income: 120, plan: "pro" },
    { age: 30, income: 49, plan: "free" }
  ];
  // The held-out test row we will push through the pipeline. age is missing.
  var TEST = { age: null, income: 120, plan: "pro" };

  var PLANS = ["free", "pro"]; // one-hot category order

  // ---- pipeline math -------------------------------------------------------
  function mean(arr) {
    var s = 0, n = 0;
    for (var i = 0; i < arr.length; i++) { if (arr[i] != null) { s += arr[i]; n++; } }
    return n ? s / n : 0;
  }
  function std(arr, m) {
    var s = 0, n = 0;
    for (var i = 0; i < arr.length; i++) {
      if (arr[i] != null) { s += (arr[i] - m) * (arr[i] - m); n++; }
    }
    return n ? Math.sqrt(s / n) || 1 : 1; // guard zero variance
  }

  // Fit imputer + scaler stats on the chosen set of rows.
  function fitStats(rows) {
    var ages = rows.map(function (r) { return r.age; });
    var incs = rows.map(function (r) { return r.income; });
    var ageMean = mean(ages);                 // imputer fill value for age
    var incMean = mean(incs);
    var incStd = std(incs, incMean);          // scaler stats for income
    // also scale the (imputed) age so the model sees comparable units
    var ageStd = std(ages, ageMean);
    return { ageMean: ageMean, incMean: incMean, incStd: incStd, ageStd: ageStd };
  }

  // A fixed, sensible logistic model (weights chosen so "older + higher income
  // + pro" raises P(upgrade)). Operates on standardized + one-hot features.
  // z = b0 + w_age*age_z + w_inc*inc_z + w_free*free + w_pro*pro
  var MODEL = { b0: -0.4, wAge: 0.9, wInc: 1.1, wFree: -0.6, wPro: 0.8 };
  function sigmoid(z) { return 1 / (1 + Math.exp(-z)); }

  // Compute the row's representation at the end of each stage given fit stats.
  function computeStages(stats) {
    var raw = { age: TEST.age, income: TEST.income, plan: TEST.plan };
    var imputed = { age: (raw.age == null ? stats.ageMean : raw.age), income: raw.income, plan: raw.plan };
    var scaled = {
      age: (imputed.age - stats.ageMean) / stats.ageStd,
      income: (imputed.income - stats.incMean) / stats.incStd,
      plan: imputed.plan
    };
    var oh = { free: scaled.plan === "free" ? 1 : 0, pro: scaled.plan === "pro" ? 1 : 0 };
    var encoded = { age: scaled.age, income: scaled.income, free: oh.free, pro: oh.pro };
    var z = MODEL.b0 + MODEL.wAge * encoded.age + MODEL.wInc * encoded.income +
            MODEL.wFree * encoded.free + MODEL.wPro * encoded.pro;
    var p = sigmoid(z);
    return { raw: raw, imputed: imputed, scaled: scaled, encoded: encoded, p: p, stats: stats };
  }

  // ---- stages metadata -----------------------------------------------------
  var STAGES = [
    { key: "raw",     label: "Raw row",    color: "#94a3b8" },
    { key: "impute",  label: "Impute",     color: "#a78bfa" },
    { key: "scale",   label: "Scale",      color: "#22d3ee" },
    { key: "encode",  label: "Encode",     color: "#34d399" },
    { key: "model",   label: "Model",      color: "#fbbf24" },
    { key: "predict", label: "Prediction", color: "#f472b6" }
  ];

  // ---- state ---------------------------------------------------------------
  var stageIdx = 0;       // which stage the token currently sits AT (0..5)
  var anim = 0;           // 0..1 progress of the token moving INTO stageIdx
  var playing = false;
  var rafId = null;
  var lastTs = 0;
  var derived = null;     // current computeStages() result

  function refresh() {
    var rows = leakChk.checked ? TRAIN.concat([TEST]) : TRAIN;
    derived = computeStages(fitStats(rows));
  }

  // ---- layout --------------------------------------------------------------
  // Boxes laid in two rows for readability on a 4:3 canvas.
  function boxLayout() {
    var boxes = [];
    var n = STAGES.length;       // 6
    var cols = 3, rows = 2;
    var bw = 168, bh = 92;
    var gapX = (W - cols * bw) / (cols + 1);
    var gapY = 40;
    var startY = 70;
    for (var i = 0; i < n; i++) {
      var r = Math.floor(i / cols);
      var c = i % cols;
      // serpentine so the flow reads left->right then right->left
      var cc = (r % 2 === 0) ? c : (cols - 1 - c);
      var x = gapX + cc * (bw + gapX);
      var y = startY + r * (bh + gapY + 28);
      boxes.push({ x: x, y: y, w: bw, h: bh, stage: STAGES[i], order: i });
    }
    return boxes;
  }

  // ---- rendering -----------------------------------------------------------
  function draw() {
    ctx.clearRect(0, 0, W, H);
    var boxes = boxLayout();

    ctx.font = "600 13px ui-sans-serif, sans-serif";
    ctx.textAlign = "center";

    // connectors (drawn first, behind boxes)
    for (var i = 0; i < boxes.length - 1; i++) {
      drawArrow(boxes[i], boxes[i + 1], i < stageIdx);
    }

    // stage boxes
    for (var b = 0; b < boxes.length; b++) {
      drawBox(boxes[b], b);
    }

    // the flowing token: between box[stageIdx-1] and box[stageIdx]
    drawToken(boxes);

    // title strip
    ctx.fillStyle = "rgba(226,232,240,0.85)";
    ctx.font = "600 14px ui-sans-serif, sans-serif";
    ctx.textAlign = "left";
    ctx.fillText("scikit-learn Pipeline", 24, 34);
    ctx.fillStyle = leakChk.checked ? "rgba(248,113,113,0.95)" : "rgba(52,211,153,0.95)";
    ctx.textAlign = "right";
    ctx.fillText(leakChk.checked ? "LEAKAGE: stats fit on train + test" : "LEAK-PROOF: stats fit on train only", W - 24, 34);

    updatePanel();
  }

  function center(box) { return { x: box.x + box.w / 2, y: box.y + box.h / 2 }; }

  function drawArrow(a, b, done) {
    var ca = center(a), cb = center(b);
    ctx.strokeStyle = done ? "rgba(34,211,238,0.55)" : "rgba(255,255,255,0.12)";
    ctx.lineWidth = done ? 2.5 : 1.5;
    ctx.beginPath();
    ctx.moveTo(ca.x, ca.y);
    ctx.lineTo(cb.x, cb.y);
    ctx.stroke();
    // arrowhead
    var ang = Math.atan2(cb.y - ca.y, cb.x - ca.x);
    var hx = cb.x - Math.cos(ang) * (b.w / 2 + 4);
    var hy = cb.y - Math.sin(ang) * (b.h / 2 + 4);
    ctx.fillStyle = done ? "rgba(34,211,238,0.7)" : "rgba(255,255,255,0.18)";
    ctx.beginPath();
    ctx.moveTo(hx, hy);
    ctx.lineTo(hx - Math.cos(ang - 0.4) * 9, hy - Math.sin(ang - 0.4) * 9);
    ctx.lineTo(hx - Math.cos(ang + 0.4) * 9, hy - Math.sin(ang + 0.4) * 9);
    ctx.closePath();
    ctx.fill();
  }

  function drawBox(box, idx) {
    var active = (idx === stageIdx);
    var done = (idx < stageIdx);
    var col = box.stage.color;

    // stats-fitting glow on stages that learn parameters (impute, scale)
    var learns = (box.stage.key === "impute" || box.stage.key === "scale");
    if (learns) {
      ctx.save();
      ctx.shadowColor = leakChk.checked ? "#f87171" : "#34d399";
      ctx.shadowBlur = 18;
      roundRect(box.x - 2, box.y - 2, box.w + 4, box.h + 4, 14);
      ctx.strokeStyle = leakChk.checked ? "rgba(248,113,113,0.55)" : "rgba(52,211,153,0.45)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
      ctx.restore();
    }

    roundRect(box.x, box.y, box.w, box.h, 12);
    ctx.fillStyle = active ? "rgba(255,255,255,0.06)" : "#14151c";
    ctx.fill();
    ctx.lineWidth = active ? 2.5 : 1.5;
    ctx.strokeStyle = active ? col : (done ? "rgba(255,255,255,0.22)" : "rgba(255,255,255,0.1)");
    ctx.stroke();

    // label
    ctx.fillStyle = col;
    ctx.font = "700 14px ui-sans-serif, sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(box.stage.label, box.x + box.w / 2, box.y + 24);

    // value summary for this stage
    ctx.fillStyle = "rgba(226,232,240,0.92)";
    ctx.font = "12px ui-monospace, monospace";
    var lines = stageLines(box.stage.key);
    for (var i = 0; i < lines.length; i++) {
      ctx.fillText(lines[i], box.x + box.w / 2, box.y + 44 + i * 15);
    }
  }

  function fmt(v, d) { return (Math.round(v * Math.pow(10, d)) / Math.pow(10, d)).toFixed(d); }

  function stageLines(key) {
    if (!derived) return [];
    var d = derived;
    switch (key) {
      case "raw":
        return ["age=NaN  inc=120", 'plan="pro"'];
      case "impute":
        return ["age=" + fmt(d.imputed.age, 1) + " (fill)", "inc=120  plan=pro"];
      case "scale":
        return ["age_z=" + fmt(d.scaled.age, 2), "inc_z=" + fmt(d.scaled.income, 2)];
      case "encode":
        return ["free=" + d.encoded.free + " pro=" + d.encoded.pro, "age_z, inc_z kept"];
      case "model":
        return ["w·x → logit", "score the vector"];
      case "predict":
        return ["P(upgrade)", fmt(d.p, 3)];
    }
    return [];
  }

  function drawToken(boxes) {
    // The token sits at boxes[stageIdx] when anim=1, traveling from
    // boxes[stageIdx-1] when anim<1.
    if (stageIdx <= 0 && anim >= 1) { tokenAt(boxes[0]); return; }
    var from = boxes[Math.max(0, stageIdx - 1)];
    var to = boxes[stageIdx];
    if (!to) { tokenAt(boxes[boxes.length - 1]); return; }
    var ca = center(from), cb = center(to);
    var u = easeInOut(anim);
    var x = ca.x + (cb.x - ca.x) * u;
    var y = ca.y + (cb.y - ca.y) * u;
    tokenXY(x, y, to.stage.color);
  }
  function tokenAt(box) { var c = center(box); tokenXY(c.x, c.y, box.stage.color); }
  function tokenXY(x, y, col) {
    ctx.save();
    ctx.shadowColor = col;
    ctx.shadowBlur = 16;
    ctx.beginPath();
    ctx.arc(x, y, 9, 0, Math.PI * 2);
    ctx.fillStyle = "#f8fafc";
    ctx.fill();
    ctx.lineWidth = 2.5;
    ctx.strokeStyle = col;
    ctx.stroke();
    ctx.restore();
  }

  function roundRect(x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.arcTo(x + w, y, x + w, y + h, r);
    ctx.arcTo(x + w, y + h, x, y + h, r);
    ctx.arcTo(x, y + h, x, y, r);
    ctx.arcTo(x, y, x + w, y, r);
    ctx.closePath();
  }
  function easeInOut(u) { return u < 0.5 ? 2 * u * u : 1 - Math.pow(-2 * u + 2, 2) / 2; }

  // ---- panel readout -------------------------------------------------------
  var NOTES = {
    raw:     "Raw input straight from the source — missing age, raw-scale income, text category.",
    impute:  "SimpleImputer fills missing age with the LEARNED mean age. Where that mean comes from is the whole game.",
    scale:   "StandardScaler centers and scales each numeric column with the learned mean/std — again, learned from the fitted rows.",
    encode:  "OneHotEncoder turns plan=\"pro\" into free=0, pro=1. No statistics needed; it's a structural transform.",
    model:   "The classifier scores the standardized + encoded vector with w·x + b, then a sigmoid.",
    predict: "Final probability of upgrade for this row, ready to threshold into a decision."
  };

  function updatePanel() {
    if (!derived) return;
    var stage = STAGES[stageIdx] || STAGES[STAGES.length - 1];
    stageNameEl.textContent = stage.label.toLowerCase();
    var leak = leakChk.checked;
    fitOnEl.textContent = leak ? "train + TEST" : "train only";
    fitOnEl.className = "stat-val " + (leak ? "leak" : "safe");

    var d = derived;
    var html;
    switch (stage.key) {
      case "raw":
        html = 'age=<b>NaN</b>, income=<b>120</b>, plan=<b>"pro"</b>'; break;
      case "impute":
        html = 'age=<b>' + fmt(d.imputed.age, 1) + '</b> (filled), income=<b>120</b>, plan=<b>"pro"</b>'; break;
      case "scale":
        html = 'age_z=<b>' + fmt(d.scaled.age, 2) + '</b>, income_z=<b>' + fmt(d.scaled.income, 2) + '</b>, plan=<b>"pro"</b>'; break;
      case "encode":
        html = 'age_z=<b>' + fmt(d.scaled.age, 2) + '</b>, income_z=<b>' + fmt(d.scaled.income, 2) + '</b>, free=<b>' + d.encoded.free + '</b>, pro=<b>' + d.encoded.pro + '</b>'; break;
      case "model":
        html = 'vector → logit (w·x + b) using fitted weights'; break;
      case "predict":
        html = 'P(upgrade) = <b>' + fmt(d.p, 3) + '</b>'; break;
      default:
        html = '';
    }
    rowValEl.innerHTML = html;
    noteEl.textContent = NOTES[stage.key];
  }

  // ---- animation loop ------------------------------------------------------
  function loop(ts) {
    if (!playing) return;
    if (!lastTs) lastTs = ts;
    var dt = ts - lastTs;
    lastTs = ts;
    anim += dt / 700; // ~0.7s per hop
    if (anim >= 1) {
      anim = 1;
      draw();
      if (stageIdx >= STAGES.length - 1) { stopPlay(); return; }
      // pause briefly on each stage, then advance
      anim = 0;
      stageIdx++;
    }
    draw();
    rafId = requestAnimationFrame(loop);
  }

  function startPlay() {
    if (stageIdx >= STAGES.length - 1 && anim >= 1) resetFlow(); // restart if finished
    playing = true;
    btnPlay.textContent = "Pause";
    btnPlay.classList.add("active");
    lastTs = 0;
    rafId = requestAnimationFrame(loop);
  }
  function stopPlay() {
    playing = false;
    if (rafId) cancelAnimationFrame(rafId);
    rafId = null;
    btnPlay.textContent = "Play";
    btnPlay.classList.remove("active");
  }

  function stepOnce() {
    stopPlay();
    if (stageIdx >= STAGES.length - 1) { resetFlow(); draw(); return; }
    stageIdx++;
    anim = 1; // snap into the next stage
    draw();
  }

  function resetFlow() {
    stopPlay();
    stageIdx = 0;
    anim = 1;
  }

  // ---- UI glue -------------------------------------------------------------
  leakChk.addEventListener("change", function () { refresh(); draw(); });
  btnPlay.addEventListener("click", function () { if (playing) stopPlay(); else startPlay(); });
  btnStep.addEventListener("click", stepOnce);
  btnReset.addEventListener("click", function () { resetFlow(); draw(); });

  // ---- init ----------------------------------------------------------------
  refresh();
  resetFlow();
  draw();
})();

# Solved — Improving a Baseline Model with Feature Engineering

> A bike-share operator wants to staff and rebalance docks by the hour — but a plain linear model thinks 1 AM and 1 PM are "almost the same time" and badly under-predicts the rush.

## Problem statement

You run a city bike-share scheme and need to predict `rentals` (bikes checked out in a given hour) from four raw signals: `hour` (0–23), `temp_c` (air temperature in Celsius), `humidity` (0–1), and `weather` (`clear` / `cloudy` / `rain`). The target is **regression** — a continuous count — and the scoring metric is **R²** on a held-out test set (how much of the variance in demand the model explains; 1.0 is perfect, 0.0 is no better than always guessing the mean).

The catch is that the *raw* features fight a linear model:

- `hour` is **cyclical**. As a plain number, the model treats hour 23 and hour 0 as 23 units apart, when they are really one hour apart. It also can only fit a straight line through the day, but demand has *two* peaks (morning and evening commutes).
- `humidity` enters demand non-linearly, and `weather` is a category, not a number.

So this lesson is a clean before/after: fit a `LinearRegression` **baseline** on the raw columns, then keep the *exact same model* but feed it **engineered features** — cyclical sin/cos hour, a rush-hour interaction, a log-damped humidity term, and one-hot weather — all inside a leak-proof `Pipeline`. Same algorithm, better inputs, much higher R².

## Data sample

A realistic slice (the code builds the full inline set below — `df` has shape `(480, 5)`: four feature columns plus the `rentals` target, from 20 days × 24 hours; columns `hour, temp_c, humidity, weather, rentals`):

| hour | temp_c | humidity | weather | rentals |
|-----:|-------:|---------:|---------|--------:|
|    8 |   18.0 |     0.55 | clear   |     312 |
|   13 |   24.0 |     0.40 | clear   |     181 |
|   18 |   21.0 |     0.50 | cloudy  |     340 |
|    3 |   12.0 |     0.80 | clear   |       9 |
|   18 |   16.0 |     0.70 | rain    |     142 |
|   12 |   26.0 |     0.35 | clear   |     205 |

The pattern baked into the data: **two commute peaks around hour 8 and hour 18**, demand rises with temperature and falls with humidity, and **rain roughly halves** rentals. A straight line on raw `hour` can capture none of the twin-peak shape — that is precisely why the baseline will stall.

## Why this problem matters

Teams reach for a bigger, fancier model (gradient boosting, a neural net) the moment a baseline disappoints — when often the real fix is cheaper and more durable: **give the model features that match the structure of the problem.** Encoding `hour` cyclically and adding a rush-hour flag costs a few lines, keeps the model fully interpretable, and frequently beats throwing a heavier algorithm at raw columns. It also forces the discipline that separates a toy notebook from production: every transform must be **fit on training data only** and bundled into a `Pipeline`, so the same steps run identically at serving time with zero leakage.

## Step-by-step reasoning

1. **Establish an honest baseline.** Fit `LinearRegression` on the raw numeric columns (`hour`, `temp_c`, `humidity`) with one-hot `weather`. Record its test R². This is the bar to beat — and it is deliberately *fair*, using the same model class we will keep.
2. **Diagnose why it fails.** Demand vs `hour` is not a line; it is a twin-peaked curve, and `hour` is circular (23 ≈ 0). A single linear coefficient on `hour` cannot bend, so the baseline smears the morning and evening rushes into a flat average.
3. **Encode the cycle with sin/cos.** Map `hour` to `sin(2π·hour/24)` and `cos(2π·hour/24)`. Now 23:00 and 00:00 sit next to each other on the circle, and the *pair* of features lets a linear model represent a smooth daily wave instead of a ramp.
4. **Add a targeted interaction and a transform.** A `rush` indicator (near hour 8 or 18) times temperature captures "warm commute hours are busiest"; a `log1p(humidity·100)` term damps the non-linear humidity effect. These are domain hunches turned into columns.
5. **Bundle everything leak-free in a `Pipeline` + `ColumnTransformer`.** Build the engineered columns with a `FunctionTransformer`, scale numerics, one-hot the category, then `LinearRegression`. Because every step is fit inside `.fit(X_train)`, the test set never influences any statistic — and the whole thing deploys as one object.
6. **Compare on one fixed split.** Train both models on the same `train_test_split` so the *only* thing that changed is the features. The R² jump is therefore attributable to feature engineering, not luck.

## Python solution

```python
import io
import numpy as np
import pandas as pd
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder, FunctionTransformer
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_absolute_error

# --- 1. Build the data inline (no downloads). 20 days x 24 hours. ---
rng = np.random.default_rng(0)
rows = []
weather_choices = np.array(["clear", "cloudy", "rain"])
for day in range(20):
    for hour in range(24):
        temp_c = 10 + 12 * np.sin(2 * np.pi * (hour - 9) / 24) + rng.normal(0, 1.5)
        humidity = float(np.clip(0.75 - 0.012 * temp_c + rng.normal(0, 0.05), 0.2, 0.95))
        weather = rng.choice(weather_choices, p=[0.65, 0.25, 0.10])

        # True demand: TWO commute peaks (hour ~8 and ~18), warmer = more,
        # humid = fewer, rain roughly halves it.
        morning = np.exp(-((hour - 8) ** 2) / 6.0)
        evening = np.exp(-((hour - 18) ** 2) / 6.0)
        base = 380 * (morning + evening) + 40
        temp_boost = 4.0 * temp_c
        humid_drop = -120 * humidity
        rain_factor = 0.5 if weather == "rain" else (0.85 if weather == "cloudy" else 1.0)
        rentals = max(0, (base + temp_boost + humid_drop) * rain_factor + rng.normal(0, 12))
        rows.append((hour, round(temp_c, 1), round(humidity, 2), weather, round(rentals)))

df = pd.DataFrame(rows, columns=["hour", "temp_c", "humidity", "weather", "rentals"])
print("Shape:", df.shape, "| mean rentals:", round(df["rentals"].mean(), 1))

X = df.drop(columns="rentals")
y = df["rentals"].values

# ONE fixed split so before/after is apples-to-apples.
X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.30, random_state=42)

# --- 2. BASELINE: same model, RAW features (hour as a plain number). ---
baseline_pre = ColumnTransformer([
    ("num", StandardScaler(), ["hour", "temp_c", "humidity"]),
    ("cat", OneHotEncoder(handle_unknown="ignore"), ["weather"]),
])
baseline = Pipeline([("pre", baseline_pre), ("lr", LinearRegression())])
baseline.fit(X_tr, y_tr)
base_pred = baseline.predict(X_te)
print(f"\nBASELINE  R2={r2_score(y_te, base_pred):.3f}  "
      f"MAE={mean_absolute_error(y_te, base_pred):.1f}")

# --- 3. FEATURE ENGINEERING (leak-free, pipeline-ready). ---
def engineer(frame):
    f = frame.copy()
    h = f["hour"].to_numpy()
    f["hour_sin"] = np.sin(2 * np.pi * h / 24)      # cyclical: 23h ~ 0h
    f["hour_cos"] = np.cos(2 * np.pi * h / 24)
    rush = (np.minimum(np.abs(h - 8), np.abs(h - 18)) <= 1).astype(float)
    f["rush_x_temp"] = rush * f["temp_c"]            # interaction term
    f["log_humidity"] = np.log1p(f["humidity"] * 100)  # damp non-linear humidity
    return f[["hour_sin", "hour_cos", "temp_c", "rush_x_temp",
              "log_humidity", "humidity", "weather"]]

eng_pre = ColumnTransformer([
    ("num", StandardScaler(),
     ["hour_sin", "hour_cos", "temp_c", "rush_x_temp", "log_humidity", "humidity"]),
    ("cat", OneHotEncoder(handle_unknown="ignore"), ["weather"]),
])
engineered = Pipeline([
    ("feat", FunctionTransformer(engineer)),   # build columns inside the pipeline
    ("pre", eng_pre),
    ("lr", LinearRegression()),
])
engineered.fit(X_tr, y_tr)
eng_pred = engineered.predict(X_te)
print(f"ENGINEERED R2={r2_score(y_te, eng_pred):.3f}  "
      f"MAE={mean_absolute_error(y_te, eng_pred):.1f}")

print(f"\nR2 lift from feature engineering: "
      f"{r2_score(y_te, eng_pred) - r2_score(y_te, base_pred):+.3f}")

# --- 4. Sanity-check a known rush hour vs a dead hour. ---
probe = pd.DataFrame({
    "hour": [8, 3], "temp_c": [18.0, 12.0],
    "humidity": [0.55, 0.80], "weather": ["clear", "clear"],
})
print("\nPredicted rentals (engineered) for 8AM clear vs 3AM clear:",
      np.round(engineered.predict(probe)).astype(int))
```

## Expected output

- `Shape: (480, 5) | mean rentals: ~140` — 480 hourly rows (4 feature columns + the target); the exact mean wobbles slightly with the seed.
- **Baseline** lands around **R² ≈ 0.25–0.40** (about **0.28** with this seed) with a large MAE near 100. With `hour` as a single straight line, the model cannot represent the two daily peaks, so it explains well under half the variance.
- **Engineered** jumps to roughly **R² ≈ 0.70–0.80** (about **0.74** here) with the MAE roughly halved (~58). The sin/cos pair lets a linear model trace the smooth daily wave, the rush interaction sharpens the peaks, and the result is a large, repeatable lift — the printed `R2 lift` is comfortably positive (around **+0.46** with this seed, and reliably **+0.40 or more**).
- The **probe** shows the engineered model predicting a busy 8 AM (around 400 rentals) far above a near-dead 3 AM (single digits) — exactly the commute pattern the baseline blurred. Approximate numbers are fine; the *direction and size* of the gap is the lesson, and small-data wobble across seeds is expected.

## Common mistakes

1. **Engineering features on the full dataset before splitting** (computing scaler means, or even the sin/cos columns, on all rows at once and *then* splitting). Any statistic learned from test rows is leakage. Fix: wrap every transform in the `Pipeline` so each step is fit only on the training fold during `.fit`.
2. **Treating cyclical `hour` as a plain number.** A single linear coefficient cannot bend or wrap, so 23:00 looks far from 00:00 and the twin peaks vanish. Fix: encode with `sin`/`cos` (or, for trees, bin the hour) so the cycle is representable.
3. **Label-encoding `weather` as 0/1/2.** That invents an order (`rain` is not "twice" `cloudy`). Fix: `OneHotEncoder` with `handle_unknown="ignore"` so unseen categories at serving time don't crash.
4. **Comparing baseline and engineered models on different splits.** If the `random_state` differs, you can't credit the gain to features. Fix: one fixed `train_test_split`, change only the feature set.
5. **Confusing "more features" with "better features."** Dumping dozens of random polynomial terms can overfit and *hurt* test R². Fix: add features that match known structure (cyclicity, a real interaction, a skew-fixing transform) and confirm each helps on the held-out set.

## Extension challenge

1. Add a `polynomial` term for `temp_c` (its square) via the engineering function and check whether test R² improves or starts to overfit — compare train vs test R² for both versions.
2. Swap `LinearRegression` for `Ridge(alpha=...)` inside the engineered pipeline and tune `alpha` with `GridSearchCV`; does light regularization help now that you have more columns?
3. Drop the cyclical encoding and instead **bin** `hour` into `KBinsDiscretizer` buckets (e.g. night / morning-rush / midday / evening-rush). Compare its R² to the sin/cos version and discuss the interpretability vs smoothness trade-off.

## Matching animation

Open **"Feature Scaling Before and After Visualizer"** and toggle `StandardScaler` on the numeric features: watch how columns on different ranges (the raw `temp_c` and the tiny sin/cos values here) snap onto a common scale, which is exactly what keeps one engineered feature from drowning out another in the linear fit. Then walk the same data through the **"Pipeline Flow Animator"** to see each stage — engineer → scale → one-hot → `LinearRegression` — fire in order on the *training fold only*, making concrete why bundling the transforms in a `Pipeline` is what makes this lift leak-free and deployable.

# Features Make or Break Models

> The single biggest lever on model accuracy is rarely the algorithm — it's the quality of the columns you feed it.

## What you'll learn
- What a **feature** actually is, and what separates a *good* feature from a useless one.
- How to turn raw fields (dates, free text, IDs) into features a model can use.
- Three workhorse techniques: **ratios**, **binning**, and **interactions**.
- Why **domain knowledge** beats brute force, with concrete examples.
- A repeatable way to brainstorm features before you ever touch an algorithm.

## Intuition
A **feature** is one column of numbers (or categories) that describes each example. A model never sees your raw data the way you do — it only sees the numbers in those columns. If the columns don't contain the signal, no algorithm can recover it. Think of features as the *questions you ask about each row*. "How old is this customer?" is a better question than "What is the exact timestamp they signed up?" — even though the timestamp technically contains the age.

Here's the mental model: imagine predicting whether a pizza delivery will be late. The raw log has an `order_time` like `2026-06-18 19:42:11`. That long string is almost useless on its own — two orders one second apart look totally different to the model. But the *hour of day* (19) and *day of week* (Wednesday) are gold: dinner rush on a weekday is when things run late. Same raw data, but one phrasing hides the signal and the other exposes it. **That reshaping is feature engineering.**

A **good feature** is one that (1) actually relates to the target, (2) is available at prediction time (no peeking at the future), and (3) is on a sensible scale and form. A **bad feature** leaks the answer (e.g. `delivery_completed_at` when predicting lateness), is a high-cardinality ID with no meaning (a raw `order_id`), or is so noisy it just lets the model memorize.

Three moves you'll reach for again and again:
- **Ratios** combine two columns into something more meaningful. `price_per_sqft` says more about a house than `price` and `sqft` separately.
- **Binning** groups a continuous number into buckets (`age` → `child / adult / senior`). Useful when the relationship is *not* a straight line.
- **Interactions** multiply or combine features so the model can express "X matters *only when* Y." `is_weekend × hour` captures that late-night Saturdays behave differently from late-night Tuesdays.

## Python in practice

```python
import pandas as pd
import numpy as np

# A tiny raw dataset, the messy way it often arrives
df = pd.DataFrame({
    "order_time":  pd.to_datetime([
        "2026-06-15 19:42", "2026-06-16 08:05",
        "2026-06-20 21:10", "2026-06-21 12:30",
    ]),
    "item_price":  [240.0, 90.0, 560.0, 130.0],
    "items_count": [3,      1,    4,     2    ],
})

# 1) DATE -> useful parts. The raw timestamp is nearly useless;
#    hour and day-of-week carry the real signal.
df["hour"]       = df["order_time"].dt.hour          # 0-23
df["dayofweek"]  = df["order_time"].dt.dayofweek     # Mon=0 ... Sun=6
df["is_weekend"] = (df["dayofweek"] >= 5).astype(int)

# 2) RATIO -> price per item is more comparable than total price
df["price_per_item"] = df["item_price"] / df["items_count"]

# 3) BINNING -> turn a continuous hour into meaningful day-parts
df["daypart"] = pd.cut(
    df["hour"],
    bins=[-1, 6, 11, 16, 21, 24],
    labels=["night", "morning", "midday", "evening", "latenight"],
)

# 4) INTERACTION -> "expensive AND large order" as a single flag
df["big_pricey_order"] = ((df["item_price"] > 200) &
                          (df["items_count"] >= 3)).astype(int)

print(df[["hour", "is_weekend", "price_per_item", "daypart",
          "big_pricey_order"]])
```

Expected output (a tidy table of *derived* columns):

```text
   hour  is_weekend  price_per_item   daypart  big_pricey_order
0    19           1           80.00   evening                 1
1     8           0           90.00   morning                 0
2    21           0          140.00   evening                 1
3    12           0           65.00    midday                 0
```

Notice we never dropped a single row — we just *asked better questions* of the same data. Every new column is something a human delivery manager would intuitively care about.

```python
# Domain knowledge in action: the SAME columns, framed for a
# loan-default problem instead. A debt-to-income RATIO is the
# classic engineered feature lenders trust more than raw income.
people = pd.DataFrame({
    "annual_income": [40000, 120000, 60000],
    "monthly_debt":  [1500,  1500,   2500 ],
})
people["debt_to_income"] = (people["monthly_debt"] * 12) / people["annual_income"]
print(people)
# Person 3 earns more than person 1 but has a WORSE ratio (0.50 vs 0.45):
# the ratio surfaces risk that raw income alone would hide.
```

## Common mistakes
- **Leaking the target.** Any column that is only known *after* the outcome (e.g. `was_refunded` when predicting a sale, or `delivery_completed_at` for lateness) is forbidden — it makes training scores look amazing and production scores collapse.
- **Feeding raw IDs or timestamps directly.** A `customer_id` of `48213` is a meaningless magnitude; a model may treat it as "bigger = more." Drop it or convert it into something real (e.g. *number of past orders by that customer*).
- **Binning when you don't need to.** Cutting a smooth, linear relationship into buckets throws away information. Bin only when the relationship is non-linear or you want interpretable groups.
- **Creating features the model can't have at prediction time.** If `price_per_item` needs `items_count`, make sure `items_count` is known *before* the prediction is needed.
- **Adding hundreds of features hoping one sticks.** More columns mean more noise and overfitting. Prefer a few well-reasoned features over a feature firehose.

## Small exercise
1. Take the `df` above and add a feature `is_rush_hour` that is `1` when `hour` is between 18 and 20 (inclusive) and `0` otherwise.
2. Add a ratio `items_per_dollar = items_count / item_price`.
3. Which of your two new features do you think relates more strongly to a delivery being late, and *why*? (Hint: think about *when* the kitchen is overloaded.)

## Before you continue
- [ ] I can explain in one sentence what a feature is and why the algorithm only ever "sees" features.
- [ ] I can give a concrete example of a leaky feature and why it ruins a model.
- [ ] I can turn a raw timestamp into at least two useful features without looking it up.
- [ ] I can describe when binning helps and when it hurts.

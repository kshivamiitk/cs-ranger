"use strict";

/* ------------------------------------------------------------------ *
 * Encoding Categorical Variables
 *
 * A model only does arithmetic, so a text column must become numbers.
 * Two ways to do that, with very different consequences:
 *
 *   LABEL / ORDINAL  red->0, green->1, blue->2   (one column, implies order)
 *   ONE-HOT          color_red / color_green / color_blue  (N binary columns)
 *
 * The trap we visualise: label-encoding an UNORDERED category invents a
 * ranking (blue > green > red) that a linear model takes literally. When a
 * category IS ordinal (small < medium < large) that same integer mapping is
 * legitimate, so the warning turns off.
 *
 * Everything here is deterministic: fixed presets, fixed row order, no RNG.
 * ------------------------------------------------------------------ */

// ----- Presets: two fixed datasets (6 rows each) ------------------
const PRESETS = {
  color: {
    feature: "color",
    ordinal: false,                                  // no natural ranking
    categories: ["red", "green", "blue"],            // label-index order
    rows: ["red", "green", "blue", "green", "red", "blue"],
    colors: { red: "#f87171", green: "#34d399", blue: "#60a5fa" }
  },
  size: {
    feature: "size",
    ordinal: true,                                   // a real ranking
    categories: ["small", "medium", "large"],
    rows: ["small", "large", "medium", "small", "large", "medium"],
    colors: { small: "#a78bfa", medium: "#22d3ee", large: "#fbbf24" }
  }
};

// ----- State -----
let presetKey = "color";
let encoding = "onehot";                             // "label" | "onehot"
let showLine = true;
let anim = null;                                     // rAF id while animating
let animT0 = 0;                                      // animation start time
const ANIM_MS = 720;

// ----- DOM -----
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const encVal = document.getElementById("encVal");
const presetVal = document.getElementById("presetVal");
const segLabel = document.getElementById("segLabel");
const segOneHot = document.getElementById("segOneHot");
const presetColor = document.getElementById("presetColor");
const presetSize = document.getElementById("presetSize");
const showLineInput = document.getElementById("showLine");
const elFeature = document.getElementById("rFeature");
const elCats = document.getElementById("rCats");
const elRows = document.getElementById("rRows");
const elCols = document.getElementById("rCols");
const elStatus = document.getElementById("rStatus");
const snipTag = document.getElementById("snipTag");
const elCode = document.getElementById("rCode");

// ----- Layout constants (world coords on the 900x500 canvas) -----
const PAD = { l: 40, r: 40, t: 70, b: 50 };
const ROW_H = 44;
const SRC_X = 70;            // left edge of the source (text) column
const SRC_W = 150;
const DST_X = 470;          // left edge of the encoded output
const CELL_GAP = 12;

function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
function easeOutCubic(k) { return 1 - Math.pow(1 - k, 3); }
function lerp(a, b, t) { return a + (b - a) * t; }

function preset() { return PRESETS[presetKey]; }
function labelIndex(cat) { return preset().categories.indexOf(cat); }

// ----- derived counts for the readout -----
function outputCols() {
  return encoding === "label" ? 1 : preset().categories.length;
}

// ============================================================== //
// Animation driver: every method switch / preset switch / replay //
// runs a fresh 0->1 progress sweep that the renderer reads.       //
// ============================================================== //
function startAnim() {
  if (anim) cancelAnimationFrame(anim);
  animT0 = performance.now();
  function frame(t) {
    const k = clamp((t - animT0) / ANIM_MS, 0, 1);
    render(easeOutCubic(k));
    if (k < 1) { anim = requestAnimationFrame(frame); }
    else { anim = null; render(1); }
  }
  anim = requestAnimationFrame(frame);
}

// ----- Master render. `p` is animation progress in [0,1]. -----
function render(p) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawTitles(p);
  drawSourceColumn(p);
  if (encoding === "label") {
    drawLabelOutput(p);
    if (showLine) drawNumberLine(p);
  } else {
    drawOneHotOutput(p);
  }
  drawArrow(p);
  updateReadout();
}

function rowY(i) { return PAD.t + 18 + i * ROW_H; }

function drawTitles(p) {
  const ps = preset();
  ctx.save();
  ctx.fillStyle = "#e2e8f0";
  ctx.font = "600 16px Inter, sans-serif";
  ctx.textAlign = "left";
  ctx.fillText("raw column", SRC_X, PAD.t - 8);

  ctx.fillStyle = "#94a3b8";
  ctx.font = "12px ui-monospace, Menlo, monospace";
  ctx.fillText(ps.feature, SRC_X, PAD.t + 8);

  ctx.fillStyle = "#e2e8f0";
  ctx.font = "600 16px Inter, sans-serif";
  const title = encoding === "label" ? "label / ordinal encoded" : "one-hot encoded";
  ctx.fillText(title, DST_X, PAD.t - 8);
  ctx.restore();
}

// Left column: the original text categories (always visible) ------
function drawSourceColumn(p) {
  const ps = preset();
  ctx.save();
  for (let i = 0; i < ps.rows.length; i++) {
    const cat = ps.rows[i];
    const y = rowY(i);
    drawCell(SRC_X, y, SRC_W, ROW_H - CELL_GAP, {
      text: cat,
      fill: hexA(ps.colors[cat], 0.16),
      border: hexA(ps.colors[cat], 0.55),
      textColor: ps.colors[cat]
    });
  }
  ctx.restore();
}

// LABEL output: one column, each text cell "flips" to its integer --
function drawLabelOutput(p) {
  const ps = preset();
  const colW = 150;
  ctx.save();
  // column header
  ctx.fillStyle = "#94a3b8";
  ctx.font = "12px ui-monospace, Menlo, monospace";
  ctx.textAlign = "left";
  ctx.fillText(ps.feature + "_idx", DST_X, PAD.t + 8);

  for (let i = 0; i < ps.rows.length; i++) {
    const cat = ps.rows[i];
    const idx = labelIndex(cat);
    const y = rowY(i);
    // "flip": cell scales in vertically as the integer settles
    const local = clamp(p * 1.4 - i * 0.06, 0, 1);
    const s = easeOutCubic(local);
    const h = (ROW_H - CELL_GAP) * s;
    const yy = y + ((ROW_H - CELL_GAP) - h) / 2;
    // unordered -> danger tint to flag the fake ordering
    const accent = ps.ordinal ? ps.colors[cat] : "#f87171";
    drawCell(DST_X, yy, colW, h, {
      text: s > 0.5 ? String(idx) : "",
      fill: hexA(accent, 0.16),
      border: hexA(accent, 0.55),
      textColor: accent,
      mono: true
    });
  }
  ctx.restore();
}

// ONE-HOT output: column EXPANDS into N binary columns -------------
function drawOneHotOutput(p) {
  const ps = preset();
  const cats = ps.categories;
  const n = cats.length;
  const fullW = 110;
  // columns slide/grow out from a single collapsed column at progress 0
  for (let c = 0; c < n; c++) {
    const cat = cats[c];
    const accent = ps.colors[cat];
    // each column expands a touch after the previous one
    const local = clamp(p * 1.3 - c * 0.12, 0, 1);
    const s = easeOutCubic(local);
    const w = fullW * s;
    if (w < 2) continue;
    const cx = DST_X + c * (fullW + 8);

    // header label color_<cat>
    ctx.save();
    ctx.globalAlpha = s;
    ctx.fillStyle = "#94a3b8";
    ctx.font = "11px ui-monospace, Menlo, monospace";
    ctx.textAlign = "left";
    ctx.fillText(ps.feature + "_" + cat, cx, PAD.t + 8);
    ctx.restore();

    for (let i = 0; i < ps.rows.length; i++) {
      const y = rowY(i);
      const on = ps.rows[i] === cat ? 1 : 0;
      // the matching 1 slides into place; the 0s are muted
      const dropIn = on ? clamp(p * 1.2 - i * 0.05, 0, 1) : 1;
      const dy = on ? (1 - easeOutCubic(dropIn)) * -16 : 0;
      drawCell(cx, y + dy, w, ROW_H - CELL_GAP, {
        text: s > 0.4 ? String(on) : "",
        fill: on ? hexA(accent, 0.20) : "rgba(255,255,255,0.03)",
        border: on ? hexA(accent, 0.6) : "rgba(255,255,255,0.10)",
        textColor: on ? accent : "#64748b",
        mono: true,
        alpha: s
      });
    }
  }
}

// The "implied number line" for label encoding --------------------
function drawNumberLine(p) {
  const ps = preset();
  const cats = ps.categories;
  const n = cats.length;
  const y = PAD.t + ps.rows.length * ROW_H + 14;
  const x0 = DST_X;
  const x1 = DST_X + 290;
  const danger = !ps.ordinal;
  const axisColor = danger ? "#f87171" : "#34d399";

  ctx.save();
  ctx.globalAlpha = clamp(p * 1.5 - 0.3, 0, 1);

  // baseline
  ctx.strokeStyle = hexA(axisColor, 0.8);
  ctx.lineWidth = 2;
  ctx.beginPath();
  ctx.moveTo(x0, y);
  ctx.lineTo(x1, y);
  ctx.stroke();
  // arrow head (suggests "increasing magnitude")
  ctx.beginPath();
  ctx.moveTo(x1, y);
  ctx.lineTo(x1 - 9, y - 5);
  ctx.lineTo(x1 - 9, y + 5);
  ctx.closePath();
  ctx.fillStyle = hexA(axisColor, 0.8);
  ctx.fill();

  // tick + label per category at its integer position
  ctx.font = "11px ui-monospace, Menlo, monospace";
  for (let c = 0; c < n; c++) {
    const tx = lerp(x0 + 14, x1 - 24, n === 1 ? 0 : c / (n - 1));
    ctx.strokeStyle = hexA(axisColor, 0.8);
    ctx.beginPath();
    ctx.moveTo(tx, y - 6);
    ctx.lineTo(tx, y + 6);
    ctx.stroke();
    ctx.fillStyle = "#94a3b8";
    ctx.textAlign = "center";
    ctx.fillText(String(c), tx, y + 20);
    ctx.fillStyle = ps.colors[cats[c]];
    ctx.fillText(cats[c], tx, y - 12);
  }

  // caption
  ctx.textAlign = "left";
  ctx.font = "600 12px Inter, sans-serif";
  ctx.fillStyle = axisColor;
  const msg = danger
    ? "⚠ implies " + cats[n - 1] + " > " + cats[0] + " (false order!)"
    : "✓ order is real: " + cats.join(" < ");
  ctx.fillText(msg, x0, y + 40);
  ctx.restore();
}

// Connector arrow between source and output -----------------------
function drawArrow(p) {
  const ps = preset();
  const midY = PAD.t + (ps.rows.length * ROW_H) / 2;
  const xa = SRC_X + SRC_W + 18;
  const xb = DST_X - 18;
  ctx.save();
  const grad = ctx.createLinearGradient(xa, 0, xb, 0);
  grad.addColorStop(0, "#a78bfa");
  grad.addColorStop(1, "#22d3ee");
  ctx.strokeStyle = grad;
  ctx.fillStyle = "#22d3ee";
  ctx.lineWidth = 2.5;
  ctx.beginPath();
  ctx.moveTo(xa, midY);
  ctx.lineTo(xb - 6, midY);
  ctx.stroke();
  ctx.beginPath();
  ctx.moveTo(xb, midY);
  ctx.lineTo(xb - 11, midY - 7);
  ctx.lineTo(xb - 11, midY + 7);
  ctx.closePath();
  ctx.fill();

  ctx.fillStyle = "#94a3b8";
  ctx.font = "11px ui-monospace, Menlo, monospace";
  ctx.textAlign = "center";
  ctx.fillText(encoding === "label" ? "encode" : "expand", (xa + xb) / 2, midY - 12);
  ctx.restore();
}

// ----- A rounded table cell with centered text -----
function drawCell(x, y, w, h, opt) {
  if (h <= 0 || w <= 0) return;
  ctx.save();
  if (typeof opt.alpha === "number") ctx.globalAlpha = opt.alpha;
  const r = 8;
  roundRect(x, y, w, h, r);
  ctx.fillStyle = opt.fill;
  ctx.fill();
  ctx.strokeStyle = opt.border;
  ctx.lineWidth = 1.5;
  ctx.stroke();
  if (opt.text !== "") {
    ctx.fillStyle = opt.textColor;
    ctx.font = opt.mono
      ? "600 16px ui-monospace, Menlo, monospace"
      : "600 15px Inter, sans-serif";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText(opt.text, x + w / 2, y + h / 2 + 1);
    ctx.textBaseline = "alphabetic";
  }
  ctx.restore();
}

function roundRect(x, y, w, h, r) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}

// "#rrggbb" + alpha -> rgba() string
function hexA(hex, a) {
  const h = hex.replace("#", "");
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  return "rgba(" + r + "," + g + "," + b + "," + a + ")";
}

// ----- Readout + code snippet -----
function updateReadout() {
  const ps = preset();
  encVal.textContent = encoding === "label" ? "Label / Ordinal" : "One-Hot";
  presetVal.textContent = ps.feature;
  elFeature.textContent = ps.feature;
  elCats.textContent = String(ps.categories.length);
  elRows.textContent = String(ps.rows.length);
  elCols.textContent = String(outputCols());

  // verdict: only label-encoding an unordered feature is the trap
  const trap = encoding === "label" && !ps.ordinal;
  elStatus.className = "v";
  if (trap) {
    elStatus.textContent = "fake order!";
    elStatus.classList.add("warn");
  } else if (encoding === "label" && ps.ordinal) {
    elStatus.textContent = "ordinal ok";
    elStatus.classList.add("good");
  } else {
    elStatus.textContent = "safe";
    elStatus.classList.add("snapped");
  }

  // matching scikit-learn / pandas snippet
  if (encoding === "label") {
    if (ps.ordinal) {
      snipTag.textContent = "OrdinalEncoder";
      elCode.textContent =
        "from sklearn.preprocessing import OrdinalEncoder\n" +
        "enc = OrdinalEncoder(categories=[[\n" +
        "    " + ps.categories.map(q).join(", ") + "  # real order\n" +
        "]])\n" +
        "X[[\"" + ps.feature + "\"]] = enc.fit_transform(X[[\"" + ps.feature + "\"]])";
    } else {
      snipTag.textContent = "OrdinalEncoder ⚠";
      elCode.textContent =
        "# fits, but invents an order on an unordered column:\n" +
        "from sklearn.preprocessing import OrdinalEncoder\n" +
        "enc = OrdinalEncoder()              # " + ps.feature +
        " -> 0,1,2 (meaningless)\n" +
        "# prefer OneHotEncoder for \"" + ps.feature + "\"";
    }
  } else {
    snipTag.textContent = "OneHotEncoder";
    elCode.textContent =
      "from sklearn.preprocessing import OneHotEncoder\n" +
      "enc = OneHotEncoder(handle_unknown=\"ignore\")\n" +
      "ohe = enc.fit_transform(X[[\"" + ps.feature + "\"]])   # " +
      ps.categories.length + " binary cols\n" +
      "# pandas equivalent: pd.get_dummies(X[\"" + ps.feature + "\"], prefix=\"" +
      ps.feature + "\")";
  }
}

function q(s) { return "\"" + s + "\""; }

// ----- Control wiring -----
function setEncoding(mode) {
  if (mode === encoding) { startAnim(); return; }
  encoding = mode;
  segLabel.classList.toggle("active", mode === "label");
  segOneHot.classList.toggle("active", mode === "onehot");
  startAnim();
}

function setPreset(key) {
  if (!PRESETS[key]) return;
  if (key === presetKey) { startAnim(); return; }
  presetKey = key;
  presetColor.classList.toggle("active", key === "color");
  presetSize.classList.toggle("active", key === "size");
  startAnim();
}

segLabel.addEventListener("click", () => setEncoding("label"));
segOneHot.addEventListener("click", () => setEncoding("onehot"));
presetColor.addEventListener("click", () => setPreset("color"));
presetSize.addEventListener("click", () => setPreset("size"));
showLineInput.addEventListener("change", () => {
  showLine = showLineInput.checked;
  render(1);
});
document.getElementById("replay").addEventListener("click", startAnim);
document.getElementById("reset").addEventListener("click", () => {
  presetKey = "color";
  encoding = "onehot";
  showLine = true;
  showLineInput.checked = true;
  segLabel.classList.remove("active");
  segOneHot.classList.add("active");
  presetColor.classList.add("active");
  presetSize.classList.remove("active");
  startAnim();
});

// ----- Init -----
startAnim();

"use strict";

/* ------------------------------------------------------------------ *
 * Pipeline Leakage Shield
 *
 * One k-fold cross-validation, animated twice over the SAME rows:
 *
 *   LEAKY lane  -- the scaler is fit ONCE on every row up front, so its
 *                  mean/std already encode the validation rows. Each fold
 *                  reuses those global stats => validation info leaks into
 *                  training => the reported CV score is inflated.
 *
 *   SHIELD lane -- a Pipeline re-fits the scaler INSIDE each fold on the
 *                  fold's TRAIN rows only. A glowing shield over the
 *                  validation block blocks the leak arrows => honest score.
 *
 * Everything is deterministic: a fixed seed builds the dataset and the
 * per-fold scores, so the animation and the numbers are identical on
 * every load. No randomness at runtime.
 * ------------------------------------------------------------------ */

// ----- Deterministic dataset of row "values" (one number per row) -----
function makeRows(n) {
  let s = 20240617; // fixed seed -> identical every load
  const rnd = () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff; // [0,1)
  };
  const rows = [];
  for (let i = 0; i < n; i++) rows.push(0.15 + rnd() * 0.85); // values in (0.15, 1)
  return rows;
}
const ROW_COUNT = 30;
const ROWS = makeRows(ROW_COUNT);

// global stats over ALL rows -- this is exactly what the leaky lane "sees"
function meanOf(arr) {
  let a = 0;
  for (const v of arr) a += v;
  return a / arr.length;
}
const GLOBAL_MEAN = meanOf(ROWS);

// ----- Fold assignment: contiguous validation blocks, k folds -----
function makeFolds(k) {
  const folds = [];
  for (let f = 0; f < k; f++) {
    const lo = Math.floor((f * ROW_COUNT) / k);
    const hi = Math.floor(((f + 1) * ROW_COUNT) / k);
    folds.push({ valLo: lo, valHi: hi }); // [valLo, valHi) are validation rows
  }
  return folds;
}

/* A fold's "score" is a clean, deterministic function of how well the
 * preprocessing matched the train rows. The honest (shielded) score uses
 * the TRAIN mean; the leaky score uses the GLOBAL mean, which always fits
 * the validation block a little too well -> a small positive inflation. */
function foldScores(folds) {
  const out = [];
  for (const fold of folds) {
    const train = [];
    const val = [];
    for (let i = 0; i < ROW_COUNT; i++) {
      if (i >= fold.valLo && i < fold.valHi) val.push(ROWS[i]);
      else train.push(ROWS[i]);
    }
    const trainMean = meanOf(train);
    const valMean = meanOf(val);

    // honest: scaler centred on train mean; score = how close val sits to it
    const honest = 0.80 + 0.18 * (1 - Math.abs(valMean - trainMean));
    // leaky: scaler centred on GLOBAL mean (already knows val) => closer fit
    const leaky = 0.80 + 0.18 * (1 - Math.abs(valMean - GLOBAL_MEAN)) + 0.05;

    out.push({
      honest: clamp(honest, 0, 1),
      leaky: clamp(leaky, 0, 1),
      trainMean,
      valMean,
    });
  }
  return out;
}

function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

// ----- DOM -----
const canvas = document.getElementById("lanes");
const ctx = canvas.getContext("2d");
const speedInput = document.getElementById("speed");
const speedVal = document.getElementById("speedVal");
const foldsInput = document.getElementById("folds");
const foldsVal = document.getElementById("foldsVal");
const runBtn = document.getElementById("run");
const resetBtn = document.getElementById("reset");
const shieldToggle = document.getElementById("shield");
const elFold = document.getElementById("rFold");
const elLeaky = document.getElementById("rLeaky");
const elSafe = document.getElementById("rSafe");
const elGap = document.getElementById("rGap");
const elVerdict = document.getElementById("rVerdict");

// ----- Layout constants -----
const W = canvas.width, H = canvas.height;
const HEAD_Y = 54;          // headings band
const LANE_TOP = 78;
const LANE_GAP = 26;
const LANE_W = (W - 40 - LANE_GAP) / 2; // two lanes, 20px outer margin each side
const LEFT_X = 20;
const RIGHT_X = LEFT_X + LANE_W + LANE_GAP;
const GRID_TOP = LANE_TOP + 86;     // where the row grid begins inside a lane
const CELL = 13;                    // row cell size
const COLS = 10;                    // rows laid out 10 x 3 = 30

// ----- Animation state -----
let K = parseInt(foldsInput.value, 10);
let speed = parseFloat(speedInput.value);
let shieldOn = shieldToggle.checked;
let folds = makeFolds(K);
let scores = foldScores(folds);

let raf = null;
let running = false;
let startTime = 0;
let leakyMeanSoFar = null;   // running CV mean shown in readout
let safeMeanSoFar = null;
let finished = false;

const FOLD_MS_BASE = 1100;   // ms per fold at 1x

// ----- Geometry helpers for the row grid in a lane -----
function rowCell(laneX, i) {
  const col = i % COLS;
  const row = Math.floor(i / COLS);
  const gridW = COLS * CELL + (COLS - 1) * 3;
  const x0 = laneX + (LANE_W - gridW) / 2;
  return {
    x: x0 + col * (CELL + 3),
    y: GRID_TOP + row * (CELL + 6),
  };
}

function isVal(fold, i) {
  return i >= fold.valLo && i < fold.valHi;
}

// ----- Rendering -----
function render(now) {
  ctx.clearRect(0, 0, W, H);
  drawHeadings();

  const foldMs = FOLD_MS_BASE / speed;
  let activeFold = -1;
  let foldT = 0; // 0..1 progress within the active fold

  if (running) {
    const elapsed = now - startTime;
    activeFold = Math.floor(elapsed / foldMs);
    if (activeFold >= K) {
      finishRun();
      activeFold = K - 1;
      foldT = 1;
    } else {
      foldT = (elapsed % foldMs) / foldMs;
    }
  } else if (finished) {
    activeFold = K - 1;
    foldT = 1;
  }

  // recompute running means up to (and including) the active fold
  if (activeFold >= 0) {
    let lk = 0, sf = 0, c = 0;
    for (let f = 0; f <= activeFold; f++) {
      lk += scores[f].leaky;
      sf += shieldOn ? scores[f].honest : scores[f].leaky;
      c++;
    }
    leakyMeanSoFar = lk / c;
    safeMeanSoFar = sf / c;
  }

  drawLane(LEFT_X, "leaky", activeFold, foldT);
  drawLane(RIGHT_X, "safe", activeFold, foldT);

  updateReadout(activeFold);

  if (running) raf = requestAnimationFrame(render);
}

function drawHeadings() {
  ctx.save();
  ctx.textAlign = "center";

  ctx.font = "600 15px Inter, sans-serif";
  ctx.fillStyle = "#f87171";
  ctx.fillText("Manual preprocessing, then CV", LEFT_X + LANE_W / 2, HEAD_Y - 26);
  ctx.fillStyle = shieldOn ? "#34d399" : "#f87171";
  ctx.fillText("Pipeline inside CV", RIGHT_X + LANE_W / 2, HEAD_Y - 26);

  ctx.font = "11px ui-monospace, Menlo, monospace";
  ctx.fillStyle = "#94a3b8";
  ctx.fillText("scaler.fit_transform(X) up front  (LEAKY)", LEFT_X + LANE_W / 2, HEAD_Y - 8);
  ctx.fillText(
    shieldOn ? "cross_val_score(Pipeline([...]), X, y)  (SAFE)" : "shield OFF — now leaking too",
    RIGHT_X + LANE_W / 2, HEAD_Y - 8
  );
  ctx.restore();
}

function drawLane(laneX, kind, activeFold, foldT) {
  const leaky = kind === "leaky";
  const shielded = !leaky && shieldOn;

  // lane frame
  ctx.save();
  ctx.strokeStyle = leaky ? "rgba(248,113,113,0.30)" : (shieldOn ? "rgba(52,211,153,0.30)" : "rgba(248,113,113,0.30)");
  ctx.lineWidth = 1.5;
  roundRect(laneX, LANE_TOP, LANE_W, H - LANE_TOP - 16, 12);
  ctx.stroke();
  ctx.restore();

  const fold = activeFold >= 0 ? folds[activeFold] : null;

  // ---- the scaler "statistics bar": where the scaler's mean was fit ----
  drawStatsBar(laneX, leaky, fold);

  // ---- the row grid ----
  for (let i = 0; i < ROW_COUNT; i++) {
    const c = rowCell(laneX, i);
    const validation = fold ? isVal(fold, i) : false;
    drawRowCell(c.x, c.y, validation, leaky, shielded, foldT, activeFold >= 0);
  }

  // ---- leak arrows / shield over the validation block ----
  if (fold) {
    if (leaky) drawLeakArrows(laneX, fold, foldT);
    else if (shielded) drawShield(laneX, fold, foldT);
    else drawLeakArrows(laneX, fold, foldT); // shield OFF: leaks too
  }

  // ---- per-fold score bars at the bottom of the lane ----
  drawScoreBars(laneX, kind, activeFold, foldT);
}

function drawStatsBar(laneX, leaky, fold) {
  const barY = LANE_TOP + 18;
  const barX = laneX + 16;
  const barW = LANE_W - 32;
  ctx.save();
  ctx.font = "10px ui-monospace, Menlo, monospace";

  if (leaky) {
    // single red bar fit ONCE on all rows
    ctx.fillStyle = "rgba(248,113,113,0.18)";
    roundRect(barX, barY, barW, 22, 6); ctx.fill();
    ctx.strokeStyle = "rgba(248,113,113,0.55)";
    ctx.lineWidth = 1; ctx.stroke();
    // marker at global mean
    const mx = barX + GLOBAL_MEAN * barW;
    ctx.strokeStyle = "#f87171"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(mx, barY - 3); ctx.lineTo(mx, barY + 25); ctx.stroke();
    ctx.fillStyle = "#f87171"; ctx.textAlign = "left";
    ctx.fillText("scaler fit on ALL rows", barX + 4, barY + 14);
  } else if (shieldOn) {
    // green bar re-fit on this fold's TRAIN mean
    ctx.fillStyle = "rgba(52,211,153,0.16)";
    roundRect(barX, barY, barW, 22, 6); ctx.fill();
    ctx.strokeStyle = "rgba(52,211,153,0.55)";
    ctx.lineWidth = 1; ctx.stroke();
    // marker re-fit on THIS fold's train mean (re-computed per fold)
    const trainMean = fold ? scores[folds.indexOf(fold)].trainMean : GLOBAL_MEAN;
    const mx = barX + trainMean * barW;
    ctx.strokeStyle = "#34d399"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(mx, barY - 3); ctx.lineTo(mx, barY + 25); ctx.stroke();
    ctx.fillStyle = "#34d399"; ctx.textAlign = "left";
    ctx.fillText("scaler re-fit on TRAIN rows", barX + 4, barY + 14);
  } else {
    ctx.fillStyle = "rgba(248,113,113,0.18)";
    roundRect(barX, barY, barW, 22, 6); ctx.fill();
    ctx.strokeStyle = "rgba(248,113,113,0.55)";
    ctx.lineWidth = 1; ctx.stroke();
    const mx = barX + GLOBAL_MEAN * barW;
    ctx.strokeStyle = "#f87171"; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.moveTo(mx, barY - 3); ctx.lineTo(mx, barY + 25); ctx.stroke();
    ctx.fillStyle = "#f87171"; ctx.textAlign = "left";
    ctx.fillText("shield OFF: global stats reused", barX + 4, barY + 14);
  }
  ctx.restore();
}

function drawRowCell(x, y, validation, leaky, shielded, foldT, foldActive) {
  ctx.save();
  let fill = "rgba(148,163,184,0.18)"; // idle train row
  let stroke = "rgba(148,163,184,0.30)";
  if (foldActive) {
    if (validation) {
      // validation rows: cyan everywhere (held out)
      fill = "rgba(34,211,238,0.30)";
      stroke = "#22d3ee";
    } else {
      // train rows: violet (used to fit/score)
      fill = "rgba(167,139,250,0.28)";
      stroke = "rgba(167,139,250,0.6)";
    }
  }
  ctx.fillStyle = fill;
  roundRect(x, y, CELL, CELL, 3); ctx.fill();
  ctx.lineWidth = validation ? 1.6 : 1;
  ctx.strokeStyle = stroke;
  ctx.stroke();

  // a pulse on validation rows: red glow if leaking, green if shielded
  if (foldActive && validation) {
    const pulse = 0.35 + 0.35 * Math.sin(foldT * Math.PI * 2);
    if (leaky || (!leaky && !shielded)) {
      ctx.shadowColor = "rgba(248,113,113," + pulse.toFixed(3) + ")";
      ctx.shadowBlur = 8;
      ctx.strokeStyle = "rgba(248,113,113,0.9)";
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawLeakArrows(laneX, fold, foldT) {
  // arrows from each validation row up into the red stats bar -> info leaks in
  const barY = LANE_TOP + 18 + 11; // centre of stats bar
  const reach = clamp(foldT * 1.6, 0, 1);
  ctx.save();
  ctx.strokeStyle = "rgba(248,113,113,0.75)";
  ctx.fillStyle = "rgba(248,113,113,0.75)";
  ctx.lineWidth = 1.4;
  for (let i = fold.valLo; i < fold.valHi; i++) {
    const c = rowCell(laneX, i);
    const sx = c.x + CELL / 2;
    const sy = c.y;
    const ey = barY;
    const cy = sy + (ey - sy) * reach;
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx, cy);
    ctx.stroke();
    if (reach >= 0.98) {
      // arrowhead into the bar
      ctx.beginPath();
      ctx.moveTo(sx, ey + 3);
      ctx.lineTo(sx - 3, ey + 8);
      ctx.lineTo(sx + 3, ey + 8);
      ctx.closePath();
      ctx.fill();
    }
  }
  ctx.restore();
}

function drawShield(laneX, fold, foldT) {
  // a glowing arc/box over the validation block; arrows hit it and stop
  const first = rowCell(laneX, fold.valLo);
  const last = rowCell(laneX, fold.valHi - 1);
  const x0 = Math.min(first.x, last.x) - 4;
  const y0 = Math.min(first.y, last.y) - 4;
  const x1 = Math.max(first.x, last.x) + CELL + 4;
  const y1 = Math.max(first.y, last.y) + CELL + 4;
  const glow = 0.45 + 0.35 * Math.sin(foldT * Math.PI * 2);

  ctx.save();
  ctx.shadowColor = "rgba(52,211,153," + glow.toFixed(3) + ")";
  ctx.shadowBlur = 16;
  ctx.strokeStyle = "rgba(52,211,153,0.9)";
  ctx.lineWidth = 2;
  roundRect(x0, y0, x1 - x0, y1 - y0, 6);
  ctx.stroke();
  ctx.restore();

  // blocked arrows: short red stubs that die at the shield edge
  const reach = clamp(foldT * 1.6, 0, 1);
  ctx.save();
  ctx.strokeStyle = "rgba(248,113,113,0.55)";
  ctx.lineWidth = 1.2;
  for (let i = fold.valLo; i < fold.valHi; i++) {
    const c = rowCell(laneX, i);
    const sx = c.x + CELL / 2;
    const sy = c.y;
    const stop = y0 + 2;
    const cy = sy - (sy - stop) * reach;
    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx, Math.max(cy, stop));
    ctx.stroke();
  }
  // "BLOCKED" tag
  ctx.fillStyle = "rgba(52,211,153,0.95)";
  ctx.font = "600 10px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("⛨ leak blocked", (x0 + x1) / 2, y0 - 6);
  ctx.restore();
}

function drawScoreBars(laneX, kind, activeFold, foldT) {
  const baseY = H - 30;
  const barAreaX = laneX + 16;
  const barAreaW = LANE_W - 32;
  const slot = barAreaW / K;
  const maxH = 56;

  ctx.save();
  ctx.font = "9px ui-monospace, Menlo, monospace";
  for (let f = 0; f < K; f++) {
    const reveal = f < activeFold ? 1 : (f === activeFold ? foldT : 0);
    const sc = kind === "leaky" ? scores[f].leaky : (shieldOn ? scores[f].honest : scores[f].leaky);
    const h = sc * maxH * reveal;
    const bx = barAreaX + f * slot + slot * 0.18;
    const bw = slot * 0.64;
    const color = (kind === "leaky" || !shieldOn) ? "rgba(248,113,113,0.7)" : "rgba(52,211,153,0.7)";
    ctx.fillStyle = "rgba(255,255,255,0.05)";
    ctx.fillRect(bx, baseY - maxH, bw, maxH);
    ctx.fillStyle = color;
    ctx.fillRect(bx, baseY - h, bw, h);
    ctx.fillStyle = "#94a3b8";
    ctx.textAlign = "center";
    ctx.fillText("f" + (f + 1), bx + bw / 2, baseY + 12);
    if (reveal >= 0.99) {
      ctx.fillStyle = "#e2e8f0";
      ctx.fillText(sc.toFixed(2), bx + bw / 2, baseY - h - 4);
    }
  }
  ctx.restore();
}

// rounded-rect path helper (works in any 2D context)
function roundRect(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

// ----- Readout -----
function updateReadout(activeFold) {
  if (activeFold < 0) {
    elFold.textContent = "—";
    elLeaky.textContent = "—";
    elSafe.textContent = "—";
    elGap.textContent = "—";
    elVerdict.textContent = "press Run";
    elVerdict.className = "v";
    return;
  }
  elFold.textContent = (activeFold + 1) + " / " + K;
  elLeaky.textContent = leakyMeanSoFar.toFixed(3);
  elSafe.textContent = safeMeanSoFar.toFixed(3);

  const gap = leakyMeanSoFar - safeMeanSoFar;
  elGap.textContent = (gap >= 0 ? "+" : "") + gap.toFixed(3);

  elLeaky.className = "v bad";
  elSafe.className = shieldOn ? "v good" : "v bad";
  elGap.className = gap > 0.001 ? "v bad" : "v";

  if (!shieldOn) {
    elVerdict.textContent = "neither (both leak)";
    elVerdict.className = "v bad";
  } else {
    elVerdict.textContent = "Pipeline ✓";
    elVerdict.className = "v good";
  }
}

// ----- Run control -----
function startRun() {
  cancelRaf();
  finished = false;
  running = true;
  startTime = performance.now();
  runBtn.disabled = true;
  raf = requestAnimationFrame(render);
}

function finishRun() {
  running = false;
  finished = true;
  runBtn.disabled = false;
}

function cancelRaf() {
  if (raf) { cancelAnimationFrame(raf); raf = null; }
}

function rebuild() {
  K = parseInt(foldsInput.value, 10);
  folds = makeFolds(K);
  scores = foldScores(folds);
}

function resetAll() {
  cancelRaf();
  running = false;
  finished = false;
  runBtn.disabled = false;
  leakyMeanSoFar = null;
  safeMeanSoFar = null;
  rebuild();
  render(performance.now());
}

// ----- Wire controls -----
speedInput.addEventListener("input", () => {
  speed = parseFloat(speedInput.value);
  speedVal.textContent = speed.toFixed(1) + "×";
  if (!running) render(performance.now());
});

foldsInput.addEventListener("input", () => {
  foldsVal.textContent = foldsInput.value;
  resetAll();
});

shieldToggle.addEventListener("change", () => {
  shieldOn = shieldToggle.checked;
  if (!running) render(performance.now());
});

runBtn.addEventListener("click", startRun);
resetBtn.addEventListener("click", resetAll);

// ----- Init -----
speedVal.textContent = speed.toFixed(1) + "×";
foldsVal.textContent = foldsInput.value;
render(performance.now());

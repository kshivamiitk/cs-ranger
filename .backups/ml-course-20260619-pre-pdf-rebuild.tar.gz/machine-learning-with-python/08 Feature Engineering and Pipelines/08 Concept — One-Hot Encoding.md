# One-Hot Encoding

> Models do math, and math needs numbers — one-hot encoding turns unordered categories like "red, green, blue" into numbers *without* secretly telling the model that blue is bigger than red.

## What is this?

One-hot encoding is how you hand a categorical column to a model that only understands numbers. Instead of mapping each category to a single integer, you create one new column per category and put a `1` in the column that matches the row, `0` everywhere else. Exactly one column is "hot" (set to 1) per row — hence *one-hot*.

So a single `color` column with values `red`, `green`, `blue` becomes three columns: `color_red`, `color_green`, `color_blue`. A row that was `green` becomes `[0, 1, 0]`.

The contrast is with **label encoding**, which would map `red→0, green→1, blue→2`. That looks tidier, but it's a trap (more on that below). One-hot keeps the categories *separate and equal* — no category is numerically "more" than another.

## Why do we need it?

Almost every scikit-learn model multiplies your features by learned weights and adds them up. That only works on numbers. A column full of the strings `"red"`, `"green"`, `"blue"` can't be multiplied by anything, so you *must* convert it.

The naive fix — label encoding to `0, 1, 2` — introduces a lie. The model now sees that `blue (2)` is twice `green (1)` and that `green` sits exactly halfway between `red` and `blue`. For a feature like color, shipping carrier, or city, that ordering is pure fiction. A linear model will happily learn "as color goes up, price goes up," which is nonsense.

One-hot encoding avoids the fiction. Each category gets its own switch, and the model learns an independent effect for each one. No fake ranking, no fake distances.

## Where it's used in real ML

- **Tabular business data** — encoding `country`, `device_type`, `subscription_plan`, `payment_method` before a churn or fraud model.
- **Inside scikit-learn pipelines** — `OneHotEncoder` is the standard categorical step in a `ColumnTransformer`, sitting next to a scaler for the numeric columns.
- **Linear and distance-based models especially** — `LogisticRegression`, `LinearRegression`, `SVM`, and `kNN` all need it, because they take the numbers literally. (Tree models tolerate label encoding better, but one-hot is still the safe default.)
- **Feature stores and ML deployment** — the encoder is fit once on training data and reused at serving time so production sees the exact same columns in the exact same order.

## What breaks if you ignore it

- **You crash.** Feed raw strings to `model.fit()` and scikit-learn raises `ValueError: could not convert string to float`.
- **You inject a fake order.** If you "fix" the crash with label encoding, the model treats arbitrary categories as ranked numbers and quietly learns garbage relationships. The code runs; the model is just wrong.
- **You break at serving time.** Encode train and test separately and you'll get mismatched columns — a category present in one but not the other shifts every column over, and predictions silently corrupt.
- **You blow up your feature count.** One-hot a column with 10,000 unique user IDs and you've created 10,000 mostly-empty columns. Memory explodes and the model overfits the noise.

## Mental model

Think of a row of light switches, one per category. For any given row, exactly one switch is flipped on:

```text
            red  green  blue
"green"  →   0     1     0      ← only the matching switch is hot
"red"    →   1     0     0
"blue"   →   0     0     1
```

Compare that to label encoding, which crams everything onto a single dimmer dial:

```text
red   = 0  ────●────────────────  "off"
green = 1  ────────────●────────  "half"
blue  = 2  ────────────────────●  "full"   ← implies blue > green > red (a lie!)
```

The switches keep the categories independent. The dimmer dial forces them onto a line where order and distance suddenly "mean" something they shouldn't.

## Example 1 — Tiny toy example

Encode three colors by hand. Start with the raw column:

```text
row   color
 1    red
 2    green
 3    blue
 4    green
```

Make one column per distinct value (`red`, `green`, `blue`) and flip on the matching switch:

```text
row   color    color_red  color_green  color_blue
 1    red          1           0            0
 2    green        0           1            0
 3    blue         0           0            1
 4    green        0           1            0
```

That's the whole operation. Row 1's `red` becomes `[1, 0, 0]`, row 2's `green` becomes `[0, 1, 0]`. Notice each row's three values always sum to exactly 1 — that's the "one-hot" invariant and a handy sanity check.

## Example 2 — Practical ML example

You're predicting whether a customer churns. One feature is `region` with values `EU`, `APAC`, `LATAM`. You don't want the model to think `LATAM` is "greater than" `EU`, so you one-hot it.

Inside a pipeline, `OneHotEncoder` learns the categories from the *training* data only, then expands `region` into `region_EU`, `region_APAC`, `region_LATAM`. The classifier learns a separate weight for each region — maybe APAC customers churn more, EU less — with no artificial ordering between them.

Two production-grade settings matter here. Set `handle_unknown="ignore"` so that if a brand-new region like `MENA` shows up at serving time (it was never in training), the encoder outputs all-zeros instead of crashing. And `drop="first"` removes one redundant column per feature — useful for linear models, where keeping all columns creates perfectly correlated features (the *dummy variable trap*).

## Python code example

```python
import pandas as pd
from sklearn.preprocessing import OneHotEncoder

# Inline toy data: a single categorical feature.
train = pd.DataFrame({"color": ["red", "green", "blue", "green", "red"]})
test  = pd.DataFrame({"color": ["green", "purple"]})  # 'purple' was NEVER in train

# 1) The quick exploratory way: pandas get_dummies.
#    Great for a one-off look, but it does NOT remember categories,
#    so train/test can end up with different columns. Avoid for real ML.
print("get_dummies on train:")
print(pd.get_dummies(train, columns=["color"], dtype=int))

# 2) The production way: OneHotEncoder remembers the training categories
#    and reproduces the exact same columns at predict/serving time.
encoder = OneHotEncoder(
    handle_unknown="ignore",   # unseen category -> all zeros instead of a crash
    sparse_output=False,       # return a plain dense array we can read
)
encoder.fit(train[["color"]])              # learns categories from TRAIN only
cols = encoder.get_feature_names_out(["color"])

train_enc = encoder.transform(train[["color"]])
test_enc  = encoder.transform(test[["color"]])  # 'purple' handled gracefully

print("\nlearned columns:", list(cols))
print("\ntrain encoded:\n", pd.DataFrame(train_enc, columns=cols, dtype=int))
print("\ntest encoded ('purple' -> all zeros):\n",
      pd.DataFrame(test_enc, columns=cols, dtype=int))

# 3) drop='first' removes one redundant column per feature (dummy-variable trap).
encoder_drop = OneHotEncoder(drop="first", sparse_output=False)
encoder_drop.fit(train[["color"]])
print("\nwith drop='first', columns:",
      list(encoder_drop.get_feature_names_out(["color"])))
```

Expected output (approximate):

```text
get_dummies on train:
   color_blue  color_green  color_red
0           0            0          1
1           0            1          0
2           1            0          0
3           0            1          0
4           0            0          1

learned columns: ['color_blue', 'color_green', 'color_red']

train encoded:
    color_blue  color_green  color_red
0           0            0          1
1           0            1          0
2           1            0          0
3           0            1          0
4           0            0          1

test encoded ('purple' -> all zeros):
    color_blue  color_green  color_red
0           0            1          0
1           0            0          0

with drop='first', columns: ['color_green', 'color_red']
```

Notice the unseen `purple` row became all zeros instead of throwing an error, and `drop='first'` kept only two columns for three categories — the dropped one is implied by the other two both being 0.

## Common mistakes

- **Label-encoding unordered categories.** Mapping `red→0, green→1, blue→2` invents an order the model takes literally. Reserve integer codes for genuinely *ordinal* data (e.g. `small < medium < large`).
- **Using `pd.get_dummies` for the real model.** It doesn't remember categories, so train and test can produce different columns. Use `OneHotEncoder` (ideally inside a pipeline) so the column set is fixed and reproducible.
- **Forgetting `handle_unknown="ignore"`.** Without it, the first unseen category at serving time crashes your prediction service.
- **One-hot encoding high-cardinality columns.** Encoding `user_id` or `zip_code` with thousands of values creates thousands of sparse columns. Group rare categories, use target/frequency encoding, or embeddings instead.
- **Fitting the encoder on the full dataset before splitting.** That leaks test information. Fit on training data only — a pipeline does this for you automatically inside cross-validation.

## Before you continue

- [ ] I can explain why label-encoding an unordered category misleads a model.
- [ ] I can one-hot a 3-category column by hand and check each row sums to 1.
- [ ] I know why `OneHotEncoder` is safer than `get_dummies` for a real model.
- [ ] I can describe what `handle_unknown="ignore"` and `drop="first"` each do.
- [ ] I can name a situation where one-hot encoding is a bad idea (high cardinality).

"use strict";

/* ------------------------------------------------------------------ *
 * Scaling Distance Before kNN
 *
 * One idea: kNN classifies by EUCLIDEAN DISTANCE. With two features on
 * wildly different scales (income 0..120000 vs age 18..70), the raw
 * distance is dominated by income -- age barely moves the needle -- so
 * the "nearest" neighbors (and the majority-vote prediction) are decided
 * almost entirely by income. StandardScaler z-scores each feature so they
 * contribute fairly; the neighbor set CHANGES and the prediction can flip.
 *
 * Distance (raw):    d^2 = (di_inc)^2 + (di_age)^2
 * Distance (scaled): d^2 = (di_inc/std_inc - ...)^2 ...  via z-scores
 *   z = (value - mean) / std   (population std, ddof=0, like sklearn)
 * Feature share of distance = (that feature's squared delta) / d^2
 * ------------------------------------------------------------------ */

// ============================ Data =================================
// Two classes. We deliberately arrange them so that in RAW space the
// query's neighbors are picked by income, but the TRUE local structure
// (visible once scaled) groups by both income AND age.
const CLASS_A = "approved";   // class 0  (blue)
const CLASS_B = "declined";   // class 1  (amber)

const INCOME_LO = 0, INCOME_HI = 120000;   // x-axis feature domain (raw)
const AGE_LO = 18, AGE_HI = 70;            // y-axis feature domain (raw)

let seed = 20240611;
function makePoints(s0) {
  // tiny deterministic LCG so the scatter is reproducible per seed
  let s = s0 >>> 0;
  const rnd = () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff;                 // in [0,1)
  };
  const jit = (amt) => (rnd() - 0.5) * 2 * amt;

  const pts = [];
  // Cluster 1 (approved): younger, lower income
  for (let i = 0; i < 9; i++) {
    pts.push({
      income: clamp(28000 + jit(22000), INCOME_LO, INCOME_HI),
      age: clamp(30 + jit(9), AGE_LO, AGE_HI),
      cls: 0
    });
  }
  // Cluster 2 (declined): older, higher income
  for (let i = 0; i < 9; i++) {
    pts.push({
      income: clamp(82000 + jit(26000), INCOME_LO, INCOME_HI),
      age: clamp(56 + jit(9), AGE_LO, AGE_HI),
      cls: 1
    });
  }
  return pts;
}

let POINTS = makePoints(seed);

// Default query point: chosen so its raw-nearest (income-driven) class
// and its scaled-nearest (income+age) class tend to differ -> teaching.
const DEFAULT_QUERY = { income: 60000, age: 34 };
let query = { income: DEFAULT_QUERY.income, age: DEFAULT_QUERY.age };

// =========================== Stats / scaling =======================
function featureStats(pts) {
  const n = pts.length;
  let si = 0, sa = 0;
  for (const p of pts) { si += p.income; sa += p.age; }
  const mi = si / n, ma = sa / n;
  let vi = 0, va = 0;
  for (const p of pts) {
    vi += (p.income - mi) * (p.income - mi);
    va += (p.age - ma) * (p.age - ma);
  }
  // population std (ddof=0), matching sklearn StandardScaler
  const stdI = Math.sqrt(vi / n) || 1;
  const stdA = Math.sqrt(va / n) || 1;
  return { mi, ma, stdI, stdA };
}
let STATS = featureStats(POINTS);

function recomputeStats() { STATS = featureStats(POINTS); }

// z-score helpers
function zIncome(v) { return (v - STATS.mi) / STATS.stdI; }
function zAge(v) { return (v - STATS.ma) / STATS.stdA; }

// =========================== Distance / kNN ========================
// Returns squared per-feature deltas + total, for a given space.
// space = "raw"  -> euclidean in raw feature units
// space = "scaled" -> euclidean in z-score units
function squaredDelta(p, space) {
  let dInc, dAge;
  if (space === "scaled") {
    dInc = zIncome(query.income) - zIncome(p.income);
    dAge = zAge(query.age) - zAge(p.age);
  } else {
    dInc = query.income - p.income;
    dAge = query.age - p.age;
  }
  const sInc = dInc * dInc;
  const sAge = dAge * dAge;
  return { sInc, sAge, total: sInc + sAge };
}

function distance(p, space) {
  return Math.sqrt(squaredDelta(p, space).total);
}

// indices of the k nearest points in the given space (sorted by distance)
function nearestIdx(space, k) {
  const order = POINTS.map((p, idx) => ({ idx, d: distance(p, space) }));
  order.sort((a, b) => a.d - b.d || a.idx - b.idx);
  return order.slice(0, k).map(o => o.idx);
}

function vote(idxList) {
  let a = 0, b = 0;
  for (const i of idxList) { if (POINTS[i].cls === 0) a++; else b++; }
  // tie-break toward the closest neighbor's class (idxList is distance-sorted)
  if (a === b) return POINTS[idxList[0]].cls;
  return a > b ? 0 : 1;
}

// aggregate distance-share split across the k neighbors (sum of squared deltas)
function shareSplit(idxList, space) {
  let sInc = 0, sAge = 0;
  for (const i of idxList) {
    const sd = squaredDelta(POINTS[i], space);
    sInc += sd.sInc;
    sAge += sd.sAge;
  }
  const tot = sInc + sAge || 1;
  return { income: sInc / tot, age: sAge / tot };
}

// ============================== DOM ================================
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const kInput = document.getElementById("k");
const kVal = document.getElementById("kVal");
const scaledInput = document.getElementById("scaled");
const showRings = document.getElementById("showRings");
const spaceLabel = document.getElementById("spaceLabel");
const elSpace = document.getElementById("rSpace");
const elPred = document.getElementById("rPred");
const elIncome = document.getElementById("rIncome");
const elAge = document.getElementById("rAge");
const elChanged = document.getElementById("rChanged");
const nbList = document.getElementById("nbList");
const btnNew = document.getElementById("newData");
const btnReset = document.getElementById("reset");

// ============================ State ================================
let k = parseInt(kInput.value, 10);
let scaled = scaledInput.checked;
let dragging = false;

// flash bookkeeping: which point indices joined/left when scaling toggled
let flash = { joined: new Set(), left: new Set(), until: 0 };
let flashAnim = null;

// ===================== Coordinate transforms =======================
const PAD = { l: 64, r: 24, t: 26, b: 50 };
function plotW() { return canvas.width - PAD.l - PAD.r; }
function plotH() { return canvas.height - PAD.t - PAD.b; }
function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

// Visible world domain depends on the active space.
function domain() {
  if (scaled) {
    // pad z-domain to comfortably hold both points and query
    return { xLo: -2.6, xHi: 2.6, yLo: -2.6, yHi: 2.6 };
  }
  return { xLo: INCOME_LO, xHi: INCOME_HI, yLo: AGE_LO, yHi: AGE_HI };
}

// world coords of a data/query point in the active space
function worldX(income) { return scaled ? zIncome(income) : income; }
function worldY(age) { return scaled ? zAge(age) : age; }

function xToPx(wx) {
  const d = domain();
  return PAD.l + ((wx - d.xLo) / (d.xHi - d.xLo)) * plotW();
}
function yToPx(wy) {
  const d = domain();
  return PAD.t + (1 - (wy - d.yLo) / (d.yHi - d.yLo)) * plotH();
}

// invert: pixel -> world -> raw feature value (used while dragging)
function pxToIncome(px) {
  const d = domain();
  const wx = d.xLo + ((px - PAD.l) / plotW()) * (d.xHi - d.xLo);
  return scaled ? (wx * STATS.stdI + STATS.mi) : wx;   // un-z-score if scaled
}
function pxToAge(py) {
  const d = domain();
  const wy = d.yLo + (1 - (py - PAD.t) / plotH()) * (d.yHi - d.yLo);
  return scaled ? (wy * STATS.stdA + STATS.ma) : wy;
}

// =========================== Rendering =============================
function niceStep(range) {
  const raw = range / 7;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  let step;
  if (norm < 1.5) step = 1;
  else if (norm < 3) step = 2;
  else if (norm < 7) step = 5;
  else step = 10;
  return step * mag;
}

function fmtAxisX(v) {
  if (scaled) return v.toFixed(1);
  return v >= 1000 ? Math.round(v / 1000) + "k" : String(Math.round(v));
}
function fmtAxisY(v) { return scaled ? v.toFixed(1) : String(Math.round(v)); }

function drawGrid() {
  const d = domain();
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.fillStyle = "#94a3b8";
  ctx.lineWidth = 1;
  ctx.font = "12px ui-monospace, Menlo, monospace";

  const stepX = niceStep(d.xHi - d.xLo);
  const startX = Math.ceil(d.xLo / stepX) * stepX;
  for (let x = startX; x <= d.xHi + 1e-9; x += stepX) {
    const px = xToPx(x);
    ctx.beginPath();
    ctx.moveTo(px, PAD.t); ctx.lineTo(px, canvas.height - PAD.b); ctx.stroke();
    ctx.textAlign = "center";
    ctx.fillText(fmtAxisX(x), px, canvas.height - PAD.b + 18);
  }
  const stepY = niceStep(d.yHi - d.yLo);
  const startY = Math.ceil(d.yLo / stepY) * stepY;
  for (let y = startY; y <= d.yHi + 1e-9; y += stepY) {
    const py = yToPx(y);
    ctx.beginPath();
    ctx.moveTo(PAD.l, py); ctx.lineTo(canvas.width - PAD.r, py); ctx.stroke();
    ctx.textAlign = "right";
    ctx.fillText(fmtAxisY(y), PAD.l - 8, py + 4);
  }

  // zero lines in scaled space make the centering obvious
  if (scaled) {
    ctx.strokeStyle = "rgba(255,255,255,0.16)";
    ctx.setLineDash([4, 4]);
    ctx.beginPath(); ctx.moveTo(xToPx(0), PAD.t); ctx.lineTo(xToPx(0), canvas.height - PAD.b); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(PAD.l, yToPx(0)); ctx.lineTo(canvas.width - PAD.r, yToPx(0)); ctx.stroke();
    ctx.setLineDash([]);
  }

  // axis titles
  ctx.fillStyle = "#fbbf24";
  ctx.font = "13px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText(scaled ? "income (z-score)" : "annual income ($)",
    (PAD.l + canvas.width - PAD.r) / 2, canvas.height - 10);
  ctx.save();
  ctx.translate(18, (PAD.t + canvas.height - PAD.b) / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillStyle = "#38bdf8";
  ctx.fillText(scaled ? "age (z-score)" : "age (years)", 0, 0);
  ctx.restore();
  ctx.restore();
}

function classColor(cls) { return cls === 0 ? "#38bdf8" : "#fbbf24"; }

function drawNeighborLinks(idxList) {
  if (!showRings.checked) return;
  const qx = xToPx(worldX(query.income)), qy = yToPx(worldY(query.age));
  ctx.save();
  // faint ring at the furthest neighbor distance (the kNN "reach")
  if (idxList.length) {
    const far = POINTS[idxList[idxList.length - 1]];
    const rPx = Math.hypot(xToPx(worldX(far.income)) - qx, yToPx(worldY(far.age)) - qy);
    ctx.strokeStyle = "rgba(167,139,250,0.30)";
    ctx.setLineDash([5, 5]);
    ctx.lineWidth = 1.5;
    ctx.beginPath(); ctx.arc(qx, qy, rPx, 0, Math.PI * 2); ctx.stroke();
    ctx.setLineDash([]);
  }
  // links to each neighbor
  ctx.lineWidth = 2;
  for (const i of idxList) {
    const p = POINTS[i];
    ctx.strokeStyle = "rgba(167,139,250,0.55)";
    ctx.beginPath();
    ctx.moveTo(qx, qy);
    ctx.lineTo(xToPx(worldX(p.income)), yToPx(worldY(p.age)));
    ctx.stroke();
  }
  ctx.restore();
}

function drawPoints(idxList) {
  const nbSet = new Set(idxList);
  const now = performance.now();
  const flashActive = now < flash.until;
  const pulse = flashActive ? 0.5 + 0.5 * Math.sin((flash.until - now) / 70) : 0;

  ctx.save();
  for (let i = 0; i < POINTS.length; i++) {
    const p = POINTS[i];
    const px = xToPx(worldX(p.income)), py = yToPx(worldY(p.age));
    const isNb = nbSet.has(i);

    // join/leave flash ring
    if (flashActive && (flash.joined.has(i) || flash.left.has(i))) {
      const col = flash.joined.has(i) ? "52,211,153" : "248,113,113";
      ctx.strokeStyle = "rgba(" + col + "," + (0.35 + 0.55 * pulse) + ")";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(px, py, 12 + 5 * pulse, 0, Math.PI * 2);
      ctx.stroke();
    }

    ctx.beginPath();
    ctx.arc(px, py, isNb ? 7 : 5.5, 0, Math.PI * 2);
    ctx.fillStyle = classColor(p.cls);
    ctx.fill();
    ctx.lineWidth = isNb ? 2.5 : 1.5;
    ctx.strokeStyle = isNb ? "#ffffff" : "rgba(11,11,16,0.9)";
    ctx.stroke();
  }

  // query point on top
  const qx = xToPx(worldX(query.income)), qy = yToPx(worldY(query.age));
  ctx.beginPath();
  ctx.arc(qx, qy, 9, 0, Math.PI * 2);
  ctx.fillStyle = "#f472b6";
  ctx.fill();
  ctx.lineWidth = 3;
  ctx.strokeStyle = "#ffffff";
  ctx.stroke();
  // little crosshair
  ctx.strokeStyle = "rgba(255,255,255,0.85)";
  ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(qx - 14, qy); ctx.lineTo(qx + 14, qy); ctx.stroke();
  ctx.beginPath(); ctx.moveTo(qx, qy - 14); ctx.lineTo(qx, qy + 14); ctx.stroke();
  ctx.restore();
}

function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  const space = scaled ? "scaled" : "raw";
  const idxList = nearestIdx(space, k);
  drawGrid();
  drawNeighborLinks(idxList);
  drawPoints(idxList);
  updateReadout(idxList, space);
}

// keep animating while a flash is active so the pulse moves
function tick() {
  render();
  if (performance.now() < flash.until) {
    flashAnim = requestAnimationFrame(tick);
  } else {
    flashAnim = null;
    flash.joined.clear();
    flash.left.clear();
    render();
  }
}

// =========================== Readout ===============================
function clsName(cls) { return cls === 0 ? CLASS_A : CLASS_B; }
function pct(x) { return (x * 100).toFixed(0) + "%"; }

function updateReadout(idxList, space) {
  const pred = vote(idxList);
  const split = shareSplit(idxList, space);

  elSpace.textContent = scaled ? "scaled (z)" : "raw units";
  elSpace.className = scaled ? "v snapped" : "v";

  elPred.textContent = clsName(pred);
  elPred.className = "v " + (pred === 0 ? "classA" : "classB");

  elIncome.textContent = pct(split.income);
  elAge.textContent = pct(split.age);
  // flag when one feature is hogging the distance
  elIncome.className = "v" + (split.income > 0.85 ? " alert" : "");
  elAge.className = "v" + (split.age > 0.85 ? " alert" : "");

  // "did the neighbor set differ between raw and scaled?" (independent of toggle)
  const rawSet = new Set(nearestIdx("raw", k));
  const scSet = new Set(nearestIdx("scaled", k));
  let diff = 0;
  for (const i of scSet) if (!rawSet.has(i)) diff++;
  elChanged.textContent = diff === 0 ? "no" : (diff + " of " + k);
  elChanged.className = "v" + (diff > 0 ? " good" : "");

  renderNeighborList(idxList, space);
}

function renderNeighborList(idxList, space) {
  // which of THESE neighbors only appear in the active space (joined),
  // relative to the other space -> annotate them
  const otherSpace = space === "scaled" ? "raw" : "scaled";
  const otherSet = new Set(nearestIdx(otherSpace, k));

  nbList.innerHTML = "";
  idxList.forEach((i, rank) => {
    const p = POINTS[i];
    const d = distance(p, space);
    const li = document.createElement("li");

    const dot = document.createElement("span");
    dot.className = "nb-dot " + (p.cls === 0 ? "A" : "B");
    li.appendChild(dot);

    const rk = document.createElement("span");
    rk.className = "nb-rank";
    rk.textContent = "#" + (rank + 1);
    li.appendChild(rk);

    const dist = document.createElement("span");
    dist.className = "nb-dist";
    const dStr = space === "scaled" ? d.toFixed(2) : Math.round(d).toLocaleString();
    dist.textContent = "d = " + dStr + "  (" + clsName(p.cls) + ")";
    li.appendChild(dist);

    if (!otherSet.has(i)) {
      const tag = document.createElement("span");
      tag.className = "nb-tag joined";
      tag.textContent = "new here";
      li.appendChild(tag);
    }
    nbList.appendChild(li);
  });
}

// ===================== Scaling toggle + flash ======================
function applyScaleToggle() {
  const beforeSpace = scaled ? "scaled" : "raw";   // space we are LEAVING
  const before = new Set(nearestIdx(beforeSpace, k));
  scaled = scaledInput.checked;
  const afterSpace = scaled ? "scaled" : "raw";    // space we are ENTERING
  const after = new Set(nearestIdx(afterSpace, k));

  flash.joined = new Set();
  flash.left = new Set();
  for (const i of after) if (!before.has(i)) flash.joined.add(i);
  for (const i of before) if (!after.has(i)) flash.left.add(i);

  spaceLabel.textContent = "currently: " + (scaled ? "scaled" : "raw");

  if (flash.joined.size || flash.left.size) {
    flash.until = performance.now() + 1600;
    if (!flashAnim) flashAnim = requestAnimationFrame(tick);
  } else {
    render();
  }
}

// =========================== Controls ==============================
kInput.addEventListener("input", () => {
  k = parseInt(kInput.value, 10);
  kVal.textContent = String(k);
  render();
});

scaledInput.addEventListener("change", applyScaleToggle);
showRings.addEventListener("change", render);

btnReset.addEventListener("click", () => {
  query.income = DEFAULT_QUERY.income;
  query.age = DEFAULT_QUERY.age;
  render();
});

btnNew.addEventListener("click", () => {
  seed = (seed * 16807 + 1) & 0x7fffffff;   // reseed only on this control
  POINTS = makePoints(seed);
  recomputeStats();
  query.income = DEFAULT_QUERY.income;
  query.age = DEFAULT_QUERY.age;
  flash.until = 0;
  render();
});

// ===================== Drag the query point ========================
function localPx(evt) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: (evt.clientX - rect.left) * (canvas.width / rect.width),
    y: (evt.clientY - rect.top) * (canvas.height / rect.height)
  };
}

function moveQueryTo(px, py) {
  query.income = clamp(pxToIncome(px), INCOME_LO, INCOME_HI);
  query.age = clamp(pxToAge(py), AGE_LO, AGE_HI);
}

canvas.addEventListener("pointerdown", (e) => {
  dragging = true;
  canvas.classList.add("dragging");
  const { x, y } = localPx(e);
  moveQueryTo(x, y);
  render();
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener("pointermove", (e) => {
  if (!dragging) return;
  const { x, y } = localPx(e);
  moveQueryTo(x, y);
  render();
});
function endDrag() { dragging = false; canvas.classList.remove("dragging"); }
canvas.addEventListener("pointerup", endDrag);
canvas.addEventListener("pointercancel", endDrag);

// ============================== Init ===============================
kVal.textContent = String(k);
spaceLabel.textContent = "currently: " + (scaled ? "scaled" : "raw");
render();

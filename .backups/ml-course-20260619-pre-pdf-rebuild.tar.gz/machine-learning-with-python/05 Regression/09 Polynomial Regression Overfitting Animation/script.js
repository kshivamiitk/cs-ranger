"use strict";

/* ------------------------------------------------------------------ *
 * Polynomial Regression Overfitting Animation
 *
 * We fit  y = c0 + c1*x + c2*x^2 + ... + cd*x^d  by ordinary least
 * squares, solved IN JS:
 *   1. Build the Vandermonde design matrix  V (n x (d+1)).
 *   2. Form the normal equations  (V^T V + lambda*I) c = V^T y.
 *   3. Solve the (d+1)x(d+1) system with Gaussian elimination
 *      (partial pivoting). A tiny ridge lambda keeps the high-degree
 *      systems non-singular and numerically stable.
 *
 * x is rescaled to [-1, 1] before powering so x^12 doesn't explode.
 * ------------------------------------------------------------------ */

// ---------- Data: ~18 noisy points from a smooth TRUE curve ----------
// True signal: a sine bump. Points are noisy; we hold some out as test.
function trueCurve(x) { return Math.sin(1.6 * x) * 1.4 + 0.25 * x; }

function makeData() {
  let s = 20240611;                       // deterministic seed
  const rnd = () => { s = (s * 1103515245 + 12345) & 0x7fffffff; return s / 0x7fffffff; };
  const gauss = () => {                    // Box-Muller for nicer noise
    const u = Math.max(rnd(), 1e-9), v = rnd();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  };
  const NOISE = 0.45;
  const all = [];
  for (let i = 0; i < 18; i++) {
    const x = -3 + (i / 17) * 6;           // x in [-3, 3]
    const y = trueCurve(x) + gauss() * NOISE;
    all.push({ x, y });
  }
  // Split: every 3rd point is held out for testing (6 test / 12 train)
  const train = [], test = [];
  all.forEach((p, i) => (i % 3 === 1 ? test : train).push(p));
  return { all, train, test };
}
const DATA = makeData();
const X_LO = -3.4, X_HI = 3.4;
// rescale x into [-1,1] for stable powers
const xMid = (X_LO + X_HI) / 2, xHalf = (X_HI - X_LO) / 2;
const rescale = (x) => (x - xMid) / xHalf;

// ---------- Linear algebra: Gaussian elimination with partial pivoting ----------
function solveLinear(A, b) {
  const n = b.length;
  // augment
  const M = A.map((row, i) => row.slice().concat(b[i]));
  for (let col = 0; col < n; col++) {
    // partial pivot: find largest magnitude in this column
    let piv = col;
    for (let r = col + 1; r < n; r++) {
      if (Math.abs(M[r][col]) > Math.abs(M[piv][col])) piv = r;
    }
    if (Math.abs(M[piv][col]) < 1e-12) continue; // (ridge should prevent this)
    [M[col], M[piv]] = [M[piv], M[col]];
    // eliminate below
    for (let r = col + 1; r < n; r++) {
      const f = M[r][col] / M[col][col];
      if (f === 0) continue;
      for (let c = col; c <= n; c++) M[r][c] -= f * M[col][c];
    }
  }
  // back-substitution
  const x = new Array(n).fill(0);
  for (let r = n - 1; r >= 0; r--) {
    let sum = M[r][n];
    for (let c = r + 1; c < n; c++) sum -= M[r][c] * x[c];
    x[r] = Math.abs(M[r][r]) < 1e-12 ? 0 : sum / M[r][r];
  }
  return x;
}

// Fit polynomial of given degree to {x,y} points -> coefficient array (length d+1).
function fitPoly(points, degree) {
  const n = points.length;
  const k = degree + 1;
  // Vandermonde on rescaled x
  const V = points.map(p => {
    const xr = rescale(p.x);
    const row = new Array(k);
    let pw = 1;
    for (let j = 0; j < k; j++) { row[j] = pw; pw *= xr; }
    return row;
  });
  // Normal equations: A = V^T V + lambda I, rhs = V^T y
  const A = Array.from({ length: k }, () => new Array(k).fill(0));
  const rhs = new Array(k).fill(0);
  for (let i = 0; i < n; i++) {
    for (let a = 0; a < k; a++) {
      rhs[a] += V[i][a] * points[i].y;
      for (let bb = 0; bb < k; bb++) A[a][bb] += V[i][a] * V[i][bb];
    }
  }
  const lambda = 1e-6;                     // tiny ridge for stability
  for (let a = 0; a < k; a++) A[a][a] += lambda;
  return solveLinear(A, rhs);
}

// Evaluate fitted poly (coeffs over RESCALED x) at a raw x.
function evalPoly(coeffs, x) {
  const xr = rescale(x);
  let y = 0, pw = 1;
  for (let j = 0; j < coeffs.length; j++) { y += coeffs[j] * pw; pw *= xr; }
  return y;
}

function mseOn(points, coeffs) {
  let acc = 0;
  for (const p of points) { const r = p.y - evalPoly(coeffs, p.x); acc += r * r; }
  return acc / points.length;
}

// Precompute best test-degree once (for "Reset to best")
function bestDegree() {
  let best = 1, bestErr = Infinity;
  for (let d = 1; d <= 12; d++) {
    const c = fitPoly(DATA.train, d);
    const e = mseOn(DATA.test, c);
    if (e < bestErr) { bestErr = e; best = d; }
  }
  return best;
}
const BEST_DEG = bestDegree();

// ---------- Plot bounds ----------
const ys = DATA.all.map(p => p.y);
const Y_LO = Math.min(...ys) - 1.2;
const Y_HI = Math.max(...ys) + 1.2;
const PAD = { l: 50, r: 22, t: 24, b: 42 };

// ---------- DOM ----------
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const degInput = document.getElementById("degree");
const degVal = document.getElementById("degreeVal");
const showTrue = document.getElementById("showTrue");
const elDeg = document.getElementById("rDeg");
const elTrain = document.getElementById("rTrain");
const elTest = document.getElementById("rTest");
const elVerdict = document.getElementById("rVerdict");
const barTrain = document.getElementById("barTrain");
const barTest = document.getElementById("barTest");

let degree = parseInt(degInput.value, 10);
let coeffs = fitPoly(DATA.train, degree);
let sweepAnim = null;

// A fixed scale for the bars so they're comparable as degree changes.
// Use the worst test error across all degrees as the 100% mark.
let BAR_MAX = 0.001;
for (let d = 1; d <= 12; d++) {
  const c = fitPoly(DATA.train, d);
  BAR_MAX = Math.max(BAR_MAX, mseOn(DATA.test, c), mseOn(DATA.train, c));
}

// ---------- transforms ----------
function plotW() { return canvas.width - PAD.l - PAD.r; }
function plotH() { return canvas.height - PAD.t - PAD.b; }
function xToPx(x) { return PAD.l + ((x - X_LO) / (X_HI - X_LO)) * plotW(); }
function yToPx(y) {
  const yc = Math.max(Y_LO, Math.min(Y_HI, y));
  return PAD.t + (1 - (yc - Y_LO) / (Y_HI - Y_LO)) * plotH();
}
function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

// ---------- render ----------
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGrid();
  if (showTrue.checked) drawTrue();
  drawFit();
  drawPoints();
  drawLegend();
  updateReadout();
}

function drawGrid() {
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.fillStyle = "#94a3b8";
  ctx.lineWidth = 1;
  ctx.font = "12px ui-monospace, Menlo, monospace";
  for (let x = Math.ceil(X_LO); x <= X_HI; x++) {
    const px = xToPx(x);
    ctx.beginPath(); ctx.moveTo(px, PAD.t); ctx.lineTo(px, canvas.height - PAD.b); ctx.stroke();
    ctx.textAlign = "center"; ctx.fillText(String(x), px, canvas.height - PAD.b + 16);
  }
  const yStep = niceStep(Y_HI - Y_LO);
  for (let y = Math.ceil(Y_LO / yStep) * yStep; y <= Y_HI; y += yStep) {
    const py = yToPx(y);
    ctx.beginPath(); ctx.moveTo(PAD.l, py); ctx.lineTo(canvas.width - PAD.r, py); ctx.stroke();
    ctx.textAlign = "right"; ctx.fillText(y.toFixed(1), PAD.l - 6, py + 4);
  }
  ctx.fillStyle = "#e2e8f0"; ctx.font = "13px Inter, sans-serif"; ctx.textAlign = "center";
  ctx.fillText("x", (PAD.l + canvas.width - PAD.r) / 2, canvas.height - 6);
  ctx.restore();
}

function niceStep(range) {
  const raw = range / 6;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  let step = norm < 1.5 ? 1 : norm < 3 ? 2 : norm < 7 ? 5 : 10;
  return step * mag;
}

function drawTrue() {
  ctx.save();
  ctx.strokeStyle = "rgba(148,163,184,0.5)";
  ctx.lineWidth = 2;
  ctx.setLineDash([6, 6]);
  ctx.beginPath();
  let first = true;
  for (let px = PAD.l; px <= canvas.width - PAD.r; px += 2) {
    const x = X_LO + ((px - PAD.l) / plotW()) * (X_HI - X_LO);
    const py = yToPx(trueCurve(x));
    if (first) { ctx.moveTo(px, py); first = false; } else ctx.lineTo(px, py);
  }
  ctx.stroke();
  ctx.restore();
}

function drawFit() {
  ctx.save();
  const verdict = classify();
  const col = verdict === "overfit" ? "#f87171" : verdict === "underfit" ? "#fbbf24" : "#a78bfa";
  ctx.strokeStyle = col;
  ctx.lineWidth = 3;
  ctx.beginPath();
  let first = true, prevY = null;
  for (let px = PAD.l; px <= canvas.width - PAD.r; px += 1) {
    const x = X_LO + ((px - PAD.l) / plotW()) * (X_HI - X_LO);
    const yv = evalPoly(coeffs, x);
    const py = yToPx(yv);
    // avoid drawing a vertical streak when the curve flies off-screen
    if (first) { ctx.moveTo(px, py); first = false; }
    else if (prevY !== null && Math.abs(py - prevY) > plotH()) { ctx.moveTo(px, py); }
    else ctx.lineTo(px, py);
    prevY = py;
  }
  ctx.stroke();
  ctx.restore();
}

function drawPoints() {
  ctx.save();
  // train points (violet), test points (cyan ring)
  for (const p of DATA.train) {
    ctx.fillStyle = "#a78bfa";
    ctx.beginPath(); ctx.arc(xToPx(p.x), yToPx(p.y), 5, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "rgba(11,11,16,0.9)"; ctx.lineWidth = 1.5; ctx.stroke();
  }
  for (const p of DATA.test) {
    ctx.beginPath(); ctx.arc(xToPx(p.x), yToPx(p.y), 6, 0, Math.PI * 2);
    ctx.strokeStyle = "#22d3ee"; ctx.lineWidth = 2.5; ctx.stroke();
    ctx.fillStyle = "rgba(34,211,238,0.18)"; ctx.fill();
  }
  ctx.restore();
}

function drawLegend() {
  ctx.save();
  ctx.font = "12px Inter, sans-serif";
  const x = PAD.l + 8, y = PAD.t + 6;
  const items = [
    ["#a78bfa", "train point", true],
    ["#22d3ee", "test point", false],
  ];
  let yy = y + 6;
  for (const [c, label, filled] of items) {
    ctx.beginPath(); ctx.arc(x, yy, 5, 0, Math.PI * 2);
    if (filled) { ctx.fillStyle = c; ctx.fill(); }
    else { ctx.strokeStyle = c; ctx.lineWidth = 2.5; ctx.stroke(); }
    ctx.fillStyle = "#94a3b8"; ctx.textAlign = "left"; ctx.fillText(label, x + 12, yy + 4);
    yy += 20;
  }
  ctx.restore();
}

// underfit (low degree) / good / overfit (high degree)
function classify() {
  if (degree <= 2) return "underfit";
  if (degree >= 8) return "overfit";
  // data-driven middle: overfit if test error is notably worse than the best degree's
  const trainE = mseOn(DATA.train, coeffs);
  const testE = mseOn(DATA.test, coeffs);
  if (testE > trainE * 3 && degree >= 6) return "overfit";
  return "good";
}

function updateReadout() {
  const trainE = mseOn(DATA.train, coeffs);
  const testE = mseOn(DATA.test, coeffs);
  elDeg.textContent = String(degree);
  elTrain.textContent = trainE.toFixed(3);
  elTest.textContent = testE.toFixed(3);

  const v = classify();
  elVerdict.textContent = v === "underfit" ? "underfit (too simple)"
    : v === "overfit" ? "overfit (memorizing noise)" : "good fit";
  elVerdict.className = "v " + v;

  barTrain.style.width = clamp((trainE / BAR_MAX) * 100, 0, 100) + "%";
  barTest.style.width = clamp((testE / BAR_MAX) * 100, 0, 100) + "%";
}

function setDegree(d) {
  degree = clamp(Math.round(d), 1, 12);
  degInput.value = degree;
  degVal.textContent = String(degree);
  coeffs = fitPoly(DATA.train, degree);
  render();
}

// ---------- auto-sweep animation ----------
function autoSweep() {
  if (sweepAnim) { clearInterval(sweepAnim); sweepAnim = null; }
  let d = 1;
  setDegree(d);
  const btn = document.getElementById("auto");
  btn.textContent = "Sweeping…";
  sweepAnim = setInterval(() => {
    d += 1;
    if (d > 12) { clearInterval(sweepAnim); sweepAnim = null; btn.textContent = "Auto-sweep 1 → 12"; return; }
    setDegree(d);
  }, 550);
}

// ---------- controls ----------
degInput.addEventListener("input", () => {
  if (sweepAnim) { clearInterval(sweepAnim); sweepAnim = null; document.getElementById("auto").textContent = "Auto-sweep 1 → 12"; }
  setDegree(parseInt(degInput.value, 10));
});
showTrue.addEventListener("change", render);
document.getElementById("auto").addEventListener("click", autoSweep);
document.getElementById("reset").addEventListener("click", () => {
  if (sweepAnim) { clearInterval(sweepAnim); sweepAnim = null; document.getElementById("auto").textContent = "Auto-sweep 1 → 12"; }
  setDegree(BEST_DEG);
});

// ---------- init ----------
degVal.textContent = String(degree);
render();

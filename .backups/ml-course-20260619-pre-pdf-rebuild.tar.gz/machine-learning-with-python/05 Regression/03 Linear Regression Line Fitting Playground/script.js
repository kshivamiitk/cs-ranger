"use strict";

/* ------------------------------------------------------------------ *
 * Linear Regression Line Fitting Playground
 * Model:    y_hat = slope * x + intercept
 * Residual: r_i = y_i - y_hat_i      (vertical gap, can be +/-)
 * MSE:      (1/n) * sum(r_i^2)        (mean squared residual)
 * Best fit: closed-form ordinary least squares
 *   slope* = sum((x-xbar)(y-ybar)) / sum((x-xbar)^2)
 *   intercept* = ybar - slope* * xbar
 * ------------------------------------------------------------------ */

// ----- Generate ~25 points: positive trend + noise (fixed seed = reproducible) -----
function makePoints() {
  // tiny deterministic PRNG so the scatter is the same every load
  let s = 1337;
  const rnd = () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff;            // in [0,1)
  };
  const TRUE_SLOPE = 2.1, TRUE_INTERCEPT = 4.0, NOISE = 5.5;
  const pts = [];
  for (let i = 0; i < 25; i++) {
    const x = 1 + (i / 24) * 9;                       // x spread 1..10
    const noise = (rnd() - 0.5) * 2 * NOISE;          // +/- NOISE
    const y = TRUE_SLOPE * x + TRUE_INTERCEPT + noise;
    pts.push({ x, y });
  }
  return pts;
}
const POINTS = makePoints();
const N = POINTS.length;

// ----- Closed-form least squares (computed once; the math we're teaching) -----
function leastSquares(pts) {
  const n = pts.length;
  let sx = 0, sy = 0;
  for (const p of pts) { sx += p.x; sy += p.y; }
  const xbar = sx / n, ybar = sy / n;
  let num = 0, den = 0;
  for (const p of pts) {
    const dx = p.x - xbar;
    num += dx * (p.y - ybar);
    den += dx * dx;
  }
  const slope = den === 0 ? 0 : num / den;            // guard vertical case
  const intercept = ybar - slope * xbar;
  return { slope, intercept };
}
const BEST = leastSquares(POINTS);
const BEST_MSE = mse(BEST.slope, BEST.intercept);

function mse(slope, intercept) {
  let acc = 0;
  for (const p of POINTS) {
    const r = p.y - (slope * p.x + intercept);
    acc += r * r;
  }
  return acc / N;
}

// ----- Plot domain (world coords) derived from the data with margin -----
const xs = POINTS.map(p => p.x), ys = POINTS.map(p => p.y);
const X_LO = Math.floor(Math.min(...xs)) - 1;
const X_HI = Math.ceil(Math.max(...xs)) + 1;
const Y_LO = Math.floor(Math.min(...ys)) - 3;
const Y_HI = Math.ceil(Math.max(...ys)) + 3;
const PAD = { l: 56, r: 24, t: 26, b: 46 };

// ----- DOM -----
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const slopeInput = document.getElementById("slope");
const interInput = document.getElementById("intercept");
const slopeVal = document.getElementById("slopeVal");
const interVal = document.getElementById("interceptVal");
const showResid = document.getElementById("showResid");
const elSlope = document.getElementById("rSlope");
const elInter = document.getElementById("rIntercept");
const elMse = document.getElementById("rMse");
const elBest = document.getElementById("rBest");
const elStatus = document.getElementById("rStatus");

// ----- State -----
let slope = parseFloat(slopeInput.value);
let intercept = parseFloat(interInput.value);
let dragging = false;
let snapAnim = null;          // requestAnimationFrame id while snapping
let snapped = false;          // true once we're sitting on the best fit

// ----- Coordinate transforms -----
function plotW() { return canvas.width - PAD.l - PAD.r; }
function plotH() { return canvas.height - PAD.t - PAD.b; }
function xToPx(x) { return PAD.l + ((x - X_LO) / (X_HI - X_LO)) * plotW(); }
function yToPx(y) { return PAD.t + (1 - (y - Y_LO) / (Y_HI - Y_LO)) * plotH(); }
function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

// ----- Rendering -----
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGrid();
  if (showResid.checked) drawResiduals();
  drawLine();
  drawPoints();
  updateReadout();
}

function drawGrid() {
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.fillStyle = "#94a3b8";
  ctx.lineWidth = 1;
  ctx.font = "12px ui-monospace, Menlo, monospace";

  for (let x = X_LO; x <= X_HI; x += niceStep(X_HI - X_LO)) {
    const px = xToPx(x);
    ctx.beginPath();
    ctx.moveTo(px, PAD.t); ctx.lineTo(px, canvas.height - PAD.b); ctx.stroke();
    ctx.textAlign = "center";
    ctx.fillText(String(Math.round(x)), px, canvas.height - PAD.b + 18);
  }
  for (let y = Y_LO; y <= Y_HI + 0.001; y += niceStep(Y_HI - Y_LO)) {
    const py = yToPx(y);
    ctx.beginPath();
    ctx.moveTo(PAD.l, py); ctx.lineTo(canvas.width - PAD.r, py); ctx.stroke();
    ctx.textAlign = "right";
    ctx.fillText(String(Math.round(y)), PAD.l - 8, py + 4);
  }

  ctx.fillStyle = "#e2e8f0";
  ctx.font = "13px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("x", (PAD.l + canvas.width - PAD.r) / 2, canvas.height - 8);
  ctx.save();
  ctx.translate(16, (PAD.t + canvas.height - PAD.b) / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText("y", 0, 0);
  ctx.restore();
  ctx.restore();
}

function niceStep(range) {
  const raw = range / 7;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  let step;
  if (norm < 1.5) step = 1;
  else if (norm < 3) step = 2;
  else if (norm < 7) step = 5;
  else step = 10;
  return step * mag;
}

function drawResiduals() {
  ctx.save();
  ctx.strokeStyle = "rgba(248,113,113,0.85)";
  ctx.lineWidth = 2;
  for (const p of POINTS) {
    const yhat = slope * p.x + intercept;
    const px = xToPx(p.x);
    ctx.beginPath();
    ctx.moveTo(px, yToPx(p.y));
    ctx.lineTo(px, yToPx(yhat));
    ctx.stroke();
  }
  ctx.restore();
}

function drawLine() {
  ctx.save();
  const grad = ctx.createLinearGradient(0, 0, canvas.width, 0);
  grad.addColorStop(0, "#a78bfa");
  grad.addColorStop(1, "#22d3ee");
  ctx.strokeStyle = grad;
  ctx.lineWidth = 3;
  // draw across the full visible x-range
  const x0 = X_LO, x1 = X_HI;
  ctx.beginPath();
  ctx.moveTo(xToPx(x0), yToPx(slope * x0 + intercept));
  ctx.lineTo(xToPx(x1), yToPx(slope * x1 + intercept));
  ctx.stroke();
  ctx.restore();
}

function drawPoints() {
  ctx.save();
  for (const p of POINTS) {
    const px = xToPx(p.x), py = yToPx(p.y);
    ctx.fillStyle = "#22d3ee";
    ctx.beginPath();
    ctx.arc(px, py, 5, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = "rgba(11,11,16,0.9)";
    ctx.lineWidth = 1.5;
    ctx.stroke();
  }
  ctx.restore();
}

function updateReadout() {
  const m = mse(slope, intercept);
  elSlope.textContent = slope.toFixed(3);
  elInter.textContent = intercept.toFixed(3);
  elMse.textContent = m.toFixed(2);
  elBest.textContent = BEST_MSE.toFixed(2);

  elMse.className = "v";
  // within ~1% of best -> celebrate
  if (m <= BEST_MSE * 1.01 + 1e-9) { elMse.classList.add("good"); }

  if (snapped && Math.abs(m - BEST_MSE) < 1e-6) {
    elStatus.textContent = "best fit ✓";
    elStatus.className = "v snapped";
  } else if (m <= BEST_MSE * 1.05) {
    elStatus.textContent = "very close to best!";
    elStatus.className = "v good";
  } else {
    elStatus.textContent = "drag the sliders";
    elStatus.className = "v";
  }
}

// ----- Snap-to-best-fit animation (eases sliders to the OLS solution) -----
function snapToBest() {
  if (snapAnim) cancelAnimationFrame(snapAnim);
  const s0 = slope, i0 = intercept;
  const dur = 700;
  const t0 = performance.now();
  function frame(t) {
    const k = clamp((t - t0) / dur, 0, 1);
    const e = 1 - Math.pow(1 - k, 3);    // ease-out cubic
    slope = s0 + (BEST.slope - s0) * e;
    intercept = i0 + (BEST.intercept - i0) * e;
    syncControls();
    render();
    if (k < 1) { snapAnim = requestAnimationFrame(frame); }
    else { slope = BEST.slope; intercept = BEST.intercept; snapped = true; syncControls(); render(); snapAnim = null; }
  }
  snapped = false;
  snapAnim = requestAnimationFrame(frame);
}

function syncControls() {
  // keep sliders in their clamped display range but show true values in readout
  slopeInput.value = clamp(slope, parseFloat(slopeInput.min), parseFloat(slopeInput.max));
  interInput.value = clamp(intercept, parseFloat(interInput.min), parseFloat(interInput.max));
  slopeVal.textContent = slope.toFixed(2);
  interVal.textContent = intercept.toFixed(2);
}

// ----- Controls -----
slopeInput.addEventListener("input", () => {
  if (snapAnim) { cancelAnimationFrame(snapAnim); snapAnim = null; }
  slope = parseFloat(slopeInput.value);
  slopeVal.textContent = slope.toFixed(2);
  snapped = false;
  render();
});
interInput.addEventListener("input", () => {
  if (snapAnim) { cancelAnimationFrame(snapAnim); snapAnim = null; }
  intercept = parseFloat(interInput.value);
  interVal.textContent = intercept.toFixed(2);
  snapped = false;
  render();
});
showResid.addEventListener("change", render);
document.getElementById("snap").addEventListener("click", snapToBest);
document.getElementById("reset").addEventListener("click", () => {
  if (snapAnim) { cancelAnimationFrame(snapAnim); snapAnim = null; }
  slope = 1; intercept = 5; snapped = false;
  syncControls(); render();
});

// ----- Drag the line vertically (sets intercept by the line at canvas center) -----
function pointerToY(evt) {
  const rect = canvas.getBoundingClientRect();
  const scaleY = canvas.height / rect.height;
  const py = (evt.clientY - rect.top) * scaleY;
  // invert yToPx
  return Y_LO + (1 - (py - PAD.t) / plotH()) * (Y_HI - Y_LO);
}
function pointerToX(evt) {
  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const px = (evt.clientX - rect.left) * scaleX;
  return X_LO + ((px - PAD.l) / plotW()) * (X_HI - X_LO);
}

canvas.addEventListener("pointerdown", (e) => {
  if (snapAnim) { cancelAnimationFrame(snapAnim); snapAnim = null; }
  dragging = true;
  snapped = false;
  canvas.classList.add("dragging");
  // shift intercept so the line passes through the cursor at this x
  const x = pointerToX(e), y = pointerToY(e);
  intercept = y - slope * x;
  syncControls(); render();
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener("pointermove", (e) => {
  if (!dragging) return;
  const x = pointerToX(e), y = pointerToY(e);
  intercept = y - slope * x;
  syncControls(); render();
});
function endDrag() { dragging = false; canvas.classList.remove("dragging"); }
canvas.addEventListener("pointerup", endDrag);
canvas.addEventListener("pointercancel", endDrag);

// ----- Init -----
slopeVal.textContent = slope.toFixed(2);
interVal.textContent = intercept.toFixed(2);
render();

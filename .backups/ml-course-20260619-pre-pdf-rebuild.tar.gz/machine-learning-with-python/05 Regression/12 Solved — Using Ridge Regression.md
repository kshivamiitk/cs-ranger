# Solved — Using Ridge Regression

> Plain least squares hands you a coefficient of +14 on one feature and −8 on its near-identical twin — a confident-looking fit that is mostly noise. Ridge calmly talks it down.

## Problem statement

You have a regression dataset with a handful of features that are **strongly correlated** (some are near-duplicates of one another) plus several columns that are **pure noise**. Plain `LinearRegression` fits it, but its coefficients come out huge and unstable — and it quietly overfits the noise, so it generalizes worse than it looks.

The task: **standardize the features, fit `Ridge` across a few `alpha` values, watch the coefficients shrink and the test error improve at the right alpha, then use `RidgeCV` to pick alpha automatically.** The non-negotiable habit baked in here is **scale first, regularize second** — Ridge penalizes the *size* of coefficients, and a coefficient's size is meaningless until every feature shares the same scale.

## Why this problem matters

Real tabular data is full of redundant, correlated columns — `height_cm` and `height_in`, `total_spend` and `avg_spend × n_orders`, a dozen engineered variants of the same idea. Ordinary least squares has no defense against this: when two features carry the same information, it can place a giant positive weight on one and a giant negative weight on the other, and the two nearly cancel. The fit looks fine on training data but the coefficients are nonsense, the model is fragile (drop one row and they swing wildly), and it has spent its flexibility memorizing noise. Ridge adds a penalty on coefficient size that **shrinks** these weights, spreads credit fairly across correlated features, and trades a sliver of bias for a large drop in variance — usually the single highest-leverage fix for "my linear model overfits."

## Tiny dataset or sample data

We generate the data so the *truth* is known and the lesson is unambiguous. There are 50 rows and 12 features:

| feature | role |
|---------|------|
| `x1` | real signal, coefficient 3 in the truth |
| `x2` | near-duplicate of `x1` (corr ≈ 0.999) |
| `x3` | near-duplicate of `x1` (corr ≈ 0.999) |
| `x4` | independent, genuinely useful, coefficient 2 |
| `noise1 … noise8` | pure noise, true coefficient 0 |

True relationship: `y = 3·x1 + 2·x4 + small Gaussian noise`. The eight noise columns and the `x2`/`x3` duplicates exist only to tempt the model into overfitting. Shape: `(50, 13)` (12 features + target).

## Step-by-step reasoning

1. **Hold out a test set first.** Split before touching the data, so we can measure honest generalization. With correlated features, the gap between train and test is exactly what we want to expose.
2. **Standardize — fit the scaler on train only.** Ridge's penalty is `alpha · Σ coef²`, which treats all coefficients on the same footing. If features are on different scales, that penalty is unfair (it punishes small-unit features more). `StandardScaler` puts everything at mean 0, std 1. Fitting it on the *full* data would leak test statistics, so fit on train, transform both.
3. **Fit plain `LinearRegression` and inspect the coefficients.** With `x1`, `x2`, `x3` nearly identical, least squares splits their shared credit arbitrarily — expect wild, large, even oppositely-signed weights and a bloated coefficient norm. That bloat *is* the overfitting.
4. **Sweep `alpha` for `Ridge`.** `alpha=0` is ordinary least squares; as `alpha` grows the `Σ coef²` penalty bites harder, so coefficients shrink toward zero (never exactly zero — that's Lasso). Track test RMSE: it should *fall* as alpha tames the variance, hit a sweet spot, then *rise* again once alpha over-shrinks and underfits (the classic U-shape).
5. **Let `RidgeCV` choose alpha.** Instead of eyeballing, `RidgeCV` runs cross-validation over a grid of alphas and keeps the best. Confirm its pick lands near the bottom of the U and gives correct, stable coefficients (`x4` should stay clearly positive; the noise columns near zero).

## Python solution

```python
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression, Ridge, RidgeCV
from sklearn.metrics import mean_squared_error

rng = np.random.RandomState(0)            # reproducible synthetic data

# --- 1. Build data where the TRUTH is known (no downloads) ---
n = 50
x1 = rng.normal(0, 1, n)
x2 = x1 + rng.normal(0, 0.03, n)          # near-duplicate of x1
x3 = x1 + rng.normal(0, 0.03, n)          # another near-duplicate of x1
x4 = rng.normal(0, 1, n)                  # independent, genuinely useful
noises = [rng.normal(0, 1, n) for _ in range(8)]   # 8 pure-noise columns

# Truth: y depends only on the x1-family and x4. The 8 noise columns are junk.
y = 3.0 * x1 + 2.0 * x4 + rng.normal(0, 1.0, n)

cols = ["x1", "x2", "x3", "x4"] + [f"noise{i}" for i in range(1, 9)]
X = np.column_stack([x1, x2, x3, x4] + noises)
print("Shape:", pd.DataFrame(X, columns=cols).shape, "+ target")
print("corr(x1, x2):", round(np.corrcoef(x1, x2)[0, 1], 3),
      "| corr(x1, x3):", round(np.corrcoef(x1, x3)[0, 1], 3))

X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.30, random_state=0)

# --- 2. Standardize: FIT ON TRAIN ONLY, then transform both (no leakage) ---
scaler = StandardScaler().fit(X_tr)
X_tr_s = scaler.transform(X_tr)
X_te_s = scaler.transform(X_te)

# --- 3. Plain least squares: unstable, bloated coefficients ---
lin = LinearRegression().fit(X_tr_s, y_tr)
lin_rmse = np.sqrt(mean_squared_error(y_te, lin.predict(X_te_s)))
print(f"\nPlain LinearRegression test RMSE = {lin_rmse:.3f}")
print(f"  coef L2 norm = {np.sqrt(np.sum(lin.coef_ ** 2)):.2f}  (bloated)")
print("  x1/x2/x3 coefs:", np.round(lin.coef_[:3], 2),
      " <- near-identical features, wildly different weights")

# --- 4. Sweep alpha: watch coefficients shrink and test error U-turn ---
print("\nalpha   test_RMSE   ||coef||    x1     x2     x3")
for alpha in [0.0, 1.0, 5.0, 10.0, 100.0]:
    m = LinearRegression() if alpha == 0.0 else Ridge(alpha=alpha)
    m.fit(X_tr_s, y_tr)
    rmse = np.sqrt(mean_squared_error(y_te, m.predict(X_te_s)))
    norm = np.sqrt(np.sum(m.coef_ ** 2))
    print(f"{alpha:6.1f}  {rmse:8.3f}   {norm:7.2f}   "
          f"{m.coef_[0]:+.2f}  {m.coef_[1]:+.2f}  {m.coef_[2]:+.2f}")

# --- 5. Let RidgeCV pick alpha by cross-validation ---
alphas = np.logspace(-2, 3, 60)           # 0.01 ... 1000
ridgecv = RidgeCV(alphas=alphas).fit(X_tr_s, y_tr)   # leave-one-out CV
cv_rmse = np.sqrt(mean_squared_error(y_te, ridgecv.predict(X_te_s)))
print(f"\nRidgeCV picked alpha = {ridgecv.alpha_:.2f}")
print(f"RidgeCV test RMSE    = {cv_rmse:.3f}")
print("RidgeCV x1/x2/x3/x4 coefs:", np.round(ridgecv.coef_[:4], 2),
      " <- x4 (truth=2) stays large; duplicates share credit")
```

## Expected output

Running it prints roughly:

```
Shape: (50, 12) + target
corr(x1, x2): 1.0 | corr(x1, x3): 1.0

Plain LinearRegression test RMSE = 1.180
  coef L2 norm = 17.02  (bloated)
  x1/x2/x3 coefs: [14.46 -2.57 -8.37]  <- near-identical features, wildly different weights

alpha   test_RMSE   ||coef||    x1     x2     x3
   0.0     1.180     17.02   +14.46  -2.57  -8.37
   1.0     0.975      2.81   +1.22  +1.21  +1.06
   5.0     0.936      2.53   +1.10  +1.10  +1.05
  10.0     1.089      2.27   +1.01  +1.02  +0.99
 100.0     2.753      0.98   +0.50  +0.50  +0.49

RidgeCV picked alpha = 1.31
RidgeCV test RMSE    = 0.962
RidgeCV x1/x2/x3/x4 coefs: [1.2  1.2  1.07 1.86]  <- x4 (truth=2) stays large; duplicates share credit
```

(The correlations print as `1.0` because they round up — the true values are ≈ 0.999.)

## Explanation of the output

**Plain least squares is a mess.** `x1`, `x2`, and `x3` carry the *same* information (correlation ≈ 0.999), yet OLS assigns them `+14.46`, `−2.57`, and `−8.37`. Those huge, oppositely-signed weights nearly cancel on the training data, so the fit looks fine — but it's nonsense: change one row and they'd swing wildly. The coefficient L2 norm is a bloated **17.02**, and the test RMSE is **1.180**. That bloat is overfitting made visible.

**Ridge shrinks and stabilizes.** Add even `alpha=1` and the penalty `alpha·Σcoef²` makes those giant weights expensive, so the three twins collapse to roughly equal, sensible values (~`+1.2` each) — credit is now *shared* fairly instead of fought over. The coefficient norm drops from 17.02 to **2.81**, and test RMSE falls to **0.975**. Push to `alpha=5` and test RMSE bottoms out at **0.936** (a ~20% improvement over plain LR). Keep going and the U-turn appears: by `alpha=100` the penalty over-shrinks everything toward zero, the model underfits, and test RMSE balloons to **2.753**. That U-shape — too little regularization overfits, too much underfits — is the whole game.

**RidgeCV automates the sweet spot.** Cross-validation picks `alpha = 1.31`, landing near the bottom of the U with test RMSE **0.962**. Its coefficients tell the true story: `x1/x2/x3` each get ~`+1.1` (their summed ~3.4 recovers the true `x1` coefficient of 3, split three ways) and `x4` stays clearly large at `+1.86` (truth = 2). Ridge correctly kept the genuine signal while refusing to let the redundant copies and noise columns run wild.

## Common mistakes

1. **Regularizing before scaling (or not scaling at all).** Ridge penalizes `Σ coef²`, so a feature measured in millimeters gets a tiny coefficient and a feature in kilometers a huge one — the penalty hits them unequally and the result is garbage. Fix: `StandardScaler` first, *always*, before Ridge/Lasso.
2. **Fitting the scaler on the full dataset before splitting.** That leaks test means and standard deviations into training and inflates your scores. Fix: `scaler.fit(X_train)`, then `transform` both — ideally inside a `Pipeline`.
3. **Reading raw OLS coefficients on correlated features as "feature importance."** The `+14 / −8` split is an artifact of collinearity, not a signal that `x1` matters and `x3` hurts. Fix: check correlations/VIF, and use Ridge to get stable, interpretable weights.
4. **Believing bigger alpha is always safer.** Past the sweet spot, Ridge underfits and test error climbs (see `alpha=100`). Fix: sweep a range and pick by cross-validation, not by gut feel.
5. **Expecting Ridge to zero out the noise columns.** Ridge shrinks coefficients toward zero but never exactly to zero — it can't do feature *selection*. Fix: if you need columns dropped entirely, use `Lasso` (L1) or `ElasticNet`.

## Extension challenge

1. Swap `RidgeCV` for `LassoCV` on the same data. Lasso should drive several `noise` coefficients to *exactly* zero — compare which features survive and how the test RMSE compares to Ridge.
2. Plot the full **coefficient path**: for `alpha` in `np.logspace(-2, 3, 50)`, store every coefficient and plot each one versus `log(alpha)`. You'll see the wild OLS weights fan in and converge as regularization tightens.
3. Wrap scaling and `Ridge` in a single `Pipeline` and tune `alpha` with `GridSearchCV`. Confirm you get the same sweet-spot alpha while making leakage structurally impossible.

## Matching animation

**Regularization Strength Slider** — drag the alpha slider from 0 toward large values and watch the coefficient bars shrink in real time while a train/test error curve traces the U-shape underneath. At alpha 0 the bars are tall and jagged (overfit); slide right and they pull together as test error dips to its minimum, then keep sliding and watch every bar flatten toward zero as the model underfits. It makes the bias–variance trade-off something you steer with your hand.

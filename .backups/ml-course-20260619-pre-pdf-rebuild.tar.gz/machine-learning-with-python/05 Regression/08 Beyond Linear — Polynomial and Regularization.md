# Beyond Linear — Polynomial and Regularization

> A straight line is sometimes too rigid and a wiggly curve is sometimes too eager — regularization is how you find the sweet spot between underfitting and overfitting.

## What you'll learn
- Use `PolynomialFeatures` to let a linear model fit curves.
- See **overfitting** happen: a model that nails the training data but flails on new data.
- Understand what **Ridge** and **Lasso** regularization do and why shrinking coefficients helps.
- Know when to reach for Ridge vs. Lasso.

## Intuition
Linear regression can only draw straight lines, but many relationships bend. The trick: invent new features from the old ones. If you add `x²`, `x³`, … as extra columns, a *linear* model on those columns traces a *curved* line in the original space. That's **polynomial regression** — same algorithm, richer features.

But power cuts both ways. Give the model a high enough degree and it has enough flexibility to thread through every single training point — including the noise. It looks perfect on training data and terrible on anything new. That's **overfitting**: the model memorized instead of generalizing. The telltale sign is a big gap between great training performance and poor test performance, and coefficients that have blown up to huge values to make the curve wiggle.

**Regularization** fights this by adding a penalty on coefficient size to the loss. Now the model can't make coefficients huge for free — it must justify every bit of wiggle by a real reduction in error. Two flavors:
- **Ridge (L2):** penalizes the *sum of squared* coefficients. It shrinks all coefficients smoothly toward zero but rarely sets any exactly to zero. Great default when you think most features matter a little.
- **Lasso (L1):** penalizes the *sum of absolute* coefficients. It can drive some coefficients **exactly to zero**, effectively performing feature selection. Great when you suspect only a few features truly matter and want a sparse, simpler model.

The strength knob is `alpha`: bigger `alpha` = stronger penalty = simpler, smoother model (more bias, less variance). `alpha=0` is just plain linear regression.

## Python in practice

```python
import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression, Ridge, Lasso
from sklearn.pipeline import make_pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

# Data from a gently curved truth (a sine wave) plus noise.
rng = np.random.default_rng(1)
X = np.sort(rng.uniform(0, 1, 40)).reshape(-1, 1)
y = np.sin(2 * np.pi * X).ravel() + rng.normal(0, 0.15, 40)

X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.35, random_state=0)
```

```python
# Watch overfitting appear as polynomial degree climbs.
for degree in [1, 4, 15]:
    model = make_pipeline(PolynomialFeatures(degree), LinearRegression())
    model.fit(X_tr, y_tr)
    rmse_tr = mean_squared_error(y_tr, model.predict(X_tr)) ** 0.5
    rmse_te = mean_squared_error(y_te, model.predict(X_te)) ** 0.5
    print(f"degree {degree:>2}:  train RMSE={rmse_tr:.3f}   test RMSE={rmse_te:.3f}")
# degree  1:  train high,  test high     -> UNDERFIT (too rigid)
# degree  4:  train low,   test low      -> good fit
# degree 15:  train ~0,    test BLOWS UP  -> OVERFIT (memorized noise)
```

```python
# Regularization tames a high-degree model so it stops overfitting.
deg = 15
for name, reg in [("Plain   ", LinearRegression()),
                  ("Ridge   ", Ridge(alpha=1e-3)),
                  ("Lasso   ", Lasso(alpha=1e-3, max_iter=10000))]:
    model = make_pipeline(PolynomialFeatures(deg), reg)
    model.fit(X_tr, y_tr)
    rmse_te = mean_squared_error(y_te, model.predict(X_te)) ** 0.5
    # the linear step is the last pipeline stage; read its coefficients
    coefs = model.steps[-1][1].coef_
    print(f"{name} test RMSE={rmse_te:.3f}   "
          f"max|coef|={np.abs(coefs).max():8.1f}   "
          f"zeros={np.sum(np.abs(coefs) < 1e-6)}")
# Plain:    huge max|coef| (wild wiggles), bad test RMSE
# Ridge:    coefs shrunk, test RMSE much better, no exact zeros
# Lasso:    several coefs exactly 0 (sparse), competitive test RMSE
```

```python
# Plot the fitted curves to SEE the difference.
xs = np.linspace(0, 1, 200).reshape(-1, 1)
plt.scatter(X_tr, y_tr, color="cyan", s=20, label="train")
for name, reg, color in [("plain deg15", LinearRegression(), "salmon"),
                         ("ridge deg15", Ridge(alpha=1e-3), "violet")]:
    m = make_pipeline(PolynomialFeatures(15), reg).fit(X_tr, y_tr)
    plt.plot(xs, m.predict(xs), label=name, color=color, lw=2)
plt.ylim(-2, 2); plt.legend(); plt.title("Regularization smooths the overfit wiggles")
plt.show()
```

## Common mistakes
- **Cranking the degree without checking test error.** Lower training error is *not* the goal — you can always get it to zero by overfitting. Watch the **test/validation** error; the best degree is where it bottoms out.
- **Forgetting to scale features before Ridge/Lasso.** The penalty acts on coefficient sizes, so features on bigger scales get unfairly penalized. Standardize (e.g. add `StandardScaler` to the pipeline), especially with polynomial features whose powers explode in scale.
- **Setting `alpha` blindly.** Too small = no real regularization; too large = the model underfits (coefficients crushed toward zero, a near-flat line). Tune `alpha` with cross-validation (`RidgeCV`, `LassoCV`).
- **Expecting Lasso and Ridge to give the same coefficients.** They won't — Lasso zeroes some out (sparse), Ridge keeps all but small. Pick based on whether you want feature selection.
- **Lasso not converging.** With many polynomial features, raise `max_iter` (and scale your features) or you'll get a convergence warning.

## Small exercise
1. Loop `degree` from 1 to 12 on the sine data, recording train and test RMSE, and plot both curves on one chart. Identify the degree where test RMSE is lowest — that's your sweet spot.
2. For a degree-15 Ridge model, sweep `alpha in [1e-4, 1e-2, 1, 100]` and report test RMSE and `max|coef|` for each. Describe how stronger regularization trades wiggle for smoothness.
3. Fit a degree-15 Lasso (`alpha=1e-3`) and print how many coefficients it drove exactly to zero. What does that imply about which polynomial terms it considered useful?

## Before you continue
- [ ] I can use `PolynomialFeatures` in a pipeline to fit a curved relationship.
- [ ] I can recognize overfitting from a train-vs-test error gap and exploding coefficients.
- [ ] I can explain, in one sentence each, what Ridge and Lasso penalize and when I'd pick each.

"use strict";

/* ------------------------------------------------------------------ *
 * MAE vs RMSE Outlier Explorer
 * The regression line is FIXED:  y_hat = TRUE_SLOPE * x + TRUE_INTERCEPT
 * Residual:  r_i = y_i - y_hat_i        (vertical gap, can be +/-)
 * MAE:       (1/n) * sum(|r_i|)         (mean ABSOLUTE error)
 * RMSE:      sqrt( (1/n) * sum(r_i^2) ) (root MEAN SQUARED error)
 *
 * Squaring inside RMSE makes one large residual dominate the average,
 * so dragging a single point far away blows RMSE up while MAE barely
 * moves. RMSE/MAE rises with outlier severity (it equals 1 only when
 * every residual has the same magnitude).
 * ------------------------------------------------------------------ */

// ----- Fixed line we measure errors against -----
const TRUE_SLOPE = 1.6;
const TRUE_INTERCEPT = 5.0;

function lineY(x) { return TRUE_SLOPE * x + TRUE_INTERCEPT; }

// ----- Deterministic seeded scatter (~12 points sitting near the line) -----
// Tiny LCG so the cloud is identical every load for a given seed.
function makeRng(seed) {
  let s = seed & 0x7fffffff;
  return () => {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff;            // in [0,1)
  };
}

const N = 12;
const SEED_BASE = 20260618;          // base seed -> reproducible
let seed = SEED_BASE;

// "New scatter" reshuffles by advancing the seed; still fully deterministic.
function buildPoints(noise) {
  const rnd = makeRng(seed);
  const pts = [];
  for (let i = 0; i < N; i++) {
    const x = 1 + (i / (N - 1)) * 9;                  // x spread 1..10
    const jitter = (rnd() - 0.5) * 2 * noise;         // +/- noise around line
    const y = lineY(x) + jitter;
    pts.push({ x, y, baseY: y });                     // baseY = clean position
  }
  return pts;
}

// The draggable outlier is always the middle point of the cloud.
const SPECIAL = Math.floor(N / 2);

let noise = 2.0;
let POINTS = buildPoints(noise);

// ----- Plot domain (world coords). Y range is fixed & generous so the line
//        and a fully-dragged outlier always stay on screen. -----
const X_LO = 0, X_HI = 11;
const Y_LO = -45, Y_HI = 65;
const PAD = { l: 56, r: 24, t: 26, b: 46 };

// ----- DOM -----
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const noiseInput = document.getElementById("noise");
const outlierInput = document.getElementById("outlier");
const noiseVal = document.getElementById("noiseVal");
const outlierVal = document.getElementById("outlierVal");
const showSq = document.getElementById("showSq");
const maeBar = document.getElementById("maeBar");
const rmseBar = document.getElementById("rmseBar");
const maeValEl = document.getElementById("maeVal");
const rmseValEl = document.getElementById("rmseVal");
const elMae = document.getElementById("rMae");
const elRmse = document.getElementById("rRmse");
const elRatio = document.getElementById("rRatio");
const elMax = document.getElementById("rMax");
const elStatus = document.getElementById("rStatus");

// ----- State -----
let dragging = false;

// Bars are scaled against a fixed reference so growth is visible & honest.
const BAR_MAX = 30;                   // error value that fills a bar to 100%

// ----- Coordinate transforms -----
function plotW() { return canvas.width - PAD.l - PAD.r; }
function plotH() { return canvas.height - PAD.t - PAD.b; }
function xToPx(x) { return PAD.l + ((x - X_LO) / (X_HI - X_LO)) * plotW(); }
function yToPx(y) { return PAD.t + (1 - (y - Y_LO) / (Y_HI - Y_LO)) * plotH(); }
function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }
// pixels-per-y-unit (for drawing the squared-error box to scale)
function pxPerY() { return plotH() / (Y_HI - Y_LO); }

// ----- The math we're teaching -----
function residuals() {
  return POINTS.map(p => p.y - lineY(p.x));
}
function metrics() {
  const r = residuals();
  let absSum = 0, sqSum = 0, maxAbs = 0;
  for (const ri of r) {
    const a = Math.abs(ri);
    absSum += a;
    sqSum += ri * ri;
    if (a > maxAbs) maxAbs = a;
  }
  const mae = absSum / N;
  const rmse = Math.sqrt(sqSum / N);
  return { mae, rmse, maxAbs };
}

// ----- Rendering -----
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGrid();
  if (showSq.checked) drawSquaredBox();
  drawResiduals();
  drawLine();
  drawPoints();
  updateReadout();
}

function drawGrid() {
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.fillStyle = "#94a3b8";
  ctx.lineWidth = 1;
  ctx.font = "12px ui-monospace, Menlo, monospace";

  for (let x = X_LO; x <= X_HI; x += niceStep(X_HI - X_LO)) {
    const px = xToPx(x);
    ctx.beginPath();
    ctx.moveTo(px, PAD.t); ctx.lineTo(px, canvas.height - PAD.b); ctx.stroke();
    ctx.textAlign = "center";
    ctx.fillText(String(Math.round(x)), px, canvas.height - PAD.b + 18);
  }
  for (let y = Y_LO; y <= Y_HI + 0.001; y += niceStep(Y_HI - Y_LO)) {
    const py = yToPx(y);
    ctx.beginPath();
    ctx.moveTo(PAD.l, py); ctx.lineTo(canvas.width - PAD.r, py); ctx.stroke();
    ctx.textAlign = "right";
    ctx.fillText(String(Math.round(y)), PAD.l - 8, py + 4);
  }

  ctx.fillStyle = "#e2e8f0";
  ctx.font = "13px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("x", (PAD.l + canvas.width - PAD.r) / 2, canvas.height - 8);
  ctx.save();
  ctx.translate(16, (PAD.t + canvas.height - PAD.b) / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText("y", 0, 0);
  ctx.restore();
  ctx.restore();
}

function niceStep(range) {
  const raw = range / 7;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  let step;
  if (norm < 1.5) step = 1;
  else if (norm < 3) step = 2;
  else if (norm < 7) step = 5;
  else step = 10;
  return step * mag;
}

// Draw the special point's squared error as a real square (area = r^2),
// anchored on the residual segment so the "squaring" is visible to scale.
function drawSquaredBox() {
  const p = POINTS[SPECIAL];
  const r = p.y - lineY(p.x);
  const sidePx = Math.abs(r) * pxPerY();        // side length in pixels == |r|
  if (sidePx < 1) return;
  const xCenter = xToPx(p.x);
  const yLineP = yToPx(lineY(p.x));
  const yPointP = yToPx(p.y);
  const topP = Math.min(yLineP, yPointP);
  // place the square to the right of the residual segment, top-aligned with it
  const left = xCenter + 6;
  ctx.save();
  ctx.fillStyle = "rgba(251,191,36,0.12)";
  ctx.strokeStyle = "rgba(251,191,36,0.7)";
  ctx.lineWidth = 1.5;
  ctx.fillRect(left, topP, sidePx, sidePx);
  ctx.strokeRect(left, topP, sidePx, sidePx);
  // label the squared contribution
  ctx.fillStyle = "#fbbf24";
  ctx.font = "12px ui-monospace, Menlo, monospace";
  ctx.textAlign = "left";
  ctx.fillText("r² = " + (r * r).toFixed(0), left + 4, topP + sidePx + 14);
  ctx.restore();
}

function drawResiduals() {
  ctx.save();
  for (let i = 0; i < POINTS.length; i++) {
    const p = POINTS[i];
    const yhat = lineY(p.x);
    const px = xToPx(p.x);
    const special = i === SPECIAL;
    // the outlier's segment thickens with its size so the "big miss" reads at a glance
    if (special) {
      const mag = Math.abs(p.y - yhat);
      ctx.strokeStyle = "rgba(248,113,113,0.95)";
      ctx.lineWidth = 2 + clamp(mag / 8, 0, 6);
    } else {
      ctx.strokeStyle = "rgba(248,113,113,0.5)";
      ctx.lineWidth = 2;
    }
    ctx.beginPath();
    ctx.moveTo(px, yToPx(p.y));
    ctx.lineTo(px, yToPx(yhat));
    ctx.stroke();
  }
  ctx.restore();
}

function drawLine() {
  ctx.save();
  const grad = ctx.createLinearGradient(0, 0, canvas.width, 0);
  grad.addColorStop(0, "#a78bfa");
  grad.addColorStop(1, "#22d3ee");
  ctx.strokeStyle = grad;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(xToPx(X_LO), yToPx(lineY(X_LO)));
  ctx.lineTo(xToPx(X_HI), yToPx(lineY(X_HI)));
  ctx.stroke();
  ctx.restore();
}

function drawPoints() {
  ctx.save();
  for (let i = 0; i < POINTS.length; i++) {
    const p = POINTS[i];
    const px = xToPx(p.x), py = yToPx(p.y);
    const special = i === SPECIAL;
    if (special) {
      // soft glow so the draggable point is obvious
      ctx.beginPath();
      ctx.arc(px, py, 13, 0, Math.PI * 2);
      ctx.fillStyle = "rgba(251,191,36,0.18)";
      ctx.fill();
      ctx.beginPath();
      ctx.arc(px, py, 7.5, 0, Math.PI * 2);
      ctx.fillStyle = "#fbbf24";
      ctx.fill();
      ctx.strokeStyle = "rgba(11,11,16,0.9)";
      ctx.lineWidth = 2;
      ctx.stroke();
    } else {
      ctx.beginPath();
      ctx.arc(px, py, 5, 0, Math.PI * 2);
      ctx.fillStyle = "#22d3ee";
      ctx.fill();
      ctx.strokeStyle = "rgba(11,11,16,0.9)";
      ctx.lineWidth = 1.5;
      ctx.stroke();
    }
  }
  ctx.restore();
}

function updateReadout() {
  const { mae, rmse, maxAbs } = metrics();
  const ratio = mae > 1e-9 ? rmse / mae : 1;

  // live bars (clamped to the track but values shown exactly)
  maeBar.style.width = clamp((mae / BAR_MAX) * 100, 0, 100) + "%";
  rmseBar.style.width = clamp((rmse / BAR_MAX) * 100, 0, 100) + "%";
  maeValEl.textContent = mae.toFixed(2);
  rmseValEl.textContent = rmse.toFixed(2);

  elMae.textContent = mae.toFixed(2);
  elRmse.textContent = rmse.toFixed(2);
  elRatio.textContent = ratio.toFixed(2);
  elMax.textContent = maxAbs.toFixed(2);

  elRatio.className = "v";
  if (ratio >= 2.2) {
    elStatus.textContent = "one point dominates!";
    elStatus.className = "v bad";
    elRatio.classList.add("bad");
  } else if (ratio >= 1.4) {
    elStatus.textContent = "RMSE pulling ahead";
    elStatus.className = "v warn";
    elRatio.classList.add("warn");
  } else {
    elStatus.textContent = "errors balanced";
    elStatus.className = "v good";
    elRatio.classList.add("good");
  }
}

// ----- Outlier pull slider (moves the special point's y relative to the line) -----
function applyOutlierPull(pull) {
  const p = POINTS[SPECIAL];
  p.y = p.baseY + pull;
  // keep the readout label honest about what the slider holds
  outlierVal.textContent = (pull >= 0 ? "+" : "") + pull.toFixed(1);
}

// ----- Controls -----
noiseInput.addEventListener("input", () => {
  noise = parseFloat(noiseInput.value);
  noiseVal.textContent = noise.toFixed(1);
  // rebuild the cloud at the new spread, then re-apply the current outlier pull
  const pull = parseFloat(outlierInput.value);
  POINTS = buildPoints(noise);
  applyOutlierPull(pull);
  render();
});

outlierInput.addEventListener("input", () => {
  applyOutlierPull(parseFloat(outlierInput.value));
  render();
});

showSq.addEventListener("change", render);

document.getElementById("reset").addEventListener("click", () => {
  outlierInput.value = "0";
  applyOutlierPull(0);
  render();
});

document.getElementById("newcloud").addEventListener("click", () => {
  seed = (seed * 16807 + 1) & 0x7fffffff;   // deterministic advance -> new but reproducible cloud
  POINTS = buildPoints(noise);
  outlierInput.value = "0";
  applyOutlierPull(0);
  render();
});

// ----- Drag the special point vertically -----
function pointerToY(evt) {
  const rect = canvas.getBoundingClientRect();
  const scaleY = canvas.height / rect.height;
  const py = (evt.clientY - rect.top) * scaleY;
  return Y_LO + (1 - (py - PAD.t) / plotH()) * (Y_HI - Y_LO);   // invert yToPx
}
function pointerToCanvas(evt) {
  const rect = canvas.getBoundingClientRect();
  return {
    px: (evt.clientX - rect.left) * (canvas.width / rect.width),
    py: (evt.clientY - rect.top) * (canvas.height / rect.height)
  };
}
function nearSpecial(evt) {
  const p = POINTS[SPECIAL];
  const { px, py } = pointerToCanvas(evt);
  const dx = px - xToPx(p.x);
  const dy = py - yToPx(p.y);
  return (dx * dx + dy * dy) <= 18 * 18;   // generous grab radius
}

// move the special point to the cursor's y and sync the slider back to the line offset
function dragTo(evt) {
  const y = clamp(pointerToY(evt), Y_LO + 1, Y_HI - 1);
  const p = POINTS[SPECIAL];
  p.y = y;
  const pull = clamp(p.y - p.baseY, parseFloat(outlierInput.min), parseFloat(outlierInput.max));
  outlierInput.value = pull;
  outlierVal.textContent = (pull >= 0 ? "+" : "") + pull.toFixed(1);
  render();
}

canvas.addEventListener("pointerdown", (e) => {
  if (!nearSpecial(e)) return;
  dragging = true;
  canvas.classList.add("dragging");
  canvas.setPointerCapture(e.pointerId);
  dragTo(e);
});
canvas.addEventListener("pointermove", (e) => {
  if (!dragging) return;
  dragTo(e);
});
function endDrag() { dragging = false; canvas.classList.remove("dragging"); }
canvas.addEventListener("pointerup", endDrag);
canvas.addEventListener("pointercancel", endDrag);

// ----- Init -----
noiseVal.textContent = noise.toFixed(1);
applyOutlierPull(parseFloat(outlierInput.value));
render();

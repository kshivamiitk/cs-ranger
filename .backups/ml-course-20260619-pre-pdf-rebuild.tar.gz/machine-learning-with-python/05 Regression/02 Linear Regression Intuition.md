# Linear Regression Intuition

> Linear regression is the "hello world" of machine learning — and it's still the model you'll reach for first whenever you need to predict a number and *explain* your prediction.

## What you'll learn
- See a regression model as drawing the single best straight line (or flat plane) through a cloud of points.
- Define a **residual** and understand why we square and average them.
- Read what a **coefficient** actually means in real-world units.
- State linear regression's main **assumptions** in plain words so you know when to trust it.

## Intuition
You have data points scattered on a chart — say, hours studied (x) versus exam score (y). You want one straight line that best summarizes the trend so you can predict the score for a new number of study hours.

But "best" needs a definition. For any candidate line, each real point sits some vertical distance above or below it. That gap — *actual minus predicted* — is the **residual**: the error for that one point. A line that hugs the data has small residuals; a badly-placed line has big ones.

Linear regression picks the line that makes the residuals smallest **on average**, after squaring them. Why squared? Two reasons: squaring makes every error positive (so a +3 miss and a −3 miss don't cancel out), and it punishes big misses much more than small ones (a residual of 4 contributes 16, a residual of 1 contributes just 1). Minimizing the *mean squared residual* gives the famous **least-squares** line.

Each input feature gets a **coefficient** — the slope for that feature. A coefficient answers a crisp question: *"If this feature goes up by one unit and everything else stays fixed, how much does the prediction change?"* That interpretability is linear regression's superpower: you don't just get predictions, you get a sentence you can say to a non-technical stakeholder ("each extra hour of study is worth about 5 more points").

With one feature the model is a line; with many features it's a flat plane (a "hyperplane") in higher dimensions — but the idea is identical: minimize squared residuals, read one slope per feature.

## Python in practice

```python
import numpy as np
import matplotlib.pyplot as plt

# Synthetic "hours studied -> exam score" data so it runs offline.
rng = np.random.default_rng(0)
hours = rng.uniform(0, 10, size=60)
score = 50 + 5 * hours + rng.normal(0, 6, size=60)   # ~50 baseline, +5 pts/hour, noise

# Fit the best-fit line with NumPy's least-squares helper.
slope, intercept = np.polyfit(hours, score, deg=1)
print(f"score ≈ {intercept:.1f} + {slope:.2f} * hours")
# score ≈ 50.x + 4.9x * hours  -> recovers our +5 pts/hour, ~50 baseline

# Predicted scores and residuals for each student.
pred = intercept + slope * hours
residuals = score - pred                # actual minus predicted
print("mean squared residual:", np.mean(residuals ** 2).round(2))
```

```python
# Visualize the line and the residual gaps it's minimizing.
plt.scatter(hours, score, s=18, alpha=0.6, label="students")
xs = np.linspace(0, 10, 50)
plt.plot(xs, intercept + slope * xs, color="cyan", lw=2, label="best-fit line")
# draw residuals as vertical sticks
for h, s, p in zip(hours, score, pred):
    plt.plot([h, h], [s, p], color="salmon", alpha=0.4, lw=1)
plt.xlabel("hours studied"); plt.ylabel("exam score")
plt.legend(); plt.title("Residuals are the vertical gaps the line minimizes")
plt.show()
```

```python
# Reading the coefficient as a sentence:
print(f"Each extra hour of study is associated with about "
      f"{slope:.1f} more exam points.")
print(f"A student who studied 0 hours is predicted to score about "
      f"{intercept:.0f}.")
```

## Common mistakes
- **Reading correlation as causation.** A coefficient of +5 says study hours *predict* higher scores in this data; it doesn't *prove* studying causes the rise. Other factors (motivation, prior knowledge) could drive both.
- **Trusting a straight line on a curved relationship.** If the true pattern bends, a line will systematically over- and under-predict. Always plot residuals: they should look like random scatter, not a smile or frown shape.
- **Extrapolating far outside the data.** The "+5 points/hour" trend learned from 0–10 hours says nothing reliable about 40 hours of study. Predict within the range you trained on.
- **Forgetting units when interpreting coefficients.** A coefficient's meaning depends entirely on the feature's units (per hour? per thousand dollars?). State the unit every time.
- **Letting outliers dominate.** Because residuals are *squared*, one wild point can drag the whole line toward it. Spot outliers before trusting the fit.

## Small exercise
1. Change the noise standard deviation in the data from `6` to `20` and refit. Does the recovered slope still land near 5? What happens to the mean squared residual?
2. Add a single outlier student: `hours=2, score=200`. Refit and describe how the line and slope move. (This shows why squared errors are sensitive to outliers.)
3. Write the one-sentence interpretation of your new slope, including the unit.

## Before you continue
- [ ] I can define a residual and explain why we minimize *squared* residuals.
- [ ] I can turn a coefficient into a plain-English sentence with the correct unit.
- [ ] I can name two situations where a straight-line fit would mislead me.

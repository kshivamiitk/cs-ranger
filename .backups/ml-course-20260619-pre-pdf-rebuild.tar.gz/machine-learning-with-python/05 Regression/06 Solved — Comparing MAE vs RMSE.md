# Solved — Comparing MAE vs RMSE

> Two error numbers can describe the *same* predictions and tell you opposite things — until one rogue data point walks in, and suddenly only one of them screams.

## Problem statement

You fit a regression that predicts apartment `price_k` (price in thousands of dollars) from `area_sqft`. You need a single number that summarizes "how wrong is this model, typically?" — and you have to pick between the two most common choices:

- **MAE** (mean absolute error): the average of the *absolute* gaps `|y − ŷ|`, in the target's own units (here, thousands of dollars).
- **RMSE** (root mean squared error): square each gap, average, then take the square root — also in the target's units, but with the squaring step in the middle.

On clean data these two numbers sit close together. The task is to **measure both, then inject one large outlier into the target and recompute**, and explain *why* RMSE leaps far more than MAE — so you can decide which metric to report for a given business goal.

## Why this problem matters

The metric you optimize is the behavior you get. If you report RMSE, your model is implicitly told "a few huge misses are unforgivable — bend over backwards to avoid them." If you report MAE, it's told "every dollar of error counts the same; don't let one weird house drag you around." Pick the wrong one and you'll either chase a single noisy outlier at the expense of the other 99% of predictions, or quietly tolerate occasional catastrophic misses that the business actually cares about. This is also the single most common reason two engineers "disagree" about whether a model is good: they're quoting different error metrics on the same predictions and don't realize it.

## Tiny dataset or sample data

Twelve apartments, inline so the whole thing runs offline. The price rises roughly linearly with area, with a little realistic noise. Shape: `(12, 2)` — one feature, one target.

| area_sqft | price_k |
|----------:|--------:|
|       600 |     142 |
|       750 |     181 |
|       900 |     199 |
|      1100 |     250 |
|      1250 |     265 |
|      1400 |     308 |
|      1600 |     331 |
|      1750 |     372 |
|      1900 |     388 |
|      2100 |     425 |
|      2300 |     475 |
|      2500 |     500 |

We will keep this exact data, then deliberately corrupt **one** target value (`308 → 900`, a "fat-finger" listing typo or a genuinely freak luxury sale) and watch what each metric does.

## Step-by-step reasoning

1. **Fit the simplest honest model.** One feature, one target — `LinearRegression` finds the best straight line by least squares. We predict on the same rows we fit, because here the metrics, not the model, are the lesson.
2. **Compute both metrics on clean data.** Use `mean_absolute_error` for MAE and `np.sqrt(mean_squared_error(...))` for RMSE. Note their *ratio*: on well-behaved data RMSE is only slightly above MAE (RMSE ≥ MAE always, by the math).
3. **Inject exactly one outlier into the target.** Copy the array (never mutate the original), then overwrite a single price with a wildly wrong value. Refit, because the line itself will tilt toward the outlier too.
4. **Recompute and compare the jumps.** MAE rises because every prediction is now a bit off (the tilted line) plus one big gap. RMSE rises *much* more, because it **squares** each gap first: a single error of ~550 contributes `550² ≈ 302,500` to the mean before the square root — it dominates the sum.
5. **Read the RMSE/MAE ratio as an "outlier detector."** When RMSE drifts far above MAE, it's telling you the error distribution has a heavy tail — a few big misses are doing the damage. A ratio near 1.0 means errors are evenly sized.

## Python solution

```python
import io
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, mean_squared_error

# --- Inline data so this runs with no downloads ---
CSV = """area_sqft,price_k
600,142
750,181
900,199
1100,250
1250,265
1400,308
1600,331
1750,372
1900,388
2100,425
2300,475
2500,500
"""
df = pd.read_csv(io.StringIO(CSV))
print("Shape:", df.shape)                 # (12, 2)

X = df[["area_sqft"]].values              # 2-D, shape (12, 1)
y = df["price_k"].values.astype(float)    # target in $thousands

# --- 1. Fit a simple line and measure both metrics on CLEAN data ---
model = LinearRegression().fit(X, y)
y_pred = model.predict(X)

mae_clean = mean_absolute_error(y, y_pred)
rmse_clean = np.sqrt(mean_squared_error(y, y_pred))   # sqrt of MSE
print("\n-- Clean data --")
print(f"MAE  = {mae_clean:6.2f}  (thousand $)")
print(f"RMSE = {rmse_clean:6.2f}  (thousand $)")
print(f"RMSE / MAE = {rmse_clean / mae_clean:.2f}   (close to 1 -> errors are even-sized)")

# --- 2. Inject ONE large outlier into the target, then REFIT ---
y_outlier = y.copy()                      # copy! never corrupt the original
idx = 5                                    # the 1400-sqft apartment
print(f"\nInjecting outlier at row {idx}: true {y[idx]:.0f} -> 900")
y_outlier[idx] = 900.0                     # fat-finger typo / freak sale

model_out = LinearRegression().fit(X, y_outlier)
y_pred_out = model_out.predict(X)

mae_out = mean_absolute_error(y_outlier, y_pred_out)
rmse_out = np.sqrt(mean_squared_error(y_outlier, y_pred_out))
print("\n-- After one outlier --")
print(f"MAE  = {mae_out:7.2f}  (was {mae_clean:.2f}, x{mae_out / mae_clean:.1f})")
print(f"RMSE = {rmse_out:7.2f}  (was {rmse_clean:.2f}, x{rmse_out / rmse_clean:.1f})")
print(f"RMSE / MAE = {rmse_out / mae_out:.2f}   (now well above 1 -> a heavy tail!)")

# --- 3. Where did the damage come from? Look at the per-row errors ---
abs_err = np.abs(y_outlier - y_pred_out)
print("\nPer-row absolute errors after outlier:")
print(np.round(abs_err, 1))
print(f"One error of {abs_err.max():.0f} dominates: it alone is "
      f"{abs_err.max()**2 / np.sum(abs_err**2):.0%} of the squared-error sum.")
```

## Expected output

Running it prints roughly:

```
Shape: (12, 2)

-- Clean data --
MAE  =   6.16  (thousand $)
RMSE =   6.35  (thousand $)
RMSE / MAE = 1.03   (close to 1 -> errors are even-sized)

Injecting outlier at row 5: true 308 -> 900

-- After one outlier --
MAE  =   91.73  (was 6.16, x14.9)
RMSE =  166.31  (was 6.35, x26.2)
RMSE / MAE = 1.81   (now well above 1 -> a heavy tail!)

Per-row absolute errors after outlier:
[ 70.   56.8  64.6  48.   58.8 550.4  53.1  37.9  47.7  45.1  29.5  38.9]
One error of 550 dominates: it alone is 91% of the squared-error sum.
```

## Explanation of the output

On clean data the two metrics are near-twins: **MAE ≈ 6.16** and **RMSE ≈ 6.35**, a ratio of **1.03**. That tells you the errors are all roughly the same modest size — exactly what you'd hope for from a good linear fit.

After flipping one target from 308 to 900, both metrics rise, but by very different amounts. **MAE grows about 15×** (6.16 → 91.73) — bad, but proportionate, because the corrupted line is now a little wrong everywhere. **RMSE grows about 26×** (6.35 → 166.31), and the RMSE/MAE ratio jumps from 1.03 to **1.81**. The per-row breakdown shows why: the outlier's residual is ~550, and `550²` is so much larger than every other squared gap that **a single point accounts for ~91% of the squared-error sum**. MAE averages the raw gaps, so that point counts once; RMSE squares first, so that point counts ~550× as much as a typical 1-unit gap before the average is taken. The square root at the end shrinks the number back into target units but does *not* undo the disproportionate weighting. The widened RMSE/MAE ratio is the fingerprint of an outlier-heavy error distribution — a free diagnostic you get for nothing.

**When to prefer each:** use **MAE** when occasional large errors are expected/tolerable and you want a metric that isn't hijacked by them (robust, "typical" error). Use **RMSE** when large misses are genuinely costly and you *want* the model punished hard for them (e.g. a single badly-mispriced contract loses real money).

## Common mistakes

1. **Mutating the original target in place** (`y[idx] = 900` without copying). Now your "clean" baseline is gone and every later comparison is wrong. Fix: `y_outlier = y.copy()` before corrupting it.
2. **Forgetting the square root and reporting MSE as if it were RMSE.** MSE is in *squared* units (thousand-dollars²), so it's not comparable to MAE and its raw value looks alarmingly huge. Fix: always `np.sqrt(mean_squared_error(...))` — or in newer sklearn, `root_mean_squared_error`.
3. **Concluding "RMSE is broken" because it moved more.** RMSE is doing its defined job — penalizing big misses. The question is whether your business *wants* that. Fix: choose the metric from the cost of errors, not from which number looks nicer.
4. **Comparing MAE on one model to RMSE on another and declaring a winner.** They're different scales; RMSE ≥ MAE always. Fix: compare like-for-like, the same metric across models.
5. **Tuning hyperparameters on RMSE without checking whether a single outlier is steering the score.** A model can look worse purely because of one mislabeled row. Fix: inspect the per-row errors (as above); if one point dominates, clean or down-weight it, or switch to MAE.

## Extension challenge

1. Sweep the outlier from 350 up to 1500 in steps and plot MAE and RMSE versus the outlier value. MAE should rise roughly linearly; RMSE should curve upward faster — see the squaring with your own eyes.
2. Add **Huber loss** thinking: compute the median absolute error too. It barely moves when you inject the outlier — explain why the median is even more robust than the mean-based MAE.
3. Replace `LinearRegression` with `HuberRegressor` (robust to outliers) and recompute both metrics after injecting the outlier. Why does the *model* now resist the bad point, narrowing the RMSE/MAE gap?

## Matching animation

**MAE vs RMSE Outlier Explorer** — drag one data point far off the line and watch two bars, MAE and RMSE, respond in real time. The RMSE bar shoots up dramatically while the MAE bar creeps, and a side panel shows each residual being squared so you can literally see the outlier's `error²` swamp all the others. It turns the abstract "RMSE penalizes large errors" into something you feel with your mouse.

# Fit, Predict, and Read the Coefficients

> Training a regression model in scikit-learn is three lines — but the value is in reading what the model learned and reporting how good it is.

## What you'll learn
- Use the standard scikit-learn workflow: `fit` → `predict` → evaluate.
- Pull out `.coef_` and `.intercept_` and interpret them per feature.
- Predict the target for brand-new rows.
- Report and read the two headline regression metrics: **RMSE** (error in target units) and **R²** (fraction of variance explained).

## Intuition
Every scikit-learn model speaks the same dialect. You create the model, call `.fit(X, y)` to learn from data, then `.predict(X_new)` to score new examples. For linear regression, fitting means finding the coefficients that minimize squared residuals — exactly the least-squares line from the last lesson, just solved instantly with linear algebra instead of a hand-written loop.

Once fitted, the model exposes what it learned:
- `.coef_` — one number per feature: the slope, i.e. how much the prediction changes per one-unit increase in that feature (holding the others fixed).
- `.intercept_` — the predicted value when every feature is zero (the baseline).

To know if the model is any good, you need two numbers a stakeholder can understand:
- **RMSE** (root mean squared error) is the typical size of a miss, **in the same units as the target**. If you're predicting disease progression and RMSE is 54, your predictions are off by ~54 of those units on average.
- **R²** is the fraction of the target's variation the model explains, from 0 to 1 (it can go negative for a model worse than always guessing the mean). R² = 0.5 means the features explain half the spread; R² = 1.0 would be perfect.

You always read both together: RMSE tells you *how wrong in real units*, R² tells you *how much better than a trivial baseline*.

## Python in practice

```python
import numpy as np
from sklearn.datasets import load_diabetes
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score

# A real built-in dataset: 10 health features -> disease progression after 1 year.
data = load_diabetes()
X, y = data.data, data.target
print(X.shape, y.shape)              # (442, 10) (442,)
print(data.feature_names)            # ['age','sex','bmi','bp','s1',...,'s6']

# Always split: train on one part, test honestly on data the model never saw.
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

model = LinearRegression()
model.fit(X_train, y_train)          # learn the coefficients
```

```python
# Read what the model learned: one coefficient per feature.
for name, coef in zip(data.feature_names, model.coef_):
    print(f"{name:>4}: {coef:8.1f}")
print(f"intercept: {model.intercept_:.1f}")
# bmi and s5 (a blood serum measure) usually have the largest positive coefficients,
# meaning they push predicted disease progression up the most in this dataset.
```

Interpretation: this dataset's features are pre-standardized, so a coefficient is the change in predicted progression for a one-standard-deviation increase in that feature. The feature with the biggest absolute coefficient is the strongest linear driver in the model.

```python
# Predict on the held-out test set and score honestly.
y_pred = model.predict(X_test)

rmse = mean_squared_error(y_test, y_pred) ** 0.5   # error in target units
r2 = r2_score(y_test, y_pred)                       # fraction of variance explained
print(f"RMSE = {rmse:.1f}   (typical miss, in progression units)")
print(f"R^2  = {r2:.3f}     (0=no better than the mean, 1=perfect)")
# RMSE ≈ 53.x   R^2 ≈ 0.45  -> the 10 features explain ~45% of the variation.
```

```python
# Predict for a brand-new patient (must match the 10-feature layout).
new_patient = X_test[0].reshape(1, -1)   # one row, shape (1, 10)
print("predicted progression:", model.predict(new_patient).round(1))
print("actual:", y_test[0])
```

## Common mistakes
- **Scoring on the training data.** A model always looks better on data it memorized. Report RMSE/R² on the **test** split, or you'll fool yourself.
- **Confusing MSE and RMSE.** `mean_squared_error` returns the *squared* error; take its square root for RMSE so the number is in the target's units. (Newer sklearn also offers `root_mean_squared_error`.)
- **Forgetting `predict` needs 2-D input.** A single example must be shape `(1, n_features)` — use `.reshape(1, -1)`. Passing a flat `(n_features,)` array can raise an error or warning.
- **Over-reading coefficients on unscaled data.** When features have wildly different units (dollars vs. years), raw coefficient sizes aren't comparable. Compare magnitudes only after standardizing, or interpret each in its own units.
- **Reporting R² alone.** R² hides the real-world error size. A model can have a decent R² and still be too imprecise for your use case — always pair it with RMSE.

## Small exercise
1. Refit the diabetes model and print the **three** features with the largest absolute coefficients. Write a one-sentence interpretation of the top one.
2. Compute RMSE on the **training** set as well as the test set. Is training RMSE lower? Explain in a comment why that's expected.
3. Build a fake "average patient" by taking `X_train.mean(axis=0)`, predict their progression, and compare it to `y_train.mean()`. Are they close? Why would you expect that?

## Before you continue
- [ ] I can run `fit` → `predict` → evaluate on a train/test split without peeking at test data during fitting.
- [ ] I can extract `.coef_`/`.intercept_` and explain one coefficient in words.
- [ ] I can compute RMSE and R² and state what each tells a non-technical stakeholder.

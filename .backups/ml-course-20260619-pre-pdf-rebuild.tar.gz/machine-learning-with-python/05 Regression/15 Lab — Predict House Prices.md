# Lab — Predict House Prices

## Objective
You will build a small but complete house-price predictor: load a tiny housing table, split into train/test, fit a `LinearRegression`, evaluate it with RMSE and R², interpret the coefficients in plain dollars-per-unit language, and then try `Ridge` to see whether regularization helps. By the end you'll have an end-to-end regression workflow you can describe in an interview and adapt to any "predict a number" problem.

## Dataset
A compact, realistic housing table embedded inline (via `io.StringIO`) so the whole lab runs offline with no downloads. Each row is one house.

| sqft | bedrooms | age | price    |
|------|----------|-----|----------|
| 850  | 2        | 35  | 172000   |
| 1200 | 3        | 20  | 249000   |
| 1500 | 3        | 15  | 312000   |
| ...  | ...      | ... | ...      |

`price` (in dollars) is the **target**; `sqft`, `bedrooms`, `age` (years) are the **features**.

## Steps

**1. Load the inline CSV into a DataFrame.** No file on disk — the data lives in the code.

```python
import io
import numpy as np
import pandas as pd

CSV = """sqft,bedrooms,age,price
850,2,35,172000
1200,3,20,249000
1500,3,15,312000
1800,4,10,366000
1100,2,25,228000
2400,4,8,470000
2000,4,12,402000
950,2,40,190000
2750,5,5,540000
1350,3,18,279000
1650,3,14,330000
3000,5,3,592000
1450,3,22,295000
2200,4,9,438000
1750,4,16,352000
1000,2,30,205000
2600,5,6,505000
1900,4,11,385000
1250,3,28,256000
2100,4,7,420000
"""
df = pd.read_csv(io.StringIO(CSV))
print(df.shape)        # (20, 4)
print(df.head())
```

**2. Separate features and target, then split.** Hold back 25% for an honest test.

```python
from sklearn.model_selection import train_test_split

X = df[["sqft", "bedrooms", "age"]]
y = df["price"]
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42
)
print("train rows:", len(X_train), " test rows:", len(X_test))   # 15  5
```

**3. Fit a LinearRegression.** Three features in, one price out.

```python
from sklearn.linear_model import LinearRegression

lin = LinearRegression()
lin.fit(X_train, y_train)
```

**4. Evaluate on the held-out test set.** RMSE in dollars, R² as a fraction of variance explained.

```python
from sklearn.metrics import mean_squared_error, r2_score

pred = lin.predict(X_test)
rmse = mean_squared_error(y_test, pred) ** 0.5
r2 = r2_score(y_test, pred)
print(f"Test RMSE = ${rmse:,.0f}")     # e.g. ~ $8,000–$15,000 typical miss
print(f"Test R^2  = {r2:.3f}")         # e.g. ~ 0.98 (sqft drives price strongly)
```

**5. Interpret the coefficients in real units.** This is the part stakeholders care about.

```python
for feature, coef in zip(X.columns, lin.coef_):
    print(f"{feature:>9}: {coef:+,.1f} dollars per unit")
print(f"{'intercept':>9}: {lin.intercept_:+,.0f} dollars")
# Read aloud, e.g.:
#  - each extra square foot adds ~$1xx to predicted price
#  - each extra bedroom adds ~$x,xxx (holding sqft & age fixed)
#  - each extra year of age subtracts ~$x,xxx
```

**6. Predict a brand-new house.** Pass a one-row DataFrame with the same columns.

```python
new_house = pd.DataFrame([{"sqft": 1600, "bedrooms": 3, "age": 12}])
print("predicted price:", f"${lin.predict(new_house)[0]:,.0f}")
```

**7. Try Ridge regularization.** Standardize first (the penalty is scale-sensitive), then compare.

```python
from sklearn.linear_model import Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import make_pipeline

ridge = make_pipeline(StandardScaler(), Ridge(alpha=10.0))
ridge.fit(X_train, y_train)
ridge_pred = ridge.predict(X_test)
ridge_rmse = mean_squared_error(y_test, ridge_pred) ** 0.5
print(f"Ridge test RMSE = ${ridge_rmse:,.0f}   (vs linear ${rmse:,.0f})")
# On this clean, small dataset Ridge and plain linear are close;
# Ridge's edge shows up more when features are correlated or noisy.
```

## Expected output
- **R² near 0.95+** on the test set — square footage is a very strong, nearly linear driver of price in this synthetic data, so the model explains almost all the variation.
- **RMSE of roughly a few thousand to ~$15,000** — interpret it as "our price predictions are typically off by about this many dollars."
- **Coefficients with sensible signs:** `sqft` positive (bigger homes cost more), `bedrooms` positive, `age` negative (older homes cost less). If a sign looks backwards, suspect feature correlation (sqft and bedrooms move together) rather than a code bug.
- **Ridge RMSE close to linear RMSE** here; the lesson is *how* to add regularization and read the comparison, not that it must always win on tiny clean data.

## Extension challenge
1. **Cross-validate properly.** Replace the single split with `cross_val_score(lin, X, y, cv=5, scoring="r2")` and report the mean ± std. Is the model stable across folds?
2. **Add an interaction or polynomial term.** Put `PolynomialFeatures(degree=2)` in front of the regressor and see whether test RMSE improves or the model starts overfitting (watch for a train/test gap).
3. **Swap in `make_regression`.** Generate `X, y = make_regression(n_samples=300, n_features=5, noise=20, random_state=0)`, repeat the fit/evaluate/interpret flow, and compare `coef_` to the true coefficients returned by `make_regression(..., coef=True)`.

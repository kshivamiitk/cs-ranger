# Regularization

> Regularization is a leash on your model: it penalizes oversized coefficients so the model stops memorizing noise and starts learning the real signal.

## What is this?

Regularization is a technique that adds a **penalty for large coefficients** to a model's training objective. Normally a regression model tunes its coefficients to fit the training points as closely as possible. Regularization changes the deal: "fit the data well, **but** keep your coefficients small." The model now has to balance two goals, and that balance is what prevents it from contorting itself to chase every wiggle in the training data.

There are two workhorse flavors:

- **Ridge (L2)** penalizes the *sum of squared* coefficients. It **shrinks** every coefficient toward zero but rarely makes any exactly zero. Good when most features matter a little.
- **Lasso (L1)** penalizes the *sum of absolute* coefficients. It can drive coefficients **exactly to zero**, which deletes features — so Lasso doubles as automatic **feature selection**. Good when you suspect many features are useless.

One knob controls the strength: **alpha**.

- `alpha = 0` -> no penalty, back to plain regression (can overfit).
- small `alpha` -> gentle shrinkage.
- large `alpha` -> heavy shrinkage; push it too far and the model **underfits** (coefficients squashed toward zero, predictions go flat).

Two non-negotiables: regularization penalizes coefficient *size*, so you **must scale your features first** (otherwise a feature measured in thousands is unfairly penalized vs one measured in fractions), and you tune `alpha` on validation data, never by eyeballing the training fit.

## Why do we need it?

Models overfit. Give a flexible model enough freedom and it will fit the training data *too* well — including the random noise — by blowing up its coefficients into a jagged, high-amplitude curve. It looks brilliant on data it has seen and falls apart on data it hasn't. The symptom is a model with huge, wildly swinging coefficients and a big gap between training error (tiny) and test error (large).

Regularization fights this directly by making big coefficients *expensive*. The model can only afford large weights if they buy a real reduction in error. Noise doesn't buy that, so the model stops chasing it. The result is a smoother, simpler model that **generalizes better to new data** — which is the only thing that matters in production.

## Where it's used in real ML

- **Almost every linear model in industry** ships with regularization on. `LogisticRegression` in scikit-learn is L2-regularized *by default* — most people use it without realizing.
- **High-dimensional data** (genomics, text with thousands of word features, ad-click features) where you have more features than samples — Lasso prunes the irrelevant ones automatically.
- **Tabular models with correlated features** (e.g. `total_sqft` and `num_rooms`) where Ridge stabilizes otherwise erratic coefficients.
- **Neural networks** use the same idea under different names — *weight decay* is L2 regularization, and *dropout* is a related anti-overfitting tool.
- **Feature selection pipelines** use Lasso as a first pass to throw away columns before fitting a bigger model.

## What breaks if you ignore it

- **Overfitting goes unchecked.** Your model nails the training set and embarrasses you on real users. Test error stays high while training error looks perfect.
- **Coefficients explode and become unreadable.** Without a penalty, correlated features can produce giant offsetting coefficients (`+9000` and `-8900`) that are unstable and meaningless to interpret.
- **You skip scaling and regularize unfairly.** If you regularize without scaling, the penalty hammers features with large numeric ranges and ignores small-range ones — the model gets distorted, not improved.
- **You crank alpha to "be safe" and underfit.** Too much penalty squashes all coefficients toward zero; the model becomes a flat line that predicts the average and learns nothing. Regularization is a dial, not an on/off switch.

## Mental model

Picture fitting a curve to scattered points as **bending a flexible ruler** through them.

- **No regularization:** the ruler is rubber. It snakes up and down to touch every single point, including the noisy ones. Beautiful on the training points, useless between them.
- **With regularization:** you stiffen the ruler. It can no longer make sharp wiggles — it has to pass *near* the points with a smooth, gentle bend. `alpha` is how stiff you make it.
- **Too much regularization:** the ruler is a steel rod. It's a flat line that ignores the points entirely. Underfit.

```
  No penalty (overfit)        Just right                 Too much (underfit)
  /\    /\                     ___                          ___________
 /  \  /  \  /                /   \___                     (flat line)
y    \/    \/      vs    y   /        \___      vs    y
   chases noise              smooth signal               ignores signal
```

Lasso's twist: it doesn't just stiffen the ruler, it can **remove rulers entirely** — setting a feature's coefficient to exactly zero, as if that feature never existed.

## Example 1 — Tiny toy example

Suppose six data points roughly follow a gentle upward trend, but with noise. A high-degree polynomial fit (lots of freedom) draws a curve that wiggles violently to pass through every point:

```
fit through 6 noisy points

  high-degree, no penalty:        with regularization:
        .                                .
   .   / \   .                      .  _____  .
  / \ /   \ / \                   __/       \__
 *   *     *   *  *              *   *     *   *  *   (smooth, passes near them)
  (touches every point,           (ignores the noise,
   but swings wildly)              follows the trend)
```

The wiggly fit has enormous coefficients (e.g. `[+312, -890, +1100, ...]`) because that's what it takes to swing the curve up and down so sharply. The smoothed fit has small, calm coefficients (e.g. `[+8, -3, +2, ...]`). Same data, same model family — the only difference is a penalty that made the violent swings too expensive to keep. Between the points, the smooth fit is the one you'd actually trust.

## Example 2 — Practical ML example

You're predicting **house prices** from 10 features: `sqft`, `bedrooms`, `bathrooms`, `age`, `garage_size`, `lot_size`, `distance_to_city`, and three noisy "junk" columns a teammate added (random survey scores that have nothing to do with price). You only have 200 houses.

A plain `LinearRegression` overfits: it assigns big coefficients to the junk columns because, by chance, they correlate slightly with price in *these* 200 rows. Test error is poor.

You scale the features, then fit `Ridge` and sweep `alpha`. As `alpha` rises from `0.01` to `10`, you watch the junk-column coefficients shrink toward zero and the **test error drop** to a minimum, then rise again once `alpha` gets so large that even `sqft` and `bathrooms` get squashed (underfitting). The best `alpha` sits in the middle. Swap in `Lasso` and the junk columns go *exactly* to zero — the model effectively tells you which features to delete.

## Python code example

```python
# Ridge regularization on a noisy, multi-feature dataset, with inline data.
import numpy as np
from sklearn.linear_model import LinearRegression, Ridge
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error

rng = np.random.default_rng(0)
n = 120

# Two REAL signal features plus three pure-noise "junk" features.
x1 = rng.normal(size=n)          # real driver
x2 = rng.normal(size=n)          # real driver
junk = rng.normal(size=(n, 3))   # irrelevant noise
X = np.column_stack([x1, x2, junk])

# True relationship uses ONLY x1 and x2; everything else is distraction + noise.
y = 5 * x1 - 3 * x2 + rng.normal(scale=1.0, size=n)

Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.3, random_state=0)

# MUST scale before regularizing: fit the scaler on TRAIN only, then apply to both.
scaler = StandardScaler().fit(Xtr)
Xtr_s, Xte_s = scaler.transform(Xtr), scaler.transform(Xte)

# Plain regression: no penalty -> chases the junk features.
lin = LinearRegression().fit(Xtr_s, ytr)
lin_err = mean_squared_error(yte, lin.predict(Xte_s))
print(f"Plain LinearRegression  test MSE = {lin_err:0.3f}")
print(f"  coefficients: {np.round(lin.coef_, 2)}")

# Ridge: sweep alpha and watch coefficients shrink + test error improve.
print("\nRidge (L2): bigger alpha = stronger shrinkage")
for alpha in [0.0, 1.0, 10.0, 1000.0]:
    ridge = Ridge(alpha=alpha).fit(Xtr_s, ytr)
    err = mean_squared_error(yte, ridge.predict(Xte_s))
    print(f"  alpha={alpha:>7.1f}  test MSE={err:0.3f}  coefs={np.round(ridge.coef_, 2)}")

# Takeaway: gentle alpha shrinks the 3 junk coefs toward 0 with little cost; push alpha
# too high (10, 1000) and it crushes even the real x1/x2 coefs -> underfitting, error climbs.
```

Expected output (numbers approximate):

```
Plain LinearRegression  test MSE = 1.234
  coefficients: [ 5.15 -3.32  0.16 -0.07  0.23]

Ridge (L2): bigger alpha = stronger shrinkage
  alpha=    0.0  test MSE=1.234  coefs=[ 5.15 -3.32  0.16 -0.07  0.23]
  alpha=    1.0  test MSE=1.229  coefs=[ 5.10 -3.29  0.14 -0.06  0.23]
  alpha=   10.0  test MSE=1.394  coefs=[ 4.62 -3.03  0.03 -0.02  0.25]
  alpha= 1000.0  test MSE=18.28  coefs=[ 0.44 -0.32 -0.08  0.03  0.06]
```

Watch the junk coefficients (the small last three) get squeezed toward zero as `alpha` grows. Test error barely moves at gentle `alpha`, then — once `alpha` gets large (`10`, and disastrously at `1000`) — it climbs because the penalty has started crushing the *real* `x1`/`x2` signal too. That climb is underfitting: the lesson is that there is a sweet spot, and overshooting `alpha` is just as harmful as having none.

## Common mistakes

- **Forgetting to scale first.** Regularization penalizes coefficient size, so features must be on the same scale. Always `StandardScaler` (fit on train only) before `Ridge`/`Lasso`.
- **Leaking the test set into the scaler.** Fitting `StandardScaler` on the full dataset before splitting leaks information. Fit on train, transform both. Better: wrap scaler + model in a `Pipeline`.
- **Treating alpha as "more is safer."** Too-large `alpha` underfits — coefficients shrink to near zero and the model predicts a flat average. Tune `alpha` on validation data.
- **Confusing Ridge and Lasso intent.** Ridge shrinks but keeps all features; Lasso can zero them out for feature selection. Picking the wrong one wastes the property you actually wanted.
- **Reading coefficient magnitudes across unscaled features.** After scaling, coefficients are comparable; on raw features they are not. Don't rank feature importance by raw coefficient size without scaling.

## Before you continue
- [ ] I can explain regularization as penalizing large coefficients to reduce overfitting.
- [ ] I know Ridge (L2) shrinks coefficients while Lasso (L1) can zero them out for feature selection.
- [ ] I understand that `alpha` controls strength: too small overfits, too large underfits.
- [ ] I know I must scale features before regularizing, fitting the scaler on the training set only.
- [ ] I can describe how rising `alpha` lowers test error up to a point, then makes it worse.

"use strict";

/* ------------------------------------------------------------------ *
 * Regularization Strength Slider  (Ridge polynomial regression)
 *
 * Model:  y_hat(x) = w0 + w1*z + w2*z^2 + ... + wd*z^d
 *         where z = (x - mu) / sigma   (x standardized for stability)
 *
 * Ridge cost: sum( (y - Xw)^2 )  +  alpha * sum_{j>=1}( w_j^2 )
 *   -> the intercept w0 is NOT penalized.
 * Normal equations:  (X^T X + alpha * P) w = X^T y
 *   with P = diag(0, 1, 1, ..., 1).
 * Solved by Gaussian elimination with partial pivoting.
 *
 * Story:  alpha -> 0   wiggly curve chases noise (overfit, big weights)
 *         alpha large  weights shrink, curve flattens (underfit)
 *         a middle alpha minimizes error on the held-out TEST points.
 * ------------------------------------------------------------------ */

// ----- Deterministic PRNG so the data is identical every load -----
function makeRng(seed) {
  let s = seed >>> 0;
  return function () {
    s = (s * 1103515245 + 12345) & 0x7fffffff;
    return s / 0x7fffffff;             // in [0,1)
  };
}

// True smooth function we are trying to recover (unknown to the model).
function trueFn(x) {
  return Math.sin(x * 1.7) * 1.15 + 0.35 * x;
}

// ----- Generate ~20 noisy points, then split into train / test -----
function makeData() {
  const rnd = makeRng(20260618);
  const NOISE = 0.45;
  const all = [];
  for (let i = 0; i < 20; i++) {
    const x = -2.6 + (i / 19) * 5.2;                 // x in [-2.6, 2.6]
    const noise = (rnd() - 0.5) * 2 * NOISE;         // +/- NOISE
    all.push({ x, y: trueFn(x) + noise });
  }
  // Fixed, deterministic split: every 3rd point is held out for testing.
  const train = [], test = [];
  all.forEach((p, i) => ((i % 3 === 1) ? test : train).push(p));
  return { all, train, test };
}
const DATA = makeData();
const TRAIN = DATA.train;
const TEST = DATA.test;

// ----- Standardization of x (fit on TRAIN only, like a real pipeline) -----
const X_MU = TRAIN.reduce((a, p) => a + p.x, 0) / TRAIN.length;
const X_SD = (function () {
  let v = 0;
  for (const p of TRAIN) v += (p.x - X_MU) * (p.x - X_MU);
  return Math.sqrt(v / TRAIN.length) || 1;
})();
function zOf(x) { return (x - X_MU) / X_SD; }

// ----- Design matrix row: [1, z, z^2, ..., z^deg] -----
function features(x, deg) {
  const row = new Array(deg + 1);
  let zp = 1, z = zOf(x);
  for (let j = 0; j <= deg; j++) { row[j] = zp; zp *= z; }
  return row;
}

// ----- Gaussian elimination with partial pivoting: solve A w = b -----
function solve(A, b) {
  const n = b.length;
  // augment
  const M = A.map((r, i) => r.slice().concat(b[i]));
  for (let c = 0; c < n; c++) {
    // pivot
    let piv = c;
    for (let r = c + 1; r < n; r++) {
      if (Math.abs(M[r][c]) > Math.abs(M[piv][c])) piv = r;
    }
    if (piv !== c) { const t = M[piv]; M[piv] = M[c]; M[c] = t; }
    const d = M[c][c];
    if (Math.abs(d) < 1e-12) continue;               // singular guard
    for (let r = 0; r < n; r++) {
      if (r === c) continue;
      const f = M[r][c] / d;
      if (f === 0) continue;
      for (let k = c; k <= n; k++) M[r][k] -= f * M[c][k];
    }
  }
  const w = new Array(n);
  for (let i = 0; i < n; i++) w[i] = Math.abs(M[i][i]) < 1e-12 ? 0 : M[i][n] / M[i][i];
  return w;
}

// ----- Fit ridge regression on TRAIN at a given (deg, alpha) -----
function fitRidge(deg, alpha) {
  const m = deg + 1;
  // Build X^T X and X^T y over the training set.
  const XtX = Array.from({ length: m }, () => new Array(m).fill(0));
  const Xty = new Array(m).fill(0);
  for (const p of TRAIN) {
    const f = features(p.x, deg);
    for (let i = 0; i < m; i++) {
      Xty[i] += f[i] * p.y;
      for (let j = 0; j < m; j++) XtX[i][j] += f[i] * f[j];
    }
  }
  // Add alpha to the diagonal, EXCEPT the intercept term (j = 0).
  for (let j = 1; j < m; j++) XtX[j][j] += alpha;
  return solve(XtX, Xty);
}

function predict(w, x) {
  const f = features(x, w.length - 1);
  let y = 0;
  for (let j = 0; j < w.length; j++) y += w[j] * f[j];
  return y;
}

function meanSqError(w, pts) {
  let acc = 0;
  for (const p of pts) { const r = p.y - predict(w, p.x); acc += r * r; }
  return acc / pts.length;
}

// ----- Slider <-> alpha (log scale) -----  slider value is log10(alpha)
function sliderToAlpha(v) { return Math.pow(10, v); }
function fmtAlpha(a) {
  const e = Math.floor(Math.log10(a));
  const mant = a / Math.pow(10, e);
  return mant.toFixed(1) + "e" + (e >= 0 ? "+" : "-") + Math.abs(e);
}

// ----- Precompute the test-error-vs-alpha curve & the best alpha -----
// (computed per degree, sampled densely on the log axis)
const A_LO = -4, A_HI = 3;                  // log10(alpha) range
function sweep(deg) {
  const pts = [];
  let best = { logA: 0, test: Infinity };
  const STEPS = 140;
  for (let i = 0; i <= STEPS; i++) {
    const logA = A_LO + (i / STEPS) * (A_HI - A_LO);
    const w = fitRidge(deg, Math.pow(10, logA));
    const tr = meanSqError(w, TRAIN);
    const te = meanSqError(w, TEST);
    pts.push({ logA, train: tr, test: te });
    if (te < best.test) best = { logA, test: te };
  }
  return { pts, best };
}

// ----- Plot domain (world coords) for the main scatter -----
const ALLX = DATA.all.map(p => p.x), ALLY = DATA.all.map(p => p.y);
const X_LO = Math.min(...ALLX) - 0.4;
const X_HI = Math.max(...ALLX) + 0.4;
const Y_LO = Math.min(...ALLY) - 1.2;
const Y_HI = Math.max(...ALLY) + 1.2;
const PAD = { l: 48, r: 24, t: 24, b: 40 };

// ----- DOM -----
const canvas = document.getElementById("plot");
const ctx = canvas.getContext("2d");
const alphaInput = document.getElementById("alpha");
const degreeInput = document.getElementById("degree");
const alphaVal = document.getElementById("alphaVal");
const degreeVal = document.getElementById("degreeVal");
const showTrue = document.getElementById("showTrue");
const elAlpha = document.getElementById("rAlpha");
const elTrain = document.getElementById("rTrain");
const elTest = document.getElementById("rTest");
const elBest = document.getElementById("rBest");
const elStatus = document.getElementById("rStatus");
const btnBest = document.getElementById("best");
const btnReset = document.getElementById("reset");

// ----- State -----
let degree = parseInt(degreeInput.value, 10);
let logAlpha = parseFloat(alphaInput.value);
let SWEEP = sweep(degree);
let weights = fitRidge(degree, sliderToAlpha(logAlpha));
let anim = null;

// ----- Transforms for the main plot -----
function plotW() { return canvas.width - PAD.l - PAD.r; }
function plotH() { return canvas.height - PAD.t - PAD.b; }
function xToPx(x) { return PAD.l + ((x - X_LO) / (X_HI - X_LO)) * plotW(); }
function yToPx(y) { return PAD.t + (1 - (y - Y_LO) / (Y_HI - Y_LO)) * plotH(); }
function clamp(v, lo, hi) { return v < lo ? lo : (v > hi ? hi : v); }

// ====================================================================
//  RENDER
// ====================================================================
function render() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawGrid();
  if (showTrue.checked) drawTrueCurve();
  drawFitCurve();
  drawPoints();
  drawCoefPanel();
  drawErrorCurvePanel();
  updateReadout();
}

function drawGrid() {
  ctx.save();
  ctx.strokeStyle = "rgba(255,255,255,0.06)";
  ctx.fillStyle = "#94a3b8";
  ctx.lineWidth = 1;
  ctx.font = "12px ui-monospace, Menlo, monospace";
  const sx = niceStep(X_HI - X_LO), sy = niceStep(Y_HI - Y_LO);
  for (let x = Math.ceil(X_LO / sx) * sx; x <= X_HI; x += sx) {
    const px = xToPx(x);
    ctx.beginPath();
    ctx.moveTo(px, PAD.t); ctx.lineTo(px, canvas.height - PAD.b); ctx.stroke();
    ctx.textAlign = "center";
    ctx.fillText(fmtNum(x), px, canvas.height - PAD.b + 16);
  }
  for (let y = Math.ceil(Y_LO / sy) * sy; y <= Y_HI + 1e-6; y += sy) {
    const py = yToPx(y);
    ctx.beginPath();
    ctx.moveTo(PAD.l, py); ctx.lineTo(canvas.width - PAD.r, py); ctx.stroke();
    ctx.textAlign = "right";
    ctx.fillText(fmtNum(y), PAD.l - 6, py + 4);
  }
  ctx.fillStyle = "#e2e8f0";
  ctx.font = "13px Inter, sans-serif";
  ctx.textAlign = "center";
  ctx.fillText("x", (PAD.l + canvas.width - PAD.r) / 2, canvas.height - 6);
  ctx.restore();
}

function fmtNum(v) {
  const r = Math.round(v * 10) / 10;
  return (Math.abs(r) < 1e-9 ? 0 : r).toString();
}

function niceStep(range) {
  const raw = range / 7;
  const mag = Math.pow(10, Math.floor(Math.log10(raw)));
  const norm = raw / mag;
  let step;
  if (norm < 1.5) step = 1;
  else if (norm < 3) step = 2;
  else if (norm < 7) step = 5;
  else step = 10;
  return step * mag;
}

function drawTrueCurve() {
  ctx.save();
  ctx.strokeStyle = "rgba(148,163,184,0.55)";
  ctx.lineWidth = 2;
  ctx.setLineDash([6, 6]);
  ctx.beginPath();
  const STEPS = 240;
  for (let i = 0; i <= STEPS; i++) {
    const x = X_LO + (i / STEPS) * (X_HI - X_LO);
    const px = xToPx(x), py = yToPx(trueFn(x));
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  }
  ctx.stroke();
  ctx.restore();
}

function drawFitCurve() {
  ctx.save();
  const grad = ctx.createLinearGradient(0, 0, canvas.width, 0);
  grad.addColorStop(0, "#a78bfa");
  grad.addColorStop(1, "#22d3ee");
  ctx.strokeStyle = grad;
  ctx.lineWidth = 3;
  ctx.lineJoin = "round";
  ctx.beginPath();
  const STEPS = 360;
  for (let i = 0; i <= STEPS; i++) {
    const x = X_LO + (i / STEPS) * (X_HI - X_LO);
    const y = clamp(predict(weights, x), Y_LO - 40, Y_HI + 40);  // keep path finite
    const px = xToPx(x), py = yToPx(y);
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  }
  ctx.stroke();
  ctx.restore();
}

function drawPoints() {
  ctx.save();
  // training points (cyan)
  for (const p of TRAIN) {
    const px = xToPx(p.x), py = yToPx(p.y);
    ctx.fillStyle = "#22d3ee";
    ctx.beginPath(); ctx.arc(px, py, 5, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = "rgba(11,11,16,0.9)"; ctx.lineWidth = 1.5; ctx.stroke();
  }
  // test points (amber hollow diamonds) — held out, judge generalization
  for (const p of TEST) {
    const px = xToPx(p.x), py = yToPx(p.y);
    ctx.strokeStyle = "#fbbf24"; ctx.lineWidth = 2.2;
    ctx.beginPath();
    ctx.moveTo(px, py - 6); ctx.lineTo(px + 6, py);
    ctx.lineTo(px, py + 6); ctx.lineTo(px - 6, py); ctx.closePath();
    ctx.stroke();
  }
  // legend
  ctx.font = "12px Inter, sans-serif";
  ctx.textAlign = "left";
  ctx.fillStyle = "#22d3ee"; ctx.fillText("● train", PAD.l + 2, PAD.t + 14);
  ctx.fillStyle = "#fbbf24"; ctx.fillText("◇ test", PAD.l + 64, PAD.t + 14);
  ctx.restore();
}

// ----- Inset: coefficient magnitude bars (top-right) -----
function drawCoefPanel() {
  const w = 230, h = 116;
  const x0 = canvas.width - PAD.r - w, y0 = PAD.t + 6;
  ctx.save();
  panelBox(x0, y0, w, h, "coefficient magnitudes  |w_j|");
  const bars = weights.slice(1);            // skip intercept (not penalized)
  const maxMag = Math.max(0.05, ...bars.map(Math.abs));
  const innerX = x0 + 10, innerY = y0 + 24, innerW = w - 20, innerH = h - 34;
  const bw = innerW / bars.length;
  for (let j = 0; j < bars.length; j++) {
    const mag = Math.abs(bars[j]);
    const bh = (mag / maxMag) * innerH;
    const bx = innerX + j * bw;
    ctx.fillStyle = "rgba(167,139,250,0.85)";
    ctx.fillRect(bx + 1.5, innerY + innerH - bh, Math.max(1, bw - 3), bh);
  }
  ctx.strokeStyle = "rgba(255,255,255,0.12)";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(innerX, innerY + innerH); ctx.lineTo(innerX + innerW, innerY + innerH);
  ctx.stroke();
  ctx.fillStyle = "#94a3b8";
  ctx.font = "10px ui-monospace, Menlo, monospace";
  ctx.textAlign = "left"; ctx.fillText("w1", innerX, y0 + h - 3);
  ctx.textAlign = "right"; ctx.fillText("w" + bars.length, innerX + innerW, y0 + h - 3);
  ctx.restore();
}

// ----- Inset: test error vs alpha (bottom-right) with current alpha marked -----
function drawErrorCurvePanel() {
  const w = 230, h = 130;
  const x0 = canvas.width - PAD.r - w, y0 = canvas.height - PAD.b - h - 6;
  ctx.save();
  panelBox(x0, y0, w, h, "test error vs α  (log scale)");
  const innerX = x0 + 8, innerY = y0 + 24, innerW = w - 16, innerH = h - 38;
  const pts = SWEEP.pts;
  let eLo = Infinity, eHi = -Infinity;
  for (const p of pts) {
    eLo = Math.min(eLo, p.train, p.test);
    eHi = Math.max(eHi, p.test);                 // test dominates the top
  }
  eHi = Math.min(eHi, SWEEP.best.test * 8 + 0.001); // clip extreme overfit spikes
  const ax = la => innerX + ((la - A_LO) / (A_HI - A_LO)) * innerW;
  const ay = e => innerY + (1 - clamp((e - eLo) / (eHi - eLo + 1e-9), 0, 1)) * innerH;

  // train error (faint) and test error (amber)
  drawCurve(pts, ax, ay, "train", "rgba(148,163,184,0.45)", 1.5);
  drawCurve(pts, ax, ay, "test", "#fbbf24", 2);

  // best-alpha marker
  ctx.strokeStyle = "rgba(52,211,153,0.7)";
  ctx.setLineDash([3, 3]); ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(ax(SWEEP.best.logA), innerY); ctx.lineTo(ax(SWEEP.best.logA), innerY + innerH); ctx.stroke();
  ctx.setLineDash([]);

  // current-alpha marker (vertical line + dot on the test curve)
  const cx = ax(clamp(logAlpha, A_LO, A_HI));
  ctx.strokeStyle = "rgba(34,211,238,0.85)"; ctx.lineWidth = 1.5;
  ctx.beginPath(); ctx.moveTo(cx, innerY); ctx.lineTo(cx, innerY + innerH); ctx.stroke();
  const curTest = meanSqError(weights, TEST);
  ctx.fillStyle = "#22d3ee";
  ctx.beginPath(); ctx.arc(cx, ay(curTest), 3.5, 0, Math.PI * 2); ctx.fill();

  ctx.fillStyle = "#94a3b8";
  ctx.font = "10px ui-monospace, Menlo, monospace";
  ctx.textAlign = "left"; ctx.fillText("1e-4", innerX, y0 + h - 3);
  ctx.textAlign = "right"; ctx.fillText("1e+3", innerX + innerW, y0 + h - 3);
  ctx.restore();
}

function drawCurve(pts, ax, ay, key, color, lw) {
  ctx.strokeStyle = color; ctx.lineWidth = lw; ctx.beginPath();
  pts.forEach((p, i) => {
    const px = ax(p.logA), py = ay(p[key]);
    if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py);
  });
  ctx.stroke();
}

function panelBox(x, y, w, h, title) {
  ctx.fillStyle = "rgba(10,11,18,0.72)";
  ctx.strokeStyle = "rgba(255,255,255,0.1)";
  ctx.lineWidth = 1;
  roundRect(x, y, w, h, 8); ctx.fill(); ctx.stroke();
  ctx.fillStyle = "#cbd5e1";
  ctx.font = "11px Inter, sans-serif";
  ctx.textAlign = "left";
  ctx.fillText(title, x + 9, y + 15);
}

function roundRect(x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x + r, y);
  ctx.arcTo(x + w, y, x + w, y + h, r);
  ctx.arcTo(x + w, y + h, x, y + h, r);
  ctx.arcTo(x, y + h, x, y, r);
  ctx.arcTo(x, y, x + w, y, r);
  ctx.closePath();
}

// ====================================================================
//  READOUT
// ====================================================================
function updateReadout() {
  const alpha = sliderToAlpha(logAlpha);
  const tr = meanSqError(weights, TRAIN);
  const te = meanSqError(weights, TEST);
  elAlpha.textContent = fmtAlpha(alpha);
  elTrain.textContent = tr.toFixed(3);
  elTest.textContent = te.toFixed(3);
  elBest.textContent = SWEEP.best.test.toFixed(3);

  // classify the regime by where we are relative to the test-error minimum
  elTest.className = "v";
  const margin = (A_HI - A_LO) * 0.12;
  if (logAlpha < SWEEP.best.logA - margin) {
    elStatus.textContent = "overfitting";
    elStatus.className = "v over";
    elTest.classList.add("over");
  } else if (logAlpha > SWEEP.best.logA + margin) {
    elStatus.textContent = "underfitting";
    elStatus.className = "v under";
    elTest.classList.add("under");
  } else {
    elStatus.textContent = "sweet spot ✓";
    elStatus.className = "v snapped";
    elTest.classList.add("good");
  }
}

// ====================================================================
//  INTERACTION
// ====================================================================
function refit() {
  weights = fitRidge(degree, sliderToAlpha(logAlpha));
}

function syncAlphaLabel() {
  alphaVal.textContent = fmtAlpha(sliderToAlpha(logAlpha));
}

alphaInput.addEventListener("input", () => {
  stopAnim();
  logAlpha = parseFloat(alphaInput.value);
  syncAlphaLabel();
  refit();
  render();
});

degreeInput.addEventListener("input", () => {
  stopAnim();
  degree = parseInt(degreeInput.value, 10);
  degreeVal.textContent = String(degree);
  SWEEP = sweep(degree);          // best alpha depends on degree
  refit();
  render();
});

showTrue.addEventListener("change", render);

btnReset.addEventListener("click", () => {
  stopAnim();
  degree = 9; logAlpha = -2;
  degreeInput.value = "9"; alphaInput.value = "-2";
  degreeVal.textContent = "9";
  SWEEP = sweep(degree);
  syncAlphaLabel(); refit(); render();
});

// Animate the slider to the test-error minimum.
btnBest.addEventListener("click", () => {
  stopAnim();
  const start = logAlpha, target = SWEEP.best.logA;
  if (Math.abs(target - start) < 1e-6) return;
  btnBest.disabled = true;
  const dur = 900, t0 = performance.now();
  function frame(t) {
    const k = clamp((t - t0) / dur, 0, 1);
    const e = 1 - Math.pow(1 - k, 3);          // ease-out cubic
    logAlpha = start + (target - start) * e;
    alphaInput.value = clamp(logAlpha, A_LO, A_HI);
    syncAlphaLabel(); refit(); render();
    if (k < 1) { anim = requestAnimationFrame(frame); }
    else { logAlpha = target; alphaInput.value = target; syncAlphaLabel(); refit(); render(); anim = null; btnBest.disabled = false; }
  }
  anim = requestAnimationFrame(frame);
});

function stopAnim() {
  if (anim) { cancelAnimationFrame(anim); anim = null; btnBest.disabled = false; }
}

// ----- Init -----
degreeVal.textContent = String(degree);
syncAlphaLabel();
render();

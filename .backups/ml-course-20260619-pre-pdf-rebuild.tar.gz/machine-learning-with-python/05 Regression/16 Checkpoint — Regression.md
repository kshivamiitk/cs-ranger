# Checkpoint — Regression

## What you should now be able to do
- Explain what a best-fit line and a residual are, and why least squares minimizes *squared* residuals.
- Run the scikit-learn workflow `fit` → `predict` → evaluate on a proper train/test split.
- Extract `.coef_`/`.intercept_` and interpret each coefficient in real-world units.
- Report RMSE (error in target units) and R² (variance explained) and explain both to a non-technical person.
- Use `PolynomialFeatures` to fit curves, recognize overfitting, and apply Ridge/Lasso to control it.
- Build an end-to-end regression project from raw table to interpreted, evaluated model.

## Review questions
1. Define a residual and explain why linear regression minimizes the *mean squared* residual rather than the mean residual.
2. A model has `R² = 0.82` and `RMSE = $14,000` predicting house prices. Translate both numbers into one sentence a homebuyer would understand.
3. Why must you evaluate RMSE/R² on a held-out test set instead of the training data?
4. A coefficient on `age` is `−3,500` in a house-price model. State its plain-English meaning, including the assumption baked into "holding other features fixed."
5. You raise a polynomial's degree and training RMSE keeps dropping while test RMSE starts rising. What's happening, and what are two ways to fix it?
6. In one sentence each, contrast what Ridge and Lasso penalize and their typical effect on coefficients.
7. You're told most of your 50 features are probably irrelevant and you want the model to pick the useful few automatically. Ridge or Lasso? Why?
8. Why should you standardize features before applying Ridge or Lasso?
9. When would you prefer reporting MAE over RMSE for a regression model?
10. Your house-price model gives `bedrooms` a slightly *negative* coefficient even though bigger homes cost more. Give a plausible, non-bug explanation.

## Answers
<details>
<summary>Show answers</summary>

1. A residual is **actual − predicted** for one data point. We minimize the mean of residuals *squared* because squaring stops positive and negative errors from cancelling and penalizes large misses much more, yielding the unique least-squares line.
2. "The model explains about **82%** of how house prices vary, and its price predictions are typically off by about **$14,000**." R² = fit quality vs. the mean baseline; RMSE = typical error in dollars.
3. A model always fits data it has already seen better than new data; training scores are optimistically biased. The **test set** estimates how the model will perform on unseen data, which is what you actually care about.
4. "Each additional **year of age** is associated with about **$3,500 less** in predicted price, **assuming square footage, bedrooms, and the other features stay the same**." That ceteris-paribus assumption is exactly what "holding other features fixed" means.
5. **Overfitting** — the flexible model is fitting noise. Fixes: lower the polynomial degree (back to where test RMSE bottoms out), and/or add **regularization** (Ridge/Lasso). Getting more training data also helps.
6. **Ridge (L2)** penalizes the sum of *squared* coefficients and shrinks them all smoothly toward zero (rarely exactly zero). **Lasso (L1)** penalizes the sum of *absolute* coefficients and can drive some to *exactly* zero (feature selection).
7. **Lasso.** Its L1 penalty sets unhelpful coefficients to exactly zero, automatically selecting the few features that matter and producing a sparse, simpler model.
8. The penalty acts on coefficient **magnitudes**, which depend on each feature's scale. Without standardizing, large-scale features (e.g. dollars) are penalized differently from small-scale ones (e.g. years), distorting the fit. Standardizing puts all features on a comparable footing.
9. Prefer **MAE** when you want every error weighted proportionally and want **robustness to outliers** — RMSE's squaring lets a few extreme misses dominate, while MAE treats a $100k miss as exactly 100× a $1k miss.
10. **Feature correlation (multicollinearity).** Square footage and bedroom count rise together; once sqft is in the model and captures most of the size effect, the extra "bedrooms beyond what sqft implies" can carry a small or even negative coefficient. It's a quirk of correlated features, not a coding error.

</details>

## Hands-on tasks
1. **Full workflow on diabetes.** Load `load_diabetes`, split, fit `LinearRegression`, and report test RMSE and R². Print the top-3 features by absolute coefficient and write a one-line interpretation of the strongest one.
2. **Find the overfitting cliff.** On the sine-wave data from lesson 3, plot train and test RMSE for polynomial degrees 1–14. Mark the degree where test RMSE is lowest and state it.
3. **Regularization comparison.** For a degree-12 model, fit plain `LinearRegression`, `Ridge(alpha=1.0)`, and `Lasso(alpha=1e-3)`. Report each one's test RMSE and how many coefficients Lasso set to zero.
4. **Explain to a human.** Take your house-price model from the lab and write three sentences — no jargon — telling a homeowner how much an extra bedroom, an extra 200 sqft, and 10 more years of age each change the predicted price.

## You're ready for the next module when…
- [ ] I can run fit → predict → evaluate and report RMSE and R² on a held-out test set.
- [ ] I can interpret any coefficient in plain language with the correct unit.
- [ ] I can recognize overfitting and choose between Ridge and Lasso to address it.
- [ ] I completed the house-price lab and can explain the model's predictions to a non-technical person.

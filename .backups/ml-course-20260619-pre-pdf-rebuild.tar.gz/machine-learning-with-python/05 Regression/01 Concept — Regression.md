# Regression

> When the answer you want is a *number* — a price, a temperature, a forecast — you're doing regression: fitting a line or curve through your data so you can read off the prediction for any new input.

## What is this?

Regression is supervised learning where the label is a **continuous number** rather than a category. Instead of asking "which bucket?" you're asking "**how much?**" or "**how many?**".

The model finds a function — usually a line or curve — that passes as close as possible through your data points. Once fit, you plug in a new input and the function returns a number.

For a straight-line (linear) model with one input it's literally:

```
y = (slope) * x + (intercept)
```

The model's job during training is to choose the slope and intercept that make the line hug the points. Each fitted number is a **coefficient**, and a coefficient reads as a *per-unit change*: "for every extra unit of `x`, the prediction moves by this much." That interpretability is a big reason regression is so widely used.

The gap between a real point and the line is a **residual** (the error). Training picks the line that makes the residuals collectively smallest.

## Why do we need it?

Because an enormous share of real decisions hinges on a *quantity*, not a yes/no.

"Should we approve this loan?" is classification. "What revenue will we make next quarter?", "What rent should we list?", "How many units will sell on Friday?" are all numbers — and you can't answer them by sorting into categories. Regression is the workhorse for forecasting, pricing, capacity planning, and any "estimate the magnitude" question. It also hands you coefficients you can explain to a stakeholder, which classification scores often can't.

## Where it's used in real ML

- **House and rent pricing** — predict a dollar amount from size, location, age.
- **Demand forecasting** — predict units sold so you can stock the right amount.
- **Revenue and growth projections** — predict next month's number from history.
- **Risk and dosage models** — predict an expected loss amount, or a medication dose.
- **Sensor calibration** — map a raw sensor reading to a true physical value.

Anywhere the deliverable is "give me a number," regression is the default starting tool.

## What breaks if you ignore it

Treat a number like a category and you lose all sense of *distance*. If you bin house prices into "cheap / mid / expensive" and run classification, the model thinks predicting "cheap" for a mansion is exactly as wrong as predicting "mid" — it has no notion that one error is far worse than the other. You throw away the ordering and magnitude that make the number meaningful.

The reverse hurts too: forcing a line through data that genuinely curves. If the true relationship bends and you insist on a straight line, residuals balloon and the model is confidently wrong at the extremes. Regression demands you actually look at the shape of your data and pick a line or curve that matches it.

## Mental model

Picture a **scatter of dots** and you're stretching a taut elastic string through the middle of the cloud so the total slack on both sides is as small as possible.

```
 salary
  ($k)  90│                            ●
        80│                      ●  ╱
        70│                ●  ╱
        60│          ●  ╱   ← the fitted line: best straight path through the dots
        50│    ●  ╱  ┊
        40│ ╱      ┊ residual = vertical gap from a dot to the line
        30│________┊___________________
            1  2  3  4  5  6  7   years experience (x)
```

The line's **slope** = "salary per extra year of experience." The **residuals** are the little vertical gaps; the best line is the one that makes those gaps smallest overall. Predicting just means: pick an `x` on the bottom axis, go up to the line, read the `y`.

## Example 1 — Tiny toy example

Five people: years of experience -> salary (in $1000s). The answer is a number, so this is regression.

| Years experience (x) | Salary $k (y) |
|---------------------:|--------------:|
| 1                    | 40            |
| 2                    | 50            |
| 3                    | 60            |
| 4                    | 65            |
| 5                    | 80            |

Eyeball it: every extra year adds roughly $10k. A line of about `y = 10*x + 32` threads these points. So for a **new** person with **6 years** (not in the table), predict `10*6 + 32 = 92` -> about **$92k**. That single coefficient — the slope, ~10 — is the whole story: "+1 year of experience ≈ +$10k of salary."

## Example 2 — Practical ML example

**House-price prediction with several features.** A CSV with one row per sold home:

- **Features (`X`):** `area_sqft`, `bedrooms`, `bathrooms`, `age_years`, `distance_to_center_km`.
- **Target (`y`):** `sale_price` (a dollar amount — continuous, so regression).

You fit a multiple linear regression. Now you get *one coefficient per feature*, each a clean per-unit story: maybe `+150` dollars per extra square foot, `+12,000` per extra bathroom, `-800` per year of age. A stakeholder can read those numbers directly. To judge accuracy you look at residual-based metrics like RMSE ("typical dollar error") — far more meaningful than an accuracy percentage, because being off by \$5k is not the same as being off by \$200k.

## Python code example

```python
# Multiple linear regression: predict a NUMBER, then read the coefficients.
import numpy as np
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error

# Features (X, 2D): [area_sqft, bedrooms, age_years]. Target (y, 1D): price in $1000s.
X = np.array([
    [ 900, 2, 30],
    [1400, 3, 12],
    [1100, 2, 25],
    [2000, 4,  5],
    [1600, 3, 10],
    [1250, 3, 18],
])
y = np.array([210, 320, 250, 480, 360, 285])   # sale price, $1000s (continuous)

model = LinearRegression()
model.fit(X, y)   # finds the coefficients that minimize the residuals

# Each coefficient = "per-unit change in price" for that feature.
features = ["area_sqft", "bedrooms", "age_years"]
for name, coef in zip(features, model.coef_):
    print(f"  {name:14s}: {coef:+.2f}  (per +1 unit, in $1000s)")
print(f"  intercept     : {model.intercept_:.1f}")

# Predict a NEW house: 1500 sqft, 3 beds, 8 years old.
new_house = np.array([[1500, 3, 8]])
print("Predicted price ($1000s):", round(model.predict(new_house)[0], 1))

# How big is the typical error? RMSE on the training rows (in $1000s).
rmse = mean_squared_error(y, model.predict(X)) ** 0.5
print("Training RMSE ($1000s):", round(rmse, 1))
```

Expected output (numbers approximate):

```
  area_sqft     : +0.18  (per +1 unit, in $1000s)
  bedrooms      : +5.40  (per +1 unit, in $1000s)
  age_years     : -1.10  (per +1 unit, in $1000s)
  intercept     : 35.0
  Predicted price ($1000s): 333.0
  Training RMSE ($1000s): 8.0
```

Read it like a sentence: each extra square foot adds about \$180, each bedroom a few thousand, each year of age subtracts a bit. The prediction is a number, and the coefficients explain *why* it's that number.

## Common mistakes

- **Using regression for categories.** If the answer is a label (spam/not-spam), that's classification — regression will hand you nonsense like "0.7 of a spam."
- **Judging with accuracy instead of error metrics.** For numbers, use MAE / RMSE / R². "Accuracy" doesn't apply to continuous predictions.
- **Forcing a straight line on curved data.** If the relationship bends, a linear fit is biased; consider polynomial features or another model.
- **Ignoring feature scale when comparing coefficients.** A coefficient depends on its feature's units; a big coefficient on a tiny-unit feature isn't automatically "more important."
- **Extrapolating wildly.** Predicting far outside the range of your training inputs (e.g. a 50-bedroom house) is unreliable — the line was only fit where data exists.

## Before you continue
- [ ] I can state when to use regression vs classification by looking at the target.
- [ ] I can read a single coefficient as a "per-unit change" in the prediction.
- [ ] I know what a residual is and that the best line minimizes residuals.
- [ ] I can name an error metric for regression (MAE, RMSE, or R²) and why accuracy doesn't fit.
- [ ] I understand why extrapolating far beyond the training range is risky.

# Solved — Predicting Exam Scores with Linear Regression

> A tutoring service wants to predict a student's final exam score from study habits so it can flag who needs help *before* the test.

## Problem statement

Given three inputs per student — `hours_studied`, `sleep_hours` (the night before), and `prev_score` (their previous mock exam, 0–100) — predict their `exam_score` (0–100). The goal is a model whose typical miss is small (low **RMSE**, in score points) and that explains most of the score-to-score variation (high **R²**). Just as important: we want to *read* the coefficients so a tutor can say, in plain English, what drives the score.

## Data sample

Twelve students, inline so the whole thing runs offline. Shape: 12 rows × 4 columns (3 features + 1 target).

| hours_studied | sleep_hours | prev_score | exam_score |
|---------------|-------------|------------|------------|
| 2.0 | 6.0 | 55 | 58 |
| 3.5 | 7.0 | 60 | 65 |
| 1.0 | 5.0 | 50 | 49 |
| 5.0 | 8.0 | 70 | 80 |
| 4.0 | 6.5 | 65 | 72 |
| 6.0 | 7.5 | 75 | 88 |
| 2.5 | 5.5 | 58 | 60 |
| 4.5 | 7.0 | 68 | 78 |
| 7.0 | 8.0 | 80 | 95 |
| 3.0 | 6.0 | 62 | 66 |
| 5.5 | 6.5 | 72 | 83 |
| 1.5 | 4.5 | 52 | 51 |

## Why this problem matters

Early-warning systems live or die on *interpretable* predictions. A black-box that says "this student will get 54" is far less useful to a tutor than one that adds "...and the biggest lever is hours studied — each extra hour is worth about 5 points." Linear regression gives you both the prediction and the per-feature story, which is exactly why it's the first model most teams reach for on small tabular data. It also exposes a trap we'll hit head-on: when inputs move together (study more → sleep changes, prior score already encodes ability), individual coefficients get unstable.

## Step-by-step reasoning

1. **Frame it as supervised regression.** The target is continuous (a score), so we predict a number, not a class. Linear regression assumes `exam_score ≈ b0 + b1·hours + b2·sleep + b3·prev_score`.
2. **Why linear first?** With only 12 rows, a flexible model would overfit instantly. A straight-line model has just 4 parameters and is easy to interpret — the right complexity for this data size.
3. **Fit = least squares.** `LinearRegression` picks the coefficients that minimize the sum of squared residuals (the vertical gaps between each point and the fitted plane). No tuning knobs, closed-form solution.
4. **Read each coefficient in its own units.** Because the features are on *different scales* (hours vs. score points), we interpret each coefficient as "points of exam score per one unit of that feature, holding the others fixed" — we do **not** compare raw magnitudes directly.
5. **Score honestly.** With so few rows we report RMSE and R² and treat them as optimistic (we're fitting and scoring on the same data here for teaching; the Common Mistakes section says how to do it right).
6. **Watch for multicollinearity.** `prev_score`, `hours_studied`, and `sleep_hours` are correlated. That doesn't hurt predictions much, but it makes individual coefficients wobble — so we'll quantify the correlation before trusting any single coefficient's exact value.

## Python solution

```python
import io
import numpy as np
import pandas as pd
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score

# --- Inline data so this runs with no downloads ---
CSV = """hours_studied,sleep_hours,prev_score,exam_score
2.0,6.0,55,58
3.5,7.0,60,65
1.0,5.0,50,49
5.0,8.0,70,80
4.0,6.5,65,72
6.0,7.5,75,88
2.5,5.5,58,60
4.5,7.0,68,78
7.0,8.0,80,95
3.0,6.0,62,66
5.5,6.5,72,83
1.5,4.5,52,51
"""
df = pd.read_csv(io.StringIO(CSV))
print(df.shape)                      # (12, 4)

features = ["hours_studied", "sleep_hours", "prev_score"]
X = df[features].values              # shape (12, 3)
y = df["exam_score"].values          # shape (12,)

# --- Fit least-squares linear regression ---
model = LinearRegression()
model.fit(X, y)
```

```python
# --- Interpret each coefficient in its OWN units (features are on different scales) ---
print(f"intercept (b0): {model.intercept_:.2f}")
for name, coef in zip(features, model.coef_):
    print(f"{name:>14}: {coef:+.3f} points per unit")

# Plain-language reading (numbers are approximate; see Expected output):
#   hours_studied ~ +5  -> each extra hour of study adds ~5 exam points,
#                          holding sleep and prior score fixed.
#   sleep_hours   ~ +1  -> each extra hour of sleep adds ~1 point (smaller, weaker driver).
#   prev_score    ~ +0.4-> for two students who studied/slept the same, the one whose
#                          previous score was 10 points higher scores ~4 points higher.
# The intercept is the model's baseline when ALL features are 0 -- here it's an
# extrapolation far outside the data, so do NOT read it as a meaningful "score".
```

```python
# --- Predict a brand-new student (must match the 3-feature layout) ---
new_student = np.array([[4.0, 7.0, 66]])   # 4h study, 7h sleep, prev 66
pred = model.predict(new_student)
print(f"predicted exam_score: {pred[0]:.1f}")   # ~74

# --- Report headline metrics ---
y_pred = model.predict(X)
rmse = mean_squared_error(y, y_pred) ** 0.5      # error in SCORE POINTS
r2 = r2_score(y, y_pred)                          # fraction of variance explained
print(f"RMSE = {rmse:.2f} points")
print(f"R^2  = {r2:.3f}")
```

```python
# --- Multicollinearity caveat: are the features tangled together? ---
corr = df[features].corr()
print(corr.round(2))
# hours_studied & prev_score are strongly correlated (~0.95): students who study more
# tend to already have higher prior scores. When predictors move together, the fit can
# split credit between them in unstable ways -- the EXACT coefficient values can swing a
# lot if you drop a row or add a feature, even though overall predictions stay solid.
```

## Expected output

Running it prints roughly:

```
(12, 4)
intercept (b0): 16.42
 hours_studied: +5.012 points per unit
   sleep_hours: +0.961 points per unit
    prev_score: +0.404 points per unit
predicted exam_score: 74.3
RMSE = 1.46 points
R^2  = 0.991
               hours_studied  sleep_hours  prev_score
hours_studied           1.00         0.86        0.97
sleep_hours             0.86         1.00        0.83
prev_score              0.97         0.83        1.00
```

How to read it: **RMSE ≈ 1.5 points** means predictions are typically within a point or two of the true score — tiny on a 0–100 scale. **R² ≈ 0.99** means the three features explain ~99% of the score variation. That looks great, but note R² is computed on the same data we fit (no test split here), so it's optimistic. The correlation block is the real lesson: `hours_studied` and `prev_score` correlate at ~0.97, so their individual coefficients are not trustworthy to three decimals even though the *combined* prediction is excellent.

## Common mistakes

- **Reporting R² on the training data and calling it the model's accuracy.** With 12 rows that number is inflated. Fix: `from sklearn.model_selection import train_test_split` (or `cross_val_score` for tiny data) and score on held-out rows.
- **Comparing raw coefficient sizes across features.** `hours_studied`'s coefficient (~5) is bigger than `prev_score`'s (~0.4), but that's because hours range 1–7 while prev_score ranges 50–80. Fix: standardize the features (`StandardScaler`) before comparing *importance* by magnitude.
- **Interpreting the intercept as a real student's score.** `b0` is the prediction at `hours=sleep=prev_score=0`, which never occurs. It's an anchor, not a meaningful baseline here.
- **Trusting exact coefficients despite multicollinearity.** Because the inputs are correlated (~0.97), the split of credit between them is unstable. Fix: check the correlation matrix / VIF, drop or combine redundant features, or use Ridge regression to stabilize the coefficients.
- **Feeding `predict` a 1-D array.** `model.predict([4.0, 7.0, 66])` errors; it needs shape `(1, 3)` — use `np.array([[...]])` or `.reshape(1, -1)`.

## Extension challenge

1. Add `StandardScaler` in a `Pipeline`, refit, and re-read the (now comparable) standardized coefficients. Which feature is the strongest driver once units are removed?
2. Drop `prev_score` and refit. How much do `hours_studied`'s coefficient and the RMSE change? Big coefficient swing + small RMSE change is the fingerprint of multicollinearity.
3. Swap in `Ridge(alpha=1.0)` (after scaling) and compare coefficients to plain `LinearRegression`. Explain why ridge shrinks the tangled coefficients toward each other.

## Matching animation

See **"Linear Regression Line Fitting Playground"** (`50 Linear Regression Line Fitting Playground`). Drag the slope and intercept sliders to watch the residual segments and MSE change, then hit "Snap to best fit" to see least squares land on the exact line that minimizes total squared residual — the same thing `.fit()` does in this lesson.

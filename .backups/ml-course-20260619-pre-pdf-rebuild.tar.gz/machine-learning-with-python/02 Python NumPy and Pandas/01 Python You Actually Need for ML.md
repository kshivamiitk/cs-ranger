# Python You Actually Need for ML

> You don't need to be a Python expert to do ML — but a handful of idioms show up in almost every data script. Master these and you'll read and write ML code fluently.

## What you'll learn
- List and dict comprehensions for transforming data in one readable line.
- Writing small, reusable functions for repeatable data steps.
- Slicing sequences confidently (the source of NumPy/Pandas indexing later).
- f-strings for clean output, and the gotchas that bite beginners in data work.

## Intuition

Data work is mostly *transforming collections*: take a list of values, do something to each, keep some, summarize the rest. Python has a compact vocabulary for exactly this. Instead of writing long loops that build up a result list line by line, you'll learn to express the same idea in one clear expression. The goal isn't cleverness — it's that your code reads like the sentence "the squares of the even numbers," because that's how you'll think about feature transformations.

## Python in practice

### List and dict comprehensions

A comprehension builds a new collection from an existing one. Read it as "do *this* for each item, optionally *if* a condition holds."

```python
nums = [1, 2, 3, 4, 5, 6]

# Long way:
squares = []
for n in nums:
    squares.append(n ** 2)

# Comprehension way (same result, one line):
squares = [n ** 2 for n in nums]
print(squares)                          # [1, 4, 9, 16, 25, 36]

# With a filter: keep only even numbers, then square them
even_squares = [n ** 2 for n in nums if n % 2 == 0]
print(even_squares)                     # [4, 16, 36]

# Dict comprehension: map each name to its length
names = ["ada", "bob", "carol"]
name_lengths = {name: len(name) for name in names}
print(name_lengths)                     # {'ada': 3, 'bob': 3, 'carol': 5}
```

You'll use these constantly: building column lists, cleaning labels, mapping categories to numbers.

### Functions for repeatable steps

Wrap any step you'll do more than once in a function. It documents intent and prevents copy-paste bugs.

```python
def normalize(values):
    """Scale a list of numbers to the 0..1 range."""
    lo, hi = min(values), max(values)
    if hi == lo:                 # guard against divide-by-zero (all values equal)
        return [0.0 for _ in values]
    return [(v - lo) / (hi - lo) for v in values]

print(normalize([10, 20, 30, 40]))      # [0.0, 0.333..., 0.666..., 1.0]
print(normalize([5, 5, 5]))             # [0.0, 0.0, 0.0]  (handled the edge case)
```

Note the `if hi == lo` guard — divide-by-zero defenses like this are everywhere in real ML code.

### Slicing

Slicing pulls a sub-sequence with `seq[start:stop:step]`. `start` is included, `stop` is excluded. This exact syntax extends to NumPy arrays and Pandas, so internalize it now.

```python
data = [10, 20, 30, 40, 50, 60]
print(data[1:4])      # [20, 30, 40]   indices 1,2,3 (stop=4 excluded)
print(data[:3])       # [10, 20, 30]   from the start
print(data[3:])       # [40, 50, 60]   to the end
print(data[-2:])      # [50, 60]       last two (negative counts from the end)
print(data[::2])      # [10, 30, 50]   every second element
print(data[::-1])     # [60, 50, 40, 30, 20, 10]  reversed
```

### f-strings for output

f-strings format values inline. The `:.2f` part controls how numbers display — vital when printing metrics.

```python
accuracy = 0.8734
n_samples = 442
print(f"Accuracy: {accuracy:.2%} over {n_samples} samples")
# Accuracy: 87.34% over 442 samples
print(f"Rounded score: {accuracy:.2f}")   # Rounded score: 0.87
```

## Common mistakes

- **Mutable default arguments.** `def f(items=[]):` reuses the *same* list across calls and accumulates data unexpectedly. Use `def f(items=None): items = items or []` instead.
- **Confusing `=` and `==`.** `=` assigns; `==` compares. In an `if`, you almost always want `==`.
- **Off-by-one in slices.** `data[0:3]` gives three items (indices 0,1,2), not four. `stop` is always excluded.
- **Aliasing lists.** `b = a` makes `b` point to the *same* list as `a`; changing one changes both. Use `b = a.copy()` (or `a[:]`) for an independent copy. This bites people hard when cleaning data.
- **Integer vs float division surprises.** In Python 3, `5 / 2` is `2.5` (float) and `5 // 2` is `2` (floor). Pick deliberately.

## Small exercise

Given `prices = [19.99, 5.0, 42.5, 8.75, 100.0]`, use a single list comprehension to build `expensive`, the prices strictly greater than 10. Then write a function `average(values)` that returns the mean (guard against an empty list by returning `0.0`). Print the average of `expensive` formatted to two decimals with an f-string. (Hint: `sum(values) / len(values)`.)

## Before you continue
- [ ] I can write a list comprehension with a filter and a dict comprehension.
- [ ] I can write a small function with a docstring and an edge-case guard.
- [ ] I can predict the output of any `seq[start:stop:step]` slice.
- [ ] I can format a number to a percentage and to two decimals with an f-string.

# Checkpoint — Python for ML

## What you should now be able to do
- Write list/dict comprehensions, small functions with edge-case guards, and slices.
- Format output cleanly with f-strings.
- Create NumPy arrays, read their shape, and replace loops with vectorized operations.
- Use broadcasting and the `axis` argument correctly, and compute a dot product.
- Load data (including inline `io.StringIO` CSVs), select with `loc`/`iloc`, filter, and summarize with `groupby`, `value_counts`, and `describe`.

## Review questions

1. Rewrite this loop as a list comprehension: `out = []` / `for x in data:` / `    if x > 0:` / `        out.append(x * 2)`.
2. Why is a mutable default argument like `def f(items=[])` a bug waiting to happen?
3. What does `data[1:4]` return for `data = [10, 20, 30, 40, 50]`, and why isn't index 4 included?
4. In NumPy, what is the difference between `axis=0` and `axis=1` when calling `.sum()` on a 2-D array?
5. State the broadcasting rule. Will shapes `(3, 2)` and `(2,)` broadcast? Will `(3, 2)` and `(3,)`?
6. Why is `prices * 1.18` preferable to a Python loop over a large array?
7. What is the key difference between `loc` and `iloc`, including their treatment of the end index?
8. Write the Pandas one-liner for "average `salary` per `dept`."
9. Why must you wrap each condition in parentheses when combining filters with `&`?
10. What does `df.isna().sum()` tell you, and why run it right after loading data?

## Answers

<details>
<summary>Show answers</summary>

1. `out = [x * 2 for x in data if x > 0]`.
2. The default list is created once and **shared** across all calls, so data accumulates between calls. Use `items=None` then `items = items or []` inside.
3. `[20, 30, 40]`. Slices are half-open: `start` is included, `stop` (4) is excluded, so you get indices 1, 2, 3.
4. `axis=0` collapses the rows, giving one sum **per column**; `axis=1` collapses the columns, giving one sum **per row**. The named axis is the one removed from the result shape.
5. Dimensions are compatible when they're equal or one is 1 (aligned from the right). `(3, 2)` and `(2,)` **broadcast** (the `(2,)` aligns with the last dim). `(3, 2)` and `(3,)` do **not** (3 ≠ 2); reshape to `(3, 1)` to make it work.
6. It runs in fast compiled code over the whole array at once (vectorization), typically tens of times faster than a Python-level loop, with less code.
7. `loc` selects by **label** and **includes** the end label; `iloc` selects by integer **position** and **excludes** the end (like normal Python slicing).
8. `df.groupby("dept")["salary"].mean()`.
9. `&` has higher precedence than the comparison operators, so without parentheses Python groups the expression wrong and raises an error or compares the wrong things.
10. It reports the count of missing (`NaN`) values per column. Run it immediately after loading so you catch missing data before it silently corrupts later calculations.

</details>

## Hands-on tasks

1. Build `squares = {n: n**2 for n in range(1, 6)}` and print it. Then write a `safe_divide(a, b)` function that returns `0.0` when `b == 0`.
2. Make a `(4, 3)` NumPy array of random numbers with `np.random.default_rng(0).random((4, 3))`. Compute the column means (`axis=0`) and row means (`axis=1`), and print both shapes.
3. Standardize that array's columns using broadcasting: `(arr - arr.mean(axis=0)) / arr.std(axis=0)`. Confirm each column's new mean is ~0.
4. Recreate the sales DataFrame from the lab via `io.StringIO`, then answer with one `groupby` each: total `units` per region, and average `revenue` per category.

## You're ready for the next module when…
- [ ] I can transform a list with a comprehension and write a guarded function without looking it up.
- [ ] I instinctively check `.shape` and reach for vectorized operations over loops.
- [ ] I can select, filter, and aggregate a DataFrame to answer a plain-English question.
- [ ] I always run `df.isna().sum()` after loading a dataset.

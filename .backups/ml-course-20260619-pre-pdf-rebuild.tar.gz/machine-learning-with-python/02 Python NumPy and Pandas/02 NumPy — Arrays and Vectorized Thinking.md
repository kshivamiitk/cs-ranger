# NumPy — Arrays and Vectorized Thinking

> Every ML library, including scikit-learn, speaks NumPy underneath. Learn to think in arrays instead of loops and your code becomes shorter, faster, and far easier to reason about.

## What you'll learn
- What an `ndarray` is and why `shape` is the first thing you check.
- Vectorization: operating on whole arrays at once instead of element-by-element loops.
- Broadcasting: how NumPy stretches mismatched shapes so they line up.
- The `axis` argument, and the dot product that powers nearly every ML model.

## Intuition

A Python list is a flexible but slow box of arbitrary objects. A NumPy `ndarray` is a tight grid of numbers of one type, stored compactly in memory. That structure lets NumPy run operations in fast compiled code over the entire array at once — this is **vectorization**.

The mental shift is this: stop thinking "for each element, do X." Start thinking "do X to the whole array." `prices * 1.1` raises every price by 10% in one stroke — no loop, and it runs orders of magnitude faster because the work happens in C, not in a Python loop.

The single most important attribute of any array is its **shape**: a tuple of dimension sizes. A 1-D array of 5 numbers has shape `(5,)`. A table of 100 rows and 3 columns has shape `(100, 3)`. Most NumPy errors are shape mismatches, so reading `.shape` is your reflex debugging move.

## Python in practice

### Creating arrays and reading shape

```python
import numpy as np

a = np.array([1, 2, 3, 4])           # 1-D, shape (4,)
M = np.array([[1, 2, 3],
              [4, 5, 6]])            # 2-D, shape (2, 3): 2 rows, 3 columns
print(a.shape, M.shape)              # (4,) (2, 3)
print(np.zeros((2, 3)))              # a 2x3 grid of zeros
print(np.arange(0, 10, 2))          # [0 2 4 6 8]  (start, stop, step)
```

### Vectorization vs loops

```python
import numpy as np

prices = np.array([100.0, 250.0, 80.0, 999.0])

# Vectorized: one operation on the whole array
with_tax = prices * 1.18             # add 18% tax to EVERY price at once
print(with_tax)                      # [118.  295.   94.4 1178.82]

# The loop equivalent (slower, more code, more bug surface):
with_tax_loop = np.array([p * 1.18 for p in prices])
```

**Timing intuition:** on an array of a million numbers, `prices * 1.18` typically runs ~50–100x faster than a Python loop doing the same thing. The bigger the data, the bigger the win. In ML you operate on large arrays constantly, so vectorized code isn't just cleaner — it's what makes training feasible.

### Broadcasting

Broadcasting lets NumPy combine arrays of *different but compatible* shapes by virtually stretching the smaller one. The rule: dimensions are compatible when they're equal or one of them is 1.

```python
import numpy as np

# Standardize each column: subtract the column mean, divide by column std.
X = np.array([[2.0, 100.0],
              [4.0, 200.0],
              [6.0, 300.0]])         # shape (3, 2)

col_mean = X.mean(axis=0)            # shape (2,): mean of each column -> [4. 200.]
col_std  = X.std(axis=0)            # shape (2,): std of each column

# (3,2) - (2,) broadcasts the row of means across all 3 rows automatically:
X_scaled = (X - col_mean) / col_std
print(X_scaled.round(2))
# [[-1.22 -1.22]
#  [ 0.    0.  ]
#  [ 1.22  1.22]]
```

No loop wrote that subtraction across rows — broadcasting did. This exact pattern is how feature scaling works under the hood.

### The `axis` argument

`axis` says *which direction to collapse*. For a 2-D array: `axis=0` goes down the rows (giving one result per column), `axis=1` goes across the columns (one result per row).

```python
import numpy as np
M = np.array([[1, 2, 3],
              [4, 5, 6]])
print(M.sum())          # 21      everything
print(M.sum(axis=0))    # [5 7 9] sum down each column  (collapses rows)
print(M.sum(axis=1))    # [6 15]  sum across each row   (collapses columns)
```

A memory hook: `axis=0` is the axis of rows, so summing over `axis=0` *removes* the row dimension and leaves per-column totals.

### The dot product

The dot product multiplies pairs and sums them — it's how a linear model turns features into a prediction.

```python
import numpy as np
features = np.array([2.0, 3.0, 1.0])   # one sample's 3 features
weights  = np.array([0.5, -1.0, 2.0])  # the model's learned weights
prediction = features @ weights        # 2*0.5 + 3*-1.0 + 1*2.0
print(prediction)                      # 1.0
```

That `@` operator (matrix multiplication) is the literal computation inside `LinearRegression.predict`.

## Common mistakes

- **Not checking `.shape` before an operation.** Most cryptic errors are shape mismatches. Print shapes first.
- **Expecting broadcasting to always work.** Shapes must be equal or 1 along each aligned dimension; `(3,2)` and `(3,)` will *not* broadcast (try `(2,)` or reshape to `(3,1)`).
- **Confusing `axis=0` and `axis=1`.** Remember: the axis you name is the one that disappears from the result's shape.
- **Mixing dtypes.** An integer array silently truncates when you assign a float. Use `np.array([...], dtype=float)` when you need decimals.
- **Looping when you could vectorize.** If you write `for` over array elements, pause and ask whether a whole-array operation does it.

## Small exercise

Create `temps_c = np.array([0, 20, 37, 100], dtype=float)` (Celsius). In one vectorized line, convert to Fahrenheit using `F = C * 9/5 + 32`. Then build a 2-D array `grades` of shape `(3, 4)` (3 students, 4 test scores) and compute (a) each student's average with the right `axis`, and (b) each test's average with the other axis. Confirm the shapes of both results match your expectation.

## Before you continue
- [ ] I can create arrays and read their `.shape`.
- [ ] I can write a vectorized operation instead of a loop and explain why it's faster.
- [ ] I can predict whether two shapes will broadcast.
- [ ] I know what `axis=0` vs `axis=1` does and what a dot product computes.

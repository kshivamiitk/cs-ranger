# Lab — Explore a Dataset with Pandas

## Objective

You will take a small, slightly messy sales dataset, load it from inline text, inspect its structure, answer business questions with `groupby`, sort the results, and produce a simple bar chart. After this lab you'll have a repeatable "first look at any dataset" routine you can run on day one of any project.

## Dataset

We embed a tiny store-sales CSV directly in the code with `io.StringIO`, so the lab runs offline. Each row is one sale.

| Column | Meaning | Notes |
|---|---|---|
| `date` | sale date | text for now |
| `region` | store region | North / South / East / West |
| `category` | product type | Electronics / Grocery / Clothing |
| `units` | items sold | integer |
| `revenue` | dollars from the sale | float; one row is blank (missing) |

```python
import pandas as pd
import io

csv_text = """date,region,category,units,revenue
2026-01-03,North,Electronics,2,799.98
2026-01-03,South,Grocery,15,84.50
2026-01-04,North,Clothing,4,159.96
2026-01-04,East,Electronics,1,
2026-01-05,West,Grocery,22,121.00
2026-01-05,North,Grocery,9,53.10
2026-01-06,South,Electronics,3,1199.97
2026-01-06,East,Clothing,7,244.93
2026-01-07,West,Electronics,2,640.00
2026-01-07,North,Clothing,5,199.95"""

df = pd.read_csv(io.StringIO(csv_text), parse_dates=["date"])
```

## Steps

**Step 1 — Inspect shape and types.** Always know what you loaded before analyzing it.

```python
print("Shape:", df.shape)          # Shape: (10, 5)
print(df.dtypes)                   # date is datetime64, revenue is float64, etc.
print(df.head())                   # eyeball the first rows
```

**Step 2 — Find the missing value.** One revenue is blank, so Pandas read it as `NaN`.

```python
print(df.isna().sum())             # counts missing per column -> revenue: 1
```

**Step 3 — Handle the missing revenue.** For this lab, fill it with the median revenue (robust to the large outlier sale). Imputation is covered deeply in the next module; here we just unblock the analysis.

```python
median_rev = df["revenue"].median()
df["revenue"] = df["revenue"].fillna(median_rev)
print(f"Filled the missing revenue with the median: {median_rev:.2f}")
print(df.isna().sum().sum())       # 0  -> no missing values remain
```

**Step 4 — Aggregate: total revenue per region.** This is the core `groupby` question.

```python
revenue_by_region = df.groupby("region")["revenue"].sum()
print(revenue_by_region)
```

**Step 5 — Sort the result.** Rank regions from best to worst seller.

```python
ranked = revenue_by_region.sort_values(ascending=False)
print(ranked)
```

**Step 6 — A second aggregation: average units per category.** Shows `groupby` answers many questions, not just one.

```python
print(df.groupby("category")["units"].mean().round(1))
```

**Step 7 — Plot the ranked regions as a bar chart.**

```python
import matplotlib.pyplot as plt

ranked.plot(kind="bar", color="#a78bfa")
plt.title("Total Revenue by Region")
plt.ylabel("Revenue ($)")
plt.tight_layout()
plt.show()          # a window/inline chart with one bar per region
```

## Expected output

- **Shape** is `(10, 5)` and `dtypes` shows `date` as `datetime64`, `revenue` as `float64`, `units` as `int64`. If `revenue` showed up as `object` (text), the blank wasn't parsed as missing — investigate.
- **`isna().sum()`** reports exactly one missing value in `revenue` before Step 3, and zero after.
- **Total revenue by region** should rank with strong Electronics regions on top. Because of the one \$1,199.97 Electronics sale, South will be high; North accumulates from several sales. Read the bar chart left-to-right: the tallest bar is your top region.
- **Average units per category** should show Grocery highest (people buy many cheap items) and Electronics lowest (few expensive items) — a sensible real-world pattern that confirms your aggregation is correct.

The interpretation matters more than the numbers: you turned a raw table into ranked, plotted answers a manager could act on, in seven steps.

## Extension challenge

1. Add a derived column `revenue_per_unit = df["revenue"] / df["units"]` and find which **category** has the highest average price per unit.
2. Group by *two* columns at once: `df.groupby(["region", "category"])["revenue"].sum()`. Read the resulting hierarchical breakdown.
3. Instead of filling the missing revenue with the median, try `groupby("category")` and fill it with that *category's* median (a smarter, group-aware imputation). Does the regional ranking change?

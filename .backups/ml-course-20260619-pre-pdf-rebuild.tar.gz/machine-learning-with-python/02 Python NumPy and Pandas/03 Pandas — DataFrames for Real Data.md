# Pandas — DataFrames for Real Data

> Real datasets arrive as messy tables, not tidy arrays. Pandas is the spreadsheet-in-code that lets you load, slice, filter, and summarize them — it's where most of your data time will be spent.

## What you'll learn
- The two core objects: `Series` (one column) and `DataFrame` (a table).
- Loading data with `read_csv`, including inline data via `io.StringIO`.
- Selecting rows and columns with `loc` (labels) and `iloc` (positions).
- Filtering with conditions, and summarizing with `groupby`, `value_counts`, and `describe`.

## Intuition

If NumPy is a grid of numbers, Pandas is a grid of numbers *with labels* — named columns and an index for rows — plus the ability to hold mixed types (text, dates, numbers) in different columns. Think of a `DataFrame` as a programmable spreadsheet: every operation you'd do by hand in Excel (filter rows, sum a column, group and average) has a one-line Pandas equivalent that scales to millions of rows and is reproducible.

A `Series` is a single labeled column. A `DataFrame` is a collection of Series sharing one index. Almost everything you do is: pick some rows, pick some columns, transform or summarize them.

## Python in practice

### Loading data — including inline with `io.StringIO`

`read_csv` reads a CSV file. When teaching or testing, it's handy to keep a tiny CSV *inside* your code as a string and feed it through `io.StringIO`, which makes a string behave like a file. This is the trick we'll use throughout the course so examples run offline.

```python
import pandas as pd
import io

csv_text = """name,dept,salary,age
Ada,Engineering,95000,29
Bob,Sales,62000,41
Carol,Engineering,120000,35
Dan,Sales,58000,38
Eve,Marketing,73000,31"""

df = pd.read_csv(io.StringIO(csv_text))   # treat the string as if it were a file
print(df)
print("Shape:", df.shape)                 # Shape: (5, 4)  -> 5 rows, 4 columns
```

### Inspecting a DataFrame

```python
print(df.head(2))        # first 2 rows -- always sanity-check after loading
print(df.dtypes)         # the type of each column (int64, object for text, ...)
print(df.columns)        # the column names
```

### Selecting columns and rows

```python
# A single column is a Series:
print(df["salary"])

# Multiple columns: pass a LIST of names -> a smaller DataFrame
print(df[["name", "salary"]])

# loc selects by LABEL (row index label, column name):
print(df.loc[0, "name"])          # 'Ada'  -> row labeled 0, column 'name'
print(df.loc[0:2, ["name", "dept"]])  # rows labeled 0..2 (loc INCLUDES 2)

# iloc selects by integer POSITION (like NumPy slicing, stop EXCLUDED):
print(df.iloc[0, 0])              # 'Ada'  -> first row, first column
print(df.iloc[0:2, 0:2])          # first 2 rows, first 2 columns
```

The `loc` vs `iloc` distinction matters: `loc` uses labels and is *inclusive* of the end; `iloc` uses positions and is *exclusive* of the end, like normal Python slicing.

### Filtering with conditions

```python
# A condition produces a boolean Series; use it to keep matching rows.
engineers = df[df["dept"] == "Engineering"]
print(engineers)

# Combine conditions with & (and) / | (or) -- wrap each in parentheses!
well_paid_eng = df[(df["dept"] == "Engineering") & (df["salary"] > 100000)]
print(well_paid_eng)              # just Carol
```

### Summarizing: groupby, value_counts, describe

```python
# groupby: split into groups, then aggregate. "Average salary per department":
print(df.groupby("dept")["salary"].mean())
# dept
# Engineering    107500.0
# Marketing       73000.0
# Sales           60000.0

# value_counts: how many rows fall in each category
print(df["dept"].value_counts())
# Engineering    2
# Sales          2
# Marketing      1

# describe: instant numeric summary (count, mean, std, min, quartiles, max)
print(df["salary"].describe())
```

`df.groupby(col)[target].agg(...)` is the workhorse of exploratory analysis — "what's the average/total/count of X *per* category Y" answers a huge fraction of real questions.

## Common mistakes

- **Forgetting parentheses in compound filters.** `df[df.a > 1 & df.b < 2]` fails or misbehaves; write `df[(df.a > 1) & (df.b < 2)]`. Use `&`/`|`, not `and`/`or`.
- **Mixing up `loc` and `iloc`.** `loc` = labels and inclusive end; `iloc` = positions and exclusive end. Picking the wrong one silently returns the wrong rows.
- **Chained-assignment warnings.** `df[df.a > 1]["b"] = 0` may not stick. Assign with a single `loc`: `df.loc[df.a > 1, "b"] = 0`.
- **Assuming the row index equals position.** After filtering, indices have gaps (0, 2, 4...). `iloc[1]` is the *second* row; `loc[1]` is the row *labeled* 1. Use `.reset_index(drop=True)` if you want them aligned.
- **Reading a column as text by accident.** A stray non-numeric value makes the whole column `object` dtype. Check `df.dtypes` and convert with `astype` when needed.

## Small exercise

Using the `df` above: (1) print the average `age` per `dept` with `groupby`. (2) Filter to everyone older than 35 and show only their `name` and `age`. (3) Use `describe()` on the `age` column and read off the median (the 50% row). (Hint: combine `groupby("dept")["age"].mean()` for the first task.)

## Before you continue
- [ ] I can load inline CSV text with `io.StringIO` and `read_csv`.
- [ ] I can select columns, and rows with both `loc` and `iloc`, and explain the inclusive/exclusive difference.
- [ ] I can filter rows with a single and a compound condition.
- [ ] I can answer "average X per category Y" with `groupby`, and use `value_counts` and `describe`.

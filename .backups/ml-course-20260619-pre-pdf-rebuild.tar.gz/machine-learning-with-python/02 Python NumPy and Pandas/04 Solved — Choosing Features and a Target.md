# Solved — Choosing Features and a Target

> Before any model exists, someone has to point at a spreadsheet and say "these columns are the inputs, *this* one is what we're predicting" — get that wrong and every later step is wasted.

## Problem statement

You've been handed a small used-car listings table and asked to predict a car's `price`. The table also carries a `listing_id`, a `sold` flag (whether the car eventually sold), and a `price_band` label that someone derived *from* the price. Your job is not to model anything yet — it's the decision that comes first: **split the columns into a feature matrix `X` (the inputs the model is allowed to see) and a single target `y` (the thing we predict).**

Concretely you must decide: which column is `y`? Which columns are legitimate features? Which columns must be **dropped** because they are identifiers, leak the answer, or are redundant? And once you've built `X` and `y`, confirm their **shapes** line up (same number of rows, `y` one-dimensional) so scikit-learn will accept them. We'll do this once for a **regression** target (predict the number `price`) and once for a **classification** target (predict the category `sold`), because the same table can pose either question.

## Why this problem matters

Choosing `X` and `y` is the cheapest step in the whole workflow and the one most quietly fatal to get wrong. Two mistakes dominate real projects. The first is **leakage**: leaving a column in `X` that was computed from the target (here, `price_band` is literally a bucketed `price`) makes the model look brilliant in testing and useless in production, because at prediction time that column doesn't exist yet. The second is **feeding the model noise**: an `listing_id` is a unique number per row with zero predictive content, and handing it to a model invites it to memorize rows instead of learning patterns. Getting `X`/`y` right is also what makes every downstream tool work — `train_test_split`, pipelines, and `.fit(X, y)` all assume you've already drawn this line cleanly.

## Tiny dataset or sample data

A used-car listings table — **shape `(10, 7)`**, columns `listing_id, make, year, mileage_k, fuel, price, sold, price_band`. `price` is a number (regression target candidate); `sold` is 0/1 (classification target candidate); `price_band` was derived from `price`; `listing_id` is a unique key.

| listing_id | make   | year | mileage_k | fuel   | price | sold | price_band |
|-----------:|--------|-----:|----------:|--------|------:|-----:|------------|
| 1001       | Toyota | 2018 | 42.0      | petrol | 13500 | 1    | mid        |
| 1002       | Honda  | 2015 | 78.0      | petrol |  8900 | 0    | low        |
| 1003       | Ford   | 2020 | 21.0      | diesel | 18200 | 1    | high       |
| 1004       | Toyota | 2013 | 95.0      | petrol |  6400 | 0    | low        |
| 1005       | Kia    | 2019 | 33.0      | petrol | 14800 | 1    | mid        |
| 1006       | Honda  | 2021 | 12.0      | hybrid | 21000 | 1    | high       |

(The full inline set below has 10 rows.) The pattern baked in: **newer cars with lower mileage cost more**, diesel/hybrid run a bit pricier, and cheaper cars sell less reliably.

## Step-by-step reasoning

1. **Name the prediction goal in one sentence — that fixes `y`.** "Predict the *price* of a car" → `y = price`, a continuous number → **regression**. "Predict *whether* a car will sell" → `y = sold`, a 0/1 category → **classification**. The target is whatever the business actually wants a number/label for at decision time; everything else is a candidate feature.
2. **Drop identifiers.** `listing_id` is unique per row. It has no causal relationship to price; it's just a label. Including it lets a model overfit to specific rows and learn nothing transferable. **Drop it from `X`.**
3. **Drop leaky columns.** `price_band` (`low`/`mid`/`high`) was bucketed *from* `price`. For the regression task it's a near-perfect copy of the answer — at prediction time, before you know the price, you wouldn't have the band either. Leaving it in inflates scores and breaks in production. **Drop it.** (`sold` is *not* leaky for the price task — it's a legitimate signal observed independently of price.)
4. **Keep the genuine predictors.** `make`, `year`, `mileage_k`, `fuel` are all known at listing time and plausibly drive price. They stay in `X`. (`make` and `fuel` are categorical and would later need encoding, but that's a modeling step, not a feature-selection one.)
5. **Build `X` and `y` explicitly.** `X = df[[...]]` with a **list** of column names (double brackets → a DataFrame). `y = df['price']` with a **single** name (one bracket → a 1-D Series). Equivalently, `X = df.drop(columns=[...])` to *remove* non-features.
6. **Confirm shapes before modeling.** `X.shape` should be `(n_rows, n_features)`; `y.shape` should be `(n_rows,)` — same row count, and `y` exactly one-dimensional. This sanity check catches the two classic bugs: a stray column left in `X`, or accidentally selecting `y` with double brackets (which makes it 2-D and trips up some estimators).

## Python solution

```python
import io
import pandas as pd

# --- Inline data so this runs with no downloads or file reads ---
CSV = """listing_id,make,year,mileage_k,fuel,price,sold,price_band
1001,Toyota,2018,42.0,petrol,13500,1,mid
1002,Honda,2015,78.0,petrol,8900,0,low
1003,Ford,2020,21.0,diesel,18200,1,high
1004,Toyota,2013,95.0,petrol,6400,0,low
1005,Kia,2019,33.0,petrol,14800,1,mid
1006,Honda,2021,12.0,hybrid,21000,1,high
1007,Ford,2016,61.0,diesel,10200,0,mid
1008,Kia,2014,88.0,petrol,7100,0,low
1009,Toyota,2022,8.0,hybrid,23500,1,high
1010,Honda,2017,54.0,petrol,11800,1,mid
"""
df = pd.read_csv(io.StringIO(CSV))
print("Full table shape:", df.shape)          # (10, 8)
print("Columns:", list(df.columns))

# --- 1. Classify every column: target / feature / drop ---
# listing_id -> DROP (unique identifier, no signal)
# price_band -> DROP for the price task (it was derived FROM price = leakage)
# make, year, mileage_k, fuel -> FEATURES (known at listing time)
# price -> regression TARGET ;  sold -> classification TARGET

drop_cols = ["listing_id", "price_band"]   # id + leaky column

# ============================================================
# TASK A — REGRESSION: predict the NUMBER `price`
# ============================================================
target_reg = "price"
# Features = everything except the drops, the regression target,
# and the OTHER target (sold) which we are not predicting here.
feature_cols_reg = [c for c in df.columns
                    if c not in drop_cols + [target_reg, "sold"]]

X_reg = df[feature_cols_reg]      # double brackets -> DataFrame
y_reg = df[target_reg]            # single bracket  -> 1-D Series

print("\n[Regression] target =", target_reg, "(continuous number)")
print("  features:", feature_cols_reg)
print("  X_reg.shape:", X_reg.shape, " y_reg.shape:", y_reg.shape)
print("  y is 1-D? ", y_reg.ndim == 1)

# ============================================================
# TASK B — CLASSIFICATION: predict the CATEGORY `sold` (0/1)
# ============================================================
target_clf = "sold"
# Now `price` becomes a legitimate FEATURE; price_band is STILL dropped
# (a price-derived band would still leak heavily into a sold/price model).
feature_cols_clf = [c for c in df.columns
                    if c not in drop_cols + [target_clf]]

X_clf = df[feature_cols_clf]
y_clf = df[target_clf]

print("\n[Classification] target =", target_clf, "(category 0/1)")
print("  features:", feature_cols_clf)
print("  X_clf.shape:", X_clf.shape, " y_clf.shape:", y_clf.shape)
print("  class balance:\n", y_clf.value_counts().to_string())

# --- 3. Final guardrails: rows match, no target hiding inside X ---
assert X_reg.shape[0] == y_reg.shape[0], "X and y row counts must match"
assert "price" not in X_reg.columns,     "target leaked into X_reg!"
assert "price_band" not in X_reg.columns, "leaky column left in X_reg!"
print("\nAll feature/target shape checks passed.")
```

## Expected output

```
Full table shape: (10, 8)
Columns: ['listing_id', 'make', 'year', 'mileage_k', 'fuel', 'price', 'sold', 'price_band']

[Regression] target = price (continuous number)
  features: ['make', 'year', 'mileage_k', 'fuel']
  X_reg.shape: (10, 4)  y_reg.shape: (10,)
  y is 1-D?  True

[Classification] target = sold (category 0/1)
  features: ['make', 'year', 'mileage_k', 'fuel', 'price']
  X_clf.shape: (10, 5)  y_clf.shape: (10,)
  class balance:
 sold
1    6
0    4

All feature/target shape checks passed.
```

- The full table is **8 columns**, but the regression `X` keeps only **4** of them — the two drops (`listing_id`, `price_band`) plus the target `price` plus the unused other-target `sold` are all excluded.
- `y_reg.shape` prints `(10,)` with a trailing comma and no second number — that's the signature of a **1-D** array, which is exactly what scikit-learn wants for a target.
- In the classification setup, `price` *re-enters* as a feature (now it's an input, not the answer) so `X_clf` has **5** columns, and `sold` leaves `X` to become `y`.

## Explanation of the output

The two shapes tell the whole story. `X_reg.shape == (10, 4)` and `y_reg.shape == (10,)` confirm the cardinal rule: **same number of rows, target is one-dimensional.** A 2-D target (shape `(10, 1)`) is the classic accident from writing `df[['price']]` with double brackets, and it makes some estimators emit a `DataConversionWarning` or behave oddly — so the `y.ndim == 1` check earns its place.

The fact that the same DataFrame produced both a **regression** problem (`y_reg = price`, a number) and a **classification** problem (`y_clf = sold`, a category) is the deeper point: the *target type* — number vs. category — is what decides which family of models and metrics you'll use later, and that's a choice you make here, not one the data makes for you. Finally, notice `price_band` never appears in either `X`: it's the leaky column, and the `assert` statements would have raised an error if it had sneaked through. The passing asserts are your proof that `X` contains only things a model could legitimately know at prediction time.

## Common mistakes

1. **Leaving an ID column in `X`.** `listing_id` is unique per row, so a flexible model can memorize "row 1003 → 18200" and score perfectly in training while learning nothing. **Fix:** drop identifiers (and any free-text keys) before modeling.
2. **Keeping a target-derived column as a feature (leakage).** `price_band` is just bucketed `price`; predicting `price` with it gives a fake-perfect score that collapses in production where the band isn't known yet. **Fix:** drop any column computed *from* the target, and ask of every feature "would I actually have this *before* the prediction is made?"
3. **Selecting `y` with double brackets.** `y = df[['price']]` returns a 2-D DataFrame, not the 1-D Series estimators expect. **Fix:** use a single bracket — `y = df['price']` — and assert `y.ndim == 1`.
4. **Confusing regression and classification targets.** Treating `sold` (0/1 category) as a regression target, or `price` (a number) as classes, leads to the wrong models and metrics. **Fix:** ask "is the answer a number or a category?" — number → regression, category → classification.
5. **Putting the *other* possible target into `X`.** When predicting `price`, dragging `sold` in is fine (it's observed independently); but when predicting `sold`, forgetting to remove `sold` from `X` means the model trivially reads the answer. **Fix:** always exclude the current target from its own feature list.

## Extension challenge

1. Add a column `days_on_lot` that is `0` for every sold car and a positive number otherwise. Decide whether it's a legitimate feature for predicting `sold` (hint: is it known *before* the car sells?), and justify dropping or keeping it.
2. Write a tiny helper `make_xy(df, target, drop=())` that returns `X, y` for *any* target column, then call it for `price`, `sold`, and `make`. What changes about the problem type each time?
3. After building `X_reg`, identify which feature columns are categorical (`make`, `fuel`) versus numeric (`year`, `mileage_k`) and print the split — the same audit you'd hand to a `ColumnTransformer` in a later module.

## Matching animation

**Features vs Labels Mapper** — drag each column card from the dataset into one of three bins (Feature / Target / Drop) and watch the live `X` and `y` shape readout update as you sort. Toss `listing_id` into Drop and the "no signal" badge confirms it; try dropping `price` into Feature while `price` is also the target and the mapper flashes a leakage warning. Use it right after this lesson to *feel* why the `(rows, features)` and `(rows,)` shapes must agree before you ever call `.fit`.
